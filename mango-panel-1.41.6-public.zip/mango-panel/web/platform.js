/* 1.19.0: premium paketler (egg'li veya serbest), destek/satın alma talepleri, sunucu verme, node yönetimi.
   app.js'in yardımcılarını (api, app, esc, fv, toast, icon, state) kullanır; app.js'ten önce yüklenir. */

const platformActions = (window.platformActions = {}); // app.js yüklenince actions'a birleştirilir
const PL = {};        // tıklama eylemleri: data-pl="ad"
const PL_FORMS = {};  // form gönderimleri: data-pl-form="ad"
let plPendingInstall = ""; // node oluşturulduktan sonra bir kez gösterilecek kurulum komutu

document.addEventListener("click", (e) => {
  const el = e.target.closest("[data-pl]");
  if (!el) return;
  const fn = PL[el.dataset.pl];
  if (fn) {
    e.preventDefault();
    fn(el);
  }
});

document.addEventListener("submit", (e) => {
  const kind = e.target.dataset.plForm;
  const fn = kind && PL_FORMS[kind];
  if (!fn) return;
  e.preventDefault();
  fn(e.target);
});

function plDate(value) {
  return value ? new Date(value).toLocaleString("tr-TR") : "-";
}

function plStatus(status) {
  const labels = { open: "açık", answered: "yanıtlandı", closed: "kapalı" };
  const cls = status === "closed" ? "exited" : status === "answered" ? "running" : "starting";
  return `<span class="badge ${cls}"><span class="dot ${cls}"></span>${labels[status] || esc(status)}</span>`;
}

/* ---------- kullanıcı: paketler ---------- */
let planCategory = "";

async function renderPlans() {
  const plans = await api("/plans");
  window.planList = plans;
  const cats = [...new Set(plans.map((p) => p.category || "Genel"))];
  app().innerHTML = `
    <div class="section-head"><h3>Paketler</h3></div>
    <p class="muted">Bir paket seçip satın alma talebi açın. Yönetici talebinizi inceleyip paketi hesabınıza tanımlar.</p>
    ${cats.length > 1 ? `<div class="plan-cats">
      <button class="${planCategory === "" ? "primary" : ""}" data-pl="planCat" data-cat="">Tümü</button>
      ${cats.map((c) => `<button class="${planCategory === c ? "primary" : ""}" data-pl="planCat" data-cat="${esc(c)}">${esc(c)}</button>`).join("")}
    </div>` : ""}
    <div class="plan-grid" id="planGrid"></div>`;
  drawPlanGrid();
}

function drawPlanGrid() {
  const box = document.getElementById("planGrid");
  if (!box) return;
  const all = window.planList || [];
  if (!all.length) {
    box.innerHTML = `<section class="card"><div class="notice">Şu anda satışa sunulan paket yok.</div></section>`;
    return;
  }
  const list = all.filter((p) => !planCategory || (p.category || "Genel") === planCategory);
  box.innerHTML = list.length
    ? list.map((p) => planCardHtml(p, `<button class="primary" data-pl="buyPlan" data-id="${p.id}">Satın alma talebi aç</button>`)).join("")
    : `<section class="card"><div class="notice">Bu kategoride paket yok.</div></section>`;
}

function planMemText(mb) {
  const n = Number(mb) || 0;
  return n >= 1024 ? (n % 1024 === 0 ? n / 1024 : (n / 1024).toFixed(1)) + " GB" : n + " MB";
}

// Paket kartı (1.27.0): ürüne göre renkli şerit, kategori, her satır bir özellik.
// action: kartın altındaki düğme HTML'i. Ana sayfada da kullanılır.
function planCardHtml(p, action) {
  const price = p.is_free ? "Ücretsiz" : (p.price_text || "Fiyat için iletişime geçin");
  const features = (p.features || []).map((f) => `<li>${esc(f)}</li>`).join("");
  const specs = [
    `${esc(p.max_servers)} sunucu hakkı`,
    p.egg_name ? `${esc(p.egg_name)} sunucusu dahil` : "Serbest paket",
    p.egg_name ? `${esc(planMemText(p.memory_mb))} RAM` : "",
    p.egg_name ? `%${esc(p.cpu_percent)} işlemci` : "",
  ].filter(Boolean).map((x) => `<li>${x}</li>`).join("");
  return `
    <section class="card plan-card" style="--plan-accent:${esc(p.accent || "#f5a524")}">
      <div class="plan-top"><span class="plan-kind">${esc(p.kind || "")}</span><span class="plan-cat">${esc(p.category || "Genel")}</span></div>
      <h3>${esc(p.name)}</h3>
      <div class="plan-price">${esc(price)}</div>
      ${p.description && !features ? `<p class="muted small-text">${esc(p.description)}</p>` : ""}
      ${features ? `<ul class="plan-features">${features}</ul>` : ""}
      <ul class="plan-specs">${specs}</ul>
      ${action}
    </section>`;
}

PL.planCat = async (el) => {
  planCategory = el.dataset.cat || "";
  document.querySelectorAll("[data-pl='planCat']").forEach((b) => b.classList.toggle("primary", b.dataset.cat === planCategory));
  drawPlanGrid();
};

PL.buyPlan = (el) => {
  location.hash = `#/tickets/new?plan=${el.dataset.id}`;
};

/* ---------- kullanıcı: talepler ---------- */
async function renderTickets(arg = "") {
  if (arg.startsWith("new")) {
    const preset = new URLSearchParams(arg.split("?")[1] || "").get("plan");
    return renderTicketForm(preset);
  }
  if (arg) {
    app().innerHTML = `
      <div class="section-head"><h3>Destek talebi</h3><a href="#/tickets">Tüm talepler</a></div>
      <div id="plTicketBox"><p class="muted">Yükleniyor...</p></div>`;
    return showTicket(Number(arg), document.getElementById("plTicketBox"));
  }
  const tickets = await api("/tickets");
  app().innerHTML = `
    <div class="section-head">
      <h3>Destek talepleri</h3>
      <button class="primary" data-pl="newTicket">${icon("plus", 14)} Yeni talep</button>
    </div>
    <section class="card">${ticketTable(tickets)}</section>`;
}

PL.newTicket = () => {
  location.hash = "#/tickets/new";
};

async function renderTicketForm(preset) {
  const plans = await api("/plans");
  const planId = preset ? Number(preset) : null;
  app().innerHTML = `
    <div class="section-head"><h3>Yeni talep</h3><a href="#/tickets">Taleplerim</a></div>
    <section class="card">
      <form data-pl-form="newTicket" class="form-stack">
        <div><label>Talep türü</label>
          <select name="category">
            <option value="purchase" ${planId ? "selected" : ""}>Paket satın alma</option>
            <option value="support" ${planId ? "" : "selected"}>Destek</option>
          </select></div>
        <div><label>Paket (satın alma için)</label>
          <select name="plan_id"><option value="">Seçin</option>
            ${plans.map((p) => `<option value="${p.id}" ${p.id === planId ? "selected" : ""}>${esc(p.name)}${p.price_text ? " · " + esc(p.price_text) : ""}</option>`).join("")}
          </select></div>
        <div><label>Kupon kodu (varsa)</label><input name="coupon_code" maxlength="32" placeholder="ÖRN. YAZ20"></div>
        <div><label>Konu</label><input name="subject" minlength="3" maxlength="120" required></div>
        <div><label>Mesaj</label><textarea name="message" rows="5" minlength="3" maxlength="2000" required></textarea></div>
        <div class="row"><button class="primary" type="submit">Talebi gönder</button></div>
      </form>
    </section>`;
}

PL_FORMS.newTicket = async (form) => {
  const body = {
    category: form.elements.category.value,
    subject: form.elements.subject.value.trim(),
    message: form.elements.message.value.trim(),
  };
  const plan = form.elements.plan_id.value;
  if (plan) body.plan_id = Number(plan);
  const coupon = (form.elements.coupon_code?.value || "").trim();
  if (coupon) body.coupon_code = coupon;
  if (body.category === "purchase" && !body.plan_id) {
    toast("Satın alma talebi için bir paket seçin", true);
    return;
  }
  try {
    const t = await api("/tickets", { method: "POST", body });
    toast("Talebiniz alındı");
    location.hash = `#/tickets/${t.id}`;
  } catch (e) { toast(e.message, true); }
};

function ticketTable(tickets) {
  if (!tickets.length) return `<div class="notice">Henüz talep yok.</div>`;
  return `
    <div class="table-wrap"><table>
      <thead><tr><th>Konu</th><th>Tür</th><th>Kullanıcı</th><th>Durum</th><th>Güncellendi</th></tr></thead>
      <tbody>
        ${tickets.map((t) => `
          <tr class="clickable" data-pl="openTicket" data-id="${t.id}">
            <td>${esc(t.subject)}</td>
            <td>${t.category === "purchase" ? "Satın alma" : "Destek"}${t.plan_name ? " · " + esc(t.plan_name) : ""}</td>
            <td>${esc(t.username)}</td>
            <td>${plStatus(t.status)}</td>
            <td>${plDate(t.updated_at)}</td>
          </tr>`).join("")}
      </tbody>
    </table></div>`;
}

PL.openTicket = (el) => {
  const box = document.getElementById("plTicketBox");
  if (box) showTicket(Number(el.dataset.id), box);   // yönetim paneli içinde aç
  else location.hash = `#/tickets/${el.dataset.id}`; // kullanıcı sayfası
};

async function showTicket(id, box) {
  const t = await api(`/tickets/${id}`);
  const isAdmin = !!(state.user && state.user.is_admin);
  const closed = t.status === "closed";
  const grantable = isAdmin && t.category === "purchase" && t.plan_id && !closed;
  const nodes = grantable ? await api("/admin/nodes") : [];
  box.dataset.ticketId = String(id);
  box.innerHTML = `
    <section class="card">
      <div class="row" style="justify-content:space-between;align-items:flex-start">
        <div>
          <h3>${esc(t.subject)}</h3>
          <div class="muted small-text">${t.category === "purchase" ? "Satın alma talebi" : "Destek"} · ${esc(t.username)} · ${plDate(t.created_at)} · ${plStatus(t.status)}</div>
          ${t.plan_name ? `<div class="small-text">Paket: <b>${esc(t.plan_name)}</b></div>` : ""}
        </div>
        ${t.plan_name ? `<button data-act="receipt" data-id="${t.id}" data-plan="${esc(t.plan_name)}" data-price="${esc(t.plan_price || "")}" data-user="${esc(t.username)}" data-date="${esc(plDate(t.created_at))}" data-coupon="${esc(t.coupon_code || "")}">Makbuz</button>` : ""}
        ${closed ? "" : `<button data-pl="closeTicket" data-id="${t.id}">Talebi kapat</button>`}
      </div>
      ${grantable ? grantFormHtml(t, nodes) : ""}
      <div class="ticket-thread" style="margin-top:14px">
        ${t.messages.map((m) => `
          <div class="msg ${m.is_admin ? "from-admin" : ""}">
            <div class="muted small-text">${esc(m.author)}${m.is_admin ? " (yönetim)" : ""} · ${plDate(m.created_at)}</div>
            <div>${esc(m.text).replace(/\n/g, "<br>")}</div>
          </div>`).join("")}
      </div>
      ${closed
        ? `<p class="muted small-text" style="margin-top:12px">Bu talep kapatıldı.</p>`
        : `<form data-pl-form="reply" data-id="${t.id}" class="form-stack" style="margin-top:14px">
             <textarea name="text" rows="3" maxlength="2000" placeholder="Yanıtınızı yazın" required></textarea>
             <div class="row" style="margin-top:8px"><button class="primary" type="submit">Gönder</button></div>
           </form>`}
    </section>`;
}

function grantFormHtml(t, nodes) {
  const withServer = !!t.plan_egg;
  return `
    <form data-pl-form="grant" data-id="${t.id}" class="form-stack grant-box" style="margin-top:14px">
      <div class="small-text muted">${withServer
        ? `Bu paket bir sunucu içerir (egg: <b>${esc(t.plan_egg)}</b>). Onaylayınca kullanıcıya bu egg'den bir sunucu verilir.`
        : "Serbest paket: onaylayınca yalnızca sunucu hakkı tanımlanır."}</div>
      ${withServer ? `
        <div class="grid2">
          <div><label>Node</label>
            <select name="node_id"><option value="">Panel (yerel)</option>
              ${nodes.map((n) => `<option value="${n.id}">${esc(n.name)}${n.online ? "" : " (çevrimdışı)"}</option>`).join("")}
            </select></div>
          <div><label>Sunucu adı (boş bırakılırsa otomatik)</label>
            <input name="server_name" minlength="2" maxlength="48" pattern="[A-Za-z0-9 _-]+" placeholder="Paket adı + kullanıcı"></div>
          <div><label>Sunucu süresi</label>
            <select name="duration">${durationOptionsHtml("unlimited")}</select>
            <input name="duration_days" type="number" min="1" max="3650" value="30" class="narrow" style="margin-top:6px" placeholder="Özel gün sayısı"></div>
        </div>` : ""}
      <div class="row"><button class="primary" type="submit">${withServer ? "Onayla ve sunucuyu ver" : "Onayla ve hak tanımla"}</button>${withServer ? ` <button type="button" data-act="grantDemo">3 Günlük Demo ver</button>` : ""}</div>
    </form>`;
}

function refreshTicket(id) {
  const box = document.getElementById("plTicketBox");
  if (box) return showTicket(id, box);
  return renderTickets(String(id));
}

PL_FORMS.reply = async (form) => {
  const text = form.elements.text.value.trim();
  if (!text) return;
  try {
    await api(`/tickets/${form.dataset.id}/messages`, { method: "POST", body: { text } });
    refreshTicket(Number(form.dataset.id));
  } catch (e) { toast(e.message, true); }
};

async function grantSubmit(form, demo) {
  const body = { demo: !!demo };
  if (form.elements.node_id && form.elements.node_id.value) body.node_id = Number(form.elements.node_id.value);
  if (form.elements.server_name && form.elements.server_name.value.trim()) {
    body.server_name = form.elements.server_name.value.trim();
  }
  if (form.elements.duration) {
    body.duration = form.elements.duration.value || "unlimited";
    if (body.duration === "custom") body.duration_days = Number(form.elements.duration_days.value);
  }
  const msg = demo
    ? "3 günlük demo sunucusu verilsin mi? Süre dolunca sunucu otomatik durdurulur."
    : "Paket bu kullanıcıya tanımlansın mı? Sunucu hakkı artar; egg'li paketlerde sunucu da oluşturulur.";
  if (!confirm(msg)) return;
  toast("İşleniyor, sunucu kurulumu birkaç dakika sürebilir...");
  try {
    await api(`/admin/tickets/${form.dataset.id}/grant`, { method: "POST", body });
    toast(demo ? "3 günlük demo verildi" : "Paket hesaba tanımlandı");
    refreshTicket(Number(form.dataset.id));
  } catch (e) { toast(e.message, true); }
}

PL_FORMS.grant = async (form) => grantSubmit(form, false);
platformActions.grantDemo = async (el) => { const form = el.closest("form"); if (form) await grantSubmit(form, true); };


PL.closeTicket = async (el) => {
  if (!confirm("Talep kapatılsın mı? Kapatılan talebe yanıt yazılamaz.")) return;
  try {
    await api(`/tickets/${el.dataset.id}/close`, { method: "POST" });
    refreshTicket(Number(el.dataset.id));
  } catch (e) { toast(e.message, true); }
};

/* ---------- yönetim: premium paketler ---------- */
async function adminPlans(body) {
  const [plans, eggs] = await Promise.all([api("/admin/plans"), api("/eggs")]);
  const choices = eggs.filter((e) => e.allowed);
  const cats = [...new Set(plans.map((p) => p.category || "Genel"))];
  body.innerHTML = `
    <div class="section-head"><h3>Premium paketler</h3></div>
    <p class="muted small-text">Paket bir egg'e bağlanabilir (ör. "Node.js sunucu paketi") ya da serbest bırakılabilir. Egg'li paket onaylanınca kullanıcıya o egg'den sunucu verilir. Satın alma talepleri destek talepleri üzerinden gelir.</p>
    <section class="card"><h4>Yeni paket</h4>${planForm(null, choices, cats)}</section>
    ${plans.map((p) => `
      <section class="card">
        <h4>${esc(p.name)} ${p.active ? "" : `<span class="muted small-text">(satışta değil)</span>`}</h4>
        ${planForm(p, choices, cats)}
      </section>`).join("")}`;
}

function planForm(p, eggs, cats = []) {
  const v = (key, fallback) => (p ? p[key] : fallback);
  const eggOptions = [`<option value="">Serbest paket (sunucu yok)</option>`]
    .concat(eggs.map((e) => `<option value="${esc(e.slug)}" ${p && p.egg === e.slug ? "selected" : ""}>${esc(e.name || e.slug)}</option>`))
    .join("");
  const catList = [...new Set(["Genel", ...cats])].map((c) => `<option value="${esc(c)}"></option>`).join("");
  return `
    <form data-pl-form="plan" data-id="${p ? p.id : ""}" class="form-stack">
      <div class="grid2">
        <div><label>Ad</label><input name="name" value="${esc(v("name", ""))}" maxlength="48" required></div>
        <div><label>Ürün (egg)</label><select name="egg">${eggOptions}</select></div>
        <div><label>Kategori</label><input name="category" list="planCatList" value="${esc(v("category", "Genel"))}" maxlength="32"><datalist id="planCatList">${catList}</datalist></div>
        <div><label>Vurgu rengi (boşsa ürüne göre otomatik)</label><input name="accent" value="${esc(v("accent", ""))}" maxlength="7" placeholder="#3fb950"></div>
        <div><label>Fiyat metni</label><input name="price_text" value="${esc(v("price_text", ""))}" maxlength="60" placeholder="ör. 120 TL / ay"></div>
        <div><label>Sunucu hakkı (limit)</label><input name="max_servers" type="number" min="0" max="100" value="${v("max_servers", 2)}"></div>
        <div><label>Sunucu RAM (MB)</label><input name="memory_mb" type="number" min="128" max="16384" value="${v("memory_mb", 1024)}"></div>
        <div><label>Sunucu CPU (%)</label><input name="cpu_percent" type="number" min="10" max="800" value="${v("cpu_percent", 100)}"></div>
        <div><label>Disk (MB, bilgi amaçlı)</label><input name="disk_mb" type="number" min="256" max="102400" value="${v("disk_mb", 2048)}"></div>
        <div><label>Sıra</label><input name="sort_order" type="number" min="-1000" max="1000" value="${v("sort_order", 0)}"></div>
        <div style="align-self:end"><label class="check"><input type="checkbox" name="active" ${v("active", true) ? "checked" : ""}> Satışta</label></div>
        <div style="align-self:end"><label class="check"><input type="checkbox" name="is_free" ${v("is_free", false) ? "checked" : ""}> Ücretsiz paket</label></div>
      </div>
      <div><label>Özellikler (her satıra bir özellik yazın)</label><textarea name="description" rows="5" maxlength="1000">${esc(v("description", ""))}</textarea></div>
      <div class="row" style="margin-top:10px">
        <button class="primary" type="submit">${p ? "Kaydet" : "Paket ekle"}</button>
        ${p ? `<button type="button" class="danger" data-pl="deletePlan" data-id="${p.id}">Sil</button>` : ""}
      </div>
    </form>`;
}

function planBody(form) {
  const f = (name) => form.elements[name].value;
  return {
    name: f("name").trim(),
    egg: f("egg") || "",
    category: f("category").trim() || "Genel",
    accent: f("accent").trim(),
    is_free: form.elements.is_free.checked,
    price_text: f("price_text").trim(),
    description: f("description").trim(),
    max_servers: Number(f("max_servers")),
    memory_mb: Number(f("memory_mb")),
    cpu_percent: Number(f("cpu_percent")),
    disk_mb: Number(f("disk_mb")),
    sort_order: Number(f("sort_order")),
    active: form.elements.active.checked,
  };
}

PL_FORMS.plan = async (form) => {
  const id = form.dataset.id;
  try {
    if (id) await api(`/admin/plans/${id}`, { method: "PATCH", body: planBody(form) });
    else await api("/admin/plans", { method: "POST", body: planBody(form) });
    toast("Paket kaydedildi");
    adminPlans(document.getElementById("adminBody"));
  } catch (e) { toast(e.message, true); }
};

PL.deletePlan = async (el) => {
  if (!confirm("Paket silinsin mi? Bu pakete bağlı talepler paketsiz kalır.")) return;
  try {
    await api(`/admin/plans/${el.dataset.id}`, { method: "DELETE" });
    toast("Paket silindi");
    adminPlans(document.getElementById("adminBody"));
  } catch (e) { toast(e.message, true); }
};

/* ---------- yönetim: sunucu verme ---------- */
async function adminGive(body) {
  const [users, eggs, nodes] = await Promise.all([api("/users"), api("/eggs"), api("/admin/nodes")]);
  body.innerHTML = `
    <div class="section-head"><h3>Sunucu ver</h3></div>
    <section class="card">
      <p class="muted small-text">Seçtiğiniz kullanıcı adına doğrudan sunucu oluşturur. Node seçimi sunucuyu o node'a bağlı olarak kaydeder.
      Not: sunucular şu an panel makinesinde çalışır; node bağlantısı kayıt ve yönetim amaçlıdır.</p>
      <form data-pl-form="give" class="form-stack">
        <div class="grid2">
          <div><label>Kullanıcı</label>
            <select name="owner_id">${users.map((u) => `<option value="${u.id}">${esc(u.username)}${u.is_admin ? " (yönetici)" : ""}</option>`).join("")}</select></div>
          <div><label>Egg (ürün)</label>
            <select name="egg">${eggs.filter((e) => e.allowed).map((e) => `<option value="${esc(e.slug)}">${esc(e.name || e.slug)}</option>`).join("")}</select></div>
          <div><label>Sunucu adı</label><input name="name" minlength="2" maxlength="48" pattern="[A-Za-z0-9 _-]+" required></div>
          <div><label>Node</label>
            <select name="node_id"><option value="">Panel (yerel)</option>
              ${nodes.map((n) => `<option value="${n.id}">${esc(n.name)}${n.online ? "" : " (çevrimdışı)"}</option>`).join("")}
            </select></div>
          <div><label>RAM (MB)</label><input name="memory_mb" type="number" min="128" max="16384" value="512"></div>
          <div><label>CPU (%)</label><input name="cpu_percent" type="number" min="10" max="800" value="100"></div>
        </div>
        <div class="row" style="margin-top:10px"><button class="primary" type="submit">Sunucuyu ver</button></div>
      </form>
    </section>`;
}

PL_FORMS.give = async (form) => {
  const f = form.elements;
  const body = {
    owner_id: Number(f.owner_id.value),
    egg: f.egg.value,
    name: f.name.value.trim(),
    memory_mb: Number(f.memory_mb.value),
    cpu_percent: Number(f.cpu_percent.value),
    variables: {},
  };
  if (f.node_id.value) body.node_id = Number(f.node_id.value);
  toast("Sunucu oluşturuluyor, kurulum birkaç dakika sürebilir...");
  try {
    await api("/servers", { method: "POST", body });
    toast("Sunucu verildi");
    form.reset();
  } catch (e) { toast(e.message, true); }
};

/* ---------- yönetim: destek talepleri ---------- */
async function adminTickets(body) {
  const tickets = await api("/tickets");
  body.innerHTML = `
    <div class="section-head"><h3>Destek ve satın alma talepleri</h3></div>
    <section class="card">${ticketTable(tickets)}</section>
    <div id="plTicketBox" style="margin-top:16px"></div>`;
}

/* ---------- yönetim: node'lar ---------- */
async function adminNodes(body) {
  const nodes = await api("/admin/nodes");
  const pending = plPendingInstall;
  plPendingInstall = "";
  body.innerHTML = `
    <div class="section-head"><h3>Node'lar</h3></div>
    <section class="card">
      <h4>Yeni node</h4>
      <p class="muted small-text">Node oluşturunca tek bir kurulum komutu gösterilir. Komutu node olacak VPS'te root olarak çalıştırın; ajan, panele bağlanan bir servis olarak kurulur. Komut yalnızca bir kez gösterilir; kaybederseniz node'un anahtarını yenileyip yeni komut alın.</p>
      <form data-pl-form="newNode" class="form-stack">
        <div class="grid2">
          <div><label>Ad</label><input name="name" minlength="2" maxlength="48" required></div>
          <div><label>Açıklama</label><input name="description" maxlength="255"></div>
          <div><label>Maks. RAM (MB)</label><input name="max_memory_mb" type="number" min="512" value="8192"></div>
          <div><label>Maks. disk (MB)</label><input name="max_disk_mb" type="number" min="1024" value="102400"></div>
        </div>
        <div class="row" style="margin-top:10px"><button class="primary" type="submit">Node oluştur</button></div>
      </form>
      ${pending ? installBox(pending) : ""}
    </section>
    <section class="card">
      <h4>Kayıtlı node'lar</h4>
      ${nodes.length ? nodes.map(nodeCard).join("") : `<div class="notice">Henüz node yok.</div>`}
    </section>`;
}

function installBox(command) {
  return `
    <div class="notice" style="margin-top:12px">Bu komutu node olacak VPS'te root olarak çalıştırın:</div>
    <div class="api-url" style="margin-top:8px"><code>${esc(command)}</code>
      <button class="small" data-act="copyText" data-text="${esc(command)}">Kopyala</button></div>`;
}

function nodeCard(n) {
  const s = n.stats || {};
  const mem = s.memory_total_mb ? `${s.memory_used_mb ?? "-"} / ${s.memory_total_mb} MB` : "-";
  const disk = s.disk_total_mb ? `${s.disk_used_mb ?? "-"} / ${s.disk_total_mb} MB` : "-";
  return `
    <div class="node-row">
      <div class="node-head">
        <b>${esc(n.name)}</b>
        <span class="badge ${n.online ? "running" : "exited"}"><span class="dot ${n.online ? "running" : "exited"}"></span>${n.online ? "çevrimiçi" : "çevrimdışı"}</span>
      </div>
      <div class="muted small-text">${esc(n.description)} · son bildirim: ${plDate(n.last_seen)} · ajan ${esc(n.version || "-")}</div>
      <div class="small-text">RAM: ${mem} · Disk: ${disk} · Yük: ${s.load ?? "-"} · Limit: ${n.max_memory_mb} MB RAM, ${n.max_disk_mb} MB disk</div>
      <form data-pl-form="editNode" data-id="${n.id}" class="form-stack" style="margin-top:10px">
        <div class="grid2">
          <div><label>Ad</label><input name="name" value="${esc(n.name)}" minlength="2" maxlength="48" required></div>
          <div><label>Açıklama</label><input name="description" value="${esc(n.description)}" maxlength="255"></div>
          <div><label>Maks. RAM (MB)</label><input name="max_memory_mb" type="number" min="512" value="${n.max_memory_mb}"></div>
          <div><label>Maks. disk (MB)</label><input name="max_disk_mb" type="number" min="1024" value="${n.max_disk_mb}"></div>
        </div>
        <div class="row" style="margin-top:10px">
          <button class="primary" type="submit">Kaydet</button>
          <button type="button" data-pl="rotateNode" data-id="${n.id}">Anahtarı yenile ve yeni komut al</button>
          <button type="button" class="danger" data-pl="deleteNode" data-id="${n.id}">Sil</button>
        </div>
      </form>
    </div>`;
}

PL_FORMS.newNode = async (form) => {
  try {
    const res = await api("/admin/nodes", {
      method: "POST",
      body: {
        name: form.elements.name.value.trim(),
        description: form.elements.description.value.trim(),
        max_memory_mb: Number(form.elements.max_memory_mb.value),
        max_disk_mb: Number(form.elements.max_disk_mb.value),
      },
    });
    plPendingInstall = res.install_command;
    toast("Node oluşturuldu. Kurulum komutunu kopyalayın.");
    adminNodes(document.getElementById("adminBody"));
  } catch (e) { toast(e.message, true); }
};

PL_FORMS.editNode = async (form) => {
  try {
    await api(`/admin/nodes/${form.dataset.id}`, {
      method: "PATCH",
      body: {
        name: form.elements.name.value.trim(),
        description: form.elements.description.value.trim(),
        max_memory_mb: Number(form.elements.max_memory_mb.value),
        max_disk_mb: Number(form.elements.max_disk_mb.value),
      },
    });
    toast("Node kaydedildi");
    adminNodes(document.getElementById("adminBody"));
  } catch (e) { toast(e.message, true); }
};

PL.rotateNode = async (el) => {
  if (!confirm("Anahtar yenilensin mi? Eski kurulum komutu ve node'un mevcut bağlantısı geçersiz olur; node'a yeni komutu yeniden çalıştırmanız gerekir.")) return;
  try {
    const res = await api(`/admin/nodes/${el.dataset.id}`, { method: "PATCH", body: { rotate_token: true } });
    plPendingInstall = res.install_command;
    toast("Yeni kurulum komutu hazır");
    adminNodes(document.getElementById("adminBody"));
  } catch (e) { toast(e.message, true); }
};

PL.deleteNode = async (el) => {
  if (!confirm("Node silinsin mi? Ajan panele bağlanamaz hale gelir; VPS'teki servisi ayrıca durdurmanız gerekir.")) return;
  try {
    await api(`/admin/nodes/${el.dataset.id}`, { method: "DELETE" });
    toast("Node silindi");
    adminNodes(document.getElementById("adminBody"));
  } catch (e) { toast(e.message, true); }
};

/* ---------- 1.20.0: özel domain bağlama (sunucu ayarları ve admin) ---------- */
async function loadDomains() {
  const box = document.getElementById("plDomains");
  if (!box || !state.sid) return;
  box.innerHTML = `<section class="card"><p class="muted small-text">Domain bilgileri yükleniyor...</p></section>`;
  try {
    const data = await api(`/servers/${state.sid}/domains`);
    box.innerHTML = domainCardHtml(data);
  } catch (e) {
    box.innerHTML = `<section class="card"><div class="notice">${esc(e.message)}</div></section>`;
  }
}

function domainCardHtml(data) {
  const head = `
    <section class="card">
      <h3>Özel domain</h3>
      <p class="muted small-text">Kendi alan adınızı sitenize bağlayın. Aşağıdaki DNS kayıtlarını alan adı sağlayıcınızda ekleyin, sonra "Doğrula" deyin.</p>`;
  if (!data.site_capable) {
    return `${head}<div class="notice">Özel domain yalnızca statik ve PHP sitelerinde kullanılabilir.</div></section>`;
  }
  if (!data.site_slug) {
    return `${head}<div class="notice">Önce yukarıdaki site adı alanına bir ad verip kaydedin; ardından domain bağlayabilirsiniz.</div></section>`;
  }
  return `${head}
      <form data-pl-form="addDomain" class="row" style="margin-bottom:12px">
        <input name="domain" placeholder="siteniz.com veya www.siteniz.com" maxlength="253" required style="flex:1">
        <button class="primary" type="submit">Domain ekle</button>
      </form>
      ${data.domains.length ? data.domains.map(domainItemHtml).join("") : `<p class="muted small-text">Henüz domain bağlanmadı.</p>`}
    </section>`;
}

function domainItemHtml(d) {
  return `
    <div class="domain-item">
      <div class="row between">
        <div><b>${esc(d.domain)}</b>
          ${d.verified
            ? ` <span class="badge running"><span class="dot running"></span>doğrulandı</span>`
            : ` <span class="badge starting"><span class="dot starting"></span>doğrulama bekliyor</span>`}
        </div>
        <div class="row">
          ${d.verified ? "" : `<button class="small" data-pl="verifyDomain" data-id="${d.id}">Doğrula</button>`}
          <button class="small danger" data-pl="deleteDomain" data-id="${d.id}">Sil</button>
        </div>
      </div>
      <div class="table-wrap" style="margin-top:8px"><table>
        <thead><tr><th>Tür</th><th>Ad</th><th>Değer</th><th>Amaç</th></tr></thead>
        <tbody>
          ${d.records.map((r) => `<tr><td>${esc(r.type)}</td><td><code>${esc(r.name)}</code></td><td><code>${esc(r.value)}</code></td><td class="muted small-text">${esc(r.purpose)}</td></tr>`).join("")}
        </tbody>
      </table></div>
    </div>`;
}

PL_FORMS.addDomain = async (form) => {
  try {
    await api(`/servers/${state.sid}/domains`, { method: "POST", body: { domain: form.elements.domain.value.trim() } });
    toast("Domain eklendi. DNS kayıtlarını ekleyip Doğrula'ya basın.");
    loadDomains();
  } catch (e) { toast(e.message, true); }
};

PL.verifyDomain = async (el) => {
  try {
    const res = await api(`/servers/${state.sid}/domains/${el.dataset.id}/verify`, { method: "POST" });
    toast(res.message, !res.verified);
    loadDomains();
  } catch (e) { toast(e.message, true); }
};

PL.deleteDomain = async (el) => {
  if (!confirm("Domain bağlantısı kaldırılsın mı?")) return;
  try {
    await api(`/servers/${state.sid}/domains/${el.dataset.id}`, { method: "DELETE" });
    toast("Domain kaldırıldı");
    loadDomains();
  } catch (e) { toast(e.message, true); }
};

async function adminDomains(body) {
  const s = await api("/admin/settings");
  body.innerHTML = `
    <div class="section-head"><h3>Domain ayarları</h3></div>
    <section class="card">
      <p class="muted small-text"><b>Cloudflare for SaaS (önerilen):</b> Aşağıdaki Cloudflare alanlarını doldurun. Domainler Cloudflare'e otomatik kaydedilir, sertifikalar Cloudflare tarafından alınır. Kullanıcılar yalnızca CNAME ekler.
      API token'da <i>Zone · SSL and Certificates · Edit</i> yetkisi olmalıdır. Token'ı kaydettikten sonra tekrar gösterilmez.</p>
      <form data-pl-form="domainSettings" class="form-stack">
        <div class="grid2">
          <div><label>Cloudflare API token</label><input name="cf_api_token" type="password" maxlength="200" autocomplete="off" placeholder="${s.cf_token_set ? "kayıtlı (değiştirmek için yeni token girin)" : "token"}"></div>
          <div><label>Cloudflare zone ID</label><input name="cf_zone_id" value="${esc(s.cf_zone_id || "")}" maxlength="40" placeholder="zone kimliği"></div>
        </div>
        <div><label>Fallback origin adı</label><input name="saas_fallback_host" value="${esc(s.saas_fallback_host || "")}" maxlength="253" placeholder="ör. panel.example.com"></div>
        <p class="muted small-text">Bu ad, zone'da tünele bağlı (turuncu bulutlu) bir CNAME olmalıdır. Kullanıcıların CNAME hedefi bu adresi gösterir.</p>
        <details style="margin-top:14px"><summary class="muted small-text">Cloudflare kullanmıyorsanız (yedek mod)</summary>
          <p class="muted small-text">Kullanıcılar TXT kaydıyla doğrulanır. Alt alanlar için CNAME hedefi, kök domainler için IP kullanılır. Sunucuda dnspython kurulu olmalıdır.</p>
          <div class="grid2">
            <div><label>CNAME hedefi</label><input name="domain_cname_target" value="${esc(s.domain_cname_target || "")}" maxlength="253" placeholder="boş = panel adresi"></div>
            <div><label>Kök domain A kaydı IP'si</label><input name="domain_ip" value="${esc(s.domain_ip || "")}" maxlength="45" placeholder="ör. 34.159.222.75"></div>
          </div>
        </details>
        <div class="row" style="margin-top:10px"><button class="primary" type="submit">Kaydet</button></div>
      </form>
    </section>`;
}

PL_FORMS.domainSettings = async (form) => {
  const v = (name) => form.elements[name].value.trim();
  const body = {
    cf_zone_id: v("cf_zone_id"),
    saas_fallback_host: v("saas_fallback_host"),
    domain_cname_target: v("domain_cname_target"),
    domain_ip: v("domain_ip"),
  };
  // Token alanı boşsa mevcut token korunur; yeni değer girilirse değişir.
  if (v("cf_api_token")) body.cf_api_token = v("cf_api_token");
  try {
    await api("/admin/settings", { method: "PUT", body });
    form.elements.cf_api_token.value = "";
    toast("Domain ayarları kaydedildi");
  } catch (e) { toast(e.message, true); }
};

// ---------- Discord bot (1.22.0) ----------

async function adminDiscord(body) {
  const s = await api("/admin/discord");
  body.innerHTML = `
    <div class="section-head"><h3>Discord bot</h3></div>
    <section class="card">
      <h4>Önce Discord tarafında (bir kez)</h4>
      <ol class="small-text">
        <li>discord.com/developers/applications adresinde yeni bir uygulama oluşturun. <b>Bot</b> sekmesinden token'ı kopyalayın.</li>
        <li><b>OAuth2 → URL Generator</b> bölümünde kapsam olarak <i>bot</i> ve <i>applications.commands</i>, izin olarak <i>Administrator</i> seçip çıkan bağlantıyla botu sunucunuza ekleyin.</li>
        <li>Discord'da sunucu adına sağ tıklayıp <i>Sunucu kimliğini kopyala</i> ile kimliği alın (geliştirici modu açık olmalı).</li>
      </ol>
      <p class="muted small-text">Bu adımlardan sonrasını panel yapar: kanallar, bot sunucusu, bot kodu ve ortam değişkenleri otomatik kurulur.</p>
      <form data-pl-form="discordSettings" class="form-stack">
        <div class="grid2">
          <div><label>Bot token</label><input name="token" type="password" maxlength="100" autocomplete="off" placeholder="${s.token_set ? "kayıtlı (değiştirmek için yeni token girin)" : "token"}"></div>
          <div><label>Discord sunucu kimliği</label><input name="guild_id" value="${esc(s.guild_id || "")}" maxlength="25" placeholder="ör. 1234567890123456789"></div>
        </div>
        <div><label>Müşteri rolü kimliği</label><input name="customer_role_id" value="${esc(s.customer_role_id || "")}" maxlength="25"></div>
        <div class="row" style="margin-top:10px"><button class="primary" type="submit">Kaydet</button></div>
      </form>
    </section>
    <section class="card">
      <h4>Kurulum</h4>
      <p class="muted small-text">"Mango Panel" kategorisinde dört kanal oluşturulur: sunucu-bildirim, destek-talepleri, satin-alma, durum-paneli. Kanallar herkese gizlidir. Bot kodu, bu hesaba verilen bir Node.js sunucusuna yazılır. Kurulumu tekrar çalıştırmak bot kodunu ve ortam değişkenlerini günceller, kanalları yeniden oluşturmaz.</p>
      <p class="small-text">Durum: <b>${s.setup_done ? "kurulu" : "kurulmadı"}</b> · Bot sunucusu: ${s.bot_server_id ? `#${s.bot_server_id}` : "yok"} · Bağlı panel hesabı: ${s.linked_users}</p>
      <div class="row" style="margin-top:10px"><button class="primary" type="button" data-pl="discordSetup">Botu kur</button></div>
    </section>`;
}

PL_FORMS.discordSettings = async (form) => {
  const v = (name) => form.elements[name].value.trim();
  const body = { guild_id: v("guild_id"), customer_role_id: v("customer_role_id") };
  if (v("token")) body.token = v("token");  // boşsa kayıtlı token korunur
  try {
    await api("/admin/discord", { method: "PUT", body });
    toast("Discord ayarları kaydedildi");
    renderAdmin("discord");
  } catch (e) { toast(e.message, true); }
};

PL.discordSetup = async () => {
  if (!confirm("Discord kurulumu başlasın mı? Kanallar oluşturulacak ve bot sunucusu hesabınıza verilecek.")) return;
  try {
    const res = await api("/admin/discord/setup", { method: "POST" });
    toast(`Kurulum tamam: ${res.bot_name}. Bot sunucusunu #${res.bot_server_id} Başlat ile çalıştırın.`);
    renderAdmin("discord");
  } catch (e) { toast(e.message, true); }
};

async function loadMeDiscord() {
  const box = document.getElementById("meDiscord");
  if (!box) return;
  try {
    const me = await api("/me/discord");
    box.innerHTML = `
      <section class="card">
        <h4>Discord bağlantısı</h4>
        ${me.linked
          ? `<p class="small-text">Hesap bağlı (Discord kimliği: <code>${esc(me.discord_id)}</code>). Discord'da <code>/sunucular</code>, <code>/durum</code>, <code>/baslat</code> gibi komutlarla sunucularınızı yönetebilirsiniz.</p>
             <div class="row"><button class="danger small" type="button" data-pl="discordUnlink">Bağlantıyı kaldır</button></div>`
          : `<p class="muted small-text">Discord'da <code>/bagla</code> yazın, size verilen kodu aşağıya girin. Kod 10 dakika geçerlidir.</p>
             <form data-pl-form="discordLink" class="row">
               <input name="code" placeholder="Kod (ör. ABCD2345)" maxlength="16" required style="flex:1">
               <button class="primary" type="submit">Bağla</button>
             </form>`}
      </section>`;
  } catch (e) {
    box.innerHTML = `<section class="card"><div class="notice">${esc(e.message)}</div></section>`;
  }
}

PL_FORMS.discordLink = async (form) => {
  try {
    const res = await api("/me/discord/link", { method: "POST", body: { code: form.elements.code.value.trim() } });
    if (res.role_granted) celebrate(res.message); else toast(res.message, !res.linked);
    loadMeDiscord();
  } catch (e) { toast(e.message, true); }
};

PL.discordUnlink = async () => {
  if (!confirm("Discord bağlantısı kaldırılsın mı?")) return;
  try {
    await api("/me/discord", { method: "DELETE" });
    toast("Bağlantı kaldırıldı");
    loadMeDiscord();
  } catch (e) { toast(e.message, true); }
};

// ---------- Eksik paketler (1.23.0) ----------

PL.scanPackages = async () => {
  const box = document.getElementById("pkgScan");
  if (!box || !state.sid) return;
  box.innerHTML = `<span class="muted small-text">Taranıyor...</span>`;
  try {
    const res = await api(`/servers/${state.sid}/missing-packages`);
    const section = (manager, names) => {
      if (!names.length) return `<p class="muted small-text">${manager}: eksik paket yok.</p>`;
      const rows = names.map((name) => {
        const info = (typeof PKG_SUGGEST !== "undefined" && PKG_SUGGEST[manager] || []).find(([n]) => n === name);
        return `<li class="pkg-missing">
          <code>${esc(name)}</code>
          <span class="muted small-text">${esc(info ? info[1] : "Kodda kullanılıyor, kurulu değil")}</span>
          <button class="small" type="button" data-pl="installOne" data-manager="${manager}" data-name="${esc(name)}">Kur</button>
        </li>`;
      }).join("");
      return `<div style="margin-top:8px"><b>${manager}</b>
        <button class="small" type="button" data-pl="installMissing" data-manager="${manager}" data-names="${esc(names.join(" "))}">Hepsini kur</button>
        <ul class="pkg-suggest">${rows}</ul></div>`;
    };
    box.innerHTML = `
      <div class="small-text muted">${res.files} dosya tarandı.</div>
      ${section("npm", res.npm)}
      ${section("pip", res.pip)}`;
  } catch (e) {
    box.innerHTML = `<div class="notice">${esc(e.message)}</div>`;
  }
};

function pkgCommand(manager, names) {
  const quoted = names.map((n) => `'${n}'`).join(" ");
  return manager === "npm" ? `npm install --no-audit --no-fund ${quoted}` : `pip install --no-cache-dir ${quoted}`;
}

PL.installOne = (el) => {
  sendShellCommand(pkgCommand(el.dataset.manager, [el.dataset.name]));
};

PL.installMissing = (el) => {
  const names = el.dataset.names.split(" ").filter(Boolean);
  if (names.length) sendShellCommand(pkgCommand(el.dataset.manager, names));
};

// ---------- Kullanım raporu (1.23.0) ----------

async function loadMeUsage() {
  loadMeSessions();
  const box = document.getElementById("meUsage");
  if (!box) return;
  try {
    const u = await api("/me/usage");
    const stat = (label, value) => `<div class="usage-stat"><span class="muted small-text">${label}</span><b>${value}</b></div>`;
    box.innerHTML = `
      <section class="card">
        <h4>Kullanım raporu</h4>
        <div class="usage-grid">
          ${stat("Sunucu", `${u.servers} / ${u.max_servers}`)}
          ${stat("Çalışan", u.running)}
          ${stat("Toplam RAM", `${u.memory_mb} MB`)}
          ${stat("Toplam CPU", `${u.cpu_percent}%`)}
          ${stat("Destek talebi", u.tickets)}
          ${stat("Discord", u.discord_linked ? "bağlı" : "bağlı değil")}
        </div>
        <h4 style="margin-top:16px">Satın alma geçmişi</h4>
        <div class="table-wrap"><table>
          <thead><tr><th>Talep</th><th>Paket</th><th>Durum</th><th>Tarih</th></tr></thead>
          <tbody>${u.purchases.map((p) => `
            <tr><td>${esc(p.subject)}</td><td>${esc(p.plan || "-")}</td><td>${esc(p.status)}</td><td class="muted">${esc(fmtDate(p.created_at))}</td></tr>`).join("")
            || `<tr><td class="muted" colspan="4">Henüz satın alma talebi yok.</td></tr>`}
          </tbody>
        </table></div>
      </section>`;
  } catch (e) {
    box.innerHTML = `<section class="card"><div class="notice">${esc(e.message)}</div></section>`;
  }
}

// ---------- Genel Sohbet (1.24.0) ----------

let chatLastId = 0;
let chatSince = 0;
let chatTimer = null;

function renderChat() {
  app().innerHTML = `
    <div class="section-head"><h3>Genel sohbet</h3>
      <span class="muted small-text">Mesajlar canlı akar. Sunucu logunu paylaşıp yardım isteyebilirsin.</span></div>
    <section class="card chat-wrap">
      <div id="chatList" class="chat-list"><p class="muted small-text chat-empty">Yükleniyor...</p></div>
      <form data-pl-form="chatSend" class="chat-compose">
        <div class="row" style="flex-wrap:wrap">
          <select name="server_id" aria-label="Paylaşılacak sunucu" style="max-width:260px">
            <option value="">Log paylaşma</option>
          </select>
          <label class="row small-text" style="gap:6px"><input type="checkbox" name="help"> Yardım istiyorum</label>
        </div>
        <textarea name="text" rows="2" maxlength="1000" placeholder="Mesajını yaz (Enter gönderir, Shift+Enter alt satır)"></textarea>
        <div class="row between">
          <span class="muted small-text">Paylaşılan logun son 80 satırı eklenir. Şifre ve token gibi bilgiler otomatik gizlenir.</span>
          <button class="primary" type="submit">Gönder</button>
        </div>
      </form>
    </section>`;
  chatLoadServers();
  chatStart();
}

async function chatLoadServers() {
  const select = document.querySelector('[data-pl-form="chatSend"] select[name="server_id"]');
  if (!select) return;
  try {
    const servers = await api("/servers?scope=mine");
    select.insertAdjacentHTML("beforeend", servers.map((s) => `<option value="${s.id}">${esc(s.name)}</option>`).join(""));
  } catch (e) { /* sunucu listesi alınamazsa yalnızca metin gönderilir */ }
}

function chatStart() {
  chatLastId = 0;
  chatSince = 0;
  clearInterval(chatTimer);
  chatTimer = setInterval(chatPoll, 2000);
  chatPoll();
  const textarea = document.querySelector('[data-pl-form="chatSend"] textarea');
  if (textarea) {
    textarea.addEventListener("keydown", (e) => {
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        textarea.form.requestSubmit();
      }
    });
  }
}

function chatMessageHtml(m) {
  const canDelete = (state.user && state.user.username === m.username) || (state.user && state.user.is_admin);
  const text = esc(m.text || "").replace(/\n/g, "<br>");
  const log = m.log_text
    ? `<div class="muted small-text" style="margin-top:6px">Paylaşılan log · sunucu: <b>${esc(m.server_name || "")}</b></div>
       <pre class="chat-log">${esc(m.log_text)}</pre>`
    : "";
  return `
    <div class="chat-msg" data-msg="${m.id}">
      <div class="row between">
        <span><b>${esc(m.username)}</b>${m.help ? ` <span class="badge starting">yardım istiyor</span>` : ""}</span>
        <span class="row" style="gap:8px">
          <span class="muted small-text">${esc(fmtDate(m.created_at))}</span>
          ${canDelete ? `<button class="small danger" type="button" data-pl="chatDelete" data-id="${m.id}">Sil</button>` : ""}
        </span>
      </div>
      <div class="chat-text">${text}</div>
      ${log}
    </div>`;
}

async function chatPoll() {
  const list = document.getElementById("chatList");
  if (!list) {  // sayfa değişti: zamanlayıcıyı durdur
    clearInterval(chatTimer);
    chatTimer = null;
    return;
  }
  try {
    const data = await api(`/chat/messages?after=${chatLastId}&since=${chatSince}`);
    const atBottom = list.scrollHeight - list.scrollTop - list.clientHeight < 90;
    for (const m of data.items) {
      if (m.hidden) {
        const old = list.querySelector(`[data-msg="${m.id}"]`);
        if (old) old.remove();
        continue;
      }
      if (list.querySelector(`[data-msg="${m.id}"]`)) continue;
      list.querySelectorAll(".chat-empty").forEach((el) => el.remove());
      list.insertAdjacentHTML("beforeend", chatMessageHtml(m));
    }
    chatLastId = Math.max(chatLastId, data.last_id);
    chatSince = data.now;
    if (!list.querySelector(".chat-msg")) {
      list.innerHTML = `<p class="muted small-text chat-empty">Henüz mesaj yok. İlk mesajı sen yaz.</p>`;
    }
    if (atBottom) list.scrollTop = list.scrollHeight;
  } catch (e) {
    /* ağ hatasında bir sonraki turda tekrar denenir */
  }
}

PL_FORMS.chatSend = async (form) => {
  const text = form.elements.text.value.trim();
  const serverId = form.elements.server_id.value;
  if (!text && !serverId) return;
  const button = form.querySelector('button[type="submit"]');
  button.disabled = true;
  try {
    await api("/chat/messages", {
      method: "POST",
      body: { text, help: form.elements.help.checked, server_id: serverId ? Number(serverId) : null },
    });
    form.elements.text.value = "";
    form.elements.help.checked = false;
    form.elements.server_id.value = "";
    chatPoll();
  } catch (e) {
    toast(e.message, true);
  } finally {
    button.disabled = false;
  }
};

PL.chatDelete = async (el) => {
  if (!confirm("Mesaj silinsin mi?")) return;
  try {
    await api(`/chat/messages/${el.dataset.id}`, { method: "DELETE" });
    const row = el.closest(".chat-msg");
    if (row) row.remove();
  } catch (e) { toast(e.message, true); }
};


/* ---------- 1.27.0: açık oturumlar ---------- */
async function loadMeSessions() {
  const box = document.getElementById("meSessions");
  if (!box) return;
  try {
    const rows = await api("/me/sessions");
    box.innerHTML = `
      <section class="card">
        <div class="section-head"><h4>Açık oturumlar</h4>
          <button data-pl="revokeOthers">Diğer oturumları kapat</button></div>
        <p class="muted small-text">Bu hesapla açık olan cihazlar. Tanımadığınız bir oturum varsa kapatın ve şifrenizi değiştirin.</p>
        ${rows.map((r) => `
          <div class="session-row">
            <div>
              <b>${r.current ? "Bu cihaz" : "Oturum"}</b>
              <span class="muted small-text">${esc(r.ip || "IP bilinmiyor")}</span>
              <div class="muted small-text">${esc((r.user_agent || "Bilinmeyen tarayıcı").slice(0, 70))} · son görülme ${esc(new Date(r.last_seen).toLocaleString("tr-TR"))}</div>
            </div>
            ${r.current ? "" : `<button data-pl="revokeSession" data-id="${esc(r.id)}">Kapat</button>`}
          </div>`).join("")}
      </section>`;
  } catch (e) {
    box.innerHTML = "";
  }
}

PL.revokeSession = async (el) => {
  try {
    await api(`/me/sessions/${el.dataset.id}`, { method: "DELETE" });
    toast("Oturum kapatıldı");
    loadMeSessions();
  } catch (e) { toast(e.message, true); }
};

PL.revokeOthers = async () => {
  if (!confirm("Bu cihaz dışındaki tüm oturumlar kapatılsın mı?")) return;
  try {
    const r = await api("/me/sessions/revoke-others", { method: "POST" });
    toast(`${r.revoked} oturum kapatıldı`);
    loadMeSessions();
  } catch (e) { toast(e.message, true); }
};


/* ---- 1.34.0: yönetim kuponları ---- */
async function adminCoupons(body) {
  const [coupons, plans] = await Promise.all([api("/admin/coupons"), api("/admin/plans").catch(() => [])]);
  const planOpts = plans.map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join("");
  const rows = coupons.map((c) => `
    <tr>
      <td><strong>${esc(c.code)}</strong></td>
      <td>%${c.percent_off}</td>
      <td>${esc(c.plan_name)}</td>
      <td>${c.used_count}${c.max_uses ? " / " + c.max_uses : ""}</td>
      <td>${c.expires_at ? esc(new Date(c.expires_at).toLocaleDateString("tr-TR")) : "—"}</td>
      <td>${c.active ? "Açık" : "Kapalı"}</td>
      <td class="row" style="gap:6px;justify-content:flex-end">
        <button data-act="couponToggle" data-id="${c.id}" data-active="${c.active ? "0" : "1"}">${c.active ? "Kapat" : "Aç"}</button>
        <button class="danger" data-act="couponDelete" data-id="${c.id}">Sil</button>
      </td>
    </tr>`).join("");
  body.innerHTML = `
    <section class="card">
      <h4>Yeni kupon</h4>
      <form id="couponForm" class="grid3">
        <div><label>Kod</label><input name="code" required minlength="3" maxlength="32" placeholder="YAZ20"></div>
        <div><label>İndirim (%)</label><input name="percent_off" type="number" min="1" max="100" value="10" required></div>
        <div><label>Paket</label><select name="plan_id"><option value="">Tüm paketler</option>${planOpts}</select></div>
        <div><label>Kullanım sınırı (boş = sınırsız)</label><input name="max_uses" type="number" min="1"></div>
        <div><label>Son kullanma tarihi</label><input name="expires_at" type="date"></div>
        <div class="row" style="align-items:end"><button class="primary" type="submit">Kupon oluştur</button></div>
      </form>
      <p class="muted small-text">İndirim, satın alma talebine kaydedilir ve yönetici tarafından paket fiyatına uygulanır.</p>
    </section>
    <section class="card">
      <h4>Kuponlar</h4>
      ${coupons.length ? `<div class="table-wrap"><table>
        <thead><tr><th>Kod</th><th>İndirim</th><th>Paket</th><th>Kullanım</th><th>Son tarih</th><th>Durum</th><th></th></tr></thead>
        <tbody>${rows}</tbody></table></div>` : `<div class="notice">Henüz kupon yok.</div>`}
    </section>`;
  document.getElementById("couponForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const f = e.target;
    const payload = {
      code: f.elements.code.value.trim(),
      percent_off: Number(f.elements.percent_off.value),
      plan_id: f.elements.plan_id.value ? Number(f.elements.plan_id.value) : null,
      max_uses: f.elements.max_uses.value ? Number(f.elements.max_uses.value) : null,
      expires_at: f.elements.expires_at.value ? new Date(f.elements.expires_at.value + "T23:59:59").toISOString() : null,
    };
    try { await api("/admin/coupons", { method: "POST", body: payload }); toast("Kupon oluşturuldu"); renderAdmin("kuponlar"); }
    catch (err) { toast(err.message, true); }
  });
}

platformActions.couponToggle = async (el) => {
  try { await api(`/admin/coupons/${el.dataset.id}?active=${el.dataset.active === "1"}`, { method: "PATCH" }); toast("Kupon güncellendi"); renderAdmin("kuponlar"); }
  catch (e) { toast(e.message, true); }
};
platformActions.couponDelete = async (el) => {
  if (!confirm("Kupon silinsin mi?")) return;
  try { await api(`/admin/coupons/${el.dataset.id}`, { method: "DELETE" }); toast("Kupon silindi"); renderAdmin("kuponlar"); }
  catch (e) { toast(e.message, true); }
};


/* ---- 1.37.0: bildirimler ---- */
async function refreshNotifBadge() {
  const badge = document.getElementById("notifBadge");
  if (!badge || !state.token) return;
  try {
    const data = await api("/notifications");
    badge.textContent = data.unread > 0 ? String(data.unread) : "";
    badge.hidden = data.unread === 0;
  } catch (e) { /* sessizce geç */ }
}

async function renderMyNotifications() {
  const box = document.getElementById("tab") || app();
  app().innerHTML = `
    <section class="card">
      <div class="row between">
        <h2>Bildirimler</h2>
        <button data-act="notifReadAll">Tümünü okundu say</button>
      </div>
      <div id="notifList"><p class="muted">Yükleniyor…</p></div>
    </section>`;
  try {
    const data = await api("/notifications");
    const list = document.getElementById("notifList");
    if (!data.items.length) { list.innerHTML = `<div class="notice">Henüz bildiriminiz yok.</div>`; }
    else {
      list.innerHTML = data.items.map((n) => `
        <article class="notif-item ${n.read ? "" : "is-unread"}" data-id="${n.id}">
          <div class="row between"><strong>${esc(n.title)}</strong><span class="muted small-text">${esc(new Date(n.created_at).toLocaleString("tr-TR"))}</span></div>
          <p>${esc(n.body)}</p>
          ${n.read ? "" : `<button data-act="notifRead" data-id="${n.id}">Okundu</button>`}
        </article>`).join("");
    }
  } catch (e) { toast(e.message, true); }
  refreshNotifBadge();
}

platformActions.notifRead = async (el) => {
  try { await api(`/notifications/${el.dataset.id}/read`, { method: "POST" }); renderMyNotifications(); }
  catch (e) { toast(e.message, true); }
};
platformActions.notifReadAll = async () => {
  try { await api("/notifications/read-all", { method: "POST" }); renderMyNotifications(); }
  catch (e) { toast(e.message, true); }
};

async function adminNotifications(body) {
  const sent = await api("/admin/notifications").catch(() => []);
  const plans = await api("/admin/plans").catch(() => []);
  const planOpts = plans.map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join("");
  const rows = sent.map((n) => `
    <tr>
      <td>${esc(new Date(n.created_at).toLocaleString("tr-TR"))}</td>
      <td><strong>${esc(n.title)}</strong></td>
      <td>${n.target === "all" ? "Herkes" : n.target === "plan" ? "Paket" : "Seçilenler"}</td>
      <td>${n.read} / ${n.recipients}</td>
    </tr>`).join("");
  body.innerHTML = `
    <section class="card">
      <h4>Yeni bildirim gönder</h4>
      <form id="notifForm" class="grid2">
        <div><label>Başlık</label><input name="title" required minlength="2" maxlength="120"></div>
        <div><label>Hedef</label>
          <select name="target" id="notifTarget">
            <option value="all">Tüm kullanıcılar</option>
            <option value="plan">Bir paketi satın alanlar</option>
            <option value="users">Seçilen kullanıcılar</option>
          </select></div>
        <div id="notifPlanBox" hidden><label>Paket</label><select name="plan_id">${planOpts}</select></div>
        <div id="notifUsersBox" hidden><label>Kullanıcı adları (virgülle)</label><input name="usernames" placeholder="ali, veli, ayse"></div>
        <div style="grid-column:1/-1"><label>Mesaj</label><textarea name="body" rows="4" required maxlength="2000"></textarea></div>
        <div class="row" style="grid-column:1/-1;justify-content:flex-end"><button class="primary" type="submit">Gönder</button></div>
      </form>
    </section>
    <section class="card">
      <h4>Gönderilenler</h4>
      ${sent.length ? `<div class="table-wrap"><table>
        <thead><tr><th>Tarih</th><th>Başlık</th><th>Hedef</th><th>Okunma</th></tr></thead>
        <tbody>${rows}</tbody></table></div>` : `<div class="notice">Henüz bildirim gönderilmedi.</div>`}
    </section>`;

  const target = document.getElementById("notifTarget");
  const sync = () => {
    document.getElementById("notifPlanBox").hidden = target.value !== "plan";
    document.getElementById("notifUsersBox").hidden = target.value !== "users";
  };
  target.addEventListener("change", sync);
  sync();

  document.getElementById("notifForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const f = e.target;
    const payload = {
      title: f.elements.title.value.trim(),
      body: f.elements.body.value.trim(),
      target: f.elements.target.value,
      plan_id: f.elements.target.value === "plan" ? Number(f.elements.plan_id.value) : null,
      usernames: f.elements.target.value === "users"
        ? f.elements.usernames.value.split(",").map((s) => s.trim()).filter(Boolean) : [],
    };
    try {
      const r = await api("/admin/notifications", { method: "POST", body: payload });
      toast(`Bildirim ${r.recipients} kişiye gönderildi`);
      renderAdmin("bildirimler");
    } catch (err) { toast(err.message, true); }
  });
}

/* ---------- 1.38.0: makbuz ve satış hunisi ---------- */
platformActions.receipt = (el) => {
  const d = el.dataset;
  const w = window.open("", "_blank");
  if (!w) { toast("Açılır pencereye izin verin", true); return; }
  const today = new Date().toLocaleDateString("tr-TR");
  w.document.write(`<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>Makbuz ${esc(d.id || "")}</title>
<style>
body{font-family:system-ui,sans-serif;max-width:680px;margin:40px auto;color:#111;padding:0 20px}
h1{font-size:22px;margin:0 0 4px}.muted{color:#666;font-size:13px}
table{width:100%;border-collapse:collapse;margin-top:22px}
td{padding:10px 8px;border-bottom:1px solid #ddd}td.r{text-align:right}
.total td{font-weight:700;border-bottom:0}
.note{margin-top:28px;font-size:12px;color:#666}
@media print{button{display:none}}
</style></head><body>
<h1>Makbuz</h1>
<div class="muted">Makbuz No: MNG-${esc(d.id || "")} · Tarih: ${esc(today)}</div>
<table>
<tr><td>Müşteri</td><td class="r">${esc(d.user || "")}</td></tr>
<tr><td>Paket</td><td class="r">${esc(d.plan || "")}</td></tr>
<tr><td>Talep tarihi</td><td class="r">${esc(d.date || "")}</td></tr>
<tr><td>Kupon</td><td class="r">${esc(d.coupon || "Yok")}</td></tr>
<tr class="total"><td>Tutar</td><td class="r">${esc(d.price || "—")}</td></tr>
</table>
<div class="note">Bu belge bilgilendirme amaçlıdır; resmi fatura veya e-fatura yerine geçmez.</div>
<p><button onclick="window.print()">Yazdır</button></p>
</body></html>`);
  w.document.close();
  w.focus();
};

async function adminFunnel(body) {
  const data = await api("/admin/funnel");
  const s = data.summary;
  const labels = { kayitli: "Kayıtlı", sunucusu_var: "Sunucusu var", satin_aldi: "Satın aldı" };
  const rows = data.users.map((u) => `
    <tr>
      <td>${esc(u.username)}</td>
      <td>${plDate(u.created_at)}</td>
      <td class="right">${u.purchases}</td>
      <td class="right">${u.servers}</td>
      <td>${labels[u.stage] || esc(u.stage)}</td>
      <td class="right">${u.stage === "kayitli" ? `<button data-act="funnelRemind" data-username="${esc(u.username)}">Hatırlat</button>` : ""}</td>
    </tr>`).join("");
  body.innerHTML = `
    <div class="section-head"><h3>Satış hunisi</h3></div>
    <p class="muted small-text">Kayıt olan kullanıcıların hangi aşamada olduğunu gösterir. Paket almamış kullanıcılara tek tıkla hatırlatma bildirimi gönderebilirsiniz.</p>
    <div class="grid2">
      <section class="card"><div class="muted small-text">Kayıtlı kullanıcı</div><h3>${s.registered}</h3></section>
      <section class="card"><div class="muted small-text">Satın alan</div><h3>${s.buyers}</h3></section>
      <section class="card"><div class="muted small-text">Henüz satın almayan</div><h3>${s.no_purchase}</h3></section>
    </div>
    <section class="card"><table class="files">
      <tr><td><b>Kullanıcı</b></td><td><b>Kayıt</b></td><td class="right"><b>Talep</b></td><td class="right"><b>Sunucu</b></td><td><b>Aşama</b></td><td></td></tr>
      ${rows || `<tr><td colspan="6" class="muted">Kullanıcı yok.</td></tr>`}
    </table></section>`;
}

platformActions.funnelRemind = async (el) => {
  const username = el.dataset.username;
  if (!confirm(`${username} kullanıcısına paket hatırlatma bildirimi gönderilsin mi?`)) return;
  try {
    await api("/admin/notifications", { method: "POST", body: {
      title: "Paket hatırlatması",
      body: "Mango Panel'de ihtiyacınıza uygun bir paket var. Paketleri inceleyip satın alma talebi oluşturabilirsiniz.",
      target: "users", usernames: [username],
    } });
    toast("Hatırlatma gönderildi");
    el.disabled = true;
  } catch (e) { toast(e.message, true); }
};

platformActions.cloudflareTest = async () => {
  const out = document.getElementById("cfTestResult");
  if (out) { out.textContent = "Test ediliyor..."; out.style.color = ""; }
  try {
    const r = await api("/admin/cloudflare/test", { method: "POST" });
    if (out) { out.textContent = r.message; out.style.color = r.ok ? "#2e7d32" : "#c62828"; }
    toast(r.message, !r.ok);
  } catch (e) {
    if (out) { out.textContent = e.message; out.style.color = "#c62828"; }
    toast(e.message, true);
  }
};

/* ---------- 1.40.4: kullanıcı onayı ---------- */
platformActions.userApprove = async (el) => {
  try {
    await api(`/users/${el.dataset.id}`, { method: "PATCH", body: { approved: true } });
    toast("Kullanıcı onaylandı");
    adminUsers(document.getElementById("adminBody"));
  } catch (e) { toast(e.message, true); }
};
