/* 1.23.0: kısa konfeti kutlamaları. Hareket azaltma tercihi açıksa hiçbir şey çizilmez. */
(function () {
  const COLORS = ["#f59e0b", "#fb923c", "#facc15", "#84cc16", "#38bdf8", "#f472b6"];

  function burst(durationMs) {
    if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const canvas = document.createElement("canvas");
    canvas.className = "confetti-canvas";
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    document.body.appendChild(canvas);
    const ctx = canvas.getContext("2d");
    const pieces = Array.from({ length: 150 }, () => ({
      x: Math.random() * canvas.width,
      y: -20 - Math.random() * canvas.height * 0.4,
      vx: (Math.random() - 0.5) * 5,
      vy: 2 + Math.random() * 4,
      rot: Math.random() * 6,
      vr: (Math.random() - 0.5) * 0.25,
      size: 6 + Math.random() * 6,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
    }));
    const start = performance.now();
    function frame(now) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      for (const p of pieces) {
        p.x += p.vx;
        p.y += p.vy;
        p.vy += 0.05;
        p.rot += p.vr;
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.fillStyle = p.color;
        ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
        ctx.restore();
      }
      if (now - start < durationMs) requestAnimationFrame(frame);
      else canvas.remove();
    }
    requestAnimationFrame(frame);
  }

  /* Kutlama: konfeti + bildirim. Aynı anda birden çok çağrılırsa tek patlama yeterli. */
  let busy = false;
  window.celebrate = function (message) {
    if (message && typeof window.toast === "function") window.toast(message);
    if (busy) return;
    busy = true;
    burst(2600);
    setTimeout(() => { busy = false; }, 1200);
  };
})();
