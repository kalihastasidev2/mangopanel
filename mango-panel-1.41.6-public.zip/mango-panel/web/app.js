"use strict";

/* Mango Panel arayüzü.
 * CSP "script-src 'self'" olduğu için inline onclick kullanılmaz.
 * Tıklamalar ve formlar document üzerinde tek noktadan yönetilir (delegasyon). */

const state = {
  token: safeGet("mango_token"),
  user: null,
  system: null,
  eggs: null,
  authMode: "login",      // "login" | "register"
  sid: null,              // açık sunucunun id'si
  server: null,
  filePath: "",           // dosya yöneticisinde bulunulan klasör
  editPath: null,         // düzenleyicide açık dosya
  ws: null,               // konsol WebSocket'i
  alerts: [],             // sunucu uyarıları (çökme, disk vb.)
  history: [],            // komut geçmişi
  historyPos: -1,
  hist: { cpu: [], mem: [] }, // grafik verisi
};
let timers = [];

function safeGet(key) { try { return localStorage.getItem(key); } catch { return null; } }
function safeSet(key, value) { try { localStorage.setItem(key, value); } catch { /* özel pencere */ } }
function safeDel(key) { try { localStorage.removeItem(key); } catch { /* yoksay */ } }

const app = () => document.getElementById("app");
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) =>
  ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
// Form alanı okuma: form.name gibi doğrudan erişim, HTML form özellikleriyle çakışabilir.
const fv = (form, name) => {
  const el = form.querySelector(`[name="${name}"]`);
  return el ? el.value : "";
};
const fc = (form, name) => {
  const el = form.querySelector(`[name="${name}"]`);
  return el ? el.checked : false;
};

let lastApiErr = null;

/* 1.41.0: Hata popup'ı. Log ile tek tıkla destek talebi açılır. */
let lastErrPopupAt = 0;
function showErrorPopup(title, err) {
  const now = Date.now();
  if (now - lastErrPopupAt < 1200) return;  // arka arkaya gelen aynı hatalarda popup yığılmasın
  lastErrPopupAt = now;
  document.getElementById("errPopup")?.remove();
  const ctx = (err && err.context) || {};
  const lines = [
    `Zaman: ${new Date().toLocaleString("tr-TR")}`,
    `Sayfa: ${location.hash || "/"}`,
    ctx.method ? `İstek: ${ctx.method} ${ctx.path} -> HTTP ${ctx.status}` : "",
    `Hata: ${(err && err.message) || title}`,
    err && err.stack ? `Yığın: ${String(err.stack).slice(0, 700)}` : "",
    `Tarayıcı: ${navigator.userAgent.slice(0, 160)}`,
  ].filter(Boolean);
  const detail = lines.join("\n");
  const wrap = document.createElement("div");
  wrap.id = "errPopup";
  wrap.className = "gate-overlay";
  wrap.innerHTML = `
    <div class="gate-card" role="alertdialog" aria-modal="true" aria-labelledby="errTitle">
      <h1 id="errTitle">⚠️ ${esc(title)}</h1>
      <p>${esc((err && err.message) || "Beklenmeyen bir hata oluştu.")}</p>
      <details style="margin-top:12px"><summary class="muted small-text">Hata logu</summary>
        <pre class="errlog">${esc(detail)}</pre></details>
      <div class="gate-actions">
        ${state.token ? '<button class="primary" data-err="ticket">Destek talebi aç</button>' : ""}
        <button class="ghost" data-err="close">Kapat</button>
      </div>
      <div class="muted small-text">Destek talebi açarsanız bu log ekibe otomatik iletilir.</div>
    </div>`;
  const close = () => wrap.remove();
  wrap.querySelector('[data-err="close"]').addEventListener("click", close);
  wrap.addEventListener("click", (e) => { if (e.target === wrap) close(); });
  const tb = wrap.querySelector('[data-err="ticket"]');
  if (tb) tb.addEventListener("click", async () => {
    tb.disabled = true;
    tb.textContent = "Gönderiliyor…";
    try {
      const t = await api("/tickets", {
        method: "POST",
        body: {
          subject: ("Hata: " + title).slice(0, 110),
          message: ("Otomatik hata raporu.\n\n" + detail).slice(0, 1990),
          category: "support",
        },
      });
      close();
      toast(`Destek talebi #${t.id} açıldı. Ekip ilgilenecek.`);
    } catch (e) {
      tb.disabled = false;
      tb.textContent = "Destek talebi aç";
      toast("Talep açılamadı: " + e.message);
    }
  });
  document.body.appendChild(wrap);
  tb ? tb.focus() : wrap.querySelector('[data-err="close"]').focus();
}

// Yakalanmamış JS hataları ve sözü tutulmayan işlemler de aynı popup'ı açar.
window.addEventListener("error", (ev) => {
  if (/ResizeObserver loop/i.test(ev.message || "")) return;  // tarayıcının zararsız uyarısı
  showErrorPopup("Beklenmeyen hata", ev.error || new Error(ev.message));
});
window.addEventListener("unhandledrejection", (ev) => {
  const r = ev.reason;
  showErrorPopup("İşlem tamamlanamadı", r instanceof Error ? r : new Error(String(r)));
});

function toast(msg, bad = false) {
  if (bad) {
    showErrorPopup("İşlem başarısız", lastApiErr && lastApiErr.message === msg ? lastApiErr : { message: msg });
    return;
  }
  let box = document.getElementById("toasts");
  if (!box) {
    box = document.createElement("div");
    box.id = "toasts";
    box.setAttribute("role", "status");
    box.setAttribute("aria-live", "polite");
    document.body.appendChild(box);
  }
  const el = document.createElement("div");
  el.className = "toast-item" + (bad ? " bad" : "");
  el.textContent = msg;
  box.appendChild(el);
  while (box.children.length > 4) box.firstElementChild.remove();
  setTimeout(() => {
    el.classList.add("out");
    el.addEventListener("animationend", () => el.remove(), { once: true });
    setTimeout(() => el.remove(), 700); // hareket azaltma açıkken animasyon olmayabilir
  }, 3800);

}

function fmtSize(n) {
  if (n < 1024) return n + " B";
  if (n < 1024 * 1024) return (n / 1024).toFixed(1) + " KB";
  return (n / 1024 / 1024).toFixed(1) + " MB";
}
function fmtDate(iso) {
  if (!iso) return "—";
  try { return new Date(iso).toLocaleString("tr-TR", { dateStyle: "short", timeStyle: "short" }); }
  catch { return "—"; }
}
function fmtDuration(sec) {
  sec = Math.max(0, Math.floor(sec || 0));
  const d = Math.floor(sec / 86400);
  const h = Math.floor((sec % 86400) / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  return [d && `${d}g`, h && `${h}s`, m && `${m}dk`, `${s}sn`].filter(Boolean).slice(0, 3).join(" ");
}

/* ---------- simgeler (Feather tarzı çizgi simgeler; emoji yerine) ---------- */
const ICONS = {
  terminal: '<polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
  globe: '<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
  users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  server: '<rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/>',
  chart: '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
  activity: '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
  scroll: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',
  arrowLeft: '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
  alert: '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
  bell: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
  play: '<polygon points="5 3 19 12 5 21 5 3"/>',
  stop: '<rect x="5" y="5" width="14" height="14" rx="2"/>',
  restart: '<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>',
  power: '<path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" y1="2" x2="12" y2="12"/>',
  external: '<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>',
  key: '<circle cx="7.5" cy="15.5" r="5.5"/><line x1="21" y1="2" x2="11.4" y2="11.6"/><line x1="16" y1="7" x2="19" y2="10"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
  plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  check: '<polyline points="20 6 9 17 4 12"/>',
  user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
  dashboard: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/>',
  moon: '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
  package: '<line x1="16.5" y1="9.4" x2="7.5" y2="4.21"/><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>',
};
const LOGO_MARK = '<path d="M12 6c4 0 7 3 7 7s-3 7-7 7-7-3-7-7 3-7 7-7z"/><path d="M12 6c0-2 1-3 3-3"/>';

function icon(name, size = 16) {
  return `<svg class="ico-svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ""}</svg>`;
}

async function api(path, opts = {}) {
  const headers = {};
  if (opts.body !== undefined) headers["Content-Type"] = "application/json";
  if (state.token) headers.Authorization = "Bearer " + state.token;
  const res = await fetch("/api" + path, {
    method: opts.method || "GET",
    headers,
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
  });
  if (res.status === 401 && state.token) { logout(); throw new Error("Oturum süresi doldu"); }
  if (res.status === 204) return null;
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const d = data.detail;
    let msg = res.statusText;
    if (typeof d === "string") msg = d;
    else if (Array.isArray(d)) msg = d.map((x) => x.msg).join(", ");
    const err = new Error(msg);
    err.status = res.status;
    err.context = { method: opts.method || "GET", path: "/api" + path, status: res.status };
    lastApiErr = err;
    throw err;
  }
  return data;
}

/* ---------- oturum ---------- */
function logout() {
  safeDel("mango_token");
  state.token = null;
  state.user = null;
  location.hash = "";
  route();
}

const THEME_KEY = "mango_theme";
function currentTheme() {
  try { return localStorage.getItem(THEME_KEY) === "light" ? "light" : "dark"; } catch { return "dark"; }
}
function applyTheme(theme) {
  document.documentElement.dataset.theme = theme;
}

function setNav() {
  const nav = document.getElementById("nav");
  document.body.classList.toggle("authed", !!state.user);
  if (!state.user) {
    const canRegister = !!(state.system && state.system.registration_enabled);
    nav.innerHTML = `
      <a class="navlink" href="#/anasayfa">Ana sayfa</a>
      <a class="navlink" href="#/" data-scroll="paketler">Paketler</a>
      <a class="navlink" href="#/giris">Giriş</a>
      ${canRegister ? '<a class="lp-btn lp-primary lp-small" href="#/kayit">Kayıt ol</a>' : ""}`;
    return;
  }
  const current = location.hash || "#/";
  const link = (href, label, extra = "", match = href) => {
    const active = href === "#/" ? current === "#/" || current.startsWith("#/server/") : current.startsWith(match);
    return `<a class="navlink side-link${active ? " active" : ""}" href="${href}" ${extra}>${label}</a>`;
  };
  nav.innerHTML = `
    <div class="side-group">
      <div class="side-label">Genel</div>
      ${link("#/", "Sunucular")}
      ${link("#/plans", "Paketler")}
      ${link("#/account", "Hesabım")}
    </div>
    <div class="side-group">
      <div class="side-label">Destek</div>
      ${link("#/tickets", "Destek talepleri")}
      ${link("#/help", "Yardım merkezi")}
      ${link("#/chat", "Genel sohbet")}
    </div>
    <div class="side-group">
      <div class="side-label">Bildirim</div>
      ${link("#/bildirimler", `Bildirimler <span class="notif-badge" id="notifBadge" hidden></span>`, 'id="notifLink"')}
    </div>
    ${state.user.is_admin ? `
    <div class="side-group">
      <div class="side-label">Yönetim</div>
      ${link("#/admin/genel", "Yönetim paneli", "", "#/admin")}
    </div>` : ""}
    ${state.user.discord_suggest ? `
    <a class="side-hint" href="#/account">Discord bağlı değil. Bildirimler için hesabınızı bağlayın.</a>` : ""}
    <div class="side-foot">
      <div class="side-user">
        <span class="side-avatar">${esc(state.user.username.slice(0, 1).toUpperCase())}</span>
        <span class="who">${esc(state.user.username)}</span>
      </div>
      <div class="side-actions">
        <button class="theme-btn" data-act="toggleTheme" title="Temayı değiştir" aria-label="Temayı değiştir">${icon(currentTheme() === "light" ? "moon" : "sun", 16)}</button>
        <button data-act="logout">Çıkış</button>
      </div>
    </div>`;
}

function discordButtonHtml(mode) {
  if (!(state.system && state.system.discord_login)) return "";
  const label = mode === "register" ? "Discord ile kayıt ol" : "Discord ile giriş yap";
  return `
    <a class="discord-btn" href="/api/auth/discord/start?mode=${mode}"><span class="discord-ico" aria-hidden="true">🎮</span>${label}</a>
    <div class="or-sep"><span>veya</span></div>`;
}

function loginFormHtml() {
  return `
    ${discordButtonHtml("login")}
    <form id="loginForm">
      <h2>Giriş</h2>
      <label>Kullanıcı adı</label><input name="username" autocomplete="username" required>
      <label>Şifre</label><input name="password" type="password" autocomplete="current-password" required>
      <button class="primary wide" type="submit">Giriş yap</button>
      <div class="error" id="err"></div>
    </form>`;
}

function registerFormHtml() {
  return `
    ${discordButtonHtml("register")}
    <form id="registerForm">
      <h2>Kayıt ol</h2>
      <label>Kullanıcı adı (3-32 karakter, harf, rakam, _)</label>
      <input name="username" autocomplete="username" required minlength="3" maxlength="32" pattern="[A-Za-z0-9_]+">
      <label>E-posta</label><input name="email" type="email" autocomplete="email" required maxlength="120">
      <label>Şifre (en az 8 karakter)</label><input name="password" type="password" autocomplete="new-password" required minlength="8">
      <label>Şifre tekrar</label><input name="password2" type="password" autocomplete="new-password" required minlength="8">
      <button class="primary wide" type="submit">Hesap oluştur</button>
      <div class="error" id="err"></div>
    </form>`;
}

function renderLogin() {
  setNav();
  const canRegister = !!(state.system && state.system.registration_enabled);
  const mode = canRegister ? state.authMode : "login";
  const maint = "";
  app().innerHTML = `
    ${maint}
    <div class="card login">
      ${canRegister ? `
        <div class="auth-tabs">
          <button class="${mode === "login" ? "primary" : ""}" data-act="authMode" data-mode="login">Giriş yap</button>
          <button class="${mode === "register" ? "primary" : ""}" data-act="authMode" data-mode="register">Kayıt ol</button>
        </div>` : ""}
      ${mode === "register" ? registerFormHtml() : loginFormHtml()}
    </div>`;
}

function setFormError(msg) {
  const err = document.getElementById("err");
  if (err) err.textContent = msg;
}

async function onLogin(form) {
  try {
    const data = await api("/auth/login", {
      method: "POST",
      body: { username: fv(form, "username"), password: fv(form, "password") },
    });
    startSession(data);
  } catch (e) { setFormError(e.message); }
}

async function onRegister(form) {
  const password = fv(form, "password");
  if (password !== fv(form, "password2")) { setFormError("Şifreler eşleşmiyor"); return; }
  try {
    const data = await api("/auth/register", {
      method: "POST",
      body: { username: fv(form, "username"), email: fv(form, "email"), password },
    });
    if (data.pending) { toast(data.message); location.hash = "#/giris"; return; }
    toast("Hesabınız oluşturuldu, hoş geldiniz");
    startSession(data);
  } catch (e) { setFormError(e.message); }
}

function startSession(data) {
  state.token = data.token;
  state.user = data.user;
  safeSet("mango_token", data.token);
  location.hash = "#/";
  route();
}

/* ---------- sunucu listesi ---------- */
/* Kullanıcının seçebileceği en yüksek değerler (yönetici sınırları). Yöneticiler sınırsızdır. */
function limits() {
  const s = state.system || {};
  const admin = !!(state.user && state.user.is_admin);
  return {
    mem: admin ? 16384 : (s.max_memory_mb || 16384),
    cpu: admin ? 800 : (s.max_cpu_percent || 800),
    disk: s.max_disk_mb || 0,
  };
}

const DURATION_LABELS = {
  "3d": "3 gün", "1w": "1 hafta", "1m": "1 ay", "3m": "3 ay", "1y": "1 yıl", unlimited: "Süresiz", custom: "Özel (gün)",
};
function durationOptionsHtml(selected) {
  return Object.entries(DURATION_LABELS)
    .map(([k, v]) => `<option value="${k}"${k === selected ? " selected" : ""}>${esc(v)}</option>`).join("");
}
function daysLeft(iso) {
  if (!iso) return null;
  return Math.ceil((new Date(iso).getTime() - Date.now()) / 86400000);
}
function daysLeftText(iso) {
  const d = daysLeft(iso);
  if (d === null) return "";
  return d <= 0 ? "süre doldu" : `${d} gün kaldı`;
}

function serverCard(s) {
  return `
    <a class="card server-card" href="#/server/${s.id}/console">
      <div class="row between">
        <strong>${esc(s.name)}</strong>
        ${s.suspended
          ? `<span class="badge suspended">askıda</span>`
          : `<span class="badge ${esc(s.status)}"><span class="dot ${esc(s.status)}"></span>${esc(s.status)}</span>`}
      </div>
      <div class="meta">${state.user && state.user.is_admin && state.userNames ? `Sahip: ${esc(state.userNames[s.owner_id] || "?")} · ` : ""}${esc(s.egg)} · ${esc(s.address)}<br>RAM ${s.memory_mb} MB · CPU ${s.cpu_percent}%</div>
    </a>`;
}

const EGG_CATEGORY_LABEL = { web: "Statik web", php: "PHP", nodejs: "Node.js", python: "Python", game: "Oyun", bot: "Bot" };
function eggCategoryLabel(cat) { return EGG_CATEGORY_LABEL[String(cat).toLowerCase()] || cat; }
function eggIconName(cat) {
  const c = String(cat).toLowerCase();
  if (c === "web") return "globe";
  if (c === "game") return "server";
  if (["nodejs", "python", "php", "bot"].includes(c)) return "terminal";
  return "file";
}

async function renderDashboard() {
  // Sunucu listesi, egg'ler, şablonlar ve kullanıcılar paralel istenir (1.20.0).
  const isAdmin = !!state.user.is_admin;
  const scope = isAdmin ? (state.dashScope || "all") : "mine";
  const [servers, eggs, templates, users] = await Promise.all([
    api(`/servers?scope=${scope}`),
    api("/eggs"),
    api("/templates"),
    isAdmin ? api("/users") : Promise.resolve([]),
  ]);
  state.eggs = eggs;
  state.templates = templates;
  state.userNames = Object.fromEntries(users.map((u) => [u.id, u.username]));
  const userOptions = users.map((u) =>
    `<option value="${u.id}" ${u.id === state.user.id ? "selected" : ""}>${esc(u.username)}${u.is_admin ? " (yönetici)" : ""}</option>`
  ).join("");
  const canCreate = !!state.user.is_admin; // 1.27.0: kullanıcılar ücretsiz sunucu oluşturamaz
  const reasons = [...new Set(eggs.filter((e) => !e.allowed).map((e) => e.reason))];
  const firstEgg = eggs.find((e) => e.allowed) || eggs[0];
  const eggCards = eggs.map((e) => {
    const on = firstEgg && e.slug === firstEgg.slug;
    return `
      <button type="button" class="egg-card${on ? " is-on" : ""}${e.allowed ? "" : " is-off"}" data-act="pickEgg" data-slug="${esc(e.slug)}"
        ${e.allowed ? "" : "disabled"} aria-pressed="${on ? "true" : "false"}" title="${esc(e.allowed ? e.description : e.reason)}">
        <span class="egg-ico">${icon(eggIconName(e.category), 18)}</span>
        <span class="egg-txt"><strong>${esc(e.name)}</strong><small>${esc(eggCategoryLabel(e.category))}${e.allowed ? "" : " · kullanılamaz"}</small></span>
      </button>`;
  }).join("");
  const limit = state.user.is_admin ? "sınırsız" : `${servers.length} / ${state.user.max_servers}`;

  app().innerHTML = `
    <div class="section-head">
      <h3>Sunucular</h3>
      ${isAdmin
        ? `<div class="seg">
             <button type="button" data-act="dashScope" data-scope="all" class="${scope === "all" ? "on" : ""}">Tüm sunucular</button>
             <button type="button" data-act="dashScope" data-scope="mine" class="${scope === "mine" ? "on" : ""}">Benim sunucularım</button>
           </div>`
        : `<span class="muted">Sunucu hakkın: ${esc(limit)}</span>`}
    </div>
    <div class="grid">${servers.map(serverCard).join("") || `<p class="muted">Henüz sunucun yok. Aşağıdan bir tane oluştur.</p>`}</div>
    <section class="card create-area" style="margin-top:20px">
      <div class="row between">
        <h4 style="margin:0">Şablonlar</h4>
        <span class="muted small-text">Kayıtlı ayarlarla tek tıkla sunucu oluştur</span>
      </div>
      <div id="tplList" style="margin-top:12px">${tplListHtml(templates)}</div>
    </section>
    <details class="card create-area" style="margin-top:20px" ${servers.length ? "" : "open"}>
      <summary class="create-sum">${icon("plus", 16)} Yeni sunucu oluştur <span class="muted small-text">egg seç, kaynakları ayarla, onayla</span></summary>
      <form id="createForm" class="wizard" data-step="1" style="margin-top:14px">
        ${reasons.map((r) => `<div class="notice">${esc(r)}</div>`).join("")}
        <div class="wiz-dots">
          <span class="on" data-dot="1">1 · Sunucu</span>
          <span data-dot="2">2 · Kaynaklar</span>
          <span data-dot="3">3 · Ayarlar ve onay</span>
        </div>

        <div class="wiz-step" data-step="1">
          <div class="grid2">
            <div><label>Ad</label><input name="name" placeholder="Sunucu adı" required minlength="2" maxlength="48"></div>
            <div><label>Süre</label>
              <select name="duration">${durationOptionsHtml("unlimited")}</select>
              <input name="duration_days" type="number" min="1" max="3650" value="30" class="narrow" style="margin-top:6px" placeholder="Özel gün sayısı (yalnızca Özel seçilince)"></div>
            <div class="egg-picker" style="grid-column:1 / -1">
              <label>Egg seç</label>
              <div class="egg-grid">${eggCards || `<p class="muted">Kullanılabilir egg yok.</p>`}</div>
              <input type="hidden" name="egg" id="eggSelect" value="${esc(firstEgg ? firstEgg.slug : "")}">
            </div>
            ${state.user.is_admin ? `<div><label>Sahibi (sunucuyu bu kullanıcı adına oluşturur)</label><select name="owner_id">${userOptions}</select></div>` : ""}
          </div>
          <div id="siteField" hidden style="margin-top:12px">
            <label>${esc(siteAddrText(false))} · boş bırakılırsa sunucu adından üretilir</label>
            <input name="site_slug" maxlength="40" placeholder="ornek-site">
          </div>
        </div>

        <div class="wiz-step" data-step="2" hidden>
          <div class="grid2">
            <div><label>RAM (MB)</label><input name="memory" id="memInput" type="number" min="128" max="${limits().mem}" value="512"></div>
            <div><label>CPU (%, 100 = 1 çekirdek)</label><input name="cpu" type="number" min="10" max="${limits().cpu}" value="100"></div>
          </div>
          ${state.user.is_admin ? "" : `<p class="muted small-text">Sınırlar: en fazla ${limits().mem} MB RAM, %${limits().cpu} CPU, ${limits().disk} MB disk.</p>`}
        </div>

        <div class="wiz-step" data-step="3" hidden>
          <div id="eggVars" class="grid2"></div>
          <div class="notice" id="wizSummary"></div>
        </div>

        <div class="row" style="margin-top:12px">
          <button type="button" class="wiz-back" data-act="wizBack" hidden>${icon("arrowLeft", 14)} Geri</button>
          <button type="button" class="primary wiz-next" data-act="wizNext">İleri →</button>
          <button class="primary wiz-submit" type="submit" hidden>Oluştur</button>
          <button type="button" class="wiz-submit" data-act="saveTemplate" hidden>Şablon olarak kaydet</button>
          <span class="muted" id="createMsg"></span>
        </div>
      </form>
    </details>`;
  if (!canCreate) {
    document.querySelectorAll(".create-area").forEach((el) => el.remove());
    document.querySelector(".section-head").insertAdjacentHTML("afterend",
      `<div class="notice">Sunucu oluşturma yönetici tarafından yapılır. Yeni bir sunucu için yöneticinizle iletişime geçin.</div>`);
  }
  renderEggVars();
}

function renderEggVars() {
  const select = document.getElementById("eggSelect");
  const box = document.getElementById("eggVars");
  if (!select || !box) return;
  const egg = (state.eggs || []).find((e) => e.slug === select.value);
  if (!egg) return;
  const siteBox = document.getElementById("siteField");
  if (siteBox) {
    const cat = String(egg.category).toLowerCase();
    siteBox.hidden = !ROUTE_EGG_CATEGORIES.includes(cat);
    const label = siteBox.querySelector("label");
    if (label) label.textContent = APP_EGG_CATEGORIES.includes(cat)
      ? "API adı (adres: /api/apps/<ad>) · boş bırakılırsa sunucu adından üretilir"
      : `${siteAddrText(false)} · boş bırakılırsa sunucu adından üretilir`;
  }
  document.getElementById("memInput").value = egg.memory_mb;
  box.innerHTML = egg.variables.map((v) => `
    <div>
      <label>${esc(v.name)}${v.description ? " · " + esc(v.description) : ""}</label>
      <input data-var="${esc(v.name)}" value="${esc(v.default ?? "")}">
    </div>`).join("");
}

/* Sihirbaz: her adım kendi alanlarını doğrular, son adımda özet gösterilir. */
function setWizStep(form, n) {
  form.dataset.step = String(n);
  form.querySelectorAll(".wiz-step").forEach((s) => { s.hidden = Number(s.dataset.step) !== n; });
  form.querySelectorAll("[data-dot]").forEach((d) => d.classList.toggle("on", Number(d.dataset.dot) <= n));
  form.querySelector(".wiz-back").hidden = n === 1;
  form.querySelector(".wiz-next").hidden = n === 3;
  form.querySelectorAll(".wiz-submit").forEach((b) => { b.hidden = n !== 3; });
  if (n === 3) renderWizSummary(form);
}

function wizNext(form) {
  const step = Number(form.dataset.step);
  const current = form.querySelector(`.wiz-step[data-step="${step}"]`);
  for (const el of current.querySelectorAll("input, select")) {
    if (!el.checkValidity()) { el.reportValidity(); return; }
  }
  setWizStep(form, step + 1);
}

function wizBack(form) {
  setWizStep(form, Math.max(1, Number(form.dataset.step) - 1));
}

function renderWizSummary(form) {
  const egg = (state.eggs || []).find((e) => e.slug === fv(form, "egg"));
  document.getElementById("wizSummary").innerHTML =
    `<strong>${esc(fv(form, "name"))}</strong> · ${esc(egg ? egg.name : "")}<br>` +
    `RAM ${esc(fv(form, "memory"))} MB · CPU %${esc(fv(form, "cpu"))}` +
    (form.querySelector('[name="owner_id"]')
      ? ` · Sahibi: ${esc(form.querySelector('[name="owner_id"]').selectedOptions[0].textContent)}` : "");
}

async function onCreateServer(form) {
  const variables = {};
  form.querySelectorAll("[data-var]").forEach((el) => { variables[el.dataset.var] = el.value; });
  const msg = document.getElementById("createMsg");
  msg.textContent = "Oluşturuluyor, kurulum birkaç dakika sürebilir...";
  try {
    const s = await api("/servers", {
      method: "POST",
      body: {
        name: fv(form, "name"),
        egg: fv(form, "egg"),
        memory_mb: Number(fv(form, "memory")),
        cpu_percent: Number(fv(form, "cpu")),
        variables,
        site_slug: fv(form, "site_slug").trim().toLowerCase(),
        duration: fv(form, "duration") || "unlimited",
        duration_days: fv(form, "duration") === "custom" ? Number(fv(form, "duration_days")) : undefined,
        owner_id: state.user.is_admin && fv(form, "owner_id") ? Number(fv(form, "owner_id")) : undefined,
      },
    });
    celebrate("Sunucu oluşturuldu");
    location.hash = `#/server/${s.id}/console`;
  } catch (e) {
    msg.textContent = "";
    toast(e.message, true);
  }
}

/* ---------- sunucu sayfası (sol menü · ana alan · istatistik kartları) ---------- */
function sparkline(values, max) {
  const w = 300, h = 110;
  const n = values.length;
  if (n < 2) return `<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"></svg>`;
  const top = Math.max(max || 1, 1);
  const pts = values.map((v, i) => {
    const x = (i / (n - 1)) * w;
    const y = h - Math.min(v / top, 1) * (h - 8) - 4;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(" ");
  return `<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">
    <polygon points="0,${h} ${pts} ${w},${h}" fill="rgba(245,165,36,.14)"/>
    <polyline points="${pts}" fill="none" stroke="#f5a524" stroke-width="2" vector-effect="non-scaling-stroke"/>
  </svg>`;
}

async function renderServerPage(id, tab) {
  if (state.sid !== id) {
    state.filePath = "";
    state.editPath = null;
    state.hist = { cpu: [], mem: [] };
  }
  state.sid = id;
  if (!state.eggs) state.eggs = await api("/eggs");
  let server;
  try {
    server = await api(`/servers/${id}`);
  } catch (e) {
    app().innerHTML = `<div class="card error">${esc(e.message)}</div>`;
    return;
  }
  state.server = server;
  const egg = state.eggs.find((e) => e.slug === server.egg);
  const perms = server.my_permissions || [];
  const isOwner = perms.includes("owner");
  const isApiEgg = !!egg && APP_EGG_CATEGORIES.includes(String(egg.category).toLowerCase());

  app().innerHTML = `
    ${server.expires_at ? `<div class="banner ${daysLeft(server.expires_at) <= 3 ? "banner-warn" : ""}">⏳ Süre: <b>${esc(daysLeftText(server.expires_at))}</b> · bitiş ${esc(new Date(server.expires_at).toLocaleString("tr-TR"))}</div>` : ""}
    ${server.maintenance && !state.user?.is_admin ? `<div class="banner maint">🛠️ Bu sunucu bakımda${server.maintenance_message ? ": " + esc(server.maintenance_message) : "."}</div>` : ""}
    <div class="server-layout">
      <aside class="sidebar">
        <a data-tab="console" href="#/server/${id}/console"><span class="ico">${icon("terminal")}</span>Terminal</a>
        ${perms.includes("files") || isOwner ? `<a data-tab="files" href="#/server/${id}/files"><span class="ico">${icon("folder")}</span>Dosyalar</a>` : ""}
        ${perms.includes("files") || isOwner ? `<a data-tab="backups" href="#/server/${id}/backups"><span class="ico">${icon("folder")}</span>Yedekler</a>` : ""}
        ${perms.includes("settings") || isOwner ? `<a data-tab="settings" href="#/server/${id}/settings"><span class="ico">${icon("settings")}</span>Ayarlar</a>` : ""}
        ${isApiEgg && (perms.includes("console") || isOwner) ? `<a data-tab="api" href="#/server/${id}/api"><span class="ico">${icon("activity")}</span>API</a>` : ""}
        ${server.site_url && !isApiEgg ? `<a href="${esc(server.site_url)}" target="_blank" rel="noopener"><span class="ico">${icon("globe")}</span>Site ${icon("external", 12)}</a>` : ""}
        <div class="sep"></div>
        <a href="#/"><span class="ico">${icon("arrowLeft")}</span>Tüm sunucular</a>
      </aside>

      <section class="server-main">
        <div class="card server-head">
          <div>
            <h2>${esc(server.name)}</h2>
            <div class="muted"><span class="dot ${esc(server.status)}" id="statusDot"></span><span id="statusText">${esc(server.status)}</span> · ${esc(egg ? egg.name : server.egg)}</div>
          </div>
          <div class="power" ${perms.includes("power") ? "" : "hidden"}>
            <button class="ok" data-act="power" data-action="start">${icon("play", 14)} Başlat</button>
            <button class="warn" data-act="power" data-action="restart">${icon("restart", 14)} Yeniden başlat</button>
            <button class="danger" data-act="reinstall">${icon("restart", 14)} Yeniden kur</button>
            <button class="danger" data-act="power" data-action="stop">${icon("stop", 14)} Durdur</button>
            <button class="solid-danger" data-act="power" data-action="kill">${icon("power", 14)} Zorla kapat</button>
          </div>
        </div>

        <div id="tab"></div>

        <div class="charts">
          <div class="card">
            <h4 class="label">CPU</h4>
            <div class="chart" id="cpuChart"></div>
            <div class="legend"><span id="cpuLegend">–</span><span>%100 = 1 çekirdek</span></div>
          </div>
          <div class="card">
            <h4 class="label">Bellek</h4>
            <div class="chart" id="memChart"></div>
            <div class="legend"><span id="memLegend">–</span><span id="memLimit"></span></div>
          </div>
        </div>
      </section>

      <aside class="stats-col">
        <div class="stat-card"><div class="k">Adres</div><div class="v" style="font-size:15px">${esc(server.address)}</div></div>
        <div class="stat-card"><div class="k">Çalışma süresi</div><div class="v" id="stUptime">–</div></div>
        <div class="stat-card"><div class="k">CPU</div><div class="v" id="stCpu">–</div><div class="bar"><i id="cpuBar"></i></div></div>
        <div class="stat-card"><div class="k">Bellek</div><div class="v" id="stMem">–</div><div class="bar"><i id="memBar"></i></div></div>
        <div class="stat-card"><div class="k">Disk</div><div class="v" id="stDisk">–</div><div class="sub">sunucu klasörü</div></div>
        <div class="stat-card"><div class="k">Öneriler</div><div class="sub" id="stSuggest" style="line-height:1.5">–</div></div>
      </aside>
    </div>`;

  refreshServer(id);
  timers.push(setInterval(() => refreshServer(id), 4000));
  showTab(tab);
}

async function refreshServer(id) {
  if (state.sid !== id || !document.getElementById("statusText")) return;
  try {
    const [s, st] = await Promise.all([api(`/servers/${id}`), api(`/servers/${id}/stats`)]);
    if (state.sid !== id || !document.getElementById("statusText")) return;
    state.server = s;

    document.getElementById("statusText").textContent = s.status;
    document.getElementById("statusDot").className = "dot " + s.status;

    const memPct = st.memory_limit_mb ? Math.min(100, (st.memory_mb / st.memory_limit_mb) * 100) : 0;
    document.getElementById("stUptime").textContent = st.running ? fmtDuration(st.uptime_seconds) : "—";
    document.getElementById("stCpu").textContent = st.running ? `${st.cpu_percent}%` : "Kapalı";
    document.getElementById("cpuBar").style.width = Math.min(100, st.cpu_percent) + "%";
    document.getElementById("stMem").textContent = `${st.memory_mb} / ${st.memory_limit_mb} MB`;
    document.getElementById("memBar").style.width = memPct + "%";
    document.getElementById("stDisk").textContent = `${st.disk_mb ?? 0} MB`;
    const sug = [];
    const isVps = (() => { const eg = (state.eggs || []).find((e) => e.slug === s.egg); return !!eg && String(eg.category).toLowerCase() === "vps"; })();
    if (!st.running) sug.push("Sunucu kapalı. Kullanmadığınızda kapalı tutmak kaynak tasarrufu sağlar.");
    if (st.running && memPct >= 85) sug.push("Bellek sınırına yakınsınız. Daha fazla RAM için paket yükseltmeyi düşünün.");
    if (st.running && st.cpu_percent >= 85) sug.push("CPU sürekli yüksek. Uygulamayı optimize edin veya CPU limitini artırın.");
    if (st.running && memPct > 0 && memPct < 20 && st.uptime_seconds > 3600) sug.push("Kaynak kullanımınız düşük. Daha küçük bir paket yeterli olabilir.");
    if (isVps && st.running && memPct >= 70) sug.push("Paket önbelleğini temizlemek için terminalde: apt clean");
    document.getElementById("stSuggest").innerHTML = sug.length ? sug.map((x) => "• " + esc(x)).join("<br>") : "Her şey yolunda.";

    state.hist.cpu = [...state.hist.cpu, st.running ? st.cpu_percent : 0].slice(-60);
    state.hist.mem = [...state.hist.mem, st.memory_mb].slice(-60);
    const cpuMax = Math.max(100, ...state.hist.cpu);
    document.getElementById("cpuChart").innerHTML = sparkline(state.hist.cpu, cpuMax);
    document.getElementById("memChart").innerHTML = sparkline(state.hist.mem, st.memory_limit_mb);
    document.getElementById("cpuLegend").textContent = st.running ? `Anlık ${st.cpu_percent}%` : "Kapalı";
    document.getElementById("memLegend").textContent = `Anlık ${st.memory_mb} MB`;
    document.getElementById("memLimit").textContent = `Limit ${st.memory_limit_mb} MB`;
  } catch { /* geçici hata: bir sonraki turda tekrar dene */ }
}

function showTab(tab) {
  document.querySelectorAll(".sidebar a[data-tab]").forEach((a) => a.classList.toggle("active", a.dataset.tab === tab));
  if (tab === "files") return renderFiles();
  if (tab === "backups") return renderBackups();
  if (tab === "settings") return renderSettings();
  if (tab === "api") return renderApi();
  if (tab === "console" && isVpsServer()) return renderVpsTerminal();
  return renderConsole();
}

/* ---- VPS web terminali (1.30.0): sunucu detayında, alt alan adı gerektirmez ---- */
const vpsTerm = { term: null, fit: null, onResize: null, sid: null, sidServer: null, alive: false, timer: null };

function isVpsServer() {
  const egg = (state.eggs || []).find((e) => e.slug === state.server?.egg);
  return !!egg && String(egg.category).toLowerCase() === "vps";
}

function closeVpsTerminal() {
  vpsTerm.alive = false;
  if (vpsTerm.timer) { clearTimeout(vpsTerm.timer); vpsTerm.timer = null; }
  if (vpsTerm.onResize) { window.removeEventListener("resize", vpsTerm.onResize); vpsTerm.onResize = null; }
  if (vpsTerm.sid && vpsTerm.sidServer) {
    api(`/vps/${vpsTerm.sidServer}/terminal/sessions/${vpsTerm.sid}`, { method: "DELETE" }).catch(() => {});
  }
  vpsTerm.sid = null;
  vpsTerm.sidServer = null;
  if (vpsTerm.term) { vpsTerm.term.dispose(); vpsTerm.term = null; }
  vpsTerm.fit = null;
}

let xtermLoading = null;
function loadXterm() {
  if (window.Terminal && window.FitAddon) return Promise.resolve();
  if (xtermLoading) return xtermLoading;
  if (!document.querySelector('link[data-xterm]')) {
    const css = document.createElement("link");
    css.rel = "stylesheet";
    css.href = "/static/vendor/xterm/xterm.css";
    css.dataset.xterm = "1";
    document.head.appendChild(css);
  }
  const load = (src) => new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = src;
    s.onload = resolve;
    s.onerror = () => reject(new Error("Terminal bileşeni yüklenemedi: " + src));
    document.head.appendChild(s);
  });
  xtermLoading = load("/static/vendor/xterm/xterm.js")
    .then(() => load("/static/vendor/xterm/addon-fit.js"))
    .catch((e) => { xtermLoading = null; throw e; });
  return xtermLoading;
}

function renderVpsTerminal() {
  const id = state.sid;
  const reuse = !!(vpsTerm.term && vpsTerm.sid && vpsTerm.sidServer === id && vpsTerm.alive);
  if (!reuse) closeVpsTerminal();
  document.getElementById("tab").innerHTML = `
    <section class="card vps-card">
      <div class="row between">
        <div>
          <strong>Terminal</strong>
          <span class="muted small-text" id="vpsState">Bağlanıyor…</span>
        </div>
        <div class="row">
          <button data-act="vpsDiagnose">Tanıla</button>
          <button data-act="vpsReconnect">Yeniden bağlan</button>
        </div>
      </div>
      <div id="vpsScreen" class="vps-screen"></div>
      <div id="vpsDiag" style="margin-top:12px"></div>
      <p class="muted small-text">Ubuntu ortamında <code>apt</code>, <code>nano</code>, <code>vim</code> ve diğer komutları kullanabilirsiniz. Sekmeyi kapatınca oturum kapanır.</p>
    </section>`;
  if (reuse) {
    const screen = document.getElementById("vpsScreen");
    if (screen) screen.appendChild(vpsTerm.term.element);
    vpsTerm.fit.fit();
    vpsTerm.term.focus();
    setVpsState("Bağlı", false);
    return;
  }
  loadXterm()
    .then(() => { if (state.sid === id) connectVpsTerminal(id); })
    .catch((e) => setVpsState(e.message, true));
}

function setVpsState(text, bad) {
  const el = document.getElementById("vpsState");
  if (!el) return;
  el.textContent = text;
  el.style.color = bad ? "var(--danger, #f87171)" : "";
}

function b64ToBytes(b64) {
  const bin = atob(b64);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function connectVpsTerminal(id) {
  closeVpsTerminal();
  const screen = document.getElementById("vpsScreen");
  if (!screen) return;
  const term = new Terminal({
    cursorBlink: true,
    fontSize: 14,
    fontFamily: "ui-monospace, Consolas, Menlo, monospace",
    theme: { background: "#0b0d10", foreground: "#e6edf3", cursor: "#f5a524" },
    scrollback: 5000,
  });
  const fit = new FitAddon.FitAddon();
  term.loadAddon(fit);
  term.open(screen);
  fit.fit();
  vpsTerm.term = term;
  vpsTerm.fit = fit;
  vpsTerm.alive = true;
  setVpsState("Bağlanıyor…", false);

  let sid;
  try {
    sid = (await api(`/vps/${id}/terminal/sessions`, { method: "POST", body: {} })).sid;
  } catch (e) {
    if (vpsTerm.term === term) {
      term.write("\r\n\x1b[31m[hata] " + e.message + "\x1b[0m\r\n");
      setVpsState(e.message, true);
    }
    vpsTerm.alive = false;
    return;
  }
  if (vpsTerm.term !== term) {
    api(`/vps/${id}/terminal/sessions/${sid}`, { method: "DELETE" }).catch(() => {});
    return;
  }
  vpsTerm.sid = sid;
  vpsTerm.sidServer = id;
  setVpsState("Bağlı", false);
  term.focus();

  const base = `/vps/${id}/terminal/sessions/${sid}`;
  const sendSize = () => api(`${base}/resize`, { method: "POST", body: { cols: term.cols, rows: term.rows } }).catch(() => {});
  sendSize();
  // Tuşlar tek bir istek uçuştayken biriktirilip toplu gönderilir (1.40.23):
  // her tuş için ayrı gidip-gelme yapılmaz, sıra da korunur.
  let pending = "";
  let flying = false;
  const flushInput = async () => {
    if (flying || !pending) return;
    const data = pending;
    pending = "";
    flying = true;
    try {
      await api(`${base}/input`, { method: "POST", body: { data } });
    } catch { /* kopma: yeniden bağlanma döngüsü halleder */ }
    flying = false;
    if (pending) flushInput();
  };
  term.onData((data) => {
    pending += data;
    flushInput();
  });
  const sendText = (text) => {
    if (!text) return;
    pending += text.replace(/\r?\n/g, "\r");
    flushInput();
  };
  // Ctrl+Shift+C: seçimi kopyala. Ctrl+C: seçim varsa kopyala, yoksa normal ^C gönderilir.
  // Ctrl+Shift+V ve Ctrl+V: panodan yapıştır.
  term.attachCustomKeyEventHandler((e) => {
    if (e.type !== "keydown") return true;
    const k = e.key.toLowerCase();
    if (e.ctrlKey && e.shiftKey && k === "c") {
      const sel = term.getSelection();
      if (sel) navigator.clipboard?.writeText(sel).catch(() => {});
      return false;
    }
    if (e.ctrlKey && !e.shiftKey && k === "c" && term.hasSelection()) {
      navigator.clipboard?.writeText(term.getSelection()).catch(() => {});
      term.clearSelection();
      return false;
    }
    if (e.ctrlKey && e.shiftKey && k === "v") {
      e.preventDefault();
      navigator.clipboard?.readText().then(sendText).catch(() => toast("Panoya erişim izni verilmedi", true));
      return false;
    }
    return true;
  });
  // Ctrl+V ve sağ tık yapıştırma: tarayıcının paste olayını kendimiz yakalayıp gönderiyoruz.
  const onPaste = (e) => {
    const text = e.clipboardData && e.clipboardData.getData("text");
    if (!text) return;
    e.preventDefault();
    e.stopPropagation();
    sendText(text);
  };
  screen.addEventListener("paste", onPaste, true);
  vpsTerm.onPaste = () => screen.removeEventListener("paste", onPaste, true);
  vpsTerm.onResize = () => { if (vpsTerm.fit && vpsTerm.term) { vpsTerm.fit.fit(); sendSize(); } };
  window.addEventListener("resize", vpsTerm.onResize);

  const decoder = new TextDecoder();
  let after = 0;
  let failures = 0;
  const poll = async () => {
    if (!vpsTerm.alive || vpsTerm.term !== term) return;
    try {
      const r = await api(`${base}/output?after=${after}&wait=15`);
      failures = 0;
      for (const [, b64] of r.chunks) term.write(decoder.decode(b64ToBytes(b64), { stream: true }));
      after = r.next;
      if (r.closed) {
        const code = r.exit_code != null ? ", çıkış kodu " + r.exit_code : "";
        term.write("\r\n\x1b[33m[kabuk kapandı" + code + "] Yeniden bağlanmak için 'Yeniden bağlan' düğmesini kullanın.\x1b[0m\r\n");
        setVpsState("Bağlantı kesildi", true);
        vpsTerm.alive = false;
        return;
      }
    } catch (e) {
      failures += 1;
      // Oturum sunucuda yok (ör. uzun kopmadan sonra temizlendi): otomatik yeniden bağla.
      if (e.status === 404) {
        setVpsState("Yeniden bağlanıyor…", false);
        vpsTerm.alive = false;
        vpsTerm.timer = setTimeout(() => {
          if (vpsTerm.term === term && state.sid === id) connectVpsTerminal(id);
        }, 800);
        return;
      }
      // Geçici kopma: vazgeçmeden artan aralıkla yeniden dene.
      if (failures === 3) setVpsState("Bağlantı yavaş, yeniden deneniyor…", true);
    }
    const delay = failures ? Math.min(10000, 1000 * failures) : 0;
    vpsTerm.timer = setTimeout(poll, delay);
  };
  poll();
}

async function power(action) {
  try {
    const r = await api(`/servers/${state.sid}/power`, { method: "POST", body: { action } });
    toast(`Durum: ${r.status}`);
    refreshServer(state.sid);
  } catch (e) { toast(e.message, true); }
}

/* ---------- konsol ---------- */
function closeConsole() {
  if (state.ws) {
    const ws = state.ws;
    state.ws = null;
    ws.onclose = null;
    try { ws.close(); } catch { /* zaten kapalı */ }
  }
}

/* Sekme değişince konsol metni kaybolmasın: son çıktı burada tutulur (1.40.20). */
const consoleCache = { sid: null, text: "" };
function keepConsole(raw) {
  if (consoleCache.sid !== state.sid) { consoleCache.sid = state.sid; consoleCache.text = ""; }
  consoleCache.text = (consoleCache.text + raw.replace(/\x1b\[[0-9;?]*[A-Za-z]/g, "")).slice(-200000);
}
function printConsole(text) {
  const el = document.getElementById("console");
  if (el) appendLog(el, text);
  keepConsole(text);
}

function appendLog(el, text) {
  const clean = text.replace(/\x1b\[[0-9;?]*[A-Za-z]/g, "");
  const nearBottom = el.scrollTop + el.clientHeight >= el.scrollHeight - 40;
  el.textContent += clean;
  if (el.textContent.length > 300000) el.textContent = el.textContent.slice(-200000);
  if (nearBottom) el.scrollTop = el.scrollHeight;
}

function setConn(text) {
  const el = document.getElementById("connState");
  if (el) el.textContent = text;
}

// Paket önerileri: her satırda paketin ne işe yaradığı görünür; tıklanınca kurulacaklara eklenir.
const PKG_SUGGEST = {
  npm: [
    ["express", "Web sunucusu ve API için en yaygın çatı"],
    ["socket.io", "Gerçek zamanlı iki yönlü iletişim (sohbet, canlı veri)"],
    ["discord.js", "Discord botları yazmak için"],
    ["axios", "HTTP istekleri yapmak için"],
    ["dotenv", ".env dosyasındaki ayarları ortam değişkeni olarak okur"],
    ["mongoose", "MongoDB için veri modelleme"],
    ["bcrypt", "Parolaları güvenli biçimde şifreler (hash)"],
    ["jsonwebtoken", "Giriş ve oturum belirteçleri (JWT) üretir"],
    ["cors", "Tarayıcıdan farklı alan adlarına izin verir"],
    ["nodemailer", "E-posta göndermek için"],
  ],
  pip: [
    ["requests", "HTTP istekleri (en yaygın kütüphane)"],
    ["flask", "Küçük web uygulamaları ve API'ler"],
    ["fastapi", "Hızlı, tip destekli API çatısı"],
    ["discord.py", "Discord botları yazmak için"],
    ["python-dotenv", ".env dosyasındaki ayarları ortam değişkeni olarak okur"],
    ["pandas", "Tablo verisi işleme ve analiz"],
    ["numpy", "Sayısal hesaplama ve diziler"],
    ["pillow", "Resim açma, düzenleme ve dönüştürme"],
    ["beautifulsoup4", "HTML sayfalarından veri çekmek için"],
    ["sqlalchemy", "Veritabanı için ORM (tablo yerine nesne ile çalışma)"],
  ],
};

function pkgSuggestHtml() {
  const rows = Object.entries(PKG_SUGGEST).flatMap(([manager, list]) =>
    list.map(([name, feature]) => `
      <li>
        <button type="button" data-act="pkgPick" data-manager="${manager}" data-name="${name}">
          <span class="badge">${manager}</span>
          <b>${esc(name)}</b>
          <span class="muted">${esc(feature)}</span>
        </button>
      </li>`));
  return `<ul class="pkg-suggest">${rows.join("")}</ul>`;
}

function renderConsole() {
  document.getElementById("tab").innerHTML = `
    <section class="card pkg-card">
      <div class="row between">
        <strong>Paket kur</strong>
        <span class="muted small-text">Komutlar konteyner içinde çalışır; çıktı aşağıdaki konsolda görünür</span>
      </div>
      <div class="row" style="margin-top:8px">
        <button data-act="pkgDeps" data-manager="npm">npm install (bağımlılıklar)</button>
        <button data-act="pkgDeps" data-manager="pip">pip install -r requirements.txt</button>
      </div>
      <form id="pkgForm" class="api-req" style="margin-top:10px">
        <select name="manager" aria-label="Paket yöneticisi"><option value="npm">npm</option><option value="pip">pip</option></select>
        <input name="packages" placeholder="paket adları, ör. express socket.io" spellcheck="false" required maxlength="500">
        <button class="primary" type="submit">Kur</button>
      </form>
      ${pkgSuggestHtml()}
      <div id="pkgScan" style="margin-top:12px">
        <button type="button" class="small" data-pl="scanPackages">Eksik paketleri tara</button>
        <span class="muted small-text"> Koddaki import ve require satırlarını okur.</span>
      </div>
    </section>
    <section class="card">
      <pre class="console" id="console"></pre>
      <form class="cmd" id="cmdForm">
        <span class="prompt">&gt;</span>
        <input id="cmdInput" name="command" placeholder="Programa yanıt yaz, ya da $ ile konteynerde komut çalıştır (ör. $ pip install requests)" autocomplete="off" spellcheck="false">
        <button type="submit">Gönder</button>
      </form>
      <div class="muted small-text">Düz yazı çalışan programın girdisine gider (ör. Python input() cevabı). "$" ile başlayan satırlar konteyner içinde ayrı bir kabuk komutu olarak çalışır.</div>
      <div class="muted small-text" id="connState">Bağlanıyor...</div>
    </section>`;
  const out = document.getElementById("console");
  const live = state.ws && state.ws.readyState === WebSocket.OPEN && state.wsSid === state.sid;
  if (live && consoleCache.sid === state.sid) {
    out.textContent = consoleCache.text;
    out.scrollTop = out.scrollHeight;
    setConn("Bağlı");
  } else {
    connectConsole(0);
  }
  document.getElementById("cmdInput").addEventListener("keydown", onCmdKey);
}

/* Bağlantı koparsa üssel bekleme ile (1, 2, 4 … en çok 15 sn) yeniden bağlanır. */
function connectConsole(attempt) {
  const out = document.getElementById("console");
  if (!out) return;
  const proto = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(
    `${proto}://${location.host}/api/servers/${state.sid}/console?token=${encodeURIComponent(state.token)}`
  );
  state.ws = ws;
  state.wsSid = state.sid;
  ws.onopen = () => {
    if (attempt > 0) {
      // Sunucu son satırları yeniden gönderir; çiftlenmemesi için ekranı temizleyip işaretleyelim
      out.textContent = "";
      consoleCache.text = "";
      consoleCache.sid = state.sid;
      printConsole("— yeniden bağlandı —\n");
    }
    attempt = 0;
    setConn("Bağlı");
  };
  ws.onmessage = (ev) => {
    let msg;
    try { msg = JSON.parse(ev.data); } catch { return; }
    if (msg.type === "log") printConsole(msg.data);
    else if (msg.type === "error") toast(msg.message, true);
  };
  ws.onclose = (ev) => {
    if (state.ws !== ws) return; // sayfa değişti ya da yeni bağlantı açıldı
    if (ev.code === 4401) { setConn("Yetki reddedildi"); return; }
    if (!document.getElementById("console")) return;
    const wait = Math.min(15000, 1000 * 2 ** attempt);
    setConn(`Bağlantı koptu, ${Math.round(wait / 1000)} sn içinde yeniden denenecek`);
    setTimeout(() => {
      if (state.ws === ws && document.getElementById("console")) connectConsole(attempt + 1);
    }, wait);
  };
}

function onCmdKey(e) {
  const input = e.target;
  if (e.key === "ArrowUp" && state.history.length) {
    state.historyPos = Math.min(state.historyPos + 1, state.history.length - 1);
    input.value = state.history[state.historyPos];
    e.preventDefault();
  } else if (e.key === "ArrowDown") {
    state.historyPos = Math.max(state.historyPos - 1, -1);
    input.value = state.historyPos >= 0 ? state.history[state.historyPos] : "";
    e.preventDefault();
  }
}

/* Konsoldaki "$" kanalından konteyner içinde kabuk komutu gönderir. */
function sendShellCommand(cmd) {
  const ws = state.ws;
  if (!ws || ws.readyState !== WebSocket.OPEN) { toast("Konsola bağlı değil", true); return false; }
  ws.send(JSON.stringify({ type: "command", data: "$ " + cmd }));
  printConsole(`> $ ${cmd}\n`);
  return true;
}

const NPM_PKG_RE = /^(@[a-z0-9][\w.-]*\/)?[a-z0-9][\w.-]*(@[\w.^~<>=*+-]+)?$/i;
const PIP_PKG_RE = /^[A-Za-z0-9][A-Za-z0-9._-]*(\[[A-Za-z0-9,._-]+\])?([<>=!~]=?[A-Za-z0-9.*+!_-]+)?$/;

function onPackageInstall(form) {
  const manager = fv(form, "manager");
  const names = fv(form, "packages").trim().split(/\s+/).filter(Boolean);
  if (!names.length) return;
  if (names.length > 20) { toast("Tek seferde en fazla 20 paket", true); return; }
  const re = manager === "npm" ? NPM_PKG_RE : PIP_PKG_RE;
  const bad = names.find((n) => !re.test(n));
  if (bad) { toast(`Geçersiz paket adı: ${bad}`, true); return; }
  const quoted = names.map((n) => `'${n}'`).join(" ");
  const cmd = manager === "npm"
    ? `npm install --no-audit --no-fund ${quoted}`
    : `pip install --no-cache-dir ${quoted}`;
  if (sendShellCommand(cmd)) form.querySelector('[name="packages"]').value = "";
}

function onSendCommand(form) {
  const text = fv(form, "command").trim();
  if (!text) return;
  const ws = state.ws;
  if (!ws || ws.readyState !== WebSocket.OPEN) { toast("Konsola bağlı değil", true); return; }
  ws.send(JSON.stringify({ type: "command", data: text }));
  state.history.unshift(text);
  state.history = state.history.slice(0, 50);
  state.historyPos = -1;
  printConsole(`> ${text}\n`);
  form.querySelector('[name="command"]').value = "";
}

/* ---------- dosyalar ---------- */
const MAX_UPLOAD_MB = 100;

/* ---- 1.32.0: sunucu yedekleri ---- */
async function renderBackups() {
  const box = document.getElementById("tab");
  box.innerHTML = `<section class="card"><p class="muted">Yedekler yükleniyor…</p></section>`;
  try {
    const data = await api(`/servers/${state.sid}/backups`);
    const srv = state.server || {};
    const maintCard = state.user?.is_admin ? `
      <section class="card" style="margin-bottom:12px">
        <strong>Bakım modu (yönetici)</strong>
        <p class="muted small-text">Açıkken bu sunucunun sitesi bakım sayfası gösterir ve terminal açılmaz.</p>
        <div class="grid2" style="margin-top:8px">
          <div><label class="check"><input type="checkbox" id="maintOn" ${srv.maintenance ? "checked" : ""}> Bu sunucu bakımda</label></div>
          <div><label>Müşteriye gösterilecek mesaj</label><input id="maintMsg" maxlength="300" value="${esc(srv.maintenance_message || "")}" placeholder="Örn. Gece 02:00 - 03:00 arası bakım"></div>
        </div>
        <div class="row" style="margin-top:10px;justify-content:flex-end"><button class="primary" data-act="serverMaintenanceSave">Kaydet</button></div>
      </section>` : "";
    const rows = data.items.map((b) => `
      <tr>
        <td>${esc(new Date(b.created_at).toLocaleString("tr-TR"))}</td>
        <td>${(b.size_bytes / 1024 / 1024).toFixed(2)} MB</td>
        <td class="row" style="gap:6px;justify-content:flex-end">
          <button data-act="backupRestore" data-name="${esc(b.name)}">Geri yükle</button>
          <button class="danger" data-act="backupDelete" data-name="${esc(b.name)}">Sil</button>
        </td>
      </tr>`).join("");
    const sc = data.schedule || { mode: "off", hour: 4, keep: data.max, last_run: null };
    const hourOpts = Array.from({ length: 24 }, (_, h) =>
      `<option value="${h}"${h === sc.hour ? " selected" : ""}>${String(h).padStart(2, "0")}:00</option>`).join("");
    const keepOpts = Array.from({ length: 30 }, (_, i) => i + 1)
      .map((n) => `<option value="${n}"${n === sc.keep ? " selected" : ""}>${n}</option>`).join("");
    const schedCard = `
      <section class="card" style="margin-bottom:12px">
        <div class="row between">
          <div>
            <strong>Otomatik yedek</strong>
            <span class="muted small-text">Saat Türkiye saatiyle (UTC+3). Kaçırılan yedek, panel açılınca telafi edilir.</span>
          </div>
        </div>
        <div class="grid3" style="margin-top:10px">
          <div><label>Sıklık</label>
            <select id="bsMode">
              <option value="off"${sc.mode === "off" ? " selected" : ""}>Kapalı</option>
              <option value="daily"${sc.mode === "daily" ? " selected" : ""}>Her gün</option>
              <option value="weekly"${sc.mode === "weekly" ? " selected" : ""}>Her hafta (pazartesi)</option>
            </select></div>
          <div><label>Saat</label><select id="bsHour">${hourOpts}</select></div>
          <div><label>Saklanacak yedek sayısı</label><select id="bsKeep">${keepOpts}</select></div>
        </div>
        <div class="row" style="margin-top:10px;justify-content:space-between;align-items:center">
          <span class="muted small-text">${sc.last_run ? `Son otomatik yedek: ${esc(sc.last_run)}` : "Henüz otomatik yedek alınmadı."} Daha eski yedekler saklama sayısını aşınca silinir.</span>
          <button class="primary" data-act="backupScheduleSave">Kaydet</button>
        </div>
      </section>`;
    box.innerHTML = maintCard + schedCard + `
      <section class="card">
        <div class="row between">
          <div>
            <strong>Yedekler</strong>
            <span class="muted small-text">En fazla ${data.max} yedek saklanır. Geri yüklemek için sunucu kapalı olmalı.</span>
          </div>
          <button class="primary" data-act="backupCreate">Yedek al</button>
        </div>
        ${data.items.length ? `
        <div class="table-wrap" style="margin-top:10px"><table>
          <thead><tr><th>Tarih</th><th>Boyut</th><th></th></tr></thead>
          <tbody>${rows}</tbody>
        </table></div>` : `<p class="muted" style="margin-top:10px">Henüz yedek yok.</p>`}
      </section>
`;
  } catch (e) {
    box.innerHTML = `<section class="card"><div class="error">${esc(e.message)}</div></section>`;
  }
}

async function renderFiles() {
  let listing;
  try {
    listing = await api(`/servers/${state.sid}/files?path=${encodeURIComponent(state.filePath)}`);
  } catch (e) {
    document.getElementById("tab").innerHTML = `<section class="card"><div class="error">${esc(e.message)}</div></section>`;
    return;
  }
  // Seçimler yalnızca görünen klasördeki öğeler için geçerli kalır
  const visible = new Set(listing.entries.map((e) => e.path));
  state.picked = new Set([...(state.picked || [])].filter((p) => visible.has(p)));

  const parts = listing.path ? listing.path.split("/") : [];
  const crumbs = [`<button class="link" data-act="cd" data-path="">Kök</button>`]
    .concat(parts.map((p, i) => ` / <button class="link" data-act="cd" data-path="${esc(parts.slice(0, i + 1).join("/"))}">${esc(p)}</button>`))
    .join("");
  const up = listing.path
    ? `<tr><td></td><td><button class="link" data-act="cd" data-path="${esc(parts.slice(0, -1).join("/"))}">${icon("folder", 14)} ..</button></td><td></td><td></td><td></td></tr>`
    : "";
  const rows = listing.entries.map((e) => `
    <tr>
      <td class="pick-cell"><input type="checkbox" class="pick" value="${esc(e.path)}" aria-label="${esc(e.name)} seç" ${state.picked.has(e.path) ? "checked" : ""}></td>
      <td><button class="link" data-act="${e.is_dir ? "cd" : "openFile"}" data-path="${esc(e.path)}">${e.is_dir ? icon("folder", 14) : icon("file", 14)} ${esc(e.name)}</button></td>
      <td class="muted">${e.is_dir ? "" : fmtSize(e.size)}</td>
      <td class="muted">${esc(fmtDate(e.modified))}</td>
      <td class="right row-actions">
        ${e.is_dir ? "" : `<button class="small" data-act="downloadEntry" data-path="${esc(e.path)}" data-name="${esc(e.name)}">İndir</button>`}
        ${!e.is_dir && /\.zip$/i.test(e.name) ? `<button class="small" data-act="extractZip" data-path="${esc(e.path)}">Aç</button>` : ""}
        <button class="danger small" data-act="delEntry" data-path="${esc(e.path)}" data-name="${esc(e.name)}">Sil</button>
      </td>
    </tr>`).join("");
  const allPicked = listing.entries.length > 0 && listing.entries.every((e) => state.picked.has(e.path));

  document.getElementById("tab").innerHTML = `
    <section class="card">
      <div class="row between">
        <div class="crumbs">${crumbs}</div>
        <div class="row">
          <button data-act="uploadPick">${icon("upload", 14)} Dosya yükle</button>
          <button data-act="newFile">+ Dosya</button>
          <button data-act="newFolder">+ Klasör</button>
          <button data-act="refreshFiles">Yenile</button>
        </div>
      </div>
      <div class="row between bulk-bar">
        <label class="check"><input type="checkbox" id="pickAll" ${allPicked ? "checked" : ""} ${listing.entries.length ? "" : "disabled"}> Tümünü seç</label>
        <span class="muted small-text" id="pickCount"></span>
        <button class="danger small" id="bulkDeleteBtn" data-act="bulkDelete" disabled>Seçilenleri sil</button>
      </div>
      <table class="files" style="margin-top:6px"><tbody>
        ${up}${rows || `<tr><td class="muted" colspan="5">Klasör boş.</td></tr>`}
      </tbody></table>
      <input type="file" id="uploadInput" multiple hidden>
      <p class="muted small-text">Yükleme en fazla ${MAX_UPLOAD_MB} MB. Metin dosyaları (en fazla 1 MB) doğrudan düzenlenebilir; "+ Dosya" ile index.js gibi yeni dosyalar oluşturabilirsiniz.</p>
      <div id="editor"></div>
    </section>`;

  syncBulkBar();
  if (state.editPath) openFile(state.editPath, true);
}

function syncBulkBar() {
  const picked = state.picked || new Set();
  const boxes = [...document.querySelectorAll(".pick")];
  const all = document.getElementById("pickAll");
  if (all) all.checked = boxes.length > 0 && boxes.every((b) => b.checked);
  const count = document.getElementById("pickCount");
  if (count) count.textContent = picked.size ? `${picked.size} öğe seçili` : "";
  const del = document.getElementById("bulkDeleteBtn");
  if (del) del.disabled = picked.size === 0;
}

function onPickChange(e) {
  const box = e.target;
  state.picked = state.picked || new Set();
  if (box.checked) state.picked.add(box.value); else state.picked.delete(box.value);
  syncBulkBar();
}

function onPickAll(box) {
  state.picked = state.picked || new Set();
  document.querySelectorAll(".pick").forEach((b) => {
    b.checked = box.checked;
    if (box.checked) state.picked.add(b.value); else state.picked.delete(b.value);
  });
  syncBulkBar();
}

const HL_KW = {
  js: "const let var function return if else for while do switch case break continue new class extends import export from default async await try catch finally throw typeof instanceof this null undefined true false of in yield super",
  py: "def class return if elif else for while in import from as try except finally raise with lambda None True False and or not is pass break continue yield global nonlocal assert async await",
  php: "function return if else elseif for foreach while do switch case break continue new class extends implements public private protected static echo print require require_once include include_once namespace use try catch finally throw null true false array as const",
  sh: "if then else elif fi for while do done case esac function in echo export cd",
  json: "true false null",
};
const HL_RULES = {
  js: [["c", /\/\/[^\n]*|\/\*[\s\S]*?\*\//], ["s", /"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'|`(?:\\[\s\S]|[^`\\])*`/], ["n", /\b\d+(?:\.\d+)?\b/], ["w", /[A-Za-z_$][\w$]*/]],
  py: [["c", /#[^\n]*/], ["s", /"""[\s\S]*?"""|'''[\s\S]*?'''|"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'/], ["n", /\b\d+(?:\.\d+)?\b/], ["w", /[A-Za-z_]\w*/]],
  php: [["c", /\/\/[^\n]*|#[^\n]*|\/\*[\s\S]*?\*\//], ["s", /"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'/], ["v", /\$[A-Za-z_]\w*/], ["n", /\b\d+(?:\.\d+)?\b/], ["w", /[A-Za-z_]\w*/]],
  css: [["c", /\/\*[\s\S]*?\*\//], ["s", /"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'/], ["n", /-?\b\d+(?:\.\d+)?(?:px|em|rem|%|vh|vw|s|ms)?/]],
  html: [["c", /<!--[\s\S]*?-->/], ["tag", /<\/?[A-Za-z][\w:-]*/], ["s", /"[^"]*"|'[^']*'/]],
  json: [["s", /"(?:\\.|[^"\\\n])*"/], ["n", /-?\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b/], ["w", /[A-Za-z]+/]],
  hash: [["c", /#[^\n]*/], ["s", /"(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*'/], ["n", /\b\d+(?:\.\d+)?\b/]],
  sh: [["c", /#[^\n]*/], ["s", /"(?:\\.|[^"\\\n])*"|'[^']*'/], ["v", /\$\{?[A-Za-z_]\w*\}?/], ["n", /\b\d+\b/], ["w", /[A-Za-z_][\w-]*/]],
};
const HL_LANG_BY_EXT = {
  js: "js", mjs: "js", cjs: "js", ts: "js", jsx: "js", json: "json", py: "py", php: "php", css: "css",
  html: "html", htm: "html", xml: "html", yml: "hash", yaml: "hash", env: "hash", conf: "hash", ini: "hash", toml: "hash", sh: "sh",
};

/* Hafif sözdizimi vurgulayıcı. Çıktı düzenleyicinin altındaki katmanda gösterilir; satır sayısı değişmez. */
function highlightCode(code, ext) {
  const lang = HL_LANG_BY_EXT[ext] || "plain";
  const rules = HL_RULES[lang];
  if (!rules) return esc(code);
  const kw = new Set((HL_KW[lang] || "").split(" ").filter(Boolean));
  const re = new RegExp(rules.map((r) => `(${r[1].source})`).join("|"), "g");
  let out = "";
  let last = 0;
  let m;
  while ((m = re.exec(code)) !== null) {
    if (m[0] === "") { re.lastIndex++; continue; }
    out += esc(code.slice(last, m.index));
    const idx = m.slice(1).findIndex((g) => g !== undefined);
    let cls = rules[idx][0];
    if (cls === "w") cls = kw.has(m[0]) ? "k" : "";
    out += cls ? `<span class="t-${cls}">${esc(m[0])}</span>` : esc(m[0]);
    last = m.index + m[0].length;
  }
  return out + esc(code.slice(last));
}

function editorHtml(path, isNew) {
  return `
    <form class="editor" id="editorForm">
      <div class="row between">
        <strong>${esc(path)}</strong>
        <div class="row">
          <button type="button" data-act="closeEditor">Kapat</button>
          <button class="primary" type="submit">${isNew ? "Oluştur ve kaydet" : "Kaydet"}</button>
        </div>
      </div>
      <div class="code-box">
        <div class="code-gutter" aria-hidden="true"></div>
        <div class="code-stage">
          <pre class="code-hl" aria-hidden="true"></pre>
          <textarea name="content" spellcheck="false" wrap="off" aria-label="Dosya içeriği"></textarea>
        </div>
      </div>
    </form>`;
}

/* Textarea'yı vurgulu katmanla ve satır numaralarıyla eşleştirir. */
function mountCodeEditor(content, path) {
  const ta = document.querySelector("#editorForm textarea");
  if (!ta) return;
  const box = ta.closest(".code-box");
  const gutter = box.querySelector(".code-gutter");
  const hl = box.querySelector(".code-hl");
  const ext = (path.split(".").pop() || "").toLowerCase();
  ta.value = content;

  const sync = () => {
    hl.scrollTop = ta.scrollTop;
    hl.scrollLeft = ta.scrollLeft;
    gutter.scrollTop = ta.scrollTop;
  };
  const paint = () => {
    const lines = ta.value.split("\n").length;
    if (Number(gutter.dataset.lines || 0) !== lines) {
      gutter.innerHTML = Array.from({ length: lines }, (_, i) => `<div>${i + 1}</div>`).join("");
      gutter.dataset.lines = String(lines);
    }
    hl.innerHTML = highlightCode(ta.value, ext) + "\n";
    sync();
  };

  ta.addEventListener("input", paint);
  ta.addEventListener("scroll", sync);
  ta.addEventListener("keydown", (e) => {
    if (e.key !== "Tab" || e.shiftKey) return;
    e.preventDefault();
    const s = ta.selectionStart;
    const end = ta.selectionEnd;
    ta.value = ta.value.slice(0, s) + "    " + ta.value.slice(end);
    ta.selectionStart = ta.selectionEnd = s + 4;
    paint();
  });
  paint();
}

async function openFile(path, quiet = false) {
  try {
    const f = await api(`/servers/${state.sid}/files/content?path=${encodeURIComponent(path)}`);
    state.editPath = path;
    state.editNew = false;
    document.getElementById("editor").innerHTML = editorHtml(path, false);
    mountCodeEditor(f.content, path);
  } catch (e) {
    state.editPath = null;
    state.editNew = false;
    if (!quiet) toast(e.message, true);
  }
}

async function openNewFile(path) {
  // Aynı adda dosya varsa üzerine yazmamak için onu açar
  try {
    await api(`/servers/${state.sid}/files/content?path=${encodeURIComponent(path)}`);
    return openFile(path);
  } catch { /* dosya yok: yeni dosya oluşturulacak */ }
  state.editPath = path;
  state.editNew = true;
  document.getElementById("editor").innerHTML = editorHtml(path, true);
  mountCodeEditor("", path);
  document.querySelector("#editorForm textarea")?.focus();
}

async function onSaveFile(form) {
  const wasNew = state.editNew;
  try {
    await api(`/servers/${state.sid}/files/content`, {
      method: "PUT",
      body: { path: state.editPath, content: fv(form, "content") },
    });
    state.editNew = false;
    toast("Dosya kaydedildi");
    if (wasNew) renderFiles(); // yeni dosya listede görünsün
  } catch (e) { toast(e.message, true); }
}

async function uploadFiles(input) {
  const files = [...input.files];
  input.value = "";
  if (!files.length) return;
  let ok = 0;
  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    if (file.size > MAX_UPLOAD_MB * 1048576) { toast(`${file.name}: en fazla ${MAX_UPLOAD_MB} MB`, true); continue; }
    const path = [state.filePath, file.name].filter(Boolean).join("/");
    const exists = [...document.querySelectorAll(".pick")].some((b) => b.value === path);
    if (exists && !confirm(`"${file.name}" zaten var. Üzerine yazılsın mı?`)) continue;
    toast(`Yükleniyor (${i + 1}/${files.length}): ${file.name}`);
    try {
      const res = await fetch(`/api/servers/${state.sid}/files/upload?path=${encodeURIComponent(path)}`, {
        method: "PUT",
        headers: { Authorization: "Bearer " + state.token, "Content-Type": "application/octet-stream" },
        body: file,
      });
      if (res.status === 401) { logout(); throw new Error("Oturum süresi doldu"); }
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof data.detail === "string" ? data.detail : res.statusText);
      ok += 1;
    } catch (e) { toast(`${file.name}: ${e.message}`, true); }
  }
  if (ok) toast(`${ok} dosya yüklendi`);
  renderFiles();
}

/* ---------- ayarlar ---------- */
function renderSettings() {
  const server = state.server;
  const perms = server.my_permissions || [];
  if (!perms.includes("settings") && !perms.includes("owner")) {
    document.getElementById("tab").innerHTML =
      `<section class="card"><div class="notice">Bu sunucunun ayarlarını değiştirme yetkiniz yok.</div></section>`;
    return;
  }
  const isOwner = perms.includes("owner");
  const egg = (state.eggs || []).find((e) => e.slug === server.egg);
  const routeEgg = !!egg && ROUTE_EGG_CATEGORIES.includes(String(egg.category).toLowerCase());
  const appEgg = !!egg && APP_EGG_CATEGORIES.includes(String(egg.category).toLowerCase());
  const subs = [["genel", "Genel"]];
  if (routeEgg) subs.push(["yayin", appEgg ? "API adı" : "Yayın ve domain"]);
  subs.push(["ortam", "Ortam değişkenleri"], ["baslatma", "Başlatma komutu"]);
  if (isOwner) subs.push(["notlar", "Notlar"], ["erisim", "Erişim"]);
  subs.push(["bakim", "Bakım"], ["kur", "Yeniden kur"]);
  if (!subs.some(([k]) => k === state.settingsSub)) state.settingsSub = "genel";
  const cur = state.settingsSub;

  const bar = `<div class="row" style="flex-wrap:wrap;gap:8px;margin-bottom:12px">${subs.map(([k, label]) =>
    `<button type="button" class="small${k === cur ? " primary" : ""}" data-act="settingsSub" data-sub="${k}">${esc(label)}</button>`).join("")}</div>`;

  const siteLink = server.site_url
    ? `<p class="muted small-text">Adres: <a href="${esc(server.site_url)}" target="_blank" rel="noopener">${esc(server.site_url)}</a></p>` : "";
  const varRows = egg ? egg.variables.map((v) => `
        <div><label>${esc(v.name)}${v.description ? " · " + esc(v.description) : ""}</label>
        <input data-var="${esc(v.name)}" value="${esc(server.variables?.[v.name] ?? "")}"></div>`).join("") : "";

  const panes = {
    genel: `
      <section class="card">
        <h3>Genel</h3>
        <form id="settingsForm">
          <div class="grid2">
            <div><label>Ad</label><input name="name" value="${esc(server.name)}" minlength="2" maxlength="48" required><span class="muted small-text">Kalan ad değişikliği: ${server.rename_left ?? "–"}</span></div>
            <div><label>RAM (MB)</label><input name="memory" type="number" min="128" max="${limits().mem}" value="${server.memory_mb}"></div>
            <div><label>CPU (%)</label><input name="cpu" type="number" min="10" max="${limits().cpu}" value="${server.cpu_percent}"></div>
          </div>
          <div class="row" style="margin-top:12px">
            <button class="primary" type="submit">Kaydet</button>
            <span class="muted small-text">RAM ve CPU değişikliği konteyneri yeniden oluşturur. Dosyalar korunur.</span>
          </div>
        </form>
      </section>`,
    yayin: routeEgg ? `
      <section class="card">
        <h3>${appEgg ? "API adı" : "Yayın adı ve adres"}</h3>
        <form id="siteForm">
          <label>${appEgg ? "API adı (adres: /api/apps/&lt;ad&gt;)" : esc(siteAddrText(false))}</label>
          <input name="site_slug" value="${esc(server.site_slug || "")}" maxlength="40" placeholder="boş bırakırsanız yayından kalkar">
          ${siteLink}
          <div class="row" style="margin-top:10px"><button class="primary" type="submit">Kaydet</button></div>
        </form>
      </section>
      <div id="plDomains"></div>` : "",
    ortam: `
      ${egg ? `<section class="card">
        <h3>Egg değişkenleri</h3>
        <form id="varsForm">
          <div class="grid2">${varRows}</div>
          <div class="row" style="margin-top:10px"><button class="primary" type="submit">Kaydet</button></div>
        </form>
      </section>` : `<div class="notice">Bu sunucunun egg'i artık mevcut değil; değişkenler düzenlenemiyor.</div>`}
      <section class="card" style="margin-top:16px">
        <h3>Ek ortam değişkenleri</h3>
        <p class="muted small-text">Her satıra bir tane: <code>AD=DEĞER</code>. Örn. <code>DISCORD_TOKEN=...</code>. Kaydedince konteyner yeniden oluşturulur; dosyalar korunur.</p>
        <form id="envForm">
          <textarea name="env" rows="6" spellcheck="false" placeholder="DISCORD_TOKEN=abc123">${esc(Object.entries(server.env || {}).map(([k, v]) => `${k}=${v}`).join("\n"))}</textarea>
          <div class="row" style="margin-top:10px"><button class="primary" type="submit">Kaydet ve yeniden oluştur</button></div>
        </form>
      </section>`,
    baslatma: `
      <section class="card">
        <h3>Başlatma komutu</h3>
        <p class="muted small-text">Egg'in varsayılan komutu yerine bu sunucuda çalışacak komut. Örnek: <code>node index.js --port 8080</code>. Boş bırakırsanız egg varsayılanı kullanılır. Kaydedince konteyner yeniden oluşturulur.</p>
        <form id="startupForm">
          <input name="startup" value="${esc(server.startup_override || "")}" maxlength="500" spellcheck="false" placeholder="boş = egg varsayılanı" style="font-family:monospace">
          <div class="row" style="margin-top:10px"><button class="primary" type="submit">Kaydet ve yeniden oluştur</button></div>
        </form>
      </section>`,
    notlar: isOwner ? `
      <section class="card">
        <h3>Sunucu notları</h3>
        <p class="muted small-text">Yalnızca sahip ve yönetici görür. Örnek: "bu bot şu tarihte token değiştirildi".</p>
        <form id="noteForm">
          <div class="row"><input name="text" maxlength="500" placeholder="Not yazın" style="flex:1"><button class="primary" type="submit">Ekle</button></div>
        </form>
        <div id="noteList" style="margin-top:12px"><span class="muted small-text">Yükleniyor…</span></div>
      </section>` : "",
    erisim: isOwner ? `<p class="muted small-text">Erişim izinleri yükleniyor…</p>` : "",
    bakim: `
      <section class="card">
        <h3>Bakım</h3>
        <p class="muted">Yeniden oluşturma konteyneri sıfırdan kurar, dosyalar korunur. Konsol komutları yalnızca yeni oluşturulan konteynerlerde çalışır; sunucu eskiyse bir kez "Yeniden oluştur" yapın.</p>
        <div class="row">
          <button data-act="rebuild">Yeniden oluştur</button>
          <button data-act="downloadServerBackup">Dosyaları yedekle</button>
          ${isOwner ? `<button data-act="cloneServer">Klonla</button>` : ""}
          <button class="danger" data-act="deleteServer" style="margin-left:auto">Sunucuyu sil</button>
        </div>
      </section>`,
    kur: `
      <section class="card">
        <h3>Yeniden kur</h3>
        <p class="muted">Kurulum betiği yeniden çalıştırılır. Dosyalarınız korunur, ancak kurulum birkaç dakika sürebilir ve bu süre içinde sunucu kapalı kalır.</p>
        <div class="row"><button class="danger" data-act="reinstall">Yeniden kur</button></div>
      </section>`,
  };

  document.getElementById("tab").innerHTML = bar + (panes[cur] || "");
  if (cur === "notlar") loadNotes();
  if (cur === "erisim") loadAccess();
  if (cur === "yayin") loadDomains();
}

async function onSaveSite(form) {
  const body = { site_slug: fv(form, "site_slug").trim().toLowerCase() };
  try {
    state.server = await api(`/servers/${state.sid}`, { method: "PATCH", body });
    toast("Yayın adı kaydedildi");
    renderSettings();
  } catch (e) { toast(e.message, true); }
}

async function onSaveVars(form) {
  const variables = {};
  form.querySelectorAll("[data-var]").forEach((el) => { variables[el.dataset.var] = el.value; });
  try {
    state.server = await api(`/servers/${state.sid}`, { method: "PATCH", body: { variables } });
    toast("Değişkenler kaydedildi");
    renderSettings();
  } catch (e) { toast(e.message, true); }
}

/* ---------- REST API (Node.js ve Python) ---------- */
function renderApi() {
  const server = state.server;
  const perms = server.my_permissions || [];
  if (!perms.includes("console") && !perms.includes("owner")) {
    document.getElementById("tab").innerHTML = `<section class="card"><div class="notice">Bu sunucuya istek gönderme yetkiniz yok.</div></section>`;
    return;
  }
  const url = server.site_url || "";
  const shown = url || "https://ornek.adres/api/apps/ad/";
  document.getElementById("tab").innerHTML = `
    <section class="card">
      <h3>REST API adresi</h3>
      ${url
        ? `<p class="muted small-text">Uygulamanız dışarıdan bu adresten erişilebilir. Kimlik doğrulamayı uygulamanızın kendisi yapmalıdır.</p>
           <div class="api-url"><code>${esc(url)}</code><button class="small" data-act="copyText" data-text="${esc(url)}">${icon("copy", 14)} Kopyala</button></div>`
        : `<div class="notice">Henüz bir API adı yok. Ayarlar sekmesinden bir ad verin; adres <code>/api/apps/&lt;ad&gt;/</code> biçiminde oluşur.</div>`}
    </section>
    <section class="card" style="margin-top:16px">
      <h3>İstek gönder</h3>
      <p class="muted small-text">İstek doğrudan sunucunuzdaki uygulamaya gider ve yanıtı burada görürsünüz. Adres olarak yalnızca yol yazın (ör. /api/kullanicilar).</p>
      <p class="muted small-text">Gerçek bir port gibi çalışır: yöntem, başlıklar (Authorization dahil), çerezler, durum kodları ve gövde değiştirilmeden iletilir. WebSocket yükseltmesi desteklenmez; istek gövdesi en çok 10 MB, yanıt en çok 50 MB, her istek en fazla 30 saniye sürer. Adres, yönetici tarafından belirlenen dakikalık IP sınırına tabidir.</p>
      <form id="apiTestForm">
        <div class="api-req">
          <select name="method" aria-label="Yöntem">${["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"].map((m) => `<option>${m}</option>`).join("")}</select>
          <input name="path" value="/" maxlength="512" required spellcheck="false" aria-label="Yol">
          <button class="primary" type="submit">Gönder</button>
        </div>
        <label style="margin-top:10px">Gövde (isteğe bağlı; { ya da [ ile başlarsa JSON gönderilir)</label>
        <textarea name="body" rows="5" spellcheck="false" placeholder='{"ad": "Ali"}'></textarea>
      </form>
      <div id="apiResult" style="margin-top:12px"></div>
    </section>
    <section class="card" style="margin-top:16px">
      <h3>Örnek kullanım</h3>
      <p class="muted small-text">Uygulamanızın içinden başka bir API'ye istek atmak için örnekler:</p>
      <pre class="codeblock">// Node.js (18 ve üstü)
const res = await fetch("${esc(shown)}");
const data = await res.json();</pre>
      <pre class="codeblock"># Python
import urllib.request, json
with urllib.request.urlopen("${esc(shown)}") as r:
    data = json.load(r)</pre>
    </section>`;
}

async function onApiTest(form) {
  const out = document.getElementById("apiResult");
  out.innerHTML = `<p class="muted">İstek gönderiliyor…</p>`;
  try {
    const r = await api(`/servers/${state.sid}/http`, {
      method: "POST",
      body: { method: fv(form, "method"), path: fv(form, "path"), body: fv(form, "body") },
    });
    out.innerHTML = `
      <div class="row between"><strong>Yanıt: ${r.status}</strong><span class="muted small-text">${esc(r.content_type)}${r.truncated ? " · kırpıldı" : ""}</span></div>
      <pre class="codeblock">${esc(r.body || "(boş yanıt)")}</pre>`;
  } catch (e) { out.innerHTML = `<div class="error">${esc(e.message)}</div>`; }
}

const ENV_KEY_CLIENT_RE = /^[A-Z_][A-Z0-9_]{0,63}$/;
async function onSaveEnv(form) {
  const env = {};
  for (const raw of fv(form, "env").split("\n")) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    const at = line.indexOf("=");
    if (at < 1) { toast(`Satır biçimi AD=DEĞER olmalı: ${line}`, true); return; }
    const key = line.slice(0, at).trim();
    if (!ENV_KEY_CLIENT_RE.test(key)) { toast(`Geçersiz ad: ${key} (büyük harf, rakam ve _)`, true); return; }
    env[key] = line.slice(at + 1).trim();
  }
  try {
    state.server = await api(`/servers/${state.sid}`, { method: "PATCH", body: { env } });
    toast("Ortam değişkenleri kaydedildi; konteyner yeniden oluşturuldu");
    renderSettings();
  } catch (e) { toast(e.message, true); }
}

/* ---------- başlatma komutu ve sunucu notları ---------- */
async function onSaveStartup(form) {
  const startup = fv(form, "startup");
  try {
    state.server = await api(`/servers/${state.sid}`, { method: "PATCH", body: { startup } });
    toast("Başlatma komutu kaydedildi");
    renderSettings();
  } catch (e) { toast(e.message, true); }
}

async function loadNotes() {
  const box = document.getElementById("noteList");
  if (!box || !state.sid) return;
  try {
    const notes = await api(`/servers/${state.sid}/notes`);
    box.innerHTML = notes.length
      ? notes.map((n) => `
          <div class="note-row">
            <div>
              <div class="muted small-text">${esc(new Date(n.created_at).toLocaleString("tr-TR"))} · ${esc(n.author)}</div>
              <div>${esc(n.text)}</div>
            </div>
            <button class="small danger" data-act="deleteNote" data-id="${n.id}">Sil</button>
          </div>`).join("")
      : `<span class="muted small-text">Henüz not yok.</span>`;
  } catch (e) { box.innerHTML = `<span class="muted small-text">${esc(e.message)}</span>`; }
}

async function onAddNote(form) {
  const text = fv(form, "text");
  if (!text) return;
  try {
    await api(`/servers/${state.sid}/notes`, { method: "POST", body: { text } });
    form.reset();
    loadNotes();
  } catch (e) { toast(e.message, true); }
}

async function deleteNote(id) {
  if (!confirm("Not silinsin mi?")) return;
  try {
    await api(`/servers/${state.sid}/notes/${id}`, { method: "DELETE" });
    loadNotes();
  } catch (e) { toast(e.message, true); }
}

/* ---------- ilk kayıt rehberi ve yardım sayfası ---------- */
const ONBOARD_STEPS = [
  { title: "Mango Panel'e hoş geldiniz", body: "Bu kısa rehber panelin nasıl kullanılacağını gösterir. İstediğiniz zaman üst menüdeki Yardım sayfasından tekrar bakabilirsiniz." },
  { title: "Sunucu oluşturma", body: "Sunucular sayfasında bir egg seçin (oyun, web sitesi, Node.js, Python, bot vb.), ad, RAM ve CPU değerlerini belirleyip sunucuyu oluşturun." },
  { title: "Sunucu sayfası", body: "Bir sunucuya tıkladığınızda Konsol (çıktılar ve komutlar), Dosyalar (yükleme, düzenleme, zip açma), Ayarlar (RAM, CPU, ortam değişkenleri, başlatma komutu, notlar) ve API sekmeleri açılır." },
  { title: "Konsol ipucu", body: "Konsolda \"$\" ile başlayan satır konteyner içinde kabuk komutu olarak çalışır (örn. $ npm install express). Diğer satırlar çalışan programın girdisine gider." },
];

function renderOnboarding() {
  const i = state.onboardStep || 0;
  const last = ONBOARD_STEPS.length - 1;
  const step = ONBOARD_STEPS[i];
  let box = document.getElementById("onboard");
  if (!box) {
    box = document.createElement("div");
    box.id = "onboard";
    box.className = "onboard-backdrop";
    document.body.appendChild(box);
  }
  box.innerHTML = `
    <div class="onboard-box" role="dialog" aria-modal="true" aria-labelledby="onboardTitle">
      <div class="muted small-text">${i + 1} / ${ONBOARD_STEPS.length}</div>
      <h3 id="onboardTitle">${esc(step.title)}</h3>
      <p>${esc(step.body)}</p>
      <div class="row" style="justify-content:space-between;margin-top:18px">
        <button class="small" data-act="onboardFinish">Atla</button>
        <span class="row">
          ${i > 0 ? `<button data-act="onboardPrev">Geri</button>` : ""}
          ${i < last
            ? `<button class="primary" data-act="onboardNext">İleri</button>`
            : `<button class="primary" data-act="onboardFinish">Bitir</button>`}
        </span>
      </div>
    </div>`;
}

async function finishOnboarding() {
  try {
    state.user = await api("/me/onboarded", { method: "POST" });
  } catch (e) { toast(e.message, true); return; }
  document.getElementById("onboard")?.remove();
  state.onboardStep = 0;
}

function renderHelp() {
  app().innerHTML = `
    <div class="section-head"><h3>Yardım ve rehber</h3></div>
    <section class="card">
      <h4>İlk sunucunuzu nasıl kurarsınız</h4>
      <ol class="help-steps">
        <li><b>Sunucular</b> sayfasında bir egg seçin. Egg; oyun, web sitesi, Node.js, Python ya da bot gibi hazır bir kurulum şablonudur.</li>
        <li>Ad, RAM ve CPU değerlerini belirleyip sunucuyu oluşturun. İlk oluşturmada gerekli imaj indirilir; birkaç dakika sürebilir.</li>
        <li>Sunucuya tıklayın ve güç düğmelerinden <b>Başlat</b>'a basın. Çıktıları <b>Konsol</b> sekmesinde izleyebilirsiniz.</li>
        <li><b>Dosyalar</b> sekmesinden kodunuzu yükleyin ya da düzenleyin. Zip dosyası yüklediyseniz içeriğini açabilirsiniz.</li>
      </ol>
    </section>
    <section class="card">
      <h4>Sunucu sayfasındaki sekmeler</h4>
      <ul class="help-steps">
        <li><b>Konsol:</b> canlı çıktı ve komut girişi. "$" ile başlayan satır konteyner içinde kabuk komutu çalıştırır (örn. <code>$ npm install express</code>). Diğer satırlar çalışan programın girdisine gider.</li>
        <li><b>Dosyalar:</b> dosya ve klasör yönetimi, çoklu seçimle toplu silme, zip açma ve kod düzenleyici.</li>
        <li><b>Ayarlar:</b> ad, RAM, CPU, ortam değişkenleri, başlatma komutu ve sahibin notları. RAM, CPU ve komut değişince konteyner yeniden oluşturulur; dosyalar korunur.</li>
        <li><b>API:</b> Node.js ve Python sunucuları için dışarıya açık adres (<code>/api/apps/&lt;ad&gt;/</code>). Dakikalık istek sınırı vardır.</li>
      </ul>
    </section>
    <section class="card">
      <h4>Başlatma komutu</h4>
      <p class="muted small-text">Ayarlar sekmesinde egg'in varsayılan komutunu bu sunucu için değiştirebilirsiniz. Örnek: <code>node index.js --port 8080</code>. Alanı boş bırakırsanız egg varsayılanına dönersiniz.</p>
    </section>
    <section class="card">
      <h4>Genel ipuçları</h4>
      <ul class="help-steps">
        <li>Üst menüdeki güneş/ay düğmesiyle açık ve koyu tema arasında geçiş yapabilirsiniz.</li>
        <li><b>Hesabım</b> sayfasından otomasyon için API anahtarı oluşturabilirsiniz.</li>
        <li>Sorun yaşarsanız sunucu ayarlarındaki notları ve konsol çıktısını not alıp yöneticinize iletin.</li>
      </ul>
    </section>
    <section class="card">
      <button data-act="onboardReplay">Tanıtım rehberini yeniden göster</button>
    </section>`;
}

/* ---------- alt kullanıcılar (sunucu paylaşımı) ---------- */
async function loadAccess() {
  const tab = document.getElementById("tab");
  if (!tab || !state.sid) return;
  document.getElementById("accessCard")?.remove();
  let rows;
  try {
    rows = await api(`/servers/${state.sid}/access`);
  } catch (e) { toast(e.message, true); return; }
  const card = document.createElement("section");
  card.className = "card";
  card.id = "accessCard";
  card.style.marginTop = "16px";
  card.innerHTML = `
    <h3>Alt kullanıcılar</h3>
    <p class="muted small-text">Sunucuyu ortak yönetmek için kullanıcı ekleyin ve yetkileri seçin. Alt kullanıcıların kendi sunucu limiti etkilenmez.</p>
    <form id="accessForm" class="grid2">
      <div><label>Kullanıcı adı</label><input name="username" required minlength="3" maxlength="32"></div>
      <div>
        <label class="check"><input type="checkbox" name="p_console" checked> Terminal (log ve komut)</label>
        <label class="check"><input type="checkbox" name="p_power" checked> Güç (başlat, durdur, yeniden başlat)</label>
        <label class="check"><input type="checkbox" name="p_files"> Dosyalar</label>
        <label class="check"><input type="checkbox" name="p_settings"> Ayarlar (RAM, CPU, değişkenler)</label>
      </div>
      <div class="row"><button class="primary" type="submit">Ekle / güncelle</button></div>
    </form>
    <div class="table-wrap" style="margin-top:12px">
      <table class="files"><tbody>${rows.map((r) => `
        <tr>
          <td><strong>${esc(r.username)}</strong></td>
          <td class="muted">${esc(r.permissions.join(", ") || "yetki yok")}</td>
          <td class="right"><button class="danger small" data-act="accessRevoke" data-id="${r.user_id}">Kaldır</button></td>
        </tr>`).join("") || `<tr><td class="muted">Alt kullanıcı yok.</td></tr>`}
      </tbody></table>
    </div>`;
  tab.appendChild(card);
}

async function onGrantAccess(form) {
  const permissions = ["console", "power", "files", "settings"].filter((p) => fc(form, `p_${p}`));
  try {
    await api(`/servers/${state.sid}/access`, {
      method: "POST",
      body: { username: fv(form, "username").trim(), permissions },
    });
    toast("Alt kullanıcı kaydedildi");
    await loadAccess();
  } catch (e) { toast(e.message, true); }
}

async function onSaveSettings(form) {
  const body = {
    name: fv(form, "name"),
    memory_mb: Number(fv(form, "memory")),
    cpu_percent: Number(fv(form, "cpu")),
  };
  const variables = {};
  form.querySelectorAll("[data-var]").forEach((el) => { variables[el.dataset.var] = el.value; });
  const siteEl = form.querySelector('[name="site_slug"]');
  if (siteEl) body.site_slug = siteEl.value.trim().toLowerCase();
  if (Object.keys(variables).length) body.variables = variables;
  try {
    state.server = await api(`/servers/${state.sid}`, { method: "PATCH", body });
    toast("Ayarlar kaydedildi");
    renderSettings();
  } catch (e) { toast(e.message, true); }
}

async function serverOp(path, body, okMessage) {
  try {
    state.server = await api(path, { method: "POST", body });
    toast(okMessage);
    renderSettings();
    refreshServer(state.sid);
  } catch (e) { toast(e.message, true); }
}

/* Yedek dosyası: Bearer başlığı gerektiği için normal bağlantı yerine fetch ile indirilir. */
async function downloadFile(path, filename) {
  try {
    const res = await fetch("/api" + path, { headers: { Authorization: "Bearer " + state.token } });
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(typeof data.detail === "string" ? data.detail : res.statusText);
    }
    const url = URL.createObjectURL(await res.blob());
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    toast("İndiriliyor");
  } catch (e) { toast(e.message, true); }
}

/* ---------- yönetim paneli ---------- */
const ADMIN_TABS = [
  ["genel", "chart", "Genel"],
  ["kullanicilar", "users", "Kullanıcılar"],
  ["sunucular", "server", "Sunucular"],
  ["ayarlar", "settings", "Ayarlar"],
  ["kuponlar", "settings", "Kuponlar"],
  ["bildirimler", "settings", "Bildirimler"],
  ["satis", "chart", "Satış hunisi"],
  ["saglik", "activity", "Sağlık"],
  ["magaza", "package", "Egg mağazası"],
  ["paketler", "package", "Premium paketler"],
  ["ver", "plus", "Sunucu ver"],
  ["domain", "globe", "Domain ayarları"],
  ["discord", "bell", "Discord bot"],
  ["destek", "bell", "Destek talepleri"],
  ["nodelar", "server", "Node'lar"],
  ["kayitlar", "scroll", "Kayıtlar"],
];

async function adminHealth(body) {
  const rows = await api("/admin/health");
  const badge = (ok) => ok === true
    ? `<span class="badge running"><span class="dot running"></span>sağlıklı</span>`
    : ok === false
      ? `<span class="badge exited"><span class="dot exited"></span>sorunlu</span>`
      : `<span class="badge">kontrol dışı</span>`;
  body.innerHTML = `
    <section class="card">
      <div class="row between">
        <h4 style="margin:0">Sistem sağlığı</h4>
        <button class="small" data-act="refreshHealth">Yenile</button>
      </div>
      <div class="table-wrap" style="margin-top:12px">
        <table class="files">
          <thead><tr><th>Bileşen</th><th>Durum</th><th>Ayrıntı</th></tr></thead>
          <tbody>${rows.map((r) => `
            <tr>
              <td><strong>${esc(r.name)}</strong></td>
              <td>${badge(r.ok)}</td>
              <td class="muted">${esc(r.detail)}</td>
            </tr>`).join("")}
          </tbody>
        </table>
      </div>
      <p class="muted small-text">Bu sayfa her açılışta güncel durumu ölçer.</p>
    </section>`;
}

function statCard(label, value, sub) {
  return `<div class="stat-card"><div class="k">${esc(label)}</div><div class="v">${esc(value)}</div><div class="sub">${esc(sub)}</div></div>`;
}

function auditTable(rows) {
  if (!rows.length) return `<p class="muted">Henüz kayıt yok.</p>`;
  return `<div class="table-wrap"><table class="files">
    <thead><tr><th>Zaman</th><th>Kullanıcı</th><th>İşlem</th><th>Hedef</th><th>Ayrıntı</th></tr></thead>
    <tbody>${rows.map((r) => `
      <tr>
        <td class="muted nowrap">${esc(fmtDate(r.created_at))}</td>
        <td>${esc(r.actor)}</td>
        <td><span class="badge">${esc(r.action)}</span></td>
        <td>${esc(r.target)}</td>
        <td class="muted">${esc(r.detail)}</td>
      </tr>`).join("")}
    </tbody></table></div>`;
}

function barChart(rows, emptyText) {
  if (!rows.length) return `<p class="muted small-text">${emptyText}</p>`;
  const max = Math.max(1, ...rows.map((r) => r.value));
  return `<div class="bar-chart">${rows.map((r) => `
    <div class="bar-row" title="${esc(r.label)}: ${r.value}">
      <span class="bar-label">${esc(r.label)}</span>
      <span class="bar-track"><span style="width:${Math.round((r.value / max) * 100)}%"></span></span>
      <span class="bar-value">${r.value}</span>
    </div>`).join("")}</div>`;
}

async function adminAnalyticsCard(box) {
  try {
    const a = await api("/admin/analytics?days=14");
    const eggRows = a.servers_by_egg.map((e) => ({ label: `${e.name} (${e.category})`, value: e.count }));
    const dayRows = a.users_per_day.map((d) => ({ label: d.date.slice(5), value: d.count }));
    box.innerHTML = `
      <div class="grid2">
        <div>
          <h4>En çok kullanılan egg'ler</h4>
          ${barChart(eggRows, "Henüz sunucu yok.")}
        </div>
        <div>
          <h4>Son 14 gün kayıtlar</h4>
          ${barChart(dayRows, "Kayıt yok.")}
        </div>
      </div>`;
  } catch (e) {
    box.innerHTML = `<p class="muted small-text">İstatistik yüklenemedi: ${esc(e.message)}</p>`;
  }
}

async function adminOverview(body) {
  const [st, audit] = await Promise.all([api("/admin/stats"), api("/admin/audit?limit=8")]);
  body.innerHTML = `
    <div class="stat-grid">
      ${statCard("Kullanıcılar", st.users, `${st.admins} yönetici`)}
      ${statCard("Sunucular", st.servers, `${st.running_servers} çalışıyor`)}
      ${statCard("Ayrılmış RAM", `${st.allocated_memory_mb} MB`, "tüm sunucular toplamı")}
      ${statCard("Kayıt", st.registration_enabled ? "Açık" : "Kapalı", `yeni kullanıcı limiti ${st.default_max_servers}`)}
    </div>
    <section class="card" id="analyticsBox"><p class="muted small-text">İstatistikler yükleniyor…</p></section>
    <section class="card">
      <h4>Yedek</h4>
      <p class="muted">Veritabanı ve tüm sunucu dosyaları tek bir arşiv olarak iner. Gizli anahtar (mango.json) bu yedekte yer almaz; onu ayrıca saklayın.</p>
      <button class="primary" data-act="downloadBackup">Tam yedek indir</button>
    </section>
    <section class="card">
      <h4>Son işlemler</h4>
      ${auditTable(audit)}
    </section>`;
  adminAnalyticsCard(document.getElementById("analyticsBox"));
}

function usageBar(label, used, cap, unit) {
  const pct = cap > 0 ? Math.min(100, Math.round((used / cap) * 100)) : 0;
  const text = cap > 0 ? `${used} / ${cap} ${unit}` : `${used} ${unit}`;
  const tone = pct >= 90 ? "hot" : pct >= 70 ? "warm" : "";
  return `
    <div class="usage-line">
      <div class="usage-head"><span class="muted">${label}</span><span>${text}</span></div>
      ${cap > 0 ? `<div class="usage-bar"><span class="${tone}" style="width:${pct}%"></span></div>` : ""}
    </div>`;
}

function usageCell(u) {
  const un = u.usage || {};
  return `
      <td class="usage-cell">
        ${usageBar("RAM (canlı)", un.live_memory_mb || 0, un.memory_cap_mb || 0, "MB")}
        ${usageBar("CPU (canlı)", un.live_cpu_percent || 0, un.cpu_cap_percent || 0, "%")}
        ${usageBar("Disk", un.disk_mb || 0, un.disk_cap_mb || 0, "MB")}
        <div class="muted small-text">Tahsis: ${un.allocated_memory_mb || 0} MB RAM · %${un.allocated_cpu_percent || 0} CPU</div>
      </td>`;
}

function userRow(u) {
  return `
    <tr data-search="${esc((u.username + " " + u.email).toLowerCase())}">
      <td><strong>${esc(u.username)}</strong><div class="muted small-text">Kayıt: ${esc(fmtDate(u.created_at))}</div></td>
      <td class="muted">${esc(u.email || "—")}</td>
      <td>${u.is_admin ? '<span class="badge running">yönetici</span>' : '<span class="badge">kullanıcı</span>'}${u.approved === false ? ' <span class="badge">onay bekliyor</span> <button class="small" data-act="userApprove" data-id="${u.id}">Onayla</button>' : ""}</td>
      <td>${u.server_count}</td>
      <td>
        <div class="row nowrap">
          <input type="number" min="0" max="100" value="${u.max_servers}" id="limit-${u.id}" class="narrow">
          <button class="small" data-act="saveLimit" data-id="${u.id}">Kaydet</button>
        </div>
      </td>
      ${usageCell(u)}
      <td class="right">
        <button class="small" data-act="userServers" data-id="${u.id}">Sunucular (${u.server_count})</button>
        <button class="small" data-act="toggleAdmin" data-id="${u.id}" data-admin="${u.is_admin ? 1 : 0}">${u.is_admin ? "Yetkiyi kaldır" : "Yönetici yap"}</button>
        <button class="small" data-act="resetPw" data-id="${u.id}" data-name="${esc(u.username)}">Şifre</button>
        <button class="danger small" data-act="deleteUser" data-id="${u.id}" data-name="${esc(u.username)}">Sil</button>
      </td>
    </tr>
    <tr id="us-${u.id}" hidden><td colspan="6" class="user-servers"></td></tr>`;
}

async function adminUsers(body) {
  const users = await api("/users");
  body.innerHTML = `
    <section class="card">
      <h4>Yeni kullanıcı</h4>
      <form id="userForm" class="grid3">
        <div><label>Kullanıcı adı</label><input name="username" required minlength="3" maxlength="32"></div>
        <div><label>E-posta</label><input name="email" type="email" maxlength="120"></div>
        <div><label>Şifre (en az 8)</label><input name="password" type="password" required minlength="8"></div>
        <div><label>Sunucu limiti</label><input name="max_servers" type="number" min="0" max="100" value="2"></div>
        <label class="check"><input type="checkbox" name="is_admin"> Yönetici</label>
        <div class="row"><button class="primary" type="submit">Ekle</button></div>
      </form>
    </section>
    <section class="card">
      <div class="row between">
        <h4 style="margin:0">Kullanıcılar (${users.length})</h4>
        <input id="userSearch" placeholder="Ara: ad veya e-posta" class="search">
      </div>
      <div class="table-wrap" style="margin-top:12px">
        <table class="files" id="userTable">
          <thead><tr><th>Kullanıcı</th><th>E-posta</th><th>Rol</th><th>Sunucu</th><th>Limit</th><th>Kullanım (kota)</th><th class="right">İşlemler</th></tr></thead>
          <tbody>${users.map(userRow).join("")}</tbody>
        </table>
      </div>
    </section>`;
}

async function adminServers(body) {
  const list = await api("/admin/servers");
  body.innerHTML = `
    <section class="card">
      <h4>Tüm sunucular (${list.length})</h4>
      <div class="table-wrap">
        <table class="files">
          <thead><tr><th>Ad</th><th>Sahip</th><th>Egg</th><th>Durum</th><th>RAM</th><th>Adres</th><th class="right">İşlem</th></tr></thead>
          <tbody>${list.map((s) => `
            <tr>
              <td><a href="#/server/${s.id}/console">${esc(s.name)}</a></td>
              <td>${esc(s.owner)}</td>
              <td class="muted">${esc(s.egg)}</td>
              <td><span class="badge ${esc(s.status)}"><span class="dot ${esc(s.status)}"></span>${esc(s.status)}</span></td>
              <td>${s.memory_mb} MB</td>
              <td class="muted">${esc(s.address)}</td>
              <td class="right">
                <button class="small icon-btn" data-act="adminPower" data-id="${s.id}" data-action="start" title="Başlat" aria-label="Başlat">${icon("play", 13)}</button>
                <button class="small icon-btn" data-act="adminPower" data-id="${s.id}" data-action="restart" title="Yeniden başlat" aria-label="Yeniden başlat">${icon("restart", 13)}</button>
                <button class="small icon-btn" data-act="adminPower" data-id="${s.id}" data-action="stop" title="Durdur" aria-label="Durdur">${icon("stop", 13)}</button>
                <button class="small" data-act="suspendServer" data-id="${s.id}" data-suspended="${s.suspended ? 1 : 0}">${s.suspended ? "Askıyı kaldır" : "Askıya al"}</button>
                <button class="danger small" data-act="adminDeleteServer" data-id="${s.id}" data-name="${esc(s.name)}">Sil</button>
              </td>
            </tr>`).join("") || `<tr><td class="muted" colspan="7">Henüz sunucu yok.</td></tr>`}
          </tbody>
        </table>
      </div>
    </section>`;
}

async function adminSettings(body) {
  const [s, eggs] = await Promise.all([api("/admin/settings"), api("/eggs")]);
  const closed = new Set(s.disabled_eggs);
  const eggBoxes = eggs.map((e) => `
    <label class="check"><input type="checkbox" name="egg_enabled" value="${esc(e.slug)}" ${closed.has(e.slug) ? "" : "checked"}>
      ${esc(e.name)} <span class="muted small-text">· ${esc(e.category)}${e.allowed ? "" : " · tünel modunda kapalı"}</span></label>`).join("");
  body.innerHTML = `
    <form id="adminSettingsForm" class="settings-grid">
      <section class="card">
        <h4>Kayıt ve limitler</h4>
        <label class="check"><input type="checkbox" name="registration_enabled" ${s.registration_enabled ? "checked" : ""}> Yeni kullanıcı kaydına izin ver</label>
        <label class="check"><input type="checkbox" name="registration_approval" ${s.registration_approval ? "checked" : ""}> Yeni kayıtlar yönetici onayı beklesin</label>
        <label>Yeni kullanıcıların varsayılan sunucu limiti</label>
        <input name="default_max_servers" type="number" min="0" max="100" value="${s.default_max_servers}" class="narrow">
        <p class="muted small-text">Limit kullanıcı bazında Kullanıcılar sekmesinden değiştirilebilir. Yöneticiler limitten muaftır.</p>
      </section>

      <section class="card">
        <h4>Cloudflare (alt alan adları)</h4>
        <p class="muted small-text">Token'ı Cloudflare'de yalnızca bu zone için DNS düzenleme izniyle oluşturun. Önce ayarları kaydedin, sonra testi çalıştırın.</p>
        <div class="grid2">
          <div><label>Zone ID</label><input name="cf_zone_id" value="${esc(s.cf_zone_id || "")}" placeholder="32 karakterli kimlik"></div>
          <div><label>Alt alan CNAME hedefi (tünel)</label><input name="domain_cname_target" value="${esc(s.domain_cname_target || "")}" maxlength="253" placeholder="UUID.cfargotunnel.com"></div>
          <div><label>API token ${s.cf_token_set ? "(kayıtlı)" : "(girilmedi)"}</label><input name="cf_api_token" type="password" placeholder="${s.cf_token_set ? "değiştirmek için yeni değer girin" : "Cloudflare API token"}" autocomplete="new-password"></div>
        </div>
        <div style="margin-top:10px"><label>Alt alan adı zone'u (ör. example.com)</label><input name="site_base_domain" value="${esc(s.site_base_domain || "")}" placeholder="boş bırakın: panel adresinden otomatik"></div>
        <label class="check" style="margin-top:10px"><input type="checkbox" name="site_subdomains" ${s.site_subdomains ? "checked" : ""}> Alt alan adlarını etkinleştir (kapalıysa siteler /sites/&lt;ad&gt; adresinde yayınlanır)</label>
        <div class="row" style="margin-top:10px"><button type="button" data-act="cloudflareTest">Bağlantıyı test et</button></div>
        <div id="cfTestResult" class="small-text" style="margin-top:8px"></div>
      </section>

      <section class="card">
        <h4>Kaynak sınırları</h4>
        <p class="muted small-text">Yöneticiler dışındaki kullanıcılar bu değerleri aşamaz.</p>
        <div class="grid3">
          <div><label>Sunucu başına en fazla RAM (MB)</label><input name="max_memory_mb" type="number" min="128" max="16384" value="${s.max_memory_mb}"></div>
          <div><label>Discord uygulama ID (Client ID)</label><input name="discord_client_id" value="${esc(s.discord_client_id || "")}" placeholder="17-20 haneli sayı"></div>
          <div><label>Discord client secret ${s.discord_secret_set ? "(kayıtlı)" : "(girilmedi)"}</label><input name="discord_client_secret" type="password" placeholder="${s.discord_secret_set ? "değiştirmek için yeni değer girin" : "Developer Portal → OAuth2"}" autocomplete="new-password"><small class="muted small-text">Discord'da Redirects alanına tam olarak şunu ekleyin: <code>${esc((state.system && state.system.public_url ? state.system.public_url.replace(/\/$/, "") : location.origin))}/api/auth/discord/callback</code></small></div>
          <div><label>Uyarı webhook adresi (https, boşsa kapalı)</label><input name="alert_webhook_url" value="${esc(s.alert_webhook_url || "")}" placeholder="https://..."><small class="muted small-text">Kötüye kullanım şüphesinde bildirim gönderir. Sunucu otomatik askıya alınmaz.</small></div>
          <div><label>Sunucu başına en fazla CPU (%)</label><input name="max_cpu_percent" type="number" min="10" max="800" value="${s.max_cpu_percent}"></div>
          <div><label>Sunucu başına en fazla disk (MB)</label><input name="max_disk_mb" type="number" min="256" max="102400" value="${s.max_disk_mb}"></div>
          <div><label>API ve site istek sınırı (IP başına, sunucu başına, dakikada)</label><input name="app_rate_per_min" type="number" min="10" max="10000" value="${s.app_rate_per_min}"></div>
        </div>
        <p class="muted small-text">Disk kotası panel üzerinden yapılan dosya kayıtlarında uygulanır.</p>
      </section>

      <section class="card">
        <h4>Marka</h4>
        <label>Site adı (en fazla 40 karakter)</label>
        <input name="site_name" maxlength="40" required value="${esc(s.site_name)}">
        <label>Logo metni / simge (en fazla 8 karakter)</label>
        <input name="logo_text" maxlength="8" value="${esc(s.logo_text)}" class="narrow" placeholder="boş: simge">
      </section>

      <section class="card">
        <h4>Bakım ve duyuru</h4>
        <label class="check"><input type="checkbox" name="maintenance_mode" ${s.maintenance_mode ? "checked" : ""}> Bakım modu: yalnızca yöneticiler giriş yapabilsin</label>
        <label class="check"><input type="checkbox" name="announcement_enabled" ${s.announcement_enabled ? "checked" : ""}> Duyuru bandını göster</label>
        <label>Duyuru metni (en fazla 255 karakter)</label>
        <input name="announcement" maxlength="255" value="${esc(s.announcement)}">
      </section>

      <section class="card">
        <h4>Egg'ler</h4>
        <p class="muted small-text">İşaretli olmayan egg'ler yalnızca yöneticiler tarafından kullanılabilir.</p>
        <div class="egg-toggles">${eggBoxes || `<p class="muted">Egg bulunamadı.</p>`}</div>
      </section>

      <div class="row" style="grid-column:1/-1">
        <button class="primary" type="submit">Tüm ayarları kaydet</button>
      </div>
    </form>`;
}

async function adminStore(body) {
  const rows = await api("/admin/egg-store");
  body.innerHTML = `
    <section class="card">
      <h4 style="margin:0">Egg mağazası</h4>
      <p class="muted small-text">Hazır egg paketlerini tek tıkla kurun. Kurulan egg sunucu oluşturma listesinde görünür. Bir sunucu tarafından kullanılan egg kaldırılamaz.</p>
      <div class="store-grid">${rows.map((r) => `
        <div class="store-card">
          <div class="row between"><strong>${esc(r.name)}</strong><span class="badge">${esc(r.category)}</span></div>
          <p class="muted small-text">${esc(r.description)}</p>
          <div class="row" style="margin-top:auto">
            ${r.installed
              ? `<span class="badge running"><span class="dot running"></span>kurulu</span>
                 <button class="danger small" data-act="storeUninstall" data-slug="${esc(r.slug)}" data-name="${esc(r.name)}">Kaldır</button>`
              : `<button class="primary small" data-act="storeInstall" data-slug="${esc(r.slug)}">${icon("download", 14)} Kur</button>`}
          </div>
        </div>`).join("") || `<p class="muted">Mağazada egg yok.</p>`}
      </div>
    </section>`;
}

async function adminAudit(body) {
  const rows = await api("/admin/audit?limit=300");
  body.innerHTML = `
    <section class="card">
      <div class="row between">
        <h4 style="margin:0">Denetim kaydı</h4>
        <button class="small" data-act="refreshAudit">Yenile</button>
      </div>
      <div style="margin-top:12px">${auditTable(rows)}</div>
    </section>`;
}

async function renderAdmin(tab = "genel") {
  if (!state.user.is_admin) { location.hash = "#/"; return; }
  if (!ADMIN_TABS.some(([id]) => id === tab)) tab = "genel";
  app().innerHTML = `
    <div class="section-head"><h3>Yönetim paneli</h3></div>
    <div class="admin-layout">
      <aside class="sidebar">
        ${ADMIN_TABS.map(([id, ico, label]) =>
          `<a data-tab="${id}" class="${id === tab ? "active" : ""}" href="#/admin/${id}"><span class="ico">${icon(ico)}</span>${label}</a>`
        ).join("")}
      </aside>
      <section id="adminBody"><p class="muted">Yükleniyor...</p></section>
    </div>`;
  const body = document.getElementById("adminBody");
  try {
    if (tab === "genel") await adminOverview(body);
    else if (tab === "kullanicilar") await adminUsers(body);
    else if (tab === "sunucular") await adminServers(body);
    else if (tab === "ayarlar") await adminSettings(body);
    else if (tab === "saglik") await adminHealth(body);
    else if (tab === "magaza") await adminStore(body);
    else if (tab === "paketler") await adminPlans(body);
    else if (tab === "kuponlar") await adminCoupons(body);
    else if (tab === "bildirimler") await adminNotifications(body);
    else if (tab === "satis") await adminFunnel(body);
    else if (tab === "ver") await adminGive(body);
    else if (tab === "domain") await adminDomains(body);
    else if (tab === "discord") await adminDiscord(body);
    else if (tab === "destek") await adminTickets(body);
    else if (tab === "nodelar") await adminNodes(body);
    else if (tab === "kayitlar") await adminAudit(body);
  } catch (e) {
    body.innerHTML = `<section class="card"><div class="error">${esc(e.message)}</div></section>`;
  }
}

async function onCreateUser(form) {
  try {
    await api("/users", {
      method: "POST",
      body: {
        username: fv(form, "username"),
        email: fv(form, "email"),
        password: fv(form, "password"),
        max_servers: Number(fv(form, "max_servers")),
        is_admin: fc(form, "is_admin"),
      },
    });
    toast("Kullanıcı eklendi");
    renderAdmin("kullanicilar");
  } catch (e) { toast(e.message, true); }
}

async function onSaveAdminSettings(form) {
  const disabled_eggs = [...form.querySelectorAll('input[name="egg_enabled"]')]
    .filter((el) => !el.checked).map((el) => el.value);
  try {
    await api("/admin/settings", {
      method: "PUT",
      body: {
        registration_enabled: fc(form, "registration_enabled"),
        registration_approval: fc(form, "registration_approval"),
        default_max_servers: Number(fv(form, "default_max_servers")),
        max_memory_mb: Number(fv(form, "max_memory_mb")),
        alert_webhook_url: fv(form, "alert_webhook_url").trim(),
        discord_client_id: fv(form, "discord_client_id").trim() || "",
        discord_client_secret: fv(form, "discord_client_secret").trim() || undefined,
        cf_zone_id: fv(form, "cf_zone_id").trim(),
        domain_cname_target: fv(form, "domain_cname_target").trim().toLowerCase(),
        cf_api_token: fv(form, "cf_api_token").trim() || undefined,
        site_base_domain: fv(form, "site_base_domain").trim().toLowerCase(),
        site_subdomains: fc(form, "site_subdomains"),
        max_cpu_percent: Number(fv(form, "max_cpu_percent")),
        max_disk_mb: Number(fv(form, "max_disk_mb")),
        app_rate_per_min: Number(fv(form, "app_rate_per_min")),
        maintenance_mode: fc(form, "maintenance_mode"),
        announcement_enabled: fc(form, "announcement_enabled"),
        announcement: fv(form, "announcement").trim(),
        site_name: fv(form, "site_name").trim(),
        logo_text: fv(form, "logo_text").trim(),
        disabled_eggs,
      },
    });
    await refreshSystem();
    renderBanner();
    toast("Ayarlar kaydedildi");
    renderAdmin("ayarlar");
  } catch (e) { toast(e.message, true); }
}

/* ---------- şablonlar ---------- */
const WEB_EGG_CATEGORIES = ["web", "php"];  // /sites yalnızca statik ve PHP egg'lerinde
const APP_EGG_CATEGORIES = ["nodejs", "python"];  // /api/apps: REST API olarak yayınlanan eggler
const ROUTE_EGG_CATEGORIES = [...WEB_EGG_CATEGORIES, ...APP_EGG_CATEGORIES];

function tplListHtml(list) {
  if (!list.length) {
    return `<p class="muted">Henüz şablon yok. Yeni sunucu formunda "Şablon olarak kaydet" ile ekleyebilirsin.</p>`;
  }
  return `<div class="tpl-grid">${list.map((t) => {
    const egg = (state.eggs || []).find((e) => e.slug === t.egg);
    return `
      <div class="tpl">
        <strong>${esc(t.name)}</strong>
        <div class="muted small-text">${esc(egg ? egg.name : t.egg)} · RAM ${t.memory_mb} MB · CPU %${t.cpu_percent}</div>
        <div class="row" style="margin-top:8px">
          <button class="primary small" data-act="tplCreate" data-id="${t.id}">Bir tıkla oluştur</button>
          <button class="danger small" data-act="tplDelete" data-id="${t.id}">Sil</button>
        </div>
      </div>`;
  }).join("")}</div>`;
}

async function refreshTemplates() {
  state.templates = await api("/templates");
  const box = document.getElementById("tplList");
  if (box) box.innerHTML = tplListHtml(state.templates);
}

async function saveTemplate(form) {
  const name = prompt("Şablon adı (2-48 karakter)");
  if (!name || !name.trim()) return;
  const variables = {};
  form.querySelectorAll("[data-var]").forEach((el) => { variables[el.dataset.var] = el.value; });
  try {
    await api("/templates", {
      method: "POST",
      body: {
        name: name.trim(),
        egg: fv(form, "egg"),
        memory_mb: Number(fv(form, "memory")),
        cpu_percent: Number(fv(form, "cpu")),
        variables,
      },
    });
    await refreshTemplates();
    toast("Şablon kaydedildi");
  } catch (e) { toast(e.message, true); }
}

async function createFromTemplate(id) {
  const tpl = (state.templates || []).find((t) => String(t.id) === String(id));
  if (!tpl) return;
  const name = prompt(`"${tpl.name}" şablonundan oluşturulacak sunucunun adı (2-48 karakter)`);
  if (!name || !name.trim()) return;
  toast("Oluşturuluyor, kurulum birkaç dakika sürebilir...");
  try {
    const s = await api("/servers", {
      method: "POST",
      body: {
        name: name.trim(),
        egg: tpl.egg,
        memory_mb: tpl.memory_mb,
        cpu_percent: tpl.cpu_percent,
        variables: tpl.variables,
      },
    });
    celebrate("Sunucu oluşturuldu");
    location.hash = `#/server/${s.id}/console`;
  } catch (e) { toast(e.message, true); }
}

/* ---------- hesabım: API anahtarları ---------- */
async function renderAccount() {
  const keys = await api("/keys");
  if (typeof loadMeDiscord === "function") setTimeout(loadMeDiscord, 0);
  if (typeof loadMeUsage === "function") setTimeout(loadMeUsage, 0);
  app().innerHTML = `
    <div class="section-head"><h3>Hesabım</h3></div>
    <div id="meUsage"></div>
    <div id="meSessions"></div>
    <div id="meDiscord"></div>
    <section class="card">
      <h4>API anahtarları</h4>
      <p class="muted small-text">Anahtar, panelin size ait işlemlerini komut satırından ya da otomasyonla yapmanızı sağlar.
      Anahtar yalnızca oluşturulduğu anda gösterilir. En fazla 5 anahtar.</p>
      <form id="keyForm" class="row" style="margin:12px 0">
        <input name="name" placeholder="Anahtar adı (ör. otomasyon)" maxlength="48" required>
        <select name="scope">
          <option value="client">İstemci (kendi sunucularım)</option>
          ${state.user.is_admin ? `<option value="application">Uygulama (yönetici işlemleri)</option>` : ""}
        </select>
        <button class="primary" type="submit">Anahtar oluştur</button>
      </form>
      <div id="keyResult"></div>
      <div class="table-wrap">
        <table class="files">
          <thead><tr><th>Ad</th><th>Kapsam</th><th>Önek</th><th>Oluşturuldu</th><th>Son kullanım</th><th class="right"></th></tr></thead>
          <tbody>${keys.map((k) => `
            <tr>
              <td>${esc(k.name)}</td>
              <td><span class="badge">${k.scope === "application" ? "uygulama (yönetici)" : "istemci"}</span></td>
              <td class="muted">${esc(k.prefix)}…</td>
              <td class="muted">${esc(fmtDate(k.created_at))}</td>
              <td class="muted">${esc(fmtDate(k.last_used))}</td>
              <td class="right"><button class="danger small" data-act="keyRevoke" data-id="${k.id}">İptal et</button></td>
            </tr>`).join("") || `<tr><td class="muted" colspan="5">Henüz anahtar yok.</td></tr>`}
          </tbody>
        </table>
      </div>
    </section>
    <section class="card">
      <h4>Kullanım örneği</h4>
      <pre class="console">curl -H "Authorization: Bearer mgp_ANAHTARINIZ" ${esc(location.origin)}/api/servers</pre>
      <p class="muted small-text">Başlıca uç noktalar: /api/servers, /api/templates, /api/alerts, /api/eggs.</p>
    </section>`;
}

async function onCreateKey(form) {
  try {
    const data = await api("/keys", {
      method: "POST",
      body: { name: fv(form, "name").trim(), scope: fv(form, "scope") || "client" },
    });
    document.getElementById("keyResult").innerHTML = `
      <div class="notice">
        <strong>Anahtarınız (bir daha gösterilmez):</strong>
        <pre class="console" style="margin:8px 0">${esc(data.key)}</pre>
        <button class="small" data-act="copyText" data-text="${esc(data.key)}">Kopyala</button>
      </div>`;
    form.reset();
    toast("Anahtar oluşturuldu");
  } catch (e) { toast(e.message, true); }
}

/* ---------- duyuru ve bakım bandı ---------- */
async function refreshSystem() {
  try {
    state.system = await fetch("/api/system").then((r) => r.json());
  } catch { /* eski değerler kalır */ }
  applyBrand();
}

/* Site adı ve logo metni başlığa ve sekme adına uygulanır. */
function applyBrand() {
  const name = (state.system && state.system.site_name) || "Mango Panel";
  const logo = (state.system && state.system.logo_text) || "";
  const brand = document.querySelector(".brand");
  if (brand) brand.innerHTML = `<span class="logo">${logo ? esc(logo) : `<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${LOGO_MARK}</svg>`}</span><span class="brand-name">${esc(name)}</span>`;
  document.title = name;
}

/* Sunucu uyarıları (çökme, yeniden başlatma, disk) periyodik olarak yenilenir. */
async function checkAlerts() {
  if (!state.token || !state.user) { state.alerts = []; return; }
  try {
    state.alerts = await api("/alerts");
  } catch { /* geçici hata: sonraki turda tekrar dene */ }
  renderBanner();
}

function renderBanner() {
  let el = document.getElementById("banner");
  if (!el) {
    el = document.createElement("div");
    el.id = "banner";
    app().before(el);
  }
  const items = [];
  if (state.system && state.system.announcement) {
    items.push(`<div class="banner announce">${icon("bell", 16)} ${esc(state.system.announcement)}</div>`);
  }
  if (state.user && state.user.is_admin && state.system && state.system.maintenance) {
    items.push(`<div class="banner maint">Bakım modu açık: yalnızca yöneticiler giriş yapabiliyor.</div>`);
  }
  for (const a of state.alerts || []) {
    const cls = a.level === "danger" ? "alert-danger" : "alert-warning";
    items.push(`<div class="banner ${cls}">${icon("alert", 16)} <a href="#/server/${a.server_id}/console">${esc(a.server)}</a>: ${esc(a.message)}</div>`);
  }
  el.innerHTML = items.join("");
  el.style.display = items.length ? "" : "none";
}

/* ---------- yönlendirme ---------- */
function teardown() {
  timers.forEach(clearInterval);
  timers = [];
  // Aynı sunucunun sekmeleri arasında geçişte konsol ve terminal açık kalır (1.40.20).
  const m = (location.hash || "").match(/^#\/server\/(\d+)/);
  if (!m || Number(m[1]) !== state.sid) {
    closeConsole();
    closeVpsTerminal();
  }
}

/* Sayfa geçişleri sıraya girer: bir sayfa yüklenirken gelen yeni istek, mevcut yükleme bitince çalışır.
   Böylece eski sayfanın geç gelen yanıtı yeni sayfanın üstüne yazmaz ve son görünen sayfa adres çubuğuyla aynı olur. */
let routing = null;
let routeQueued = false;

function route() {
  if (routing) {
    routeQueued = true;
    return routing;
  }
  routing = (async () => {
    do {
      routeQueued = false;
      try {
        await routeOnce();
      } catch (e) {
        toast(e.message || "Sayfa yüklenemedi", true);
      }
    } while (routeQueued);
  })().finally(() => {
    routing = null;
  });
  return routing;
}

function renderMaintenance() {
  document.body.classList.add("maint-mode");
  const nav = document.getElementById("nav");
  if (nav) nav.innerHTML = "";
  app().innerHTML = `
    <section class="maint-screen">
      <div class="maint-box">
        <div class="maint-icon">🛠️</div>
        <h1>Bakımdayız</h1>
        <p>Panelde planlı bir bakım yapılıyor. Kısa süre sonra tekrar deneyin.</p>
        <a class="maint-admin" href="#/giris">Yönetici girişi</a>
      </div>
    </section>`;
}

const DISCORD_MESSAGES = {
  "onay": "Hesabınız yönetici onayı bekliyor. Onaylandıktan sonra tekrar deneyin.",
  "iptal": "Discord girişi iptal edildi veya süresi doldu.",
  "hata": "Discord girişinde beklenmeyen bir hata oluştu. Tekrar deneyin.",
  "yetki": "Discord yetkilendirme hatası: Client ID, client secret veya yönlendirme adresi yanlış. Ayarları kontrol edin.",
  "ag": "Sunucu Discord'a ulaşamadı. Sunucunun internet erişimini kontrol edin.",
  "kayitli-degil": "Bu Discord hesabı kayıtlı değil. Önce Discord ile kayıt olun.",
  "kayit-kapali": "Kayıt şu an kapalı.",
  "bakim": "Panel bakım modunda. Lütfen daha sonra tekrar deneyin.",
};

function hashParams() {
  const raw = (location.hash || "").split("?")[1] || "";
  return new URLSearchParams(raw);
}

async function routeOnce() {
  teardown();
  app().classList.remove("landing-mode");
  const hashPath = (location.hash || "#/").slice(2).split("?")[0];
  if (hashPath === "discord") {
    const token = hashParams().get("token");
    history.replaceState(null, "", "#/");
    if (token) {
      state.token = token;
      state.user = null;
      safeSet("mango_token", token);
    }
  }
  if (hashPath === "giris" && hashParams().get("discord")) {
    const code = hashParams().get("discord");
    history.replaceState(null, "", "#/giris");
    toast(DISCORD_MESSAGES[code] || "Discord girişi tamamlanamadı.", true);
  }
  if (state.token && !state.user) {
    try { state.user = await api("/me"); } catch { /* aşağıda ele alınır */ }
  }
  const h0 = (location.hash || "#/").replace(/^#\/?/, "");
  const isAdmin = !!(state.user && state.user.is_admin);
  if (state.system && state.system.maintenance && !isAdmin && h0 !== "giris") {
    return renderMaintenance();
  }
  document.body.classList.remove("maint-mode");
  renderBanner();
  if (state.user && typeof refreshNotifBadge === "function") setTimeout(refreshNotifBadge, 0);
  if (!state.token) {
    const h = (location.hash || "#/").replace(/^#\/?/, "");
    if (h === "giris" || h === "kayit") {
      state.authMode = h === "kayit" ? "register" : "login";
      return renderLogin();
    }
    return typeof renderLanding === "function" ? renderLanding() : renderLogin();
  }
  try {
    state.user = await api("/me");
  } catch { return renderLogin(); }
  setNav();
  maybeSuggestDiscord();
  timers.push(setInterval(checkAlerts, 20000));
  checkAlerts();
  if (state.user && state.user.onboarded === false && !document.getElementById("onboard")) {
    state.onboardStep = 0;
    renderOnboarding();
  }
  const parts = (location.hash || "#/").replace(/^#\/?/, "").split("/").filter(Boolean);
  if (parts[0] === "anasayfa" && typeof renderLanding === "function") return renderLanding();
  if (parts[0] === "server" && parts[1]) {
    return renderServerPage(Number(parts[1]), parts[2] || "console");
  }
  if (parts[0] === "help") {
    state.sid = null;
    return renderHelp();
  }
  if (parts[0] === "plans") {
    state.sid = null;
    return renderPlans();
  }
  if (parts[0] === "tickets") {
    state.sid = null;
    return renderTickets(parts.slice(1).join("/"));
  }
  if (parts[0] === "account") return renderAccount();
  if (parts[0] === "chat") return renderChat();
  if (parts[0] === "bildirimler") return renderMyNotifications();
  if (parts[0] === "admin") {
    return renderAdmin(parts[1] || "genel");
  }
  state.sid = null;
  return renderDashboard();
}

/* ---------- eylemler (tek noktadan) ---------- */
function siteAddrText(isApp) {
  if (isApp) return "API adı (adres: /api/apps/<ad>)";
  const base = state.system && state.system.site_base_domain;
  return base ? `Alt alan adı (adres: <ad>.${base})` : "Site adı (adres: /sites/<ad>)";
}

/* Discord önerisi (1.40.25): zorunlu değil. Bağlamayan kullanıcıya üç günde bir kapatılabilir
   bir pencere çıkar; sol menüde de kalıcı bir ipucu bulunur. */
const DISCORD_HINT_KEY = "mango_discord_hint_at";
const DISCORD_HINT_EVERY_MS = 3 * 86400000;

function discordHintDue() {
  try {
    const last = Number(localStorage.getItem(DISCORD_HINT_KEY) || 0);
    return Date.now() - last > DISCORD_HINT_EVERY_MS;
  } catch { return true; }
}
function markDiscordHint() {
  try { localStorage.setItem(DISCORD_HINT_KEY, String(Date.now())); } catch { /* gizli mod */ }
}

function maybeSuggestDiscord() {
  if (!state.user || !state.user.discord_suggest) return;
  if (!discordHintDue() || document.getElementById("discordHint")) return;
  document.body.insertAdjacentHTML("beforeend", `
    <div id="discordHint" class="gate-overlay" role="dialog" aria-modal="true" aria-labelledby="dhTitle">
      <div class="gate-card">
        <div class="gate-kicker">Öneri</div>
        <h1 id="dhTitle">Discord hesabınızı bağlayın</h1>
        <p>Sunucunuz çöktüğünde, süreniz dolmak üzereyken ya da destek talebinize yanıt geldiğinde Discord'dan haber alırsınız. Bağlamak zorunlu değil, ama bildirimleri kaçırmamak için önerilir.</p>
        <div class="gate-actions">
          <button class="primary" data-act="discordLinkStart">Discord ile bağla</button>
          <button data-act="discordHintClose">Daha sonra</button>
        </div>
      </div>
    </div>`);
  markDiscordHint();
}

const actions = {
  backupScheduleSave: async () => {
    const body = {
      schedule: document.getElementById("bsMode").value,
      hour: Number(document.getElementById("bsHour").value),
      keep: Number(document.getElementById("bsKeep").value),
    };
    try {
      await api(`/servers/${state.sid}/backups/schedule`, { method: "PUT", body });
      toast("Otomatik yedek ayarı kaydedildi");
      renderBackups();
    } catch (e) { toast(e.message, true); }
  },
  discordHintClose: () => { document.getElementById("discordHint")?.remove(); },
  discordLinkStart: async () => {
    try {
      const r = await api("/auth/discord/link-url");
      window.location.href = r.url;
    } catch (e) {
      toast(e.message || "Discord bağlantısı başlatılamadı", true);
    }
  },
  logout: () => logout(),
  vpsReconnect: () => { if (state.sid) connectVpsTerminal(state.sid); },
  serverMaintenanceSave: async () => {
    const on = !!document.getElementById("maintOn")?.checked;
    const message = (document.getElementById("maintMsg")?.value || "").trim();
    try {
      await api(`/admin/servers/${state.sid}/maintenance`, { method: "PATCH", body: { on, message: message || null } });
      toast(on ? "Sunucu bakıma alındı" : "Bakım kapatıldı");
      refreshServer(state.sid);
    } catch (e) { toast(e.message, true); }
  },
  vpsDiagnose: async () => {
    const box = document.getElementById("vpsDiag");
    if (!box || !state.sid) return;
    box.innerHTML = `<p class="muted small-text">Kontrol ediliyor…</p>`;
    try {
      const r = await api(`/vps/${state.sid}/terminal/diagnose`);
      box.innerHTML = `<div class="notice${r.ok ? "" : " error"}">${r.ok ? "Tüm kontroller geçti." : "Bazı kontroller başarısız; aşağıdaki satıra bakın."}</div>
        <ul class="small-text">${r.checks.map((c) => `<li>${c.ok ? "✅" : "❌"} <b>${esc(c.name)}</b>${c.detail ? ": <code>" + esc(c.detail) + "</code>" : ""}</li>`).join("")}</ul>`;
    } catch (e) {
      box.innerHTML = `<div class="notice error">${esc(e.message)}</div>`;
    }
  },
  settingsSub: (el) => {
    state.settingsSub = el.dataset.sub;
    renderSettings();
  },
  backupCreate: async () => {
    try { await api(`/servers/${state.sid}/backups`, { method: "POST" }); toast("Yedek alındı"); renderBackups(); }
    catch (e) { toast(e.message, true); }
  },
  backupRestore: async (el) => {
    if (!confirm("Sunucunun mevcut dosyaları bu yedekle değiştirilecek. Devam edilsin mi?")) return;
    try { await api(`/servers/${state.sid}/backups/${encodeURIComponent(el.dataset.name)}/restore`, { method: "POST" }); toast("Yedek geri yüklendi"); renderBackups(); }
    catch (e) { toast(e.message, true); }
  },
  backupDelete: async (el) => {
    if (!confirm("Bu yedek silinsin mi?")) return;
    try { await api(`/servers/${state.sid}/backups/${encodeURIComponent(el.dataset.name)}`, { method: "DELETE" }); toast("Yedek silindi"); renderBackups(); }
    catch (e) { toast(e.message, true); }
  },
  dashScope: (el) => {
    state.dashScope = el.dataset.scope;
    renderDashboard();
  },
  onboardNext: () => { state.onboardStep = Math.min((state.onboardStep || 0) + 1, ONBOARD_STEPS.length - 1); renderOnboarding(); },
  onboardPrev: () => { state.onboardStep = Math.max((state.onboardStep || 0) - 1, 0); renderOnboarding(); },
  onboardFinish: () => finishOnboarding(),
  onboardReplay: () => { state.onboardStep = 0; renderOnboarding(); },
  deleteNote: (el) => deleteNote(el.dataset.id),
  authMode: (el) => {
    state.authMode = el.dataset.mode === "register" ? "register" : "login";
    renderLogin();
  },
  power: (el) => {
    if (el.dataset.action === "kill" && !confirm("Sunucu zorla kapatılsın mı?")) return;
    power(el.dataset.action);
  },
  cd: (el) => { state.filePath = el.dataset.path || ""; state.editPath = null; renderFiles(); },
  openFile: (el) => openFile(el.dataset.path),
  closeEditor: () => { state.editPath = null; document.getElementById("editor").innerHTML = ""; },
  newFolder: async () => {
    const name = prompt("Klasör adı (ör. plugins)");
    if (!name || !name.trim()) return;
    const path = [state.filePath, name.trim()].filter(Boolean).join("/");
    try {
      await api(`/servers/${state.sid}/files/folder`, { method: "POST", body: { path } });
      renderFiles();
    } catch (e) { toast(e.message, true); }
  },
  refreshFiles: () => renderFiles(),
  delEntry: async (el) => {
    const path = el.dataset.path;
    if (!confirm(`"${el.dataset.name}" silinsin mi? Klasörse içindekilerle birlikte silinir.`)) return;
    try {
      await api(`/servers/${state.sid}/files?path=${encodeURIComponent(path)}`, { method: "DELETE" });
      if (state.editPath === path || (state.editPath || "").startsWith(path + "/")) state.editPath = null;
      renderFiles();
    } catch (e) { toast(e.message, true); }
  },
  rebuild: () => {
    if (!confirm("Konteyner yeniden oluşturulsun mu? Dosyalar korunur.")) return;
    serverOp(`/servers/${state.sid}/rebuild`, { reinstall: false }, "Konteyner yeniden oluşturuldu");
  },
  reinstall: () => {
    if (!confirm("Kurulum betiği yeniden çalıştırılsın mı? Dosyalar korunur, birkaç dakika sürebilir.")) return;
    serverOp(`/servers/${state.sid}/rebuild`, { reinstall: true }, "Yeniden kurulum tamamlandı");
  },
  deleteServer: async () => {
    if (!confirm("Sunucu ve tüm dosyaları silinsin mi? Bu işlem geri alınamaz.")) return;
    try {
      await api(`/servers/${state.sid}`, { method: "DELETE" });
      state.sid = null;
      location.hash = "#/";
    } catch (e) { toast(e.message, true); }
  },
  adminDeleteServer: async (el) => {
    if (!confirm(`"${el.dataset.name}" sunucusu ve tüm dosyaları silinsin mi?`)) return;
    try {
      await api(`/servers/${el.dataset.id}`, { method: "DELETE" });
      toast("Sunucu silindi");
      renderAdmin("sunucular");
    } catch (e) { toast(e.message, true); }
  },
  saveLimit: async (el) => {
    const input = document.getElementById(`limit-${el.dataset.id}`);
    try {
      await api(`/users/${el.dataset.id}`, { method: "PATCH", body: { max_servers: Number(input.value) } });
      toast("Limit güncellendi");
    } catch (e) { toast(e.message, true); }
  },
  toggleAdmin: async (el) => {
    const makeAdmin = el.dataset.admin !== "1";
    try {
      await api(`/users/${el.dataset.id}`, { method: "PATCH", body: { is_admin: makeAdmin } });
      toast("Yetki güncellendi");
      renderAdmin("kullanicilar");
    } catch (e) { toast(e.message, true); }
  },
  resetPw: async (el) => {
    const pw = prompt(`${el.dataset.name} için yeni şifre (en az 8 karakter)`);
    if (!pw) return;
    try {
      await api(`/users/${el.dataset.id}`, { method: "PATCH", body: { password: pw } });
      toast("Şifre değiştirildi");
    } catch (e) { toast(e.message, true); }
  },
  deleteUser: async (el) => {
    if (!confirm(`"${el.dataset.name}" kullanıcısı silinsin mi?`)) return;
    try {
      await api(`/users/${el.dataset.id}`, { method: "DELETE" });
      toast("Kullanıcı silindi");
      renderAdmin("kullanicilar");
    } catch (e) { toast(e.message, true); }
  },
  uploadPick: () => document.getElementById("uploadInput")?.click(),
  extractZip: async (el) => {
    toast("Arşiv açılıyor…");
    try {
      const r = await api(`/servers/${state.sid}/files/extract?path=${encodeURIComponent(el.dataset.path)}`, { method: "POST" });
      toast(`${r.extracted} dosya açıldı`);
      renderFiles();
    } catch (e) { toast(e.message, true); }
  },
  toggleTheme: () => {
    const next = currentTheme() === "light" ? "dark" : "light";
    try { localStorage.setItem(THEME_KEY, next); } catch { /* tarayıcı depolamayı engelliyor */ }
    applyTheme(next);
    setNav();
  },
  newFile: () => {
    const name = prompt("Dosya adı (ör. index.js veya plugins/config.yml)");
    if (!name || !name.trim()) return;
    openNewFile([state.filePath, name.trim()].filter(Boolean).join("/"));
  },
  downloadEntry: (el) => downloadFile(`/servers/${state.sid}/files/download?path=${encodeURIComponent(el.dataset.path)}`, el.dataset.name),
  bulkDelete: async () => {
    const paths = [...(state.picked || [])];
    if (!paths.length) return;
    if (paths.length > 200) { toast("Tek seferde en fazla 200 öğe silinebilir", true); return; }
    if (!confirm(`${paths.length} öğe silinsin mi? Klasörler içindekilerle birlikte silinir.`)) return;
    try {
      const results = await api(`/servers/${state.sid}/files/delete-many`, { method: "POST", body: { paths } });
      const failed = results.filter((r) => !r.ok);
      const removed = results.filter((r) => r.ok).map((r) => r.path);
      if (state.editPath && removed.some((p) => state.editPath === p || state.editPath.startsWith(p + "/"))) state.editPath = null;
      state.picked = new Set();
      toast(failed.length
        ? `${removed.length} öğe silindi, ${failed.length} öğe silinemedi (${failed[0].error})`
        : `${removed.length} öğe silindi`, failed.length > 0);
      renderFiles();
    } catch (e) { toast(e.message, true); }
  },
  cloneServer: async () => {
    const name = prompt("Yeni sunucunun adı (ayarlar ve tüm dosyalar kopyalanır; yalnızca harf, rakam, boşluk, - ve _)");
    if (!name || !name.trim()) return;
    toast("Klonlanıyor, bu biraz sürebilir…");
    try {
      const created = await api(`/servers/${state.sid}/clone`, { method: "POST", body: { name: name.trim() } });
      toast("Sunucu klonlandı");
      location.hash = `#/server/${created.id}/console`;
    } catch (e) { toast(e.message, true); }
  },
  storeInstall: async (el) => {
    try {
      await api(`/admin/egg-store/${el.dataset.slug}/install`, { method: "POST" });
      toast("Egg kuruldu");
      renderAdmin("magaza");
    } catch (e) { toast(e.message, true); }
  },
  storeUninstall: async (el) => {
    if (!confirm(`"${el.dataset.name}" egg'i kaldırılsın mı? Bu egg'i kullanan sunucu varsa kaldırılamaz.`)) return;
    try {
      await api(`/admin/eggs/${el.dataset.slug}`, { method: "DELETE" });
      toast("Egg kaldırıldı");
      renderAdmin("magaza");
    } catch (e) { toast(e.message, true); }
  },
  pickEgg: (el) => {
    const input = document.getElementById("eggSelect");
    if (!input || el.disabled) return;
    input.value = el.dataset.slug;
    document.querySelectorAll(".egg-card").forEach((c) => {
      const on = c === el;
      c.classList.toggle("is-on", on);
      c.setAttribute("aria-pressed", on ? "true" : "false");
    });
    renderEggVars();
  },
  adminPower: async (el) => {
    try {
      const r = await api(`/servers/${el.dataset.id}/power`, { method: "POST", body: { action: el.dataset.action } });
      toast(`Durum: ${r.status}`);
      renderAdmin("sunucular");
    } catch (e) { toast(e.message, true); }
  },
  pkgPick: (el) => {
    const form = document.getElementById("pkgForm");
    if (!form) return;
    form.elements.manager.value = el.dataset.manager;
    const input = form.elements.packages;
    const names = input.value.trim() ? input.value.trim().split(/\s+/) : [];
    if (!names.includes(el.dataset.name)) names.push(el.dataset.name);
    input.value = names.join(" ");
    input.focus();
  },
  pkgDeps: (el) => {
    const cmd = el.dataset.manager === "npm" ? "npm install --no-audit --no-fund" : "pip install --no-cache-dir -r requirements.txt";
    sendShellCommand(cmd);
  },
  refreshAudit: () => renderAdmin("kayitlar"),
  refreshHealth: () => renderAdmin("saglik"),
  accessRevoke: async (el) => {
    if (!confirm("Bu alt kullanıcının erişimi kaldırılsın mı?")) return;
    try {
      await api(`/servers/${state.sid}/access/${el.dataset.id}`, { method: "DELETE" });
      toast("Erişim kaldırıldı");
      await loadAccess();
    } catch (e) { toast(e.message, true); }
  },
  tplCreate: (el) => createFromTemplate(el.dataset.id),
  tplDelete: async (el) => {
    if (!confirm("Şablon silinsin mi?")) return;
    try {
      await api(`/templates/${el.dataset.id}`, { method: "DELETE" });
      await refreshTemplates();
      toast("Şablon silindi");
    } catch (e) { toast(e.message, true); }
  },
  saveTemplate: (el) => saveTemplate(el.closest("form")),
  keyRevoke: async (el) => {
    if (!confirm("Anahtar iptal edilsin mi? Bu anahtarı kullanan otomasyonlar çalışmayı durdurur.")) return;
    try {
      await api(`/keys/${el.dataset.id}`, { method: "DELETE" });
      toast("Anahtar iptal edildi");
      renderAccount();
    } catch (e) { toast(e.message, true); }
  },
  copyText: async (el) => {
    try {
      await navigator.clipboard.writeText(el.dataset.text);
      toast("Kopyalandı");
    } catch { toast("Kopyalanamadı; metni elle seçin", true); }
  },
  wizNext: (el) => wizNext(el.closest("form")),
  wizBack: (el) => wizBack(el.closest("form")),
  userServers: async (el) => {
    const row = document.getElementById(`us-${el.dataset.id}`);
    if (!row) return;
    if (!row.hidden) { row.hidden = true; return; }
    try {
      const all = await api("/admin/servers");
      const mine = all.filter((s) => String(s.owner_id) === String(el.dataset.id));
      row.querySelector("td").innerHTML = mine.length
        ? `<table class="files"><thead><tr><th>Ad</th><th>Egg</th><th>Durum</th><th>RAM</th><th>Adres</th></tr></thead><tbody>${mine.map((s) => `
            <tr>
              <td><a href="#/server/${s.id}/console">${esc(s.name)}</a>${s.suspended ? ' <span class="badge suspended">askıda</span>' : ""}</td>
              <td class="muted">${esc(s.egg)}</td>
              <td><span class="badge ${esc(s.status)}"><span class="dot ${esc(s.status)}"></span>${esc(s.status)}</span></td>
              <td>${s.memory_mb} MB</td>
              <td class="muted">${esc(s.address)}</td>
            </tr>`).join("")}</tbody></table>`
        : `<span class="muted">Bu kullanıcının sunucusu yok.</span>`;
      row.hidden = false;
    } catch (e) { toast(e.message, true); }
  },
  downloadBackup: () => downloadFile("/admin/backup", `mango-yedek-${Date.now()}.tar.gz`),
  downloadServerBackup: () => downloadFile(`/servers/${state.sid}/backup`, `sunucu-${state.sid}.tar.gz`),
  suspendServer: async (el) => {
    const suspend = el.dataset.suspended !== "1";
    const question = suspend
      ? "Sunucu askıya alınsın mı? Konteyner durdurulur, sahibi erişemez, veriler silinmez."
      : "Askıya alma kaldırılsın mı?";
    if (!confirm(question)) return;
    try {
      await api(`/admin/servers/${el.dataset.id}/suspend`, { method: "POST", body: { suspended: suspend } });
      toast(suspend ? "Sunucu askıya alındı" : "Askıya alma kaldırıldı");
      renderAdmin("sunucular");
    } catch (e) { toast(e.message, true); }
  },
};

/* ---------- formlar ---------- */
const forms = {
  loginForm: onLogin,
  registerForm: onRegister,
  createForm: (form) => (Number(form.dataset.step) < 3 ? wizNext(form) : onCreateServer(form)),
  cmdForm: onSendCommand,
  settingsForm: onSaveSettings,
  siteForm: onSaveSite,
  varsForm: onSaveVars,
  editorForm: onSaveFile,
  userForm: onCreateUser,
  adminSettingsForm: onSaveAdminSettings,
  keyForm: onCreateKey,
  accessForm: onGrantAccess,
  apiTestForm: onApiTest,
  pkgForm: onPackageInstall,
  envForm: onSaveEnv,
  startupForm: onSaveStartup,
  noteForm: onAddNote,
};

Object.assign(actions, window.platformActions || {});

document.addEventListener("click", (e) => {
  const el = e.target.closest("[data-act]");
  if (!el) return;
  const fn = actions[el.dataset.act];
  if (fn) {
    e.preventDefault();
    fn(el);
  }
});

document.addEventListener("submit", (e) => {
  const handler = forms[e.target.id];
  if (!handler) return;
  e.preventDefault();
  handler(e.target);
});

document.addEventListener("change", (e) => {
  if (e.target.id === "eggSelect") renderEggVars();
  if (e.target.id === "uploadInput") uploadFiles(e.target);
  if (e.target.id === "pickAll") onPickAll(e.target);
  if (e.target.classList.contains("pick")) onPickChange(e);
});

document.addEventListener("input", (e) => {
  if (e.target.id !== "userSearch") return;
  const q = e.target.value.trim().toLowerCase();
  document.querySelectorAll("#userTable tbody tr").forEach((row) => {
    row.style.display = !q || (row.dataset.search || "").includes(q) ? "" : "none";
  });
});

async function init() {
  await refreshSystem();
  if (state.system.source_url) document.getElementById("source").href = state.system.source_url;
  if (state.system.version) document.getElementById("version").textContent = "v" + state.system.version;
  window.addEventListener("hashchange", () => { route(); if (state.user) setNav(); });
  route();
}

applyTheme(currentTheme());
init();
