/* Ana sayfa (1.26.0): giriş yapmamış ziyaretçiye gösterilen tanıtım sayfası.
 * Giriş ve kayıt butonları #/giris ve #/kayit rotalarına gider; paketler /api/public/plans'ten okunur. */
(function () {
  const FEATURES = [
    ["Canlı konsol", "Sunucu çıktısını anlık izleyin ve komut gönderin."],
    ["Dosya yöneticisi", "Dosyalarınızı tarayıcıdan yükleyin, düzenleyin ve indirin."],
    ["Paket kurulumu", "npm ve pip paketlerini tek tıkla kurun, eksik paketleri otomatik bulun."],
    ["Discord entegrasyonu", "Hesabınızı Discord'a bağlayın, sunucunuzu bot üzerinden yönetin."],
    ["Destek ve Genel sohbet", "Destek talebi açın, logunuzu paylaşın, topluluktan yardım alın."],
    ["Özel alan adı", "Kendi domaininizi sunucunuza bağlayın."],
  ];
  const STEPS = [
    ["Hesabınızı oluşturun", "Kayıt olun ve giriş yapın. Yalnızca birkaç dakika sürer."],
    ["Paketinizi seçin", "Bir paket seçin, sunucunuz yönetici tarafından hazırlanır."],
    ["Konsoldan yönetin", "Dosyalarınızı düzenleyin, paketlerinizi kurun, sunucunuzu başlatın."],
  ];
  const FAQ = [
    ["Mango Panel nedir?", "Oyun sunucuları, web siteleri ve Discord botları için tarayıcıdan yönetilen bir hosting panelidir."],
    ["Sunucumu nasıl açarım?", "Hesap oluşturduktan sonra bir paket seçip destek talebi açarsınız. Ekibimiz sunucunuzu hazırlar."],
    ["Ödeme nasıl yapılır?", "Satın alma talebi açarsınız, ödeme ve kurulum adımlarını ekibimiz sizinle paylaşır."],
    ["Sunucularım birbirinden ayrı mı?", "Evet. Her sunucu kendi konteynerinde çalışır ve gizli bilgiler panelde maskelenir."],
    ["Destek nasıl alırım?", "Panelden destek talebi açabilir veya Genel sohbet sekmesinde yardım isteyebilirsiniz."],
  ];

  const PRODUCTS = [
    ["game", "Oyun sunucuları", "Minecraft, Rust ve benzeri oyunlar için hazır kurulum. Konsoldan yönetin, yedek alın.", ["Tek tıkla kurulum", "Canlı konsol", "Otomatik yedek"]],
    ["web", "Web hosting", "Node.js, PHP ve Python sitelerinizi yayınlayın. Kendi alan adınızı bağlayın.", ["Özel alan adı", "Dosya yöneticisi", "Canlı log"]],
    ["vps", "Linux VPS", "Ubuntu 24.04 ve Debian 12 üzerinde tam kontrollü sunucu. Terminal panelin içinde.", ["Renkli terminal", "Apt ile paket kurma", "Yeniden kurulum"]],
    ["bot", "Discord botları", "Node.js veya Python botlarınızı çalıştırın, panelden yönetin ve olaylarda bildirim alın.", ["Otomatik yeniden başlatma", "Bildirimler", "Paket kurulumu"]],
  ];

  function memText(mb) {
    const n = Number(mb) || 0;
    if (n >= 1024) return (n % 1024 === 0 ? n / 1024 : (n / 1024).toFixed(1)) + " GB";
    return n + " MB";
  }

  function previewRow(name, cls, label) {
    return `<div class="lp-row"><span class="lp-dot ${cls}"></span><span class="lp-name">${esc(name)}</span><span class="lp-state">${esc(label)}</span></div>`;
  }

  function renderLanding() {
    setNav();
    const el = app();
    el.classList.add("landing-mode");
    const canRegister = !!(state.system && state.system.registration_enabled);
    const signup = state.token
      ? '<a class="lp-btn lp-primary" href="#/">Panele git</a>'
      : canRegister
        ? '<a class="lp-btn lp-primary" href="#/kayit">Ücretsiz kayıt ol</a>'
        : '<a class="lp-btn lp-primary" href="#/giris">Giriş yap</a>';
    el.innerHTML = `
      <div class="lp-topbar">
        <div class="lp-topbar-in">
          <span>Destek: panelden talep açın</span>
          <span class="lp-topbar-links">
            <a href="#/chat">Genel sohbet</a>
            <a href="#paketler" data-scroll="paketler">Paketler</a>
            ${state.token ? '<a href="#/">Panele git</a>' : '<a href="#/giris">Giriş</a>'}
          </span>
        </div>
      </div>

      <section class="lp-hero">
        <div class="lp-hero-text">
          <span class="lp-badge">Oyun · Web · VPS · Bot</span>
          <h1>Sunucularınız için tek panel</h1>
          <p class="lp-lead">Oyun sunucusu, web sitesi, VPS veya Discord botu: hepsini tarayıcıdan kurun, izleyin ve yönetin.</p>
          <ul class="lp-checks">
            <li>Tek tıkla kurulum</li>
            <li>Canlı konsol ve dosya yöneticisi</li>
            <li>Yedek alma ve geri yükleme</li>
          </ul>
          <div class="lp-actions">
            ${signup}
            <a class="lp-btn lp-ghost" href="#paketler" data-scroll="paketler">Paketleri incele</a>
          </div>
        </div>
        <div class="lp-visual" aria-hidden="true">
          <div class="lp-mock">
            <div class="lp-mock-top"><span></span><span></span><span></span></div>
            <div class="lp-mock-title">Sunucu durumu</div>
            ${previewRow("Discord botu", "running", "Çalışıyor")}
            ${previewRow("Linux VPS", "running", "Çalışıyor")}
            ${previewRow("Web sitesi", "stopped", "Durduruldu")}
            ${previewRow("Oyun sunucusu", "restarting", "Yeniden başlıyor")}
            <div class="lp-mock-bars"><i style="width:62%"></i><i style="width:38%"></i><i style="width:80%"></i></div>
          </div>
        </div>
      </section>

      <section class="lp-products" aria-label="Ürünler">
        <div class="lp-tabs" role="tablist">
          ${PRODUCTS.map(([id, name], i) => `<button class="lp-tab ${i === 0 ? "is-on" : ""}" role="tab" data-ltab="${id}">${esc(name)}</button>`).join("")}
        </div>
        <div class="lp-tabpanel" id="lpTabPanel">
          ${PRODUCTS.map(([id, name, desc, pts], i) => `
            <div class="lp-tabcontent ${i === 0 ? "is-on" : ""}" data-lcontent="${id}">
              <div>
                <h3>${esc(name)}</h3>
                <p>${esc(desc)}</p>
                <a class="lp-btn lp-primary" href="#paketler" data-scroll="paketler">Paketleri gör</a>
              </div>
              <ul class="lp-checks">${pts.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>
            </div>`).join("")}
        </div>
      </section>

      <section class="lp-section">
        <h2>Her şey tek yerde</h2>
        <p class="lp-sub">Sunucunuzu yönetmek için ihtiyacınız olan araçlar panelde hazır.</p>
        <div class="lp-grid">
          ${FEATURES.map(([t, d]) => `<article class="lp-feature"><h3>${esc(t)}</h3><p>${esc(d)}</p></article>`).join("")}
        </div>
      </section>

      <section class="lp-section" id="paketler">
        <h2>Paketler</h2>
        <p class="lp-sub">Size uygun paketi seçin, kaynaklar paket içinde tanımlıdır.</p>
        <div id="landingPlans" class="lp-grid">
          <p class="muted">Paketler yükleniyor...</p>
        </div>
      </section>

      <section class="lp-section">
        <h2>Nasıl çalışır?</h2>
        <div class="lp-grid">
          ${STEPS.map(([t, d], i) => `<article class="lp-step"><span class="lp-step-num">${i + 1}</span><h3>${esc(t)}</h3><p>${esc(d)}</p></article>`).join("")}
        </div>
      </section>

      <section class="lp-section">
        <h2>Sık sorulan sorular</h2>
        ${FAQ.map(([q, a]) => `<details class="lp-faq"><summary>${esc(q)}</summary><p>${esc(a)}</p></details>`).join("")}
      </section>

      <section class="lp-cta">
        <h2>Hemen başlayın</h2>
        <p>Hesabınızı açın, paketinizi seçin ve sunucunuzu yönetmeye bugün başlayın.</p>
        ${signup}
      </section>`;
    loadLandingPlans();
  }

  async function loadLandingPlans() {
    const box = document.getElementById("landingPlans");
    if (!box) return;
    let plans;
    try {
      plans = await api("/public/plans");
    } catch (err) {
      plans = null;
    }
    if (!document.getElementById("landingPlans")) return; // kullanıcı başka sayfaya geçtiyse
    if (plans === null) {
      box.innerHTML = '<p class="muted">Paketler şu an yüklenemedi. Lütfen sayfayı yenileyin.</p>';
      return;
    }
    if (!plans.length) {
      box.innerHTML = '<p class="muted">Paketler hazırlanıyor. Bilgi için kayıt olup destek talebi açabilirsiniz.</p>';
      return;
    }
    box.innerHTML = plans.map((p) => window.planCardHtml(p, '<a class="lp-btn lp-primary" href="#/kayit">Bu paketle başla</a>')).join("");
  }

  // Ürün sekmeleri
  document.addEventListener("click", (e) => {
    const tab = e.target.closest && e.target.closest("[data-ltab]");
    if (!tab) return;
    const id = tab.dataset.ltab;
    document.querySelectorAll("[data-ltab]").forEach((b) => b.classList.toggle("is-on", b === tab));
    document.querySelectorAll("[data-lcontent]").forEach((c) => c.classList.toggle("is-on", c.dataset.lcontent === id));
  });

  // Sayfa içi kaydırma: adres çubuğundaki rotayı değiştirmeden bölüme iner.
  document.addEventListener("click", (e) => {
    const link = e.target.closest && e.target.closest("[data-scroll]");
    if (!link) return;
    e.preventDefault();
    const target = document.getElementById(link.dataset.scroll);
    if (target) target.scrollIntoView({ behavior: "smooth", block: "start" });
    else location.hash = "#/";
  });

  window.renderLanding = renderLanding;
})();
