/* Mango maskotu (1.25.0): sağ altta yaşayan, sunucu durumuna göre tepki veren karakter.
 * Sunucular çalışıyorsa mutlu, bir sunucu sürekli yeniden başlıyorsa üzgün ve uyarır,
 * hiç çalışan sunucu yoksa uykuda. Konuşmalar animasyonlu balonda, harf harf çıkar. */
(function () {
  const POLL_MS = 15000;
  const CALM_QUIP_MS = 120000;
  const WARN_REPEAT_MS = 60000;
  const LINES = {
    happy: [
      "Sunucuların hepsi tıkır tıkır çalışıyor!",
      "Bugün harika gidiyorsun, bu işi çok iyi yönetiyorsun.",
      "Her şey yolunda, devam!",
      "Bir sunucu daha çalışsa çiftlik tamamlanacak gibi!",
    ],
    sad: [
      "Bir sunucun sürekli yeniden başlıyor gibi görünüyor, bir göz atar mısın?",
      "Ah... bir sunucu iyi değil. Konsoldaki son satırlara bakabilirsin.",
      "Yardıma ihtiyacın olursa Genel sohbet sekmesinden log paylaşabilirsin.",
    ],
    sleep: [
      "Şu an çalışan bir sunucu yok. Biraz uyuyorum...",
      "Bir sunucuyu başlatsan ben de uyanırım!",
      "Zzz... sunucuların uyanmasını bekliyorum.",
    ],
  };
  const MOUTHS = {
    happy: "M46 78 Q60 94 74 78",
    sad: "M46 90 Q60 76 74 90",
    sleep: "M52 84 L68 84",
  };
  const reduceMotion = !!(window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches);

  let root, bubble, bubbleText, mouth, eyes;
  let mood = null;
  let typing = null;
  let hideTimer = null;
  let lastCalm = 0;
  let lastWarn = 0;

  function pick(list) {
    return list[Math.floor(Math.random() * list.length)];
  }

  function build() {
    root = document.createElement("div");
    root.id = "mangoPet";
    root.className = "mp-root";
    root.hidden = true;

    bubble = document.createElement("div");
    bubble.className = "mp-bubble";
    bubble.setAttribute("role", "status");
    bubble.setAttribute("aria-live", "polite");
    bubbleText = document.createElement("span");
    bubble.appendChild(bubbleText);

    const button = document.createElement("button");
    button.type = "button";
    button.className = "mp-mascot";
    button.title = "Mango'ya dokun";
    button.setAttribute("aria-label", "Mango");
    button.innerHTML =
      '<svg viewBox="0 0 120 120" class="mp-svg" aria-hidden="true">' +
      '<path class="mp-body" d="M60 12 C92 10 112 40 108 72 C104 102 82 114 60 112 C36 114 14 100 12 70 C10 40 30 14 60 12 Z"/>' +
      '<path class="mp-leaf" d="M62 16 C66 4 80 2 90 8 C82 18 72 20 62 16 Z"/>' +
      '<g class="mp-eyes"><circle class="mp-eye" cx="44" cy="62" r="5"/><circle class="mp-eye" cx="76" cy="62" r="5"/></g>' +
      '<circle class="mp-cheek" cx="34" cy="76" r="5"/><circle class="mp-cheek" cx="86" cy="76" r="5"/>' +
      '<path class="mp-mouth" d="M46 78 Q60 94 74 78"/>' +
      "</svg>";
    eyes = button.querySelector(".mp-eyes");
    mouth = button.querySelector(".mp-mouth");
    button.addEventListener("click", () => {
      poll(true);
    });

    root.appendChild(bubble);
    root.appendChild(button);
    document.body.appendChild(root);
  }

  function say(text, holdMs) {
    clearTimeout(hideTimer);
    const token = { cancelled: false };
    if (typing) typing.cancelled = true;
    typing = token;
    bubbleText.textContent = "";
    bubbleText.classList.toggle("mp-caret", !reduceMotion);
    bubble.classList.add("mp-show");
    let i = 0;
    const step = () => {
      if (token.cancelled) return;
      i += 1;
      bubbleText.textContent = text.slice(0, i);
      if (i < text.length) {
        setTimeout(step, reduceMotion ? 0 : 22);
      } else {
        bubbleText.classList.remove("mp-caret");
        hideTimer = setTimeout(() => bubble.classList.remove("mp-show"), holdMs);
      }
    };
    step();
  }

  function applyMood(next) {
    root.classList.toggle("mp-sad", next === "sad");
    root.classList.toggle("mp-sleep", next === "sleep");
    root.classList.toggle("mp-happy", next === "happy");
    mouth.setAttribute("d", MOUTHS[next]);
    eyes.classList.toggle("mp-sleepy", next === "sleep");
  }

  function evaluate(servers) {
    const running = servers.filter((s) => s.status === "running").length;
    const broken = servers.filter((s) => s.status === "restarting" || s.status === "dead");
    if (broken.length) return { mood: "sad", detail: broken[0].name || "Bir sunucu" };
    if (running > 0) return { mood: "happy", detail: running + " sunucu çalışıyor" };
    return { mood: "sleep", detail: "" };
  }

  async function poll(force) {
    if (!root) return;
    if (typeof state === "undefined" || !state.token) {
      root.hidden = true;
      return;
    }
    root.hidden = false;
    let servers;
    try {
      servers = await api("/servers?scope=mine");
    } catch (err) {
      return; // ağ hatasında sessiz kal; maskot son durumunu korur
    }
    const { mood: next, detail } = evaluate(servers || []);
    const changed = next !== mood;
    mood = next;
    applyMood(next);
    const now = Date.now();

    if (changed) {
      if (next === "sad") {
        lastWarn = now;
        say(detail + " sürekli yeniden başlıyor gibi. " + pick(LINES.sad), 12000);
      } else if (next === "happy") {
        lastCalm = now;
        say(detail + ". " + pick(LINES.happy), 7000);
      } else {
        say(pick(LINES.sleep), 7000);
      }
    } else if (next === "sad" && now - lastWarn > WARN_REPEAT_MS) {
      lastWarn = now;
      say(pick(LINES.sad), 10000);
    } else if (next === "happy" && (force || now - lastCalm > CALM_QUIP_MS)) {
      lastCalm = now;
      say(pick(LINES.happy), 6000);
    } else if (next === "sleep" && force) {
      say(pick(LINES.sleep), 5000);
    }
  }

  function start() {
    if (!document.body) return;
    build();
    setTimeout(() => poll(false), 1500);
    setInterval(() => poll(false), POLL_MS);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start);
  } else {
    start();
  }
})();
