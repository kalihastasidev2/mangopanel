# Mango Panel

Docker tabanlı, egg (şablon) sistemine sahip açık kaynak sunucu yönetim paneli.
Lisans: AGPL-3.0-or-later (bkz. `LICENSE`).

## Özellikler (1.1.0)

- **Sunucular:** egg'den oluşturma, başlat / yeniden başlat / durdur / zorla kapat, ad, RAM, CPU ve ortam değişkenlerini düzenleme
- **Canlı konsol:** log akışı ve konsola komut gönderme (geçmiş için ok tuşları)
- **İstatistikler:** sunucu başına anlık CPU ve bellek kullanımı
- **Dosya yöneticisi:** klasörlerde gezinme, metin dosyalarını düzenleme (1 MB'a kadar), klasör oluşturma, silme
- **Bakım:** konteyneri yeniden oluşturma (dosyalar korunur), kurulum betiğini yeniden çalıştırma
- **Kullanıcılar:** yönetici/kullanıcı rolleri, şifre değiştirme, kullanıcı silme
- **Kurulum:** `setup.py` ile tek komut kurulum, Cloudflare Tunnel desteği, teşhis (`--doctor`) ve kaldırma (`--uninstall`)

Henüz yok: dosya yükleme, yedekleme, zamanlanmış görevler, barındırılan sitelerin tünel üzerinden otomatik yayını.

## Mimari

```
İstemci ──> nginx (tek giriş noktası)
              ├── /          PHP (php/index.php)   arayüz sayfası, php-fpm
              ├── /static/   web/                  JS/CSS
              └── /api/      Python FastAPI        yalnızca 127.0.0.1
Barındırılan siteler: Node.js, PHP, Python eggleri (Docker konteynerleri)
```

Erişim iki şekilde yapılır:

- **Doğrudan:** nginx sunucu portunda dinler.
- **Cloudflare Tunnel:** nginx yalnızca 127.0.0.1:8080'de dinler, tünel HTTPS trafiğini buraya yönlendirir.
  Bu modda yalnızca web, PHP, Node.js, Python ve bot eggleri çalışabilir. Oyun sunucuları engellenir.

## Kurulum (Debian/Ubuntu, root)

```bash
cd ~/mango-panel
sudo python3 setup.py --cloudflare --domain panel.alanadi.com   # Cloudflare ile
sudo python3 setup.py --yes                                       # doğrudan erişim
```

Cloudflare modunda kurulum bir giriş bağlantısı gösterir. Bağlantıyı tarayıcıda açıp onaylaman gerekir.
Bunun dışındaki tüm adımlar otomatiktir.

Teşhis ve onarım:

```bash
sudo python3 setup.py --doctor
```

Kaldırma:

```bash
sudo python3 setup.py --uninstall
```

## Güncelleme (1.0.x → 1.1.0)

Mevcut kurulumun üzerine yeni sürümü kopyala. `mango.json`, `data/`, `.venv/` ve `mango-admin.txt` dosyalarına dokunma.

```bash
# 1) Yeni zip'i sunucuya yükle ve aç (ör. /root/mango-update)
cd /root && unzip -o mango-panel-1.1.0.zip -d mango-update

# 2) Kod dosyalarını mevcut kuruluma kopyala
cp -r /root/mango-update/mango-panel/mango /root/mango-panel/
cp -r /root/mango-update/mango-panel/web /root/mango-panel/
cp -r /root/mango-update/mango-panel/php /root/mango-panel/
cp -r /root/mango-update/mango-panel/eggs /root/mango-panel/
cp /root/mango-update/mango-panel/setup.py /root/mango-panel/

# 3) Arayüz dosyalarını nginx'in okuduğu klasöre yayınla
cp /root/mango-panel/php/*.php /var/lib/mango/www/
cp -r /root/mango-panel/web/. /var/lib/mango/www/static/
chmod -R a+rX /var/lib/mango/www

# 4) Paneli yeniden başlat
systemctl restart mango-panel
```

Zip'in iç klasör adı farklıysa (`mango-panel/` yerine başka bir ad) 2. adımdaki yolları buna göre değiştir.

Güncelleme sonrası eski sunucuların konsoldan komut alabilmesi için her sunucunun **Ayarlar → Bakım → Yeniden oluştur** butonuna bir kez bas. Dosyalar silinmez.

Sunucu teşhisi:

```bash
journalctl -u mango-panel -n 50 --no-pager
```

## Dosya yapısı

| Yol | Görev |
|---|---|
| `mango/` | Python API, veritabanı, Docker yönetimi, dosya yöneticisi, egg yükleyici |
| `php/` | Arayüz sayfası (index.php), sağlık kontrolü (health.php) |
| `web/` | Arayüz dosyaları (index.html, app.js, style.css) |
| `eggs/` | Uygulama şablonları (YAML) |
| `setup.py` | Kurulum, teşhis, onarım ve kaldırma aracı |
| `tests/` | Birim ve API testleri (`pytest`) |

Kurulum sırasında `php/` ve `web/` içeriği `/var/lib/mango/www` altına kopyalanır.
Bu klasör www-data tarafından okunabilir olmalıdır. `/root` altındaki dosyalar buradan okunamaz.

## Egg yazmak

| Alan | Açıklama |
|---|---|
| `name`, `description` | Arayüzde görünen ad |
| `category` | `web`, `php`, `nodejs`, `python`, `bot` veya `game`. Tünel modunda `game` engellenir. |
| `docker_image` | Kullanılacak Docker imajı |
| `install_script` | Sunucu ilk oluşturulduğunda (ve "Yeniden kur" ile) çalışır |
| `startup` | Konteynerin ana komutu; `{{DEGISKEN}}` yer tutucuları kullanılabilir |
| `ports` | İlk port konteyner içindeki birincil porttur |
| `variables` | Kullanıcının dolduracağı değerler |

Değişken değerlerinde yalnızca `A-Z a-z 0-9 . _ - / : = @ ,` karakterlerine izin verilir (shell enjeksiyonunu önlemek için).

## Güvenlik

- Docker socket erişimi root yetkisine eşdeğerdir. Docker grubuna yalnızca güvendiğin kullanıcıları ekle.
- Konteynerler `cap_drop: ALL` ve `no-new-privileges` ile çalışır.
- Dosya yöneticisi yalnızca sunucunun kendi klasörüne erişir. Sembolik bağlantılarla klasör dışına çıkma engellenir.
- Konsol komutları tek satır ve en fazla 500 karakterdir.
- Python API yalnızca 127.0.0.1'de dinler; dışarıya nginx üzerinden açılır.
- `mango.json` (gizli anahtar, veritabanı bilgisi) yalnızca root tarafından okunabilir. Web klasörüne kopyalanmaz.
- Parolalar PBKDF2-SHA256 (260.000 iterasyon) ile saklanır, oturum JWT ile yönetilir.
- Arayüz inline script kullanmaz (CSP `script-src 'self'`).
- Mevcut bir DNS kaydı, hostname'e ait değilse kurulum tarafından değiştirilmez (`--force-dns` gerekir).

## Testler

```bash
pip install -r requirements.txt
python -m pytest -q tests
```

Testler Docker gerektirmez. Konteyner işlemleri (başlat, konsol, istatistik) gerçek bir Docker ortamında ayrıca doğrulanmalıdır.

## Bilinen sınırlamalar

- Barındırılan sitelerin Cloudflare Tunnel üzerinden dışarı açılması henüz otomatik değil; yalnızca panel arayüzü tünelden yayınlanır.
- Dosya yükleme ve büyük dosya düzenleme yok (düzenleyici 1 MB sınırlıdır).
- Yedekleme ve zamanlanmış görevler sonraki sürümde.
- Kurulum yalnızca Debian/Ubuntu (apt) ve systemd için tasarlandı.
- `AGPL` gereği `LICENSE` dosyasının tam metnini `https://www.gnu.org/licenses/agpl-3.0.txt` adresinden kopyala.
