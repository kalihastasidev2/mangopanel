"""1.40.5: alt alan kayıtları ayarlanan CNAME hedefine (tünel adresi) yazılır."""
from mango import site_dns
from mango.db import SessionLocal, init_db
from mango.store import set_setting

TUNNEL = "1b2081b8-60ed-44be-bf76-72571291b7bc.cfargotunnel.com"


def test_cname_target_uses_configured_tunnel_address():
    init_db()
    db = SessionLocal()
    set_setting(db, "site_subdomains", "1")
    set_setting(db, "site_base_domain", "example.com")
    set_setting(db, "cf_api_token", "tok")
    set_setting(db, "cf_zone_id", "zone123")
    set_setting(db, "domain_cname_target", TUNNEL.upper())
    db.commit()
    cfg = site_dns._cfg(db)
    db.close()
    assert cfg is not None
    assert cfg[3] == TUNNEL


def test_subdomains_are_off_by_default():
    init_db()
    db = SessionLocal()
    set_setting(db, "site_subdomains", "0")
    set_setting(db, "cf_api_token", "tok")
    set_setting(db, "cf_zone_id", "zone123")
    db.commit()
    assert site_dns._cfg(db) is None
    assert site_dns.public_base(db) == ""
    db.close()
