"""1.40.4: yeni kayıtlar yönetici onayı beklesin (registration_approval)."""
import pytest
from fastapi.testclient import TestClient

from mango.config import settings
from mango.db import SessionLocal, User, init_db
from mango.main import app
from mango.security import hash_password
from mango.store import set_setting


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-v1404"))
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="v1404_admin").first() is None:
        db.add(User(username="v1404_admin", email="v1404a@example.com",
                    password_hash=hash_password("adminpass1"), is_admin=True, max_servers=99))
        db.commit()
    db.close()
    return TestClient(app)


@pytest.fixture
def approval_on():
    db = SessionLocal()
    set_setting(db, "registration_approval", "1")
    db.commit()
    db.close()
    yield
    db = SessionLocal()
    set_setting(db, "registration_approval", "0")
    db.commit()
    db.close()


def _admin(client):
    r = client.post("/api/auth/login", json={"username": "v1404_admin", "password": "adminpass1"})
    return {"Authorization": f"Bearer {r.json()['token']}"}


def test_register_without_approval_returns_token(client):
    r = client.post("/api/auth/register", json={
        "username": "v1404_open", "email": "open@example.com", "password": "guclu-sifre-1"})
    assert r.status_code == 201
    assert "token" in r.json()


def test_pending_user_cannot_login_until_approved(client, approval_on):
    r = client.post("/api/auth/register", json={
        "username": "v1404_pending", "email": "pending@example.com", "password": "guclu-sifre-1"})
    assert r.status_code == 201
    assert r.json().get("pending") is True
    assert "token" not in r.json()

    blocked = client.post("/api/auth/login", json={"username": "v1404_pending", "password": "guclu-sifre-1"})
    assert blocked.status_code == 403
    assert "onay" in blocked.json()["detail"].lower()

    db = SessionLocal()
    uid = db.query(User).filter_by(username="v1404_pending").one().id
    db.close()
    assert client.patch(f"/api/users/{uid}", json={"approved": True}, headers=_admin(client)).status_code == 200

    ok = client.post("/api/auth/login", json={"username": "v1404_pending", "password": "guclu-sifre-1"})
    assert ok.status_code == 200
    assert "token" in ok.json()


def test_admin_is_never_blocked_by_approval(client, approval_on):
    r = client.post("/api/auth/login", json={"username": "v1404_admin", "password": "adminpass1"})
    assert r.status_code == 200


def test_approval_setting_is_exposed_and_saved(client):
    headers = _admin(client)
    r = client.put("/api/admin/settings", json={"registration_approval": True}, headers=headers)
    assert r.status_code == 200
    assert r.json()["registration_approval"] is True
    client.put("/api/admin/settings", json={"registration_approval": False}, headers=headers)
