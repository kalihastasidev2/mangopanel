import pytest
from fastapi.testclient import TestClient

from mango.config import settings
from mango.db import ServerAccess, SessionLocal, Server, User, init_db
from mango.main import app
from mango.security import hash_password


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-v19"))
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="v19_admin").first() is None:
        db.add(User(username="v19_admin", email="v19a@example.com",
                    password_hash=hash_password("adminpass1"), is_admin=True, max_servers=99))
        db.commit()
    db.close()
    return TestClient(app)


def _login(client, name, password):
    r = client.post("/api/auth/login", json={"username": name, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["token"]}


def _member(client, name):
    db = SessionLocal()
    user = db.query(User).filter_by(username=name).first()
    if user is None:
        user = User(username=name, email=f"{name}@example.com",
                    password_hash=hash_password("guclu-sifre-1"), is_admin=False, max_servers=5)
        db.add(user)
        db.commit()
    uid = user.id
    db.close()
    return uid, _login(client, name, "guclu-sifre-1")


def _server(owner_id, port, name="Paylasim"):
    db = SessionLocal()
    server = Server(name=name, egg="static-web", owner_id=owner_id, port=port,
                    memory_mb=256, cpu_percent=100, variables={})
    db.add(server)
    db.commit()
    sid = server.id
    db.close()
    return sid


def _cleanup(sid):
    db = SessionLocal()
    db.query(ServerAccess).filter_by(server_id=sid).delete()
    db.query(Server).filter_by(id=sid).delete()
    db.commit()
    db.close()


def test_health_is_admin_only_and_reports_database(client):
    admin = _login(client, "v19_admin", "adminpass1")
    _, member = _member(client, "health_member")
    assert client.get("/api/admin/health", headers=member).status_code == 403
    rows = client.get("/api/admin/health", headers=admin).json()
    names = {r["name"]: r for r in rows}
    assert names["Veritabanı"]["ok"] is True
    assert "Sunucu diski" in names and "nginx" in names


def test_client_key_cannot_use_admin_endpoints_but_application_key_can(client):
    admin = _login(client, "v19_admin", "adminpass1")
    client_key = client.post("/api/keys", headers=admin, json={"name": "istemci", "scope": "client"}).json()
    app_key = client.post("/api/keys", headers=admin, json={"name": "uygulama", "scope": "application"}).json()
    assert client_key["scope"] == "client" and app_key["scope"] == "application"

    c_headers = {"Authorization": "Bearer " + client_key["key"]}
    a_headers = {"Authorization": "Bearer " + app_key["key"]}
    assert client.get("/api/admin/stats", headers=c_headers).status_code == 403
    assert client.get("/api/admin/stats", headers=a_headers).status_code == 200
    assert client.get("/api/me", headers=c_headers).status_code == 200


def test_member_cannot_create_application_key(client):
    _, member = _member(client, "app_key_member")
    r = client.post("/api/keys", headers=member, json={"name": "x", "scope": "application"})
    assert r.status_code == 403


def test_sub_user_gets_only_granted_permissions(client):
    owner_id, owner = _member(client, "share_owner")
    _, sub = _member(client, "share_sub")
    sid = _server(owner_id, 27401)
    try:
        assert client.get(f"/api/servers/{sid}", headers=sub).status_code == 404  # henüz erişim yok

        granted = client.post(f"/api/servers/{sid}/access", headers=owner,
                              json={"username": "share_sub", "permissions": ["console"]})
        assert granted.status_code == 201, granted.text

        view = client.get(f"/api/servers/{sid}", headers=sub)
        assert view.status_code == 200
        assert view.json()["my_permissions"] == ["console"]
        assert any(s["id"] == sid for s in client.get("/api/servers", headers=sub).json())

        # Yetkisi olmayan işlemler reddedilir.
        assert client.patch(f"/api/servers/{sid}", headers=sub, json={"name": "Hack"}).status_code == 403
        assert client.post(f"/api/servers/{sid}/power", headers=sub, json={"action": "stop"}).status_code == 403
        assert client.get(f"/api/servers/{sid}/files?path=", headers=sub).status_code == 403
        assert client.delete(f"/api/servers/{sid}", headers=sub).status_code == 403
        assert client.get(f"/api/servers/{sid}/access", headers=sub).status_code == 403
    finally:
        _cleanup(sid)


def test_owner_manages_access_list(client):
    owner_id, owner = _member(client, "acl_owner")
    _member(client, "acl_sub")
    sid = _server(owner_id, 27402)
    try:
        assert client.post(f"/api/servers/{sid}/access", headers=owner,
                           json={"username": "acl_sub", "permissions": ["cokbilmem"]}).status_code == 400
        assert client.post(f"/api/servers/{sid}/access", headers=owner,
                           json={"username": "acl_sub", "permissions": []}).status_code == 400
        assert client.post(f"/api/servers/{sid}/access", headers=owner,
                           json={"username": "acl_owner", "permissions": ["console"]}).status_code == 409
        assert client.post(f"/api/servers/{sid}/access", headers=owner,
                           json={"username": "yok_boyle_biri", "permissions": ["console"]}).status_code == 404

        client.post(f"/api/servers/{sid}/access", headers=owner,
                    json={"username": "acl_sub", "permissions": ["console", "files"]})
        rows = client.get(f"/api/servers/{sid}/access", headers=owner).json()
        assert rows[0]["username"] == "acl_sub" and rows[0]["permissions"] == ["console", "files"]

        # Aynı kullanıcıya yeniden verilince yetkiler güncellenir.
        client.post(f"/api/servers/{sid}/access", headers=owner,
                    json={"username": "acl_sub", "permissions": ["settings"]})
        rows = client.get(f"/api/servers/{sid}/access", headers=owner).json()
        assert rows[0]["permissions"] == ["settings"]

        sub_id = rows[0]["user_id"]
        assert client.delete(f"/api/servers/{sid}/access/{sub_id}", headers=owner).status_code == 204
        sub = _login(client, "acl_sub", "guclu-sifre-1")
        assert client.get(f"/api/servers/{sid}", headers=sub).status_code == 404
    finally:
        _cleanup(sid)
