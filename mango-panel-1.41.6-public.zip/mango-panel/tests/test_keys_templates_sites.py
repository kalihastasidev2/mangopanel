import pytest
from fastapi.testclient import TestClient

from mango.config import settings
from mango.db import SessionLocal, Server, User, init_db
from mango.main import app
from mango.security import hash_password


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-v17"))
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="v17_admin").first() is None:
        db.add(User(username="v17_admin", email="v17a@example.com",
                    password_hash=hash_password("adminpass1"), is_admin=True, max_servers=99))
        db.commit()
    db.close()
    return TestClient(app)


def _member(client, name):
    db = SessionLocal()
    user = db.query(User).filter_by(username=name).first()
    if user is None:
        user = User(username=name, email=f"{name}@example.com",
                    password_hash=hash_password("guclu-sifre-1"), is_admin=False, max_servers=5)
        db.add(user)
        db.commit()
    uid = user.id
    db.close()
    r = client.post("/api/auth/login", json={"username": name, "password": "guclu-sifre-1"})
    assert r.status_code == 200, r.text
    return uid, {"Authorization": "Bearer " + r.json()["token"]}


def _server(owner_id, port, name="Test", site_slug=None, suspended=False, rename_count=0):
    db = SessionLocal()
    server = Server(name=name, egg="static-web", owner_id=owner_id, port=port, memory_mb=256,
                    cpu_percent=100, variables={}, site_slug=site_slug, suspended=suspended,
                    rename_count=rename_count)
    db.add(server)
    db.commit()
    sid = server.id
    db.close()
    return sid


def _delete_server(sid):
    db = SessionLocal()
    db.query(Server).filter_by(id=sid).delete()
    db.commit()
    db.close()


def test_api_key_authenticates_and_can_be_revoked(client):
    _, headers = _member(client, "key_user")
    created = client.post("/api/keys", headers=headers, json={"name": "otomasyon"})
    assert created.status_code == 201, created.text
    raw = created.json()["key"]
    assert raw.startswith("mgp_")
    assert "key" not in client.get("/api/keys", headers=headers).json()[0]  # liste anahtarı göstermez

    key_headers = {"Authorization": "Bearer " + raw}
    me = client.get("/api/me", headers=key_headers)
    assert me.status_code == 200 and me.json()["username"] == "key_user"

    key_id = created.json()["id"]
    assert client.delete(f"/api/keys/{key_id}", headers=headers).status_code == 204
    assert client.get("/api/me", headers=key_headers).status_code == 401


def test_api_key_limit(client):
    _, headers = _member(client, "key_limit")
    for i in range(5):
        assert client.post("/api/keys", headers=headers, json={"name": f"k{i}"}).status_code == 201
    assert client.post("/api/keys", headers=headers, json={"name": "fazla"}).status_code == 409


def test_template_crud_and_caps(client):
    admin = client.post("/api/auth/login", json={"username": "v17_admin", "password": "adminpass1"}).json()["token"]
    _, member = _member(client, "tpl_user")
    ok = client.post("/api/templates", headers=member, json={
        "name": "Hizli site", "egg": "static-web", "memory_mb": 256, "cpu_percent": 100, "variables": {},
    })
    assert ok.status_code == 201, ok.text
    listed = client.get("/api/templates", headers=member).json()
    assert any(t["name"] == "Hizli site" for t in listed)
    assert client.delete(f"/api/templates/{ok.json()['id']}", headers=member).status_code == 204
    assert not any(t["name"] == "Hizli site" for t in client.get("/api/templates", headers=member).json())
    assert admin  # yönetici tarafı da çalışır


def test_template_respects_resource_caps(client):
    admin = {"Authorization": "Bearer " + client.post(
        "/api/auth/login", json={"username": "v17_admin", "password": "adminpass1"}).json()["token"]}
    client.put("/api/admin/settings", headers=admin, json={"max_memory_mb": 512})
    try:
        _, member = _member(client, "tpl_cap")
        r = client.post("/api/templates", headers=member, json={
            "name": "Buyuk", "egg": "static-web", "memory_mb": 1024, "cpu_percent": 100, "variables": {},
        })
        assert r.status_code == 403
    finally:
        client.put("/api/admin/settings", headers=admin, json={"max_memory_mb": 4096})


def test_site_offline_when_container_not_running(client):
    uid, _ = _member(client, "site_owner")
    sid = _server(uid, 27301, name="Site", site_slug="ornek-site")
    try:
        r = client.get("/api/sites/ornek-site/")
        assert r.status_code == 503
        assert "çevrimdışı" in r.json()["detail"]
        assert client.get("/api/sites/yok-boyle-bir-site").status_code == 404
    finally:
        _delete_server(sid)


def test_suspended_site_is_forbidden(client):
    uid, _ = _member(client, "site_susp")
    sid = _server(uid, 27302, name="Askı", site_slug="askili-site", suspended=True)
    try:
        assert client.get("/api/sites/askili-site/").status_code == 403
    finally:
        _delete_server(sid)


def test_site_slug_validation_and_uniqueness(client):
    uid, headers = _member(client, "slug_owner")
    first = _server(uid, 27303, name="Bir", site_slug="benzersiz-site")
    second = _server(uid, 27304, name="İki")
    try:
        bad = client.patch(f"/api/servers/{second}", headers=headers, json={"site_slug": "Kötü Ad!"})
        assert bad.status_code == 400
        clash = client.patch(f"/api/servers/{second}", headers=headers, json={"site_slug": "benzersiz-site"})
        assert clash.status_code == 409
        ok = client.patch(f"/api/servers/{second}", headers=headers, json={"site_slug": "ikinci-site"})
        assert ok.status_code == 200 and ok.json()["site_url"].endswith("/sites/ikinci-site/")
        cleared = client.patch(f"/api/servers/{second}", headers=headers, json={"site_slug": ""})
        assert cleared.json()["site_url"] is None
    finally:
        _delete_server(first)
        _delete_server(second)


def test_rename_limit_is_three_for_members(client):
    uid, headers = _member(client, "rename_user")
    sid = _server(uid, 27305, name="Eski", rename_count=0)
    try:
        for i in range(3):
            r = client.patch(f"/api/servers/{sid}", headers=headers, json={"name": f"Yeni {i}"})
            assert r.status_code == 200, r.text
        assert client.get(f"/api/servers/{sid}", headers=headers).json()["rename_left"] == 0
        blocked = client.patch(f"/api/servers/{sid}", headers=headers, json={"name": "Dorduncu"})
        assert blocked.status_code == 403
        assert "3" in blocked.json()["detail"]
    finally:
        _delete_server(sid)
