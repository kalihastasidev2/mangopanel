"""1.24.0: Genel Sohbet: mesaj akışı, silme, log paylaşımında gizli bilgi maskeleme ve hız sınırı."""
import shutil
import time
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from mango import chat_api
from mango import docker_manager as dm_module
from mango.config import settings
from mango.db import SessionLocal, Server, User, init_db
from mango.main import app
from mango.security import hash_password

REPO_EGGS = Path(__file__).resolve().parent.parent / "eggs"
_next_port = [42000]


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-v124"))
    eggs_copy = tmp_path_factory.mktemp("eggs-v124") / "eggs"
    shutil.copytree(REPO_EGGS, eggs_copy)
    settings.eggs_dir = str(eggs_copy)
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="v124_admin").first() is None:
        db.add(User(username="v124_admin", email="v124a@example.com",
                    password_hash=hash_password("adminpass1"), is_admin=True, max_servers=99))
        db.commit()
    db.close()
    return TestClient(app)


@pytest.fixture(autouse=True)
def fresh_cooldowns(monkeypatch):
    monkeypatch.setattr(chat_api, "_last_sent", {})
    monkeypatch.setattr(chat_api, "SEND_COOLDOWN", 0)  # testlerde hız sınırını kapat; ayrı testte açılır


def _login(client, name, password="guclu-sifre-1"):
    r = client.post("/api/auth/login", json={"username": name, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["token"]}


def _user(client, name):
    db = SessionLocal()
    user = db.query(User).filter_by(username=name).first()
    if user is None:
        user = User(username=name, email=f"{name}@example.com", password_hash=hash_password("guclu-sifre-1"),
                    is_admin=False, max_servers=5)
        db.add(user)
        db.commit()
    uid = user.id
    db.close()
    return uid, _login(client, name)


def test_message_is_visible_to_everyone_and_polling_returns_it(client):
    _, headers = _user(client, "v124_talker")
    initial = client.get("/api/chat/messages", headers=headers).json()
    assert "items" in initial and initial["last_id"] >= 0

    posted = client.post("/api/chat/messages", headers=headers, json={"text": "Merhaba herkese"})
    assert posted.status_code == 201, posted.text
    msg_id = posted.json()["id"]

    _, other = _user(client, "v124_reader")
    fresh = client.get(f"/api/chat/messages?after={initial['last_id']}&since={initial['now']}", headers=other).json()
    texts = [m["text"] for m in fresh["items"] if m["id"] == msg_id]
    assert texts == ["Merhaba herkese"]


def test_deleted_message_is_marked_hidden_for_live_clients(client):
    _, headers = _user(client, "v124_deleter")
    before = client.get("/api/chat/messages", headers=headers).json()
    msg = client.post("/api/chat/messages", headers=headers, json={"text": "silinecek"}).json()
    client.delete(f"/api/chat/messages/{msg['id']}", headers=headers)
    poll = client.get(f"/api/chat/messages?after={before['last_id']}&since={before['now']}", headers=headers).json()
    hidden = [m for m in poll["items"] if m["id"] == msg["id"]]
    assert hidden and hidden[0]["hidden"] is True and hidden[0]["text"] == ""


def test_only_owner_or_admin_can_delete(client):
    _, owner = _user(client, "v124_owner_msg")
    _, stranger = _user(client, "v124_stranger")
    admin = _login(client, "v124_admin", "adminpass1")
    msg = client.post("/api/chat/messages", headers=owner, json={"text": "benim"}).json()
    assert client.delete(f"/api/chat/messages/{msg['id']}", headers=stranger).status_code == 403
    assert client.delete(f"/api/chat/messages/{msg['id']}", headers=admin).status_code == 204


def test_shared_log_is_redacted_before_it_reaches_the_chat(client, monkeypatch):
    uid, headers = _user(client, "v124_log_owner")
    _next_port[0] += 1
    db = SessionLocal()
    server = Server(name=f"Log{_next_port[0]}", egg="nodejs-app", owner_id=uid, port=_next_port[0], memory_mb=256,
                    cpu_percent=100, variables={}, container_id="cid-log")
    db.add(server)
    db.commit()
    sid = server.id
    db.close()
    secret_log = ("Bot hazır\nDISCORD_TOKEN=abc123secretvalue\n"
                  "Authorization: Bearer xyz987tokenvalue\n"
                  "MTIzNDU2Nzg5MDEyMzQ1Njc4.GhIjKl.abcdefghijklmnopqrstuvwxyz0123456789")
    monkeypatch.setattr(dm_module, "logs", lambda server, tail=200: secret_log)
    res = client.post("/api/chat/messages", headers=headers,
                      json={"text": "yardım", "help": True, "server_id": sid})
    assert res.status_code == 201, res.text
    body = res.json()
    assert body["help"] is True and body["server_name"].startswith("Log")
    assert "abc123secretvalue" not in body["log_text"]
    assert "xyz987tokenvalue" not in body["log_text"]
    assert "MTIzNDU2Nzg5MDEyMzQ1Njc4" not in body["log_text"]
    assert "Bot hazır" in body["log_text"]


def test_sending_too_fast_is_rejected(client, monkeypatch):
    monkeypatch.setattr(chat_api, "SEND_COOLDOWN", 60)
    _, headers = _user(client, "v124_fast")
    assert client.post("/api/chat/messages", headers=headers, json={"text": "bir"}).status_code == 201
    assert client.post("/api/chat/messages", headers=headers, json={"text": "iki"}).status_code == 429


def test_empty_message_without_log_is_rejected(client):
    _, headers = _user(client, "v124_empty")
    assert client.post("/api/chat/messages", headers=headers, json={"text": "   "}).status_code == 400
