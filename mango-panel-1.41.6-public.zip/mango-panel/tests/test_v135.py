"""1.35.0: sunucuya özel bakım, terminal dizin koruması, bakım sayfası."""
from mango.db import Server
from mango.main import app
from mango.vps_terminal import SHELL_SCRIPT


def test_terminal_shell_cannot_leave_the_server_folder():
    assert "cd() {" in SHELL_SCRIPT
    assert "/home/container" in SHELL_SCRIPT
    assert "cd /home/container" in SHELL_SCRIPT


def test_server_has_maintenance_fields():
    assert hasattr(Server, "maintenance") and hasattr(Server, "maintenance_message")


def test_server_maintenance_admin_route_exists():
    from fastapi.testclient import TestClient
    res = TestClient(app).patch("/api/admin/servers/1/maintenance", json={"on": True})
    assert res.status_code in (401, 403)  # rota var; yetkisiz istek reddedilir (404 olmamalı)
