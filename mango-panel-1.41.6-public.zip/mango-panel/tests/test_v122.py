"""1.22.0: Discord botu kurulumu, hesap bağlama, bot API'si, olaylar ve çökme izleme (Discord ve Docker taklit edilir)."""
import shutil
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from mango import discord_api
from mango import discord_bot
from mango import docker_manager as dm_module
from mango import files_manager as fm
from mango.config import settings
from mango.db import DiscordEvent, SessionLocal, Server, User, init_db
from mango.main import app
from mango.security import hash_password
from mango.store import get_setting

REPO_EGGS = Path(__file__).resolve().parent.parent / "eggs"
_next_port = [38000]
GUILD = "123456789012345"
ROLE = "1554895980045017274"
MEMBER_DISCORD = "223456789012345678"


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-v122"))
    eggs_copy = tmp_path_factory.mktemp("eggs-v122") / "eggs"
    shutil.copytree(REPO_EGGS, eggs_copy)
    settings.eggs_dir = str(eggs_copy)
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="v122_admin").first() is None:
        db.add(User(username="v122_admin", email="v122a@example.com",
                    password_hash=hash_password("adminpass1"), is_admin=True, max_servers=99))
        db.commit()
    db.close()
    return TestClient(app)


def _login(client, name, password="guclu-sifre-1"):
    r = client.post("/api/auth/login", json={"username": name, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["token"]}


def _user(client, name):
    db = SessionLocal()
    user = db.query(User).filter_by(username=name).first()
    if user is None:
        user = User(username=name, email=f"{name}@example.com",
                    password_hash=hash_password("guclu-sifre-1"), is_admin=False, max_servers=5)
        db.add(user)
        db.commit()
    uid = user.id
    db.close()
    return uid, _login(client, name)


def _server(owner_id, egg, container_id=None):
    _next_port[0] += 1
    db = SessionLocal()
    server = Server(name=f"S{_next_port[0]}", egg=egg, owner_id=owner_id, port=_next_port[0], memory_mb=256,
                    cpu_percent=100, variables={}, container_id=container_id)
    db.add(server)
    db.commit()
    sid = server.id
    db.close()
    return sid


def _secret():
    db = SessionLocal()
    value = get_setting(db, "discord_bot_secret")
    db.close()
    return value


@pytest.fixture
def fake_discord(monkeypatch):
    calls = {"roles": [], "channels": 0}

    def channel(token, guild_id, name, parent_id):
        calls["channels"] += 1
        return {"id": f"ch-{calls['channels']}"}

    monkeypatch.setattr(discord_api, "me", lambda token: {"username": "mangobot", "id": "999"})
    monkeypatch.setattr(discord_api, "guild", lambda token, gid: {"id": gid})
    monkeypatch.setattr(discord_api, "create_category", lambda token, gid, name: {"id": "cat-1"})
    monkeypatch.setattr(discord_api, "create_text_channel", channel)
    monkeypatch.setattr(discord_api, "add_role",
                        lambda token, gid, uid, rid: calls["roles"].append((uid, rid)))
    return calls


@pytest.fixture
def bot_ready(client, fake_discord, fake_docker):
    """Token ve kurulum tamam: bot sırrı ve bot sunucusu oluşur (tek seferlik, sonraki çağrılar idempotent)."""
    admin = _login(client, "v122_admin", "adminpass1")
    client.put("/api/admin/discord", headers=admin,
               json={"token": "bot-token-v122", "guild_id": GUILD, "customer_role_id": ROLE})
    res = client.post("/api/admin/discord/setup", headers=admin)
    assert res.status_code == 200, res.text
    return res.json()


def _link_db(username, discord_id):
    db = SessionLocal()
    user = db.query(User).filter_by(username=username).first()
    user.discord_id = discord_id
    db.commit()
    db.close()


@pytest.fixture
def fake_docker(monkeypatch):
    state = {"power": "exited", "running": True}
    monkeypatch.setattr(dm_module, "run_install", lambda server, egg, script: "")
    monkeypatch.setattr(dm_module, "create", lambda server, egg, startup, port: "cid-created")
    monkeypatch.setattr(dm_module, "recreate", lambda server, egg, startup, port: "cid-recreated")
    monkeypatch.setattr(dm_module, "status", lambda server: "running")
    monkeypatch.setattr(dm_module, "power", lambda server, action: state["power"])
    monkeypatch.setattr(dm_module, "status_map", lambda: None)
    return state


def test_admin_saves_token_without_returning_it(client, fake_discord):
    admin = _login(client, "v122_admin", "adminpass1")
    saved = client.put("/api/admin/discord", headers=admin,
                       json={"token": "bot-token-v122", "guild_id": GUILD, "customer_role_id": ROLE})
    assert saved.status_code == 200, saved.text
    body = saved.json()
    assert body["token_set"] is True
    assert body["guild_id"] == GUILD
    assert "bot-token-v122" not in saved.text


def test_setup_creates_channels_and_bot_server_for_admin(client, fake_discord, fake_docker):
    admin = _login(client, "v122_admin", "adminpass1")
    res = client.post("/api/admin/discord/setup", headers=admin)
    assert res.status_code == 200, res.text
    body = res.json()
    assert body["bot_name"] == "mangobot"
    assert set(body["channels"]) == {"discord_ch_alerts", "discord_ch_tickets", "discord_ch_purchases", "discord_ch_status"}
    assert fake_discord["channels"] == 4

    db = SessionLocal()
    server = db.get(Server, body["bot_server_id"])
    admin_row = db.query(User).filter_by(username="v122_admin").first()
    assert server.egg == "nodejs-app"
    assert server.owner_id == admin_row.id
    assert server.env["DISCORD_TOKEN"] == "bot-token-v122"
    assert server.env["DISCORD_GUILD_ID"] == GUILD
    assert server.env["PANEL_BOT_SECRET"] == _secret()
    assert server.startup_override == discord_bot.BOT_STARTUP
    db.close()
    assert "discord.js" in fm.read_text(body["bot_server_id"], "package.json")
    assert 'require("discord.js")' in fm.read_text(body["bot_server_id"], "index.js")

    again = client.post("/api/admin/discord/setup", headers=admin)
    assert again.status_code == 200, again.text
    assert fake_discord["channels"] == 4  # ikinci kurulum kanal oluşturmaz


def test_bot_api_requires_the_shared_secret(client, bot_ready):
    wrong = client.post("/api/discord/link-code", json={"discord_id": MEMBER_DISCORD},
                        headers={"X-Bot-Secret": "yanlis"})
    assert wrong.status_code == 403
    missing = client.get("/api/discord/events?after=-1")
    assert missing.status_code == 403


def test_member_links_discord_and_gets_customer_role(client, bot_ready, fake_discord):
    secret = {"X-Bot-Secret": _secret()}
    code = client.post("/api/discord/link-code", json={"discord_id": MEMBER_DISCORD}, headers=secret).json()["code"]
    uid, headers = _user(client, "v122_member")
    linked = client.post("/api/me/discord/link", headers=headers, json={"code": code})
    assert linked.status_code == 200, linked.text
    assert linked.json()["role_granted"] is True
    assert fake_discord["roles"] == [(MEMBER_DISCORD, ROLE)]
    view = client.get(f"/api/discord/user/{MEMBER_DISCORD}", headers=secret).json()
    assert view["linked"] is True and view["username"] == "v122_member"

    reused = client.post("/api/me/discord/link", headers=headers, json={"code": code})
    assert reused.status_code == 400  # kod tek kullanımlık


def test_ticket_from_discord_creates_event_for_admins(client, bot_ready):
    secret = {"X-Bot-Secret": _secret()}
    _user(client, "v122_member")
    _link_db("v122_member", MEMBER_DISCORD)
    before = client.get("/api/discord/events?after=-1", headers=secret).json()["latest"]
    res = client.post(f"/api/discord/user/{MEMBER_DISCORD}/tickets", headers=secret,
                      json={"subject": "Sunucu açılmıyor", "message": "Başlat'a basınca hata alıyorum."})
    assert res.status_code == 201, res.text
    events = client.get(f"/api/discord/events?after={before}", headers=secret).json()["events"]
    ticket_events = [e for e in events if e["kind"] == "ticket_new"]
    assert ticket_events and ticket_events[0]["discord_id"] == MEMBER_DISCORD


def test_bot_power_respects_ownership_and_marks_manual_stop(client, bot_ready):
    secret = {"X-Bot-Secret": _secret()}
    uid, _ = _user(client, "v122_power_owner")
    sid = _server(uid, "nodejs-app", container_id="cid-power")
    db = SessionLocal()
    owner = db.get(User, uid)
    owner.discord_id = "323456789012345678"
    db.commit()
    db.close()
    res = client.post(f"/api/discord/user/323456789012345678/servers/{sid}/power", headers=secret,
                      json={"action": "stop"})
    assert res.status_code == 200, res.text
    assert sid in discord_bot._intentional

    stranger = client.post(f"/api/discord/user/{MEMBER_DISCORD}/servers/{sid}/power", headers=secret,
                           json={"action": "start"})
    assert stranger.status_code in (403, 404)  # bağlı değil ya da bu sunucuya erişimi yok


def test_watcher_reports_crashes_but_not_manual_stops(client, fake_docker, monkeypatch):
    monkeypatch.setattr(discord_bot, "_last_status", {})
    monkeypatch.setattr(discord_bot, "_intentional", {})
    uid, _ = _user(client, "v122_watch_owner")
    crashed = _server(uid, "nodejs-app", container_id="cid-crash")
    manual = _server(uid, "nodejs-app", container_id="cid-manual")

    monkeypatch.setattr(dm_module, "status_map", lambda: {"cid-crash": "running", "cid-manual": "running"})
    discord_bot.watch_once()
    monkeypatch.setattr(dm_module, "status_map", lambda: {"cid-crash": "exited", "cid-manual": "running"})
    discord_bot.mark_intentional(manual)
    discord_bot.watch_once()
    monkeypatch.setattr(dm_module, "status_map", lambda: {"cid-crash": "exited", "cid-manual": "exited"})
    discord_bot.watch_once()

    db = SessionLocal()
    down = {e.server_id for e in db.query(DiscordEvent).filter_by(kind="server_down").all()}
    db.close()
    assert crashed in down
    assert manual not in down


def test_discord_channel_ids_are_hidden_from_everyone_in_request(monkeypatch):
    sent = {}

    def fake_call(method, path, token, body=None):
        sent["body"] = body
        return {"id": "1"}

    monkeypatch.setattr(discord_api, "_call", fake_call)
    discord_api.create_text_channel("tok", GUILD, "durum-paneli", "cat")
    overwrite = sent["body"]["permission_overwrites"][0]
    assert overwrite["id"] == GUILD and overwrite["deny"] == str(discord_api.PERM_VIEW_CHANNEL)
