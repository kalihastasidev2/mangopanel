from types import SimpleNamespace
"""1.28.1: VPS egg'i Cloudflare Tunnel modunda da kullanılabilir, dışarıya port açmaz."""
from pathlib import Path

from mango import docker_manager as dm
from mango.config import settings
from mango.eggs import load_eggs
from mango.policy import egg_allowed

REPO_EGGS = Path(__file__).resolve().parent.parent / "eggs"


def test_vps_is_allowed_in_tunnel_mode(monkeypatch):
    monkeypatch.setattr(settings, "access_mode", "cloudflare")
    assert egg_allowed({"category": "vps"})[0] is True


def test_games_still_blocked_in_tunnel_mode(monkeypatch):
    monkeypatch.setattr(settings, "access_mode", "cloudflare")
    assert egg_allowed({"category": "game"})[0] is False


def test_vps_egg_publishes_no_ports(monkeypatch):
    monkeypatch.setattr(settings, "eggs_dir", str(REPO_EGGS))
    egg = load_eggs()["linux-vps"]
    assert egg["publish_ports"] is False
    assert dm._ports(None, 2222, egg) == {}


def test_other_eggs_still_publish_their_port():
    server = type("S", (), {"port": 30001})()
    assert dm._ports(server, 8080, {"ports": [8080]}) == {"8080/tcp": (dm._bind_ip(), 30001)}
