"""1.26.0: geçici Docker hatalarında otomatik yeniden deneme, herkese açık paket listesi ve ana sayfa dosyaları."""
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from mango import docker_manager as dm
from mango.db import PremiumPlan, SessionLocal, init_db
from mango.main import app

WEB = Path(__file__).resolve().parent.parent / "web"
RUNC_ERROR = "OCI runtime create failed: runc did not terminate successfully: exit status 134"


@pytest.fixture(autouse=True)
def no_sleep(monkeypatch):
    monkeypatch.setattr(dm.time, "sleep", lambda seconds: None)


def test_transient_error_is_retried_until_it_succeeds():
    calls = []

    def action():
        calls.append(1)
        if len(calls) < 3:
            raise RuntimeError(RUNC_ERROR)
        return "ok"

    assert dm.with_retry(action) == "ok"
    assert len(calls) == 3


def test_non_transient_error_is_raised_immediately():
    calls = []

    def action():
        calls.append(1)
        raise ValueError("geçersiz ayar")

    with pytest.raises(ValueError):
        dm.with_retry(action)
    assert len(calls) == 1


def test_cleanup_runs_between_failed_attempts():
    events = []
    attempts = []

    def action():
        attempts.append(1)
        events.append("try")
        if len(attempts) < 2:
            raise RuntimeError("pthread_create failed: Resource temporarily unavailable")
        return "ok"

    assert dm.with_retry(action, cleanup=lambda: events.append("cleanup")) == "ok"
    assert events == ["try", "cleanup", "try"]


def test_gives_up_after_all_attempts():
    calls = []

    def action():
        calls.append(1)
        raise RuntimeError(RUNC_ERROR)

    with pytest.raises(RuntimeError):
        dm.with_retry(action)
    assert len(calls) == len(dm.RETRY_DELAYS) + 1


def test_public_plans_lists_only_active_plans_without_internal_fields():
    init_db()
    db = SessionLocal()
    db.add(PremiumPlan(name="v126-acik", description="Herkese açık", price_text="100 TL / ay", egg="nodejs-app",
                       memory_mb=1024, cpu_percent=100, disk_mb=2048, max_servers=2, active=True))
    db.add(PremiumPlan(name="v126-kapali", description="Gizli", price_text="", egg=None,
                       memory_mb=512, cpu_percent=50, disk_mb=1024, max_servers=1, active=False))
    db.commit()
    db.close()

    res = TestClient(app).get("/api/public/plans")  # giriş yok
    assert res.status_code == 200
    names = [p["name"] for p in res.json()]
    assert "v126-acik" in names and "v126-kapali" not in names
    plan = next(p for p in res.json() if p["name"] == "v126-acik")
    assert "egg" not in plan and "active" not in plan


def test_landing_page_is_wired_and_served():
    assert (WEB / "landing.js").is_file()
    index = (WEB / "index.html").read_text(encoding="utf-8")
    assert "/static/landing.js" in index
    assert index.index("app.js") < index.index("landing.js")
    app_js = (WEB / "app.js").read_text(encoding="utf-8")
    assert "renderLanding" in app_js and '"giris"' in app_js and '"kayit"' in app_js
    assert TestClient(app).get("/static/landing.js").status_code == 200


def test_logged_in_users_can_open_landing_from_menu():
    app_js = (WEB / "app.js").read_text(encoding="utf-8")
    assert 'href="#/anasayfa"' in app_js and 'parts[0] === "anasayfa"' in app_js
    assert "Panele git" in (WEB / "landing.js").read_text(encoding="utf-8")
