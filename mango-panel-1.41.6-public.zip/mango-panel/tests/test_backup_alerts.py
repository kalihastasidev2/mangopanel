import io
import sqlite3
import tarfile

import pytest
from fastapi.testclient import TestClient

from mango import files_manager as fm
from mango.config import settings
from mango.db import SessionLocal, Server, User, init_db
from mango.main import app
from mango.security import hash_password
from mango.store import set_setting


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-v16"))
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="v16_admin").first() is None:
        db.add(User(username="v16_admin", email="v16@example.com",
                    password_hash=hash_password("adminpass1"), is_admin=True, max_servers=99))
        db.commit()
    db.close()
    return TestClient(app)


def _login(client, name, password):
    r = client.post("/api/auth/login", json={"username": name, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["token"]}


def test_site_name_and_logo_are_public_and_editable(client):
    admin = _login(client, "v16_admin", "adminpass1")
    r = client.put("/api/admin/settings", headers=admin, json={"site_name": "Deneme Panel", "logo_text": "🍋"})
    assert r.status_code == 200, r.text
    system = client.get("/api/system").json()
    assert system["site_name"] == "Deneme Panel" and system["logo_text"] == "🍋"
    client.put("/api/admin/settings", headers=admin, json={"site_name": "Mango Panel", "logo_text": "🥭"})


def test_site_name_length_is_validated(client):
    admin = _login(client, "v16_admin", "adminpass1")
    r = client.put("/api/admin/settings", headers=admin, json={"site_name": "x" * 41})
    assert r.status_code == 422


def test_alerts_report_disk_pressure_for_owner(client):
    admin = _login(client, "v16_admin", "adminpass1")
    db = SessionLocal()
    user = User(username="alert_owner", email="alert@example.com",
                password_hash=hash_password("guclu-sifre-1"), is_admin=False, max_servers=5)
    db.add(user)
    db.commit()
    uid = user.id
    server = Server(name="Dolu", egg="static-web", owner_id=uid, port=27201,
                    memory_mb=256, cpu_percent=100, variables={})
    db.add(server)
    db.commit()
    sid = server.id
    db.close()
    owner = _login(client, "alert_owner", "guclu-sifre-1")

    assert client.get("/api/alerts", headers=owner).json() == []
    set_quota = SessionLocal()
    set_setting(set_quota, "max_disk_mb", "1")  # 1 MB sınır: 1 MB dosya kotanın tamamı
    set_quota.commit()
    set_quota.close()
    try:
        (fm.server_dir(sid) / "buyuk.bin").write_bytes(b"0" * (1024 * 1024))
        alerts = client.get("/api/alerts", headers=owner).json()
        assert any("Disk" in a["message"] and a["server_id"] == sid for a in alerts)
        # Yönetici de aynı uyarıyı görür, diğer kullanıcılar görmez.
        assert any(a["server_id"] == sid for a in client.get("/api/alerts", headers=admin).json())
    finally:
        s2 = SessionLocal()
        set_setting(s2, "max_disk_mb", "5120")
        s2.query(Server).filter_by(id=sid).delete()
        s2.commit()
        s2.close()


def test_admin_full_backup_contains_database_and_data(client, tmp_path):
    admin = _login(client, "v16_admin", "adminpass1")
    r = client.get("/api/admin/backup", headers=admin)
    assert r.status_code == 200
    assert r.headers["content-type"].startswith("application/gzip")
    with tarfile.open(fileobj=io.BytesIO(r.content), mode="r:gz") as tar:
        names = tar.getnames()
        assert "mango.db" in names
        assert any(n.startswith("data") for n in names)
        db_bytes = tar.extractfile("mango.db").read()
    # Yedek dosyası geçerli bir SQLite veritabanı olmalı.
    path = tmp_path / "restored.db"
    path.write_bytes(db_bytes)
    conn = sqlite3.connect(str(path))
    tables = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    conn.close()
    assert "users" in tables and "servers" in tables


def test_backup_is_admin_only_for_full_archive(client):
    client.post("/api/auth/register", json={
        "username": "backup_norm", "email": "bn@example.com", "password": "guclu-sifre-1",
    })
    member = _login(client, "backup_norm", "guclu-sifre-1")
    assert client.get("/api/admin/backup", headers=member).status_code == 403


def test_server_backup_for_owner_and_forbidden_for_others(client):
    admin = _login(client, "v16_admin", "adminpass1")
    db = SessionLocal()
    owner = db.query(User).filter_by(username="backup_norm").first()
    server = Server(name="Yedekli", egg="static-web", owner_id=owner.id, port=27202,
                    memory_mb=256, cpu_percent=100, variables={})
    db.add(server)
    db.commit()
    sid = server.id
    db.close()
    try:
        (fm.server_dir(sid) / "index.html").write_text("merhaba")
        member = _login(client, "backup_norm", "guclu-sifre-1")
        r = client.get(f"/api/servers/{sid}/backup", headers=member)
        assert r.status_code == 200
        with tarfile.open(fileobj=io.BytesIO(r.content), mode="r:gz") as tar:
            assert any(n.endswith("index.html") for n in tar.getnames())
        client.post("/api/auth/register", json={
            "username": "backup_other", "email": "bo@example.com", "password": "guclu-sifre-1",
        })
        other = _login(client, "backup_other", "guclu-sifre-1")
        assert client.get(f"/api/servers/{sid}/backup", headers=other).status_code == 404
    finally:
        db = SessionLocal()
        db.query(Server).filter_by(id=sid).delete()
        db.commit()
        db.close()
