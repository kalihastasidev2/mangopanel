"""1.36.x: Discord ile giriş/kayıt. Secret asla geri gönderilmez; ayarlar yoksa akış kapalıdır."""
from fastapi.testclient import TestClient

from mango.config import settings
from mango.db import SessionLocal
from mango.main import app
from mango.store import all_settings, set_setting


def _clear_discord():
    db = SessionLocal()
    set_setting(db, "discord_client_id", "")
    set_setting(db, "discord_client_secret", "")
    db.commit()
    db.close()


def test_discord_start_is_closed_without_settings():
    _clear_discord()
    res = TestClient(app).get("/api/auth/discord/start", follow_redirects=False)
    assert res.status_code == 404


def test_bad_state_is_sent_back_to_login_with_message(monkeypatch):
    monkeypatch.setattr(settings, "public_url", "https://panel.example.com")
    res = TestClient(app).get("/api/auth/discord/callback?code=abc&state=yok", follow_redirects=False)
    assert res.status_code in (302, 307)
    assert res.headers["location"] == "https://panel.example.com/#/giris?discord=iptal"


def test_secret_is_never_returned_by_settings():
    db = SessionLocal()
    set_setting(db, "discord_client_secret", "gizli-deger-123")
    db.commit()
    try:
        data = all_settings(db)
        assert "discord_client_secret" not in data
        assert data["discord_secret_set"] is True
    finally:
        set_setting(db, "discord_client_secret", "")
        db.commit()
        db.close()


def test_system_info_reports_discord_login_flag():
    _clear_discord()
    body = TestClient(app).get("/api/system").json()
    assert body["discord_login"] is False
