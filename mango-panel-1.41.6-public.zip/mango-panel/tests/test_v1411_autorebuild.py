"""1.41.1: başlatılamayan konteyner sıfırdan kurulup bir kez daha denenir; VPS egg'i standart imajda."""
import pytest

from mango import api, docker_manager as dm
from mango.eggs import load_eggs, render


class S:
    id = 7
    egg = "linux-vps"
    container_id = "old"
    variables = {}
    startup_override = None


class DB:
    committed = 0
    rolled = 0

    def commit(self):
        self.committed += 1

    def rollback(self):
        self.rolled += 1


def test_vps_egg_loads_and_startup_renders():
    egg = load_eggs()["linux-vps"]
    assert egg["docker_image"] == "ubuntu:24.04"
    script = render(egg["startup"], {})
    assert "sleep infinity" in script and "wait $!" in script


def test_auto_rebuild_recreates_and_starts(monkeypatch):
    calls = []
    seen = []
    monkeypatch.setattr(dm, "recreate", lambda server, egg, startup, port: calls.append("recreate") or "new-id")
    monkeypatch.setattr(dm, "power", lambda server, action: seen.append(server.container_id) or calls.append(action) or "running")
    monkeypatch.setattr(dm, "status", lambda server: "running")
    server, db = S(), DB()
    state = api._auto_rebuild(server, db, RuntimeError("init-p reset"))
    assert calls == ["recreate", "start"]
    assert seen == ["new-id"]  # başlatma yeni kimlikle yapılmalı
    assert server.container_id == "new-id"
    assert db.committed == 1
    assert state == "running"


def test_auto_rebuild_reports_both_errors_when_retry_fails(monkeypatch):
    def fail(*a, **k):
        raise RuntimeError("ikinci hata")

    monkeypatch.setattr(dm, "recreate", lambda *a, **k: "new-id")
    monkeypatch.setattr(dm, "power", fail)
    db = DB()
    from fastapi import HTTPException

    with pytest.raises(HTTPException) as info:
        api._auto_rebuild(S(), db, RuntimeError("ilk hata"))
    assert info.value.status_code == 409
    assert "ilk hata" in info.value.detail and "ikinci hata" in info.value.detail
    assert db.rolled == 1


def test_cleanup_removes_same_name_even_without_label(monkeypatch):
    removed = []

    class C:
        def __init__(self, name, labels):
            self.name = name
            self.labels = labels

        def remove(self, force=False):
            removed.append(self.name)

    class Containers:
        def list(self, all=False, filters=None):
            # Etiketsiz ve ayrı adlı konteynerler de listede; yalnız mango-7 silinmeli
            return [C("mango-7", {}), C("mango-70", {}), C("other", {"mango.server": "7"})]

    class Cli:
        containers = Containers()

    monkeypatch.setattr(dm, "client", lambda: Cli())
    dm._cleanup_named(7)
    assert removed == ["mango-7"]
