"""1.40.28: başlatılamayan sunucunun nedeni panele taşınır."""
from fastapi.testclient import TestClient

from mango import docker_manager as dm
from mango.main import app


class _Cont:
    def __init__(self, status):
        self.status = status
        self.attrs = {"State": {"ExitCode": 128, "Error": "boom"}}

    def reload(self):
        pass

    def logs(self, tail=20):
        return b"fatal: repository not found\n"


def test_last_failure_returns_exit_code_and_log(monkeypatch):
    monkeypatch.setattr(dm, "_container", lambda server: _Cont("exited"))

    class S:
        id = 1

    info = dm.last_failure(S())
    assert info["exit_code"] == 128
    assert info["error"] == "boom"
    assert "repository not found" in info["log"]


def test_last_failure_never_raises(monkeypatch):
    def boom(server):
        raise RuntimeError("docker yok")

    monkeypatch.setattr(dm, "_container", boom)

    class S:
        id = 1

    info = dm.last_failure(S())
    assert info["exit_code"] is None
    assert "docker yok" in info["error"]
