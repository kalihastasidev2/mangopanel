import pytest

from mango.config import settings
from mango.eggs import EggError, build_variables, render
from mango.policy import egg_allowed


def test_tunnel_blocks_game_eggs(monkeypatch):
    monkeypatch.setattr(settings, "access_mode", "cloudflare")
    assert egg_allowed({"category": "game"})[0] is False


def test_tunnel_allows_web_eggs(monkeypatch):
    monkeypatch.setattr(settings, "access_mode", "cloudflare")
    for cat in ("nodejs", "python", "web", "bot"):
        assert egg_allowed({"category": cat})[0] is True


def test_tunnel_blocks_unknown_category(monkeypatch):
    monkeypatch.setattr(settings, "access_mode", "cloudflare")
    assert egg_allowed({"category": "something-else"})[0] is False


def test_direct_allows_game(monkeypatch):
    monkeypatch.setattr(settings, "access_mode", "direct")
    assert egg_allowed({"category": "game"})[0] is True


def test_shell_metacharacters_rejected():
    egg = {"variables": [{"name": "ENTRY", "default": "index.js"}]}
    with pytest.raises(EggError):
        build_variables(egg, {"ENTRY": "x; rm -rf /"})


def test_unknown_variable_rejected():
    egg = {"variables": [{"name": "ENTRY", "default": "index.js"}]}
    with pytest.raises(EggError):
        build_variables(egg, {"HACK": "1"})


def test_render_fills_placeholders():
    assert render("java -jar {{JAR}}", {"JAR": "server.jar"}) == "java -jar server.jar"


def test_render_missing_key_raises():
    with pytest.raises(EggError):
        render("node {{ENTRY}}", {})
