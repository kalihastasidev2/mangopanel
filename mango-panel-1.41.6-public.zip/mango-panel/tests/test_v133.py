"""1.33.0: yeniden kurulum ve formatlama yardımcıları."""
from mango import reinstall


def test_wipe_removes_all_server_files_but_keeps_the_folder(tmp_path, monkeypatch):
    from mango.config import settings
    monkeypatch.setattr(settings, "data_dir", str(tmp_path))
    root = tmp_path / "55"
    (root / "alt").mkdir(parents=True)
    (root / "alt" / "x.txt").write_text("x")
    (root / "y.txt").write_text("y")
    reinstall._clear_server_dir(55)
    assert root.exists()
    assert list(root.iterdir()) == []


def test_reinstall_body_wipes_by_default():
    body = reinstall.ReinstallIn()
    assert body.wipe is True and body.egg is None
