"""1.36.0: hosting tarzı ana sayfa; ürün sekmeleri ve üst çubuk dosyada var."""
from pathlib import Path

WEB = Path(__file__).resolve().parent.parent / "web"


def test_landing_has_topbar_hero_and_product_tabs():
    src = (WEB / "landing.js").read_text(encoding="utf-8")
    for marker in ("lp-topbar", "lp-hero", "lp-tabs", "data-ltab", "lp-tabcontent", "#/chat"):
        assert marker in src, marker


def test_landing_styles_exist():
    css = (WEB / "style.css").read_text(encoding="utf-8")
    for cls in (".lp-topbar", ".lp-tab", ".lp-tabcontent", ".lp-mock"):
        assert cls in css, cls
