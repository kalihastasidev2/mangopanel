"""1.41.3: VPS onarım aracı (vpsdebug) karar mantığı."""
from docker.errors import NotFound

import pytest

from mango import docker_manager as dm
from mango import vpsdebug


@pytest.fixture(autouse=True)
def _clear_cooldown():
    vpsdebug._last_attempt.clear()
    yield
    vpsdebug._last_attempt.clear()


class Res:
    def __init__(self, code):
        self.exit_code = code


class Cont:
    def __init__(self, status, probe_ok=True, restart_fixes=False):
        self.status = status
        self.probe_ok = probe_ok
        self.restart_fixes = restart_fixes
        self.restarted = False

    def reload(self):
        pass

    def restart(self, timeout=20):
        self.restarted = True
        if self.restart_fixes:
            self.probe_ok = True

    def exec_run(self, cmd):
        return Res(0 if self.probe_ok else 1)


class S:
    id = 9
    name = "vps9"
    egg = "linux-vps"
    container_id = "c"
    variables = {}
    startup_override = None


class DB:
    def commit(self):
        pass

    def rollback(self):
        pass


def _patch(monkeypatch, cont=None, missing=False):
    def _container(server):
        if missing:
            raise NotFound("yok")
        return cont

    monkeypatch.setattr(dm, "_container", _container)
    monkeypatch.setattr(vpsdebug, "_rebuild_and_start", lambda *a, **k: "new-id")


def test_healthy_running_vps_is_left_alone(monkeypatch):
    _patch(monkeypatch, Cont("running", probe_ok=True))
    assert vpsdebug.check_and_fix(S(), DB()) == "sağlıklı"


def test_broken_terminal_is_fixed_by_restart(monkeypatch):
    c = Cont("running", probe_ok=False, restart_fixes=True)
    _patch(monkeypatch, c)
    assert vpsdebug.check_and_fix(S(), DB()) == "onarıldı"
    assert c.restarted


def test_broken_terminal_that_restart_cannot_fix_gets_rebuilt(monkeypatch):
    c = Cont("running", probe_ok=False, restart_fixes=False)
    _patch(monkeypatch, c)
    assert vpsdebug.check_and_fix(S(), DB()) == "onarıldı"


def test_created_vps_is_started(monkeypatch):
    _patch(monkeypatch, Cont("created"))
    monkeypatch.setattr(dm, "power", lambda server, action: "running")
    assert vpsdebug.check_and_fix(S(), DB()) == "onarıldı"


def test_missing_container_is_rebuilt(monkeypatch):
    _patch(monkeypatch, missing=True)
    assert vpsdebug.check_and_fix(S(), DB()) == "onarıldı"


def test_user_stopped_vps_is_not_touched(monkeypatch):
    _patch(monkeypatch, Cont("exited"))
    assert vpsdebug.check_and_fix(S(), DB()) == "atlandı"


def test_cooldown_prevents_repeated_attempts(monkeypatch):
    vpsdebug._last_attempt.clear()
    called = []

    def _container(server):
        called.append(1)
        raise NotFound("yok")

    monkeypatch.setattr(dm, "_container", _container)
    monkeypatch.setattr(vpsdebug, "_rebuild_and_start", lambda *a, **k: "new-id")
    assert vpsdebug.check_and_fix(S(), DB()) == "onarıldı"
    assert vpsdebug.check_and_fix(S(), DB()) == "beklemede"
    assert len(called) == 1  # ikinci taramada Docker'a hiç dokunulmadı
    vpsdebug._last_attempt.clear()
