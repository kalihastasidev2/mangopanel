"""1.40.25: Discord bağlama zorunlu değildir; bağlamayan kullanıcıya öneri (discord_suggest) gösterilir."""
from fastapi.testclient import TestClient

from mango.config import settings
from mango.db import SessionLocal, User, init_db
from mango.main import app
from mango.security import hash_password
from mango.store import set_setting
import pytest


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-v1420"))
    init_db()
    db = SessionLocal()
    for name, admin in (("v1420_admin", True), ("v1420_user", False)):
        if db.query(User).filter_by(username=name).first() is None:
            db.add(User(username=name, email=f"{name}@example.com",
                        password_hash=hash_password("adminpass1"), is_admin=admin, max_servers=5))
    db.commit()
    db.close()
    return TestClient(app)


def _login(client, name):
    r = client.post("/api/auth/login", json={"username": name, "password": "adminpass1"})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['token']}"}


def test_unlinked_user_is_never_blocked(client):
    h = _login(client, "v1420_user")
    assert client.get("/api/servers?scope=mine", headers=h).status_code == 200


def test_suggestion_only_when_discord_is_configured_and_unlinked(client):
    h = _login(client, "v1420_user")
    db = SessionLocal()
    set_setting(db, "discord_client_id", "")
    set_setting(db, "discord_client_secret", "")
    db.commit()
    db.close()
    assert client.get("/api/me", headers=h).json()["discord_suggest"] is False

    db = SessionLocal()
    set_setting(db, "discord_client_id", "12345678901234567")
    set_setting(db, "discord_client_secret", "test-secret")
    db.commit()
    db.close()
    assert client.get("/api/me", headers=h).json()["discord_suggest"] is True


def test_linked_user_gets_no_suggestion(client):
    db = SessionLocal()
    u = db.query(User).filter_by(username="v1420_user").first()
    u.discord_id = "99900000000000001"
    db.commit()
    db.close()
    h = _login(client, "v1420_user")
    assert client.get("/api/me", headers=h).json()["discord_suggest"] is False
    db = SessionLocal()
    u = db.query(User).filter_by(username="v1420_user").first()
    u.discord_id = None
    db.commit()
    db.close()


def test_link_url_requires_login(client):
    assert client.get("/api/auth/discord/link-url").status_code == 401
    h = _login(client, "v1420_user")
    r = client.get("/api/auth/discord/link-url", headers=h)
    assert r.status_code == 200
    assert r.json()["url"].startswith("https://discord.com/")
