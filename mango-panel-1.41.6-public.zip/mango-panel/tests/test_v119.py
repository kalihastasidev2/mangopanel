"""1.19.0: egg'li premium paketler, serbest paketler, yönetici sunucu verme ve node seçimi."""
import shutil
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from mango import api as api_module
from mango.config import settings
from mango.db import SessionLocal, User, init_db
from mango.main import app
from mango.security import hash_password

REPO_EGGS = Path(__file__).resolve().parent.parent / "eggs"


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-v119"))
    eggs_copy = tmp_path_factory.mktemp("eggs-v119") / "eggs"
    shutil.copytree(REPO_EGGS, eggs_copy)
    settings.eggs_dir = str(eggs_copy)
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="v119_admin").first() is None:
        db.add(User(username="v119_admin", email="v119a@example.com",
                    password_hash=hash_password("adminpass1"), is_admin=True, max_servers=99))
        db.commit()
    db.close()
    return TestClient(app)


def _login(client, name, password="guclu-sifre-1"):
    r = client.post("/api/auth/login", json={"username": name, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["token"]}


def _member(client, name):
    db = SessionLocal()
    if db.query(User).filter_by(username=name).first() is None:
        db.add(User(username=name, email=f"{name}@example.com",
                    password_hash=hash_password("guclu-sifre-1"), is_admin=False, max_servers=5))
        db.commit()
    db.close()
    return _login(client, name)


def _uid(name):
    db = SessionLocal()
    uid = db.query(User).filter_by(username=name).first().id
    db.close()
    return uid


def _stub_docker(monkeypatch):
    monkeypatch.setattr(api_module.dm, "run_install", lambda *a, **k: None)
    monkeypatch.setattr(api_module.dm, "create", lambda *a, **k: "cid-v119")
    monkeypatch.setattr(api_module.dm, "status", lambda s: "running")


def test_plan_can_be_tied_to_an_egg_and_invalid_eggs_are_rejected(client):
    admin = _login(client, "v119_admin", "adminpass1")
    bad = client.post("/api/admin/plans", headers=admin, json={"name": "Yanlış Egg", "egg": "yok-boyle"})
    assert bad.status_code == 400
    plan = client.post("/api/admin/plans", headers=admin, json={
        "name": "Node.js Paketi", "egg": "nodejs-app", "max_servers": 3, "memory_mb": 1024, "cpu_percent": 100,
    })
    assert plan.status_code == 201, plan.text
    assert plan.json()["egg"] == "nodejs-app"
    assert plan.json()["egg_name"]
    free = client.post("/api/admin/plans", headers=admin, json={"name": "Serbest Hak", "egg": ""})
    assert free.json()["egg"] == ""
    # Egg değiştirilebilir; geçersiz egg güncellemede de reddedilir.
    patched = client.patch(f"/api/admin/plans/{free.json()['id']}", headers=admin, json={"egg": "nodejs-app"})
    assert patched.json()["egg"] == "nodejs-app"
    assert client.patch(f"/api/admin/plans/{free.json()['id']}", headers=admin,
                        json={"egg": "yok-boyle"}).status_code == 400


def test_egg_plan_grant_creates_server_for_buyer_on_chosen_node(client, monkeypatch):
    _stub_docker(monkeypatch)
    admin = _login(client, "v119_admin", "adminpass1")
    buyer = _member(client, "v119_buyer")
    node = client.post("/api/admin/nodes", headers=admin, json={"name": "Paket Node"}).json()["node"]
    plan = client.post("/api/admin/plans", headers=admin, json={
        "name": "Node.js Paketi", "egg": "nodejs-app", "max_servers": 3, "memory_mb": 1024, "cpu_percent": 100,
    }).json()
    ticket = client.post("/api/tickets", headers=buyer, json={
        "subject": "Node.js paketi", "message": "Almak istiyorum", "category": "purchase", "plan_id": plan["id"],
    }).json()
    assert ticket["plan_egg"] == "nodejs-app"

    granted = client.post(f"/api/admin/tickets/{ticket['id']}/grant", headers=admin,
                          json={"node_id": node["id"], "server_name": "Paket Sunucusu"})
    assert granted.status_code == 200, granted.text
    assert "Sunucu oluşturuldu: Paket Sunucusu" in granted.json()["messages"][-1]["text"]

    mine = [s for s in client.get("/api/servers", headers=buyer).json() if s["name"] == "Paket Sunucusu"]
    assert len(mine) == 1
    assert mine[0]["egg"] == "nodejs-app"
    assert mine[0]["node_id"] == node["id"]


def test_free_plan_grant_only_sets_server_allowance(client):
    admin = _login(client, "v119_admin", "adminpass1")
    buyer = _member(client, "v119_free_buyer")
    plan = client.post("/api/admin/plans", headers=admin, json={"name": "Serbest Hak", "max_servers": 7}).json()
    ticket = client.post("/api/tickets", headers=buyer, json={
        "subject": "Serbest hak", "message": "Hak istiyorum", "category": "purchase", "plan_id": plan["id"],
    }).json()
    granted = client.post(f"/api/admin/tickets/{ticket['id']}/grant", headers=admin)
    assert granted.status_code == 200, granted.text
    assert "Sunucu oluşturuldu" not in granted.json()["messages"][-1]["text"]
    db = SessionLocal()
    assert db.query(User).filter_by(username="v119_free_buyer").first().max_servers == 7
    db.close()


def test_admin_gives_server_to_user_with_node_choice(client, monkeypatch):
    _stub_docker(monkeypatch)
    admin = _login(client, "v119_admin", "adminpass1")
    receiver = _member(client, "v119_receiver")
    node = client.post("/api/admin/nodes", headers=admin, json={"name": "Verme Node"}).json()["node"]
    body = {"name": "Verilen Sunucu", "egg": "nodejs-app", "memory_mb": 512, "cpu_percent": 100,
            "variables": {}, "owner_id": _uid("v119_receiver")}

    given = client.post("/api/servers", headers=admin, json={**body, "node_id": node["id"]})
    assert given.status_code == 201, given.text
    assert given.json()["node_id"] == node["id"]
    assert any(s["name"] == "Verilen Sunucu" for s in client.get("/api/servers", headers=receiver).json())

    unknown = client.post("/api/servers", headers=admin, json={**body, "name": "Yok Node", "node_id": 999999})
    assert unknown.status_code == 400

    # Yerel (node'suz) sunucu da verilebilir.
    local = client.post("/api/servers", headers=admin, json={**body, "name": "Yerel Sunucu"})
    assert local.status_code == 201
    assert local.json()["node_id"] is None

    # Üye kendi adına node seçemez (sunucu oluşturma yetkisi olmadığı için de reddedilir).
    member_try = client.post("/api/servers", headers=receiver, json={**body, "name": "Kendi Node", "node_id": node["id"]})
    assert member_try.status_code == 403
