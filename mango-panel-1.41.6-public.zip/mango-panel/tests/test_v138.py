"""1.38.0: 3 günlük demo, satış hunisi, makbuz için kupon/fiyat alanları."""
import datetime as dt
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from mango import demo
from mango.db import Notification, NotificationRecipient, Server, SessionLocal, User, init_db
from mango.main import app
from mango.premium_api import GrantIn
from mango.security import hash_password


@pytest.fixture(scope="module")
def client():
    init_db()
    db = SessionLocal()
    for name, admin in [("v138_admin", True), ("v138_user", False)]:
        if db.query(User).filter_by(username=name).first() is None:
            db.add(User(username=name, email=f"{name}@example.com", password_hash=hash_password("guclu-sifre-1"),
                        is_admin=admin, max_servers=5))
    db.commit()
    db.close()
    return TestClient(app)


def _token(client, name):
    res = client.post("/api/auth/login", json={"username": name, "password": "guclu-sifre-1"})
    assert res.status_code == 200, res.text
    return {"Authorization": "Bearer " + res.json()["token"]}


def test_grant_demo_defaults_off():
    assert GrantIn().demo is False


def test_mark_demo_sets_three_days_from_now():
    server = SimpleNamespace(expires_at=None)
    before = dt.datetime.now(dt.timezone.utc)
    demo.mark_demo(None, server)
    delta = server.expires_at - before
    assert dt.timedelta(days=2, hours=23) < delta <= dt.timedelta(days=3, minutes=1)


def test_check_expired_stops_server_notifies_owner_and_clears_expiry(client):
    db = SessionLocal()
    owner = db.query(User).filter_by(username="v138_user").one()
    server = Server(name="v138-demo", egg="linux-vps", owner_id=owner.id, port=59138,
                    expires_at=dt.datetime.now(dt.timezone.utc) - dt.timedelta(minutes=1))
    db.add(server)
    db.commit()
    sid = server.id
    db.close()

    stopped = []
    done = demo.check_expired(lambda s, action: stopped.append((s.id, action)))
    assert done >= 1
    assert (sid, "stop") in stopped

    db = SessionLocal()
    try:
        assert db.get(Server, sid).expires_at is None
        note = db.query(Notification).filter_by(title="Sunucu süreniz doldu").order_by(Notification.id.desc()).first()
        assert note is not None
        rec = db.query(NotificationRecipient).filter_by(notification_id=note.id).first()
        assert rec is not None and rec.user_id == owner.id
        db.delete(db.get(Server, sid))
        db.commit()
    finally:
        db.close()


def test_check_expired_ignores_active_demo(client):
    db = SessionLocal()
    owner = db.query(User).filter_by(username="v138_user").one()
    server = Server(name="v138-active", egg="linux-vps", owner_id=owner.id, port=59139,
                    expires_at=dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=2))
    db.add(server)
    db.commit()
    sid = server.id
    db.close()

    stopped = []
    demo.check_expired(lambda s, action: stopped.append(s.id))
    assert sid not in stopped

    db = SessionLocal()
    db.delete(db.get(Server, sid))
    db.commit()
    db.close()


def test_funnel_is_admin_only(client):
    assert client.get("/api/admin/funnel").status_code in (401, 403)
    assert client.get("/api/admin/funnel", headers=_token(client, "v138_user")).status_code == 403


def test_funnel_summary_and_stages(client):
    res = client.get("/api/admin/funnel", headers=_token(client, "v138_admin"))
    assert res.status_code == 200, res.text
    data = res.json()
    assert set(data["summary"]) == {"registered", "buyers", "no_purchase"}
    assert data["summary"]["registered"] == data["summary"]["buyers"] + data["summary"]["no_purchase"]
    user = next(u for u in data["users"] if u["username"] == "v138_user")
    assert user["stage"] == "kayitli"
    assert user["purchases"] == 0 and user["servers"] == 0
    assert all(u["stage"] in ("kayitli", "sunucusu_var", "satin_aldi") for u in data["users"])


def test_receipt_fields_exposed_on_tickets(client):
    from mango.premium_api import _ticket_row
    from mango.db import Ticket
    t = Ticket(subject="x", category="purchase", status="open", user_id=1, plan_id=None,
               created_at=dt.datetime.now(dt.timezone.utc), updated_at=dt.datetime.now(dt.timezone.utc),
               coupon_code="ABC")
    row = _ticket_row(t, None, None)
    assert row["coupon_code"] == "ABC"
    assert row["plan_price"] == ""
