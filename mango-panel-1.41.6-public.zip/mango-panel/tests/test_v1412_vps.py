from pathlib import Path

import pytest
import yaml
from docker.errors import ImageNotFound

from mango import docker_manager as dm

ROOT = Path(__file__).resolve().parent.parent


def _egg():
    return yaml.safe_load((ROOT / "eggs" / "linux-vps.yaml").read_text(encoding="utf-8"))


def test_vps_egg_uses_local_image_without_published_ports():
    egg = _egg()
    assert egg["docker_image"] == "ubuntu:24.04"
    assert egg["publish_ports"] is False
    assert egg["install_script"] == ""
    assert "trap 'exit 0' TERM INT" in egg["startup"]
    assert "apt-get install" in egg["startup"]
    assert "SYS_CHROOT" not in egg["cap_add"]


def test_vps_image_has_no_ssh_and_handles_sigterm():
    vps = ROOT / "docker" / "vps"
    dockerfile = (vps / "Dockerfile").read_text(encoding="utf-8")
    assert "openssh" not in dockerfile
    start = (vps / "mango-vps-start.sh").read_text(encoding="utf-8")
    assert "trap 'exit 0' TERM INT" in start
    assert "wait $!" in start


def test_local_mango_image_is_never_pulled(monkeypatch):
    class _Images:
        pulled = []

        def get(self, image):
            raise ImageNotFound("yok")

        def pull(self, repo, tag=None):
            self.pulled.append((repo, tag))

    class _Client:
        images = _Images()

    monkeypatch.setattr(dm, "client", lambda: _Client())
    with pytest.raises(RuntimeError, match="docker build"):
        dm.ensure_image("mango/vps-ubuntu:24.04")
    assert _Client.images.pulled == []


def test_index_page_has_version_filled():
    from fastapi.testclient import TestClient

    from mango.main import app

    r = TestClient(app).get("/")
    assert r.status_code == 200
    assert "{{VERSION}}" not in r.text
    assert r.headers.get("cache-control") == "no-cache"


def test_image_keeps_apt_lists_and_refreshes_them_at_start():
    vps = ROOT / "docker" / "vps"
    dockerfile = (vps / "Dockerfile").read_text(encoding="utf-8")
    assert "rm -rf /var/lib/apt/lists" not in dockerfile
    assert "python3" in dockerfile
    start = (vps / "mango-vps-start.sh").read_text(encoding="utf-8")
    assert "apt-get update" in start
