import pytest
from fastapi.testclient import TestClient

from mango.api import _validate_command
from mango.config import settings
from mango.db import SessionLocal, Server, User, init_db
from mango.main import app
from mango.security import create_token, hash_password


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers"))
    init_db()
    db = SessionLocal()
    admin = db.query(User).filter_by(username="root_admin").first()
    if admin is None:
        admin = User(username="root_admin", password_hash=hash_password("adminpass1"), is_admin=True)
        db.add(admin)
        db.commit()
    user = db.query(User).filter_by(username="plain_user").first()
    if user is None:
        user = User(username="plain_user", password_hash=hash_password("userpass1"), is_admin=False)
        db.add(user)
        db.commit()
    srv = db.query(Server).filter_by(name="files-test").first()
    if srv is None:
        srv = Server(name="files-test", egg="static-web", owner_id=user.id, port=25999,
                     memory_mb=512, cpu_percent=100, variables={})
        db.add(srv)
        db.commit()
    ids = {"admin": admin.id, "user": user.id, "server": srv.id}
    db.close()
    c = TestClient(app)
    c.ids = ids
    return c


def _auth(client, name):
    db = SessionLocal()
    try:
        u = db.query(User).filter_by(username=name).first()
        return {"Authorization": "Bearer " + create_token(u)}
    finally:
        db.close()


def test_login_and_me(client):
    r = client.post("/api/auth/login", json={"username": "plain_user", "password": "userpass1"})
    assert r.status_code == 200
    assert client.get("/api/me", headers={"Authorization": "Bearer " + r.json()["token"]}).json()["username"] == "plain_user"


def test_wrong_password_rejected(client):
    r = client.post("/api/auth/login", json={"username": "plain_user", "password": "wrongpass"})
    assert r.status_code == 401


def test_system_reports_version(client):
    assert client.get("/api/system").json()["version"] == "1.41.6"


def test_files_write_read_list(client):
    h = _auth(client, "plain_user")
    sid = client.ids["server"]
    r = client.put(f"/api/servers/{sid}/files/content", headers=h,
                   json={"path": "index.html", "content": "<h1>merhaba</h1>"})
    assert r.status_code == 200
    r = client.get(f"/api/servers/{sid}/files/content", headers=h, params={"path": "index.html"})
    assert r.json()["content"] == "<h1>merhaba</h1>"
    names = [e["name"] for e in client.get(f"/api/servers/{sid}/files", headers=h).json()["entries"]]
    assert "index.html" in names


def test_files_traversal_returns_400(client):
    h = _auth(client, "plain_user")
    sid = client.ids["server"]
    r = client.get(f"/api/servers/{sid}/files", headers=h, params={"path": "../../etc"})
    assert r.status_code == 400


def test_other_user_cannot_see_server(client):
    # root_admin dışındaki başka bir kullanıcı, plain_user'ın sunucusunu göremez.
    db = SessionLocal()
    other = db.query(User).filter_by(username="other_user").first()
    if other is None:
        other = User(username="other_user", password_hash=hash_password("otherpass1"), is_admin=False)
        db.add(other)
        db.commit()
    db.close()
    h = _auth(client, "other_user")
    sid = client.ids["server"]
    assert client.get(f"/api/servers/{sid}/files", headers=h).status_code == 404


def test_admin_can_update_user_and_cannot_remove_own_admin(client):
    h = _auth(client, "root_admin")
    me = client.ids["admin"]
    r = client.patch(f"/api/users/{me}", headers=h, json={"is_admin": False})
    assert r.status_code == 409


def test_cannot_delete_self(client):
    h = _auth(client, "root_admin")
    r = client.delete(f"/api/users/{client.ids['admin']}", headers=h)
    assert r.status_code == 409


def test_non_admin_cannot_list_users(client):
    h = _auth(client, "plain_user")
    assert client.get("/api/users", headers=h).status_code == 403


@pytest.mark.parametrize("text, ok", [
    ("say merhaba", True),
    ("", False),
    ("   ", False),
    ("a\nb", False),
    ("a\rb", False),
    ("a\x00b", False),
])
def test_command_validation(text, ok):
    assert (_validate_command(text) is None) is ok
