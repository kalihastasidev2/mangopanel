"""1.18.0: premium paketler, destek/satın alma talepleri, node yönetimi ve node ajanı."""
import shutil
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from mango.config import settings
from mango.db import SessionLocal, User, init_db
from mango.main import app
from mango.security import hash_password

REPO_EGGS = Path(__file__).resolve().parent.parent / "eggs"


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-v118"))
    eggs_copy = tmp_path_factory.mktemp("eggs-v118") / "eggs"
    shutil.copytree(REPO_EGGS, eggs_copy)
    settings.eggs_dir = str(eggs_copy)
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="v118_admin").first() is None:
        db.add(User(username="v118_admin", email="v118a@example.com",
                    password_hash=hash_password("adminpass1"), is_admin=True, max_servers=99))
        db.commit()
    db.close()
    return TestClient(app)


def _login(client, name, password="guclu-sifre-1"):
    r = client.post("/api/auth/login", json={"username": name, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["token"]}


def _member(client, name):
    db = SessionLocal()
    if db.query(User).filter_by(username=name).first() is None:
        db.add(User(username=name, email=f"{name}@example.com",
                    password_hash=hash_password("guclu-sifre-1"), is_admin=False, max_servers=2))
        db.commit()
    db.close()
    return _login(client, name)


def _token_from(command: str) -> str:
    # "curl -fsSL https://host/api/nodes/install/TOKEN | sudo bash"
    return command.split()[2].rsplit("/", 1)[1]


def test_plans_are_managed_by_admin_and_only_active_ones_are_listed(client):
    admin = _login(client, "v118_admin", "adminpass1")
    user = _member(client, "v118_plan_user")
    pro = client.post("/api/admin/plans", headers=admin, json={
        "name": "Pro", "price_text": "120 TL / ay", "max_servers": 5,
        "memory_mb": 2048, "cpu_percent": 200, "disk_mb": 8192, "active": True,
    })
    assert pro.status_code == 201, pro.text
    hidden = client.post("/api/admin/plans", headers=admin, json={"name": "Gizli", "active": False}).json()["id"]

    visible = [p["name"] for p in client.get("/api/plans", headers=user).json()]
    assert "Pro" in visible and "Gizli" not in visible
    assert client.post("/api/admin/plans", headers=user, json={"name": "Hack"}).status_code == 403
    assert client.get("/api/admin/plans", headers=user).status_code == 403

    updated = client.patch(f"/api/admin/plans/{pro.json()['id']}", headers=admin, json={"price_text": "150 TL / ay"})
    assert updated.status_code == 200
    assert updated.json()["price_text"] == "150 TL / ay"

    assert client.delete(f"/api/admin/plans/{hidden}", headers=admin).status_code == 204
    names = [p["name"] for p in client.get("/api/admin/plans", headers=admin).json()]
    assert "Gizli" not in names


def test_purchase_ticket_flow_visibility_and_grant(client):
    admin = _login(client, "v118_admin", "adminpass1")
    buyer = _member(client, "v118_buyer")
    other = _member(client, "v118_other")
    plan_id = client.post("/api/admin/plans", headers=admin,
                          json={"name": "Plus", "max_servers": 4}).json()["id"]

    # Satın alma talebinde paket zorunlu; geçersiz paket reddedilir.
    no_plan = client.post("/api/tickets", headers=buyer,
                          json={"subject": "Paket al", "message": "Merhaba", "category": "purchase"})
    assert no_plan.status_code == 400
    bad_plan = client.post("/api/tickets", headers=buyer,
                           json={"subject": "Paket al", "message": "Merhaba", "category": "purchase", "plan_id": 999999})
    assert bad_plan.status_code == 400

    created = client.post("/api/tickets", headers=buyer, json={
        "subject": "Plus paketi", "message": "Satın almak istiyorum", "category": "purchase", "plan_id": plan_id,
    })
    assert created.status_code == 201, created.text
    tid = created.json()["id"]
    assert created.json()["status"] == "open"
    assert created.json()["plan_name"] == "Plus"

    # Başka kullanıcı talebi göremez; kendi listesinde görünür.
    assert client.get(f"/api/tickets/{tid}", headers=other).status_code == 404
    assert any(t["id"] == tid for t in client.get("/api/tickets", headers=buyer).json())
    assert all(t["id"] != tid for t in client.get("/api/tickets", headers=other).json())

    # Yönetici yanıtlayınca 'yanıtlandı', kullanıcı yanıtlayınca tekrar 'açık'.
    answered = client.post(f"/api/tickets/{tid}/messages", headers=admin, json={"text": "Ödeme bilgisi gönderildi"})
    assert answered.json()["status"] == "answered"
    reopened = client.post(f"/api/tickets/{tid}/messages", headers=buyer, json={"text": "Tamam"})
    assert reopened.json()["status"] == "open"
    assert [m["is_admin"] for m in reopened.json()["messages"]] == [False, True, False]

    # Paket onayı yalnızca yönetici; sunucu limiti paketteki değere ayarlanır.
    assert client.post(f"/api/admin/tickets/{tid}/grant", headers=buyer).status_code == 403
    granted = client.post(f"/api/admin/tickets/{tid}/grant", headers=admin)
    assert granted.status_code == 200, granted.text
    db = SessionLocal()
    assert db.query(User).filter_by(username="v118_buyer").first().max_servers == 4
    db.close()

    # Destek talebi için paket onayı yok.
    support = client.post("/api/tickets", headers=buyer, json={"subject": "Yardım lazım", "message": "Sorun var"})
    assert client.post(f"/api/admin/tickets/{support.json()['id']}/grant", headers=admin).status_code == 400

    # Kapatılan talebe yazılamaz.
    closed = client.post(f"/api/tickets/{tid}/close", headers=buyer)
    assert closed.json()["status"] == "closed"
    assert client.post(f"/api/tickets/{tid}/messages", headers=buyer, json={"text": "x"}).status_code == 409


def test_node_install_heartbeat_and_token_rotation(client):
    admin = _login(client, "v118_admin", "adminpass1")
    user = _member(client, "v118_nodeuser")
    assert client.post("/api/admin/nodes", headers=user, json={"name": "Node Yok"}).status_code == 403
    assert client.get("/api/admin/nodes", headers=user).status_code == 403

    created = client.post("/api/admin/nodes", headers=admin, json={"name": "Node A", "description": "Frankfurt"})
    assert created.status_code == 201, created.text
    body = created.json()
    node_id = body["node"]["id"]
    assert body["node"]["online"] is False
    token = _token_from(body["install_command"])
    assert body["install_command"].startswith("curl -fsSL ")
    assert body["install_command"].endswith("| sudo bash")

    script = client.get(f"/api/nodes/install/{token}")
    assert script.status_code == 200
    assert token in script.text
    assert "__NODE_TOKEN__" not in script.text and "__PANEL_URL__" not in script.text
    assert "systemctl enable --now mango-node" in script.text
    assert client.get("/api/nodes/install/bilinmeyen-anahtar").status_code == 404

    agent = client.get("/api/nodes/agent.py")
    assert agent.status_code == 200
    assert "def heartbeat" in agent.text

    beat = client.post("/api/nodes/heartbeat", headers={"Authorization": "Bearer " + token},
                       json={"version": "1.18.0", "stats": {"memory_total_mb": 2048, "memory_used_mb": 512}})
    assert beat.status_code == 200, beat.text
    assert beat.json()["name"] == "Node A"
    assert client.post("/api/nodes/heartbeat", headers={"Authorization": "Bearer yanlis"}, json={}).status_code == 401
    assert client.post("/api/nodes/heartbeat", json={}).status_code == 401

    nodes = client.get("/api/admin/nodes", headers=admin).json()
    node = next(n for n in nodes if n["id"] == node_id)
    assert node["online"] is True
    assert node["stats"]["memory_used_mb"] == 512
    assert node["version"] == "1.18.0"

    # Anahtar yenilenince eski komut ve eski anahtar geçersiz olur.
    rotated = client.patch(f"/api/admin/nodes/{node_id}", headers=admin,
                           json={"rotate_token": True, "description": "Yeni konum"})
    assert rotated.status_code == 200, rotated.text
    new_token = _token_from(rotated.json()["install_command"])
    assert new_token != token
    assert client.post("/api/nodes/heartbeat", headers={"Authorization": "Bearer " + token}, json={}).status_code == 401
    assert client.get(f"/api/nodes/install/{token}").status_code == 404
    assert client.post("/api/nodes/heartbeat", headers={"Authorization": "Bearer " + new_token},
                       json={}).status_code == 200

    assert client.delete(f"/api/admin/nodes/{node_id}", headers=admin).status_code == 204
    assert all(n["id"] != node_id for n in client.get("/api/admin/nodes", headers=admin).json())
