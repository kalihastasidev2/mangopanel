"""1.39.0: Cloudflare ayarları (Zone ID, API token) ve bağlantı testi."""
import pytest
from fastapi.testclient import TestClient

from mango import cf_check as cloudflare
from mango.db import SessionLocal, User, init_db
from mango.main import app
from mango.security import hash_password

ZONE = "6f0b132113bee38f1334a6bd7742687d"


@pytest.fixture(scope="module")
def client():
    init_db()
    db = SessionLocal()
    for name, admin in [("v139_admin", True), ("v139_user", False)]:
        if db.query(User).filter_by(username=name).first() is None:
            db.add(User(username=name, email=f"{name}@example.com", password_hash=hash_password("guclu-sifre-1"),
                        is_admin=admin, max_servers=5))
    db.commit()
    db.close()
    return TestClient(app)


def _token(client, name):
    res = client.post("/api/auth/login", json={"username": name, "password": "guclu-sifre-1"})
    assert res.status_code == 200, res.text
    return {"Authorization": "Bearer " + res.json()["token"]}


def test_token_is_saved_but_never_returned(client):
    h = _token(client, "v139_admin")
    res = client.put("/api/admin/settings", headers=h,
                     json={"cf_zone_id": ZONE, "cf_api_token": "cf-test-gizli-deger"})
    assert res.status_code == 200, res.text
    got = client.get("/api/admin/settings", headers=h).json()
    assert got["cf_zone_id"] == ZONE
    assert got["cf_token_set"] is True
    assert "cf-test-gizli-deger" not in res.text
    assert "cf_api_token" not in got


def test_zone_id_length_is_limited(client):
    h = _token(client, "v139_admin")
    res = client.put("/api/admin/settings", headers=h, json={"cf_zone_id": "x" * 41})
    assert res.status_code == 422


def test_test_endpoint_is_admin_only(client):
    assert client.post("/api/admin/cloudflare/test").status_code in (401, 403)
    assert client.post("/api/admin/cloudflare/test", headers=_token(client, "v139_user")).status_code == 403


def test_check_requires_token_and_zone():
    assert cloudflare.check("", ZONE)["ok"] is False
    assert "token" in cloudflare.check("", ZONE)["message"].lower()
    assert "zone" in cloudflare.check("abc", "")["message"].lower()


def _fake(responses):
    calls = iter(responses)

    def _get(path, token):
        return next(calls)
    return _get


def test_check_success(monkeypatch):
    monkeypatch.setattr(cloudflare, "_get", _fake([
        (200, {"success": True, "result": {"status": "active"}}),
        (200, {"success": True, "result": []}),
    ]))
    r = cloudflare.check("tok", ZONE)
    assert r["ok"] is True and "DNS erişimi tamam" in r["message"]


def test_check_bad_token(monkeypatch):
    monkeypatch.setattr(cloudflare, "_get", _fake([(401, {"success": False})]))
    r = cloudflare.check("tok", ZONE)
    assert r["ok"] is False and "geçersiz" in r["message"]


def test_check_zone_not_found(monkeypatch):
    monkeypatch.setattr(cloudflare, "_get", _fake([
        (200, {"success": True}), (404, {"success": False}),
    ]))
    r = cloudflare.check("tok", ZONE)
    assert r["ok"] is False and "Zone ID bulunamadı" in r["message"]


def test_check_no_access_to_zone(monkeypatch):
    monkeypatch.setattr(cloudflare, "_get", _fake([
        (200, {"success": True}), (403, {"success": False}),
    ]))
    assert "zone izni" in cloudflare.check("tok", ZONE)["message"]


def test_check_network_error(monkeypatch):
    monkeypatch.setattr(cloudflare, "_get", _fake([(0, {})]))
    assert "ulaşılamadı" in cloudflare.check("tok", ZONE)["message"]
