"""1.20.0: sunucu listesi kapsamı, özel domain bağlama ve doğrulanmış domain yönlendirmesi."""
import shutil
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from mango import api as api_module
from mango import domains as domains_module
from mango.config import settings
from mango.db import SessionLocal, Server, User, init_db
from mango.main import app
from mango.security import hash_password

REPO_EGGS = Path(__file__).resolve().parent.parent / "eggs"
_next_port = [34000]


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-v120"))
    eggs_copy = tmp_path_factory.mktemp("eggs-v120") / "eggs"
    shutil.copytree(REPO_EGGS, eggs_copy)
    settings.eggs_dir = str(eggs_copy)
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="v120_admin").first() is None:
        db.add(User(username="v120_admin", email="v120a@example.com",
                    password_hash=hash_password("adminpass1"), is_admin=True, max_servers=99))
        db.commit()
    db.close()
    return TestClient(app)


def _login(client, name, password="guclu-sifre-1"):
    r = client.post("/api/auth/login", json={"username": name, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["token"]}


def _user(client, name):
    db = SessionLocal()
    user = db.query(User).filter_by(username=name).first()
    if user is None:
        user = User(username=name, email=f"{name}@example.com",
                    password_hash=hash_password("guclu-sifre-1"), is_admin=False, max_servers=5)
        db.add(user)
        db.commit()
    uid = user.id
    db.close()
    return uid, _login(client, name)


def _server(owner_id, egg, site_slug=None, container_id=None):
    _next_port[0] += 1
    db = SessionLocal()
    server = Server(name=f"S{_next_port[0]}", egg=egg, owner_id=owner_id, port=_next_port[0], memory_mb=256,
                    cpu_percent=100, variables={}, site_slug=site_slug, container_id=container_id)
    db.add(server)
    db.commit()
    sid = server.id
    db.close()
    return sid


@pytest.fixture
def docker_stub(monkeypatch):
    monkeypatch.setattr(api_module.dm, "status_map", lambda: None)  # Docker yokmuş gibi tek tek sorgulanır
    monkeypatch.setattr(api_module.dm, "status", lambda s: "running")


def test_admin_sees_all_servers_and_scope_mine_narrows_the_list(client, docker_stub):
    admin = _login(client, "v120_admin", "adminpass1")
    a_id, a_headers = _user(client, "v120_owner_a")
    b_id, b_headers = _user(client, "v120_owner_b")
    a_server = _server(a_id, "nodejs-app")
    b_server = _server(b_id, "nodejs-app")

    everything = {s["id"] for s in client.get("/api/servers", headers=admin).json()}
    assert {a_server, b_server} <= everything
    mine = {s["id"] for s in client.get("/api/servers?scope=mine", headers=admin).json()}
    assert a_server not in mine and b_server not in mine

    a_view = {s["id"] for s in client.get("/api/servers", headers=a_headers).json()}
    assert a_server in a_view and b_server not in a_view
    assert {s["id"] for s in client.get("/api/servers?scope=all", headers=a_headers).json()} == a_view

    row = next(s for s in client.get("/api/servers", headers=a_headers).json() if s["id"] == a_server)
    assert row["status"] == "running"
    assert "owner" in row["my_permissions"]


def test_custom_domain_is_routed_only_after_txt_verification(client, docker_stub, monkeypatch):
    monkeypatch.setattr(api_module, "_site_fetch",
                        lambda port, path, query: (200, "text/html; charset=utf-8", f"<h1>{path or 'ana'}</h1>".encode()))
    uid, headers = _user(client, "v120_site_owner")
    sid = _server(uid, "static-web", site_slug="portfolio-v120", container_id="cid-site")
    host = {"host": "portfolio.example-v120.com"}

    before = client.get("/", headers=host)
    assert b"<h1>ana</h1>" not in before.content  # doğrulanmamış domain yayınlanmaz

    added = client.post(f"/api/servers/{sid}/domains", headers=headers, json={"domain": "portfolio.example-v120.com"})
    assert added.status_code == 201, added.text
    records = added.json()["records"]
    txt = next(r for r in records if r["type"] == "TXT")
    assert txt["name"] == "_mango-verify.portfolio.example-v120.com"
    token = txt["value"].split("mango-verify=")[1]
    assert any(r["type"] == "CNAME" and r["name"] == "portfolio.example-v120.com" for r in records)

    # TXT kaydı yokken doğrulama başarısız.
    monkeypatch.setattr(domains_module, "lookup_txt", lambda name: [])
    domain_id = added.json()["id"]
    fail = client.post(f"/api/servers/{sid}/domains/{domain_id}/verify", headers=headers)
    assert fail.json()["verified"] is False

    monkeypatch.setattr(domains_module, "lookup_txt", lambda name: [f"mango-verify={token}"])
    ok = client.post(f"/api/servers/{sid}/domains/{domain_id}/verify", headers=headers)
    assert ok.json()["verified"] is True

    root = client.get("/", headers=host)
    assert b"<h1>ana</h1>" in root.content
    about = client.get("/about", headers=host)
    assert b"<h1>about</h1>" in about.content

    assert client.delete(f"/api/servers/{sid}/domains/{domain_id}", headers=headers).status_code == 204
    gone = client.get("/", headers=host)
    assert b"<h1>ana</h1>" not in gone.content


def test_domain_rules_are_enforced(client, docker_stub):
    uid, headers = _user(client, "v120_rules_owner")
    node_sid = _server(uid, "nodejs-app", site_slug="uygulama-v120")
    site_sid = _server(uid, "static-web", container_id="cid-x")  # site adı yok

    # Node.js uygulaması gibi site olmayan egg'lerde domain bağlanmaz.
    not_site = client.post(f"/api/servers/{node_sid}/domains", headers=headers, json={"domain": "bot.example-v120.com"})
    assert not_site.status_code == 400
    # Site adı olmadan domain bağlanamaz.
    no_slug = client.post(f"/api/servers/{site_sid}/domains", headers=headers, json={"domain": "yeni.example-v120.com"})
    assert no_slug.status_code == 400
    # Geçersiz domain adı.
    site_with_slug = _server(uid, "static-web", site_slug="site-kuralli-v120", container_id="cid-y")
    invalid = client.post(f"/api/servers/{site_with_slug}/domains", headers=headers, json={"domain": "bad_domain"})
    assert invalid.status_code == 400
    # Panelin kendi adresi.
    own = client.post(f"/api/servers/{site_with_slug}/domains", headers=headers, json={"domain": "localhost"})
    assert own.status_code == 400
    # Aynı domain iki sunucuda kullanılamaz.
    first = client.post(f"/api/servers/{site_with_slug}/domains", headers=headers, json={"domain": "tek.example-v120.com"})
    assert first.status_code == 201
    other_uid, other_headers = _user(client, "v120_rules_other")
    other_site = _server(other_uid, "static-web", site_slug="baska-site-v120", container_id="cid-z")
    dup = client.post(f"/api/servers/{other_site}/domains", headers=other_headers, json={"domain": "tek.example-v120.com"})
    assert dup.status_code == 409
    # Başka kullanıcının sunucusunun domainlerini göremez.
    assert client.get(f"/api/servers/{site_with_slug}/domains", headers=other_headers).status_code == 404


def test_admin_dns_targets_appear_in_instructions(client, docker_stub):
    admin = _login(client, "v120_admin", "adminpass1")
    uid, headers = _user(client, "v120_dns_owner")
    sid = _server(uid, "static-web", site_slug="dns-site-v120", container_id="cid-dns")
    saved = client.put("/api/admin/settings", headers=admin,
                       json={"domain_ip": "203.0.113.7", "domain_cname_target": "cname.example-v120.net"})
    assert saved.status_code == 200, saved.text
    added = client.post(f"/api/servers/{sid}/domains", headers=headers, json={"domain": "kok-v120.com"})
    assert added.status_code == 201, added.text
    records = added.json()["records"]
    a_rec = next(r for r in records if r["type"] == "A")
    www = next(r for r in records if r["name"] == "www.kok-v120.com")
    assert a_rec["value"] == "203.0.113.7"
    assert www["value"] == "cname.example-v120.net"
