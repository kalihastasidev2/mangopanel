"""1.40.24: sunucu süresi seçenekleri, kalan gün ve süre dolmadan hatırlatma."""
import datetime as dt

import pytest
from fastapi.testclient import TestClient

from mango import expiry
from mango.config import settings
from mango.db import Notification, NotificationRecipient, SessionLocal, Server, User, init_db
from mango.duration import LABELS, days_left, resolve_days, set_expiry
from mango.main import app
from mango.security import hash_password


def test_presets_and_unlimited():
    assert resolve_days(None, None) is None
    assert resolve_days("unlimited", None) is None
    assert resolve_days("3d", None) == 3
    assert resolve_days("1w", None) == 7
    assert resolve_days("1m", None) == 30
    assert resolve_days("3m", None) == 90
    assert resolve_days("1y", None) == 365
    assert resolve_days("custom", 45) == 45


def test_invalid_durations_are_rejected():
    with pytest.raises(ValueError):
        resolve_days("custom", None)
    with pytest.raises(ValueError):
        resolve_days("custom", 0)
    with pytest.raises(ValueError):
        resolve_days("custom", 99999)
    with pytest.raises(ValueError):
        resolve_days("bilinmeyen", None)


def test_set_expiry_and_days_left():
    now = dt.datetime(2026, 1, 1, tzinfo=dt.timezone.utc)
    s = Server(name="x", egg="e", owner_id=1, port=1)
    set_expiry(s, 30, now)
    assert s.expires_at == now + dt.timedelta(days=30)
    assert days_left(s.expires_at, now) == 30
    assert days_left(s.expires_at, now + dt.timedelta(days=31)) == 0
    set_expiry(s, None)
    assert s.expires_at is None


def test_labels_cover_all_options():
    assert {"3d", "1w", "1m", "3m", "1y", "unlimited", "custom"} <= set(LABELS)


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-v1424"))
    init_db()
    db = SessionLocal()
    for name, admin in (("v1424_admin", True), ("v1424_user", False)):
        if db.query(User).filter_by(username=name).first() is None:
            db.add(User(username=name, email=f"{name}@example.com",
                        password_hash=hash_password("adminpass1"), is_admin=admin, max_servers=9))
    db.commit()
    db.close()
    return TestClient(app)


def _h(client, name):
    r = client.post("/api/auth/login", json={"username": name, "password": "adminpass1"})
    return {"Authorization": f"Bearer {r.json()['token']}"}


def test_create_server_rejects_bad_custom_duration(client):
    h = _h(client, "v1424_admin")
    r = client.post("/api/servers", headers=h, json={
        "name": "v1424-bad", "egg": "nodejs-app", "duration": "custom", "duration_days": 0})
    assert r.status_code == 422 or r.status_code == 400


def test_reminder_sent_once_per_expiry_date():
    db = SessionLocal()
    owner = db.query(User).filter_by(username="v1424_user").one()
    now = dt.datetime.now(dt.timezone.utc)
    srv = Server(name="v1424-hatirlat", egg="nodejs-app", owner_id=owner.id, port=26424,
                 expires_at=now + dt.timedelta(days=2))
    db.add(srv)
    db.commit()
    sid = srv.id
    db.close()

    db = SessionLocal()
    expiry.remind(db, now)
    expiry.remind(db, now)  # ikinci tarama aynı tarih için tekrar bildirmemeli
    db = SessionLocal()
    srv = db.get(Server, sid)
    notes = db.query(Notification).filter_by(title="Sunucu süresi yaklaşıyor").all()
    mine = [n for n in notes if db.query(NotificationRecipient).filter_by(
        notification_id=n.id, user_id=owner.id).first() and srv.name in n.body]
    assert len(mine) == 1
    assert srv.expiry_notified_for == srv.expires_at.date().isoformat()
    db.delete(srv)
    db.commit()
    db.close()
