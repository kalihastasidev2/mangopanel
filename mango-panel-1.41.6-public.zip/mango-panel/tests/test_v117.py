"""1.17.0: sunucuya özel başlatma komutu, sunucu notları, ilk kayıt rehberi."""
import shutil
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from mango import api as api_module
from mango.config import settings
from mango.db import ServerAccess, SessionLocal, Server, User, init_db
from mango.main import app
from mango.security import hash_password

REPO_EGGS = Path(__file__).resolve().parent.parent / "eggs"
_next_port = [33000]


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-v117"))
    eggs_copy = tmp_path_factory.mktemp("eggs-v117") / "eggs"
    shutil.copytree(REPO_EGGS, eggs_copy)
    settings.eggs_dir = str(eggs_copy)
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="v117_admin").first() is None:
        db.add(User(username="v117_admin", email="v117a@example.com",
                    password_hash=hash_password("adminpass1"), is_admin=True, max_servers=99))
        db.commit()
    db.close()
    return TestClient(app)


def _login(client, name, password="guclu-sifre-1"):
    r = client.post("/api/auth/login", json={"username": name, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["token"]}


def _member(client, name):
    db = SessionLocal()
    user = db.query(User).filter_by(username=name).first()
    if user is None:
        user = User(username=name, email=f"{name}@example.com",
                    password_hash=hash_password("guclu-sifre-1"), is_admin=False, max_servers=5)
        db.add(user)
        db.commit()
    uid = user.id
    db.close()
    return uid, _login(client, name)


def _server(owner_id, egg="nodejs-app", name="Test"):
    _next_port[0] += 1
    db = SessionLocal()
    server = Server(name=name, egg=egg, owner_id=owner_id, port=_next_port[0], memory_mb=256,
                    cpu_percent=100, variables={})
    db.add(server)
    db.commit()
    sid = server.id
    db.close()
    return sid


def test_startup_override_is_used_on_recreate_and_resets_to_egg_default(client, monkeypatch):
    calls = []
    monkeypatch.setattr(api_module.dm, "recreate",
                        lambda server, egg, startup, port: calls.append(startup) or "cid-start")
    monkeypatch.setattr(api_module.dm, "status", lambda server: "running")
    uid, headers = _member(client, "v117_start")
    sid = _server(uid)
    db = SessionLocal()
    db.query(Server).filter_by(id=sid).update({"variables": {"ENTRY": "server.js"}})
    db.commit()
    db.close()

    r = client.patch(f"/api/servers/{sid}", headers=headers, json={"startup": "node index.js --port 8080"})
    assert r.status_code == 200, r.text
    assert r.json()["startup_override"] == "node index.js --port 8080"
    assert calls[-1] == "node index.js --port 8080"

    # Aynı değer tekrar gönderilirse konteyner yeniden oluşturulmaz.
    count = len(calls)
    same = client.patch(f"/api/servers/{sid}", headers=headers, json={"startup": "node index.js --port 8080"})
    assert same.status_code == 200
    assert len(calls) == count

    # Tek satır kuralı.
    multi = client.patch(f"/api/servers/{sid}", headers=headers, json={"startup": "node index.js\nrm -rf /"})
    assert multi.status_code == 400

    # Boş değer egg varsayılanına döner.
    reset = client.patch(f"/api/servers/{sid}", headers=headers, json={"startup": "   "})
    assert reset.status_code == 200, reset.text
    assert reset.json()["startup_override"] == ""
    egg_default = api_module.render(api_module.load_eggs()["nodejs-app"]["startup"], {"ENTRY": "server.js"})
    assert calls[-1] == egg_default


def test_notes_are_visible_only_to_owner_and_admin(client, monkeypatch):
    monkeypatch.setattr(api_module.dm, "status", lambda server: "running")
    uid, headers = _member(client, "v117_notes")
    sid = _server(uid)

    added = client.post(f"/api/servers/{sid}/notes", headers=headers,
                        json={"text": "bu bot şu tarihte token değiştirildi"})
    assert added.status_code == 201, added.text
    note_id = added.json()["id"]
    listed = client.get(f"/api/servers/{sid}/notes", headers=headers).json()
    assert [n["text"] for n in listed] == ["bu bot şu tarihte token değiştirildi"]
    assert client.post(f"/api/servers/{sid}/notes", headers=headers, json={"text": "   "}).status_code == 400

    # Alt kullanıcı sunucuyu görür ama notları göremez ve yazamaz.
    worker_id, worker_headers = _member(client, "v117_worker")
    db = SessionLocal()
    db.add(ServerAccess(server_id=sid, user_id=worker_id, permissions="console,settings"))
    db.commit()
    db.close()
    assert client.get(f"/api/servers/{sid}/notes", headers=worker_headers).status_code == 403
    assert client.post(f"/api/servers/{sid}/notes", headers=worker_headers, json={"text": "x"}).status_code == 403

    # Yönetici görür.
    admin = _login(client, "v117_admin", "adminpass1")
    assert client.get(f"/api/servers/{sid}/notes", headers=admin).status_code == 200

    # Silme.
    assert client.delete(f"/api/servers/{sid}/notes/{note_id}", headers=headers).status_code == 204
    assert client.get(f"/api/servers/{sid}/notes", headers=headers).json() == []

    # Notlar sunucu yanıtında yer almaz; alt kullanıcıya gitmez.
    assert "notes" not in client.get(f"/api/servers/{sid}", headers=headers).json()


def test_new_accounts_start_without_onboarding_and_can_finish(client):
    r = client.post("/api/auth/register", json={
        "username": "v117_new", "email": "v117new@example.com", "password": "guclu-sifre-1",
    })
    assert r.status_code == 201, r.text
    assert r.json()["user"]["onboarded"] is False
    headers = {"Authorization": "Bearer " + r.json()["token"]}
    done = client.post("/api/me/onboarded", headers=headers)
    assert done.status_code == 200, done.text
    assert done.json()["onboarded"] is True
    assert client.get("/api/me", headers=headers).json()["onboarded"] is True


def test_admin_created_users_also_start_onboarding_and_existing_users_do_not(client):
    admin = _login(client, "v117_admin", "adminpass1")
    r = client.post("/api/users", headers=admin, json={
        "username": "v117_made", "email": "", "password": "guclu-sifre-1", "is_admin": False, "max_servers": 2,
    })
    assert r.status_code == 201, r.text
    assert r.json()["onboarded"] is False
    # Migration öncesi/diğer mevcut hesaplar rehberi zaten görmüş sayılır.
    assert client.get("/api/me", headers=admin).json()["onboarded"] is True
