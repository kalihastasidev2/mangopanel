"""1.11.0: dosya yükleme/indirme, toplu silme, /sites egg kısıtı, sunucu klonlama, egg mağazası."""
import shutil
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from mango import api as api_module
from mango import files_manager as fm
from mango.config import settings
from mango.db import SessionLocal, Server, User, init_db
from mango.main import app
from mango.security import hash_password
from mango.store import set_setting

REPO_EGGS = Path(__file__).resolve().parent.parent / "eggs"
_next_port = [31000]


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-v111"))
    eggs_copy = tmp_path_factory.mktemp("eggs-v111") / "eggs"
    shutil.copytree(REPO_EGGS, eggs_copy)
    settings.eggs_dir = str(eggs_copy)
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="v111_admin").first() is None:
        db.add(User(username="v111_admin", email="v111a@example.com",
                    password_hash=hash_password("adminpass1"), is_admin=True, max_servers=99))
        db.commit()
    db.close()
    return TestClient(app)


def _login(client, name, password="guclu-sifre-1"):
    r = client.post("/api/auth/login", json={"username": name, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["token"]}


def _member(client, name):
    db = SessionLocal()
    user = db.query(User).filter_by(username=name).first()
    if user is None:
        user = User(username=name, email=f"{name}@example.com",
                    password_hash=hash_password("guclu-sifre-1"), is_admin=False, max_servers=5)
        db.add(user)
        db.commit()
    uid = user.id
    db.close()
    return uid, _login(client, name)


def _server(owner_id, egg="nodejs-app", site_slug=None, name="Test"):
    _next_port[0] += 1
    db = SessionLocal()
    server = Server(name=name, egg=egg, owner_id=owner_id, port=_next_port[0], memory_mb=256,
                    cpu_percent=100, variables={}, site_slug=site_slug)
    db.add(server)
    db.commit()
    sid = server.id
    db.close()
    return sid


def _set(key, value):
    db = SessionLocal()
    set_setting(db, key, value)
    db.commit()
    db.close()


def test_upload_download_and_bulk_delete(client):
    uid, headers = _member(client, "v111_files")
    sid = _server(uid, egg="nodejs-app")

    up = client.put(f"/api/servers/{sid}/files/upload?path=src/index.js",
                    content=b"console.log('ok')", headers=headers)
    assert up.status_code == 201, up.text
    assert fm.resolve(sid, "src/index.js").read_bytes() == b"console.log('ok')"

    dl = client.get(f"/api/servers/{sid}/files/download?path=src/index.js", headers=headers)
    assert dl.status_code == 200
    assert dl.content == b"console.log('ok')"

    bad = client.put(f"/api/servers/{sid}/files/upload?path=../kacis.txt", content=b"x", headers=headers)
    assert bad.status_code == 400

    res = client.post(f"/api/servers/{sid}/files/delete-many", headers=headers,
                      json={"paths": ["src/index.js", "yok.txt", "src"]})
    assert res.status_code == 200, res.text
    by_path = {r["path"]: r for r in res.json()}
    assert by_path["src/index.js"]["ok"] is True
    assert by_path["yok.txt"]["ok"] is False
    assert by_path["src"]["ok"] is True
    assert not fm.resolve(sid, "src").exists()


def test_bulk_delete_refuses_root(client):
    uid, headers = _member(client, "v111_root")
    sid = _server(uid, egg="nodejs-app")
    res = client.post(f"/api/servers/{sid}/files/delete-many", headers=headers, json={"paths": [""]})
    assert res.status_code == 200
    assert res.json()[0]["ok"] is False


def test_node_egg_has_no_public_site(client):
    uid, _ = _member(client, "v111_site")
    sid = _server(uid, egg="nodejs-app", site_slug="v111nodesite")
    assert sid
    r = client.get("/api/sites/v111nodesite/")
    assert r.status_code == 404


def test_python_egg_has_no_public_site(client):
    uid, _ = _member(client, "v111_pysite")
    _server(uid, egg="python-app", site_slug="v111pysite")
    r = client.get("/api/sites/v111pysite/")
    assert r.status_code == 404


def test_clone_is_blocked_for_members_without_self_service(client, monkeypatch):
    uid, headers = _member(client, "v111_noclone")
    sid = _server(uid, egg="nodejs-app")
    _set("self_service_servers", "0")
    r = client.post(f"/api/servers/{sid}/clone", headers=headers, json={"name": "Kopya"})
    assert r.status_code == 403


def test_clone_copies_files_and_settings(client, monkeypatch):
    created_containers = []

    def fake_create(server, egg, startup, container_port):
        created_containers.append(server.id)
        return "cid-" + str(server.id)

    monkeypatch.setattr(api_module.dm, "create", fake_create)
    monkeypatch.setattr(api_module.dm, "status", lambda server: "stopped")
    uid, _ = _member(client, "v111_clone")
    headers = _login(client, "v111_admin", "adminpass1")  # 1.27.0: klonlama yalnızca yönetici
    sid = _server(uid, egg="nodejs-app", name="Kaynak")
    fm.save_bytes(sid, "index.js", b"hello clone")
    fm.save_bytes(sid, "lib/util.js", b"module.exports = 1")

    _set("self_service_servers", "1")
    r = client.post(f"/api/servers/{sid}/clone", headers=headers, json={"name": "Kopya Sunucu"})
    assert r.status_code == 201, r.text
    body = r.json()
    new_id = body["id"]
    assert new_id != sid
    assert created_containers == [new_id]
    assert fm.resolve(new_id, "index.js").read_bytes() == b"hello clone"
    assert fm.resolve(new_id, "lib/util.js").read_bytes() == b"module.exports = 1"
    assert body["name"] == "Kopya Sunucu"
    assert body["egg"] == "nodejs-app"


def test_clone_rolls_back_when_container_fails(client, monkeypatch):
    def boom(server, egg, startup, container_port):
        raise RuntimeError("docker yok")

    removed = []
    monkeypatch.setattr(api_module.dm, "create", boom)
    monkeypatch.setattr(api_module.dm, "delete_by_id", lambda sid, cid=None: removed.append(sid))
    uid, _ = _member(client, "v111_cloneroll")
    headers = _login(client, "v111_admin", "adminpass1")
    sid = _server(uid, egg="nodejs-app")
    _set("self_service_servers", "1")
    r = client.post(f"/api/servers/{sid}/clone", headers=headers, json={"name": "Geri Alinan"})
    assert r.status_code == 500
    db = SessionLocal()
    assert db.query(Server).filter_by(name="Geri Alinan").count() == 0
    db.close()
    assert len(removed) == 1


def test_egg_store_install_and_uninstall(client):
    admin = _login(client, "v111_admin", "adminpass1")
    listing = client.get("/api/admin/egg-store", headers=admin)
    assert listing.status_code == 200, listing.text
    slugs = {row["slug"]: row for row in listing.json()}
    assert "nodejs-express" in slugs and "python-flask" in slugs
    assert slugs["nodejs-express"]["installed"] is False

    inst = client.post("/api/admin/egg-store/nodejs-express/install", headers=admin)
    assert inst.status_code == 201, inst.text
    again = client.post("/api/admin/egg-store/nodejs-express/install", headers=admin)
    assert again.status_code == 409

    from mango.eggs import load_eggs
    assert "nodejs-express" in load_eggs()

    rm = client.delete("/api/admin/eggs/nodejs-express", headers=admin)
    assert rm.status_code == 204
    assert "nodejs-express" not in load_eggs()


def test_egg_store_is_admin_only(client):
    _, headers = _member(client, "v111_store_user")
    assert client.get("/api/admin/egg-store", headers=headers).status_code == 403
    assert client.post("/api/admin/egg-store/python-flask/install", headers=headers).status_code == 403


def test_admin_users_include_usage(client, monkeypatch):
    monkeypatch.setattr(api_module.dm, "stats", lambda server: {"memory_mb": 100.0, "cpu_percent": 25.0})
    uid, _ = _member(client, "v112_usage")
    _server(uid, egg="nodejs-app", name="Kullanım")
    admin = _login(client, "v111_admin", "adminpass1")
    rows = client.get("/api/users", headers=admin)
    assert rows.status_code == 200, rows.text
    row = next(r for r in rows.json() if r["username"] == "v112_usage")
    usage = row["usage"]
    assert usage["servers"] >= 1
    assert usage["server_slots"] == 5
    assert usage["live_memory_mb"] >= 100.0
    assert usage["memory_cap_mb"] == 5 * 4096
    assert usage["disk_cap_mb"] == 5 * 5120
    assert "disk_mb" in usage and "allocated_cpu_percent" in usage


def test_admin_power_endpoint_still_requires_permission(client):
    uid, headers = _member(client, "v112_power")
    sid = _server(uid, egg="nodejs-app")
    other_uid, other_headers = _member(client, "v112_stranger")
    assert sid and other_headers
    r = client.post(f"/api/servers/{sid}/power", headers=other_headers, json={"action": "stop"})
    assert r.status_code == 404


def test_zip_extracts_inside_folder_and_blocks_traversal(client):
    import io
    import zipfile

    uid, headers = _member(client, "v113_zip")
    sid = _server(uid, egg="nodejs-app")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("app/index.js", "console.log(1)")
        zf.writestr("readme.txt", "merhaba")
    up = client.put(f"/api/servers/{sid}/files/upload?path=paket/app.zip", content=buf.getvalue(), headers=headers)
    assert up.status_code == 201, up.text
    ext = client.post(f"/api/servers/{sid}/files/extract?path=paket/app.zip", headers=headers)
    assert ext.status_code == 200, ext.text
    assert ext.json()["extracted"] == 2
    assert fm.resolve(sid, "paket/app/index.js").read_text() == "console.log(1)"

    evil = io.BytesIO()
    with zipfile.ZipFile(evil, "w") as zf:
        zf.writestr("../../kacak.txt", "x")
    client.put(f"/api/servers/{sid}/files/upload?path=kotu.zip", content=evil.getvalue(), headers=headers)
    bad = client.post(f"/api/servers/{sid}/files/extract?path=kotu.zip", headers=headers)
    assert bad.status_code == 400
    assert not fm._root(sid).parent.parent.joinpath("kacak.txt").exists()

    not_zip = client.put(f"/api/servers/{sid}/files/upload?path=metin.txt", content=b"x", headers=headers)
    assert not_zip.status_code == 201
    assert client.post(f"/api/servers/{sid}/files/extract?path=metin.txt", headers=headers).status_code == 400


def test_node_app_gets_public_rest_address(client, monkeypatch):
    monkeypatch.setattr(api_module.dm, "status", lambda server: "running")
    calls = []

    def fake_forward(port, method, path, query, headers, body):
        calls.append((port, method, path, query, headers, body))
        return 200, [("Content-Type", "application/json")], b'{"ok": true}'

    monkeypatch.setattr(api_module, "_forward", fake_forward)
    uid, _ = _member(client, "v114_api")
    _server(uid, egg="nodejs-app", site_slug="v114-api")
    r = client.post("/api/apps/v114-api/kullanicilar?sayfa=2", content=b'{"ad":"Ali"}',
                    headers={"Content-Type": "application/json", "Authorization": "Bearer gizli"})
    assert r.status_code == 200, r.text
    assert r.json() == {"ok": True}
    port, method, path, query, headers, body = calls[-1]
    assert method == "POST" and path == "kullanicilar" and query == "sayfa=2"
    assert body == b'{"ad":"Ali"}'
    assert headers.get("authorization") == "Bearer gizli"  # uygulama kendi kimlik kontrolünü yapar


def test_static_site_is_not_an_app_and_web_routes_stay_separate(client, monkeypatch):
    monkeypatch.setattr(api_module.dm, "status", lambda server: "running")
    uid, _ = _member(client, "v114_static")
    _server(uid, egg="static-web", site_slug="v114-statik")
    assert client.get("/api/apps/v114-statik/").status_code == 404


def test_app_route_refuses_suspended_and_stopped(client, monkeypatch):
    uid, _ = _member(client, "v114_stop")
    monkeypatch.setattr(api_module.dm, "status", lambda server: "exited")
    _server(uid, egg="python-app", site_slug="v114-durdu")
    assert client.get("/api/apps/v114-durdu/").status_code == 503


def test_tester_sends_request_to_own_app(client, monkeypatch):
    monkeypatch.setattr(api_module.dm, "status", lambda server: "running")
    seen = {}

    def fake_forward(port, method, path, query, headers, body):
        seen.update(method=method, path=path, query=query, body=body, headers=headers)
        return 201, [("Content-Type", "text/plain")], b"olustu"

    monkeypatch.setattr(api_module, "_forward", fake_forward)
    uid, headers = _member(client, "v114_tester")
    sid = _server(uid, egg="python-app")
    r = client.post(f"/api/servers/{sid}/http", headers=headers,
                    json={"method": "POST", "path": "/kayit?x=1", "body": '{"a": 1}'})
    assert r.status_code == 200, r.text
    assert r.json() == {"status": 201, "content_type": "text/plain", "body": "olustu", "truncated": False}
    assert seen["method"] == "POST" and seen["path"] == "kayit" and seen["query"] == "x=1"
    assert seen["headers"]["Content-Type"] == "application/json"


def test_tester_rejects_full_urls(client, monkeypatch):
    monkeypatch.setattr(api_module.dm, "status", lambda server: "running")
    uid, headers = _member(client, "v114_fullurl")
    sid = _server(uid, egg="nodejs-app")
    r = client.post(f"/api/servers/{sid}/http", headers=headers, json={"method": "GET", "path": "http://evil.example/"})
    assert r.status_code == 400
    r2 = client.post(f"/api/servers/{sid}/http", headers=headers, json={"method": "GET", "path": "//evil.example/"})
    assert r2.status_code == 400


def test_console_routes_dollar_lines_to_shell_and_others_to_stdin():
    assert api_module._console_route("$ pip install requests") == ("exec", "pip install requests")
    assert api_module._console_route("  $ls -la ") == ("exec", "ls -la")
    assert api_module._console_route("Ali") == ("stdin", "Ali")
    assert api_module._console_route("$") == ("exec", "")


def test_api_rate_limit_returns_429_after_limit(client, monkeypatch):
    monkeypatch.setattr(api_module.dm, "status", lambda server: "running")
    monkeypatch.setattr(api_module, "_forward", lambda *a: (200, [("Content-Type", "text/plain")], b"ok"))
    uid, _ = _member(client, "v115_rate")
    _server(uid, egg="nodejs-app", site_slug="v115-rate")
    _set("app_rate_per_min", "2")
    try:
        codes = [client.get("/api/apps/v115-rate/").status_code for _ in range(3)]
    finally:
        _set("app_rate_per_min", "120")
    assert codes == [200, 200, 429]


def test_env_variables_are_validated_and_stored(client, monkeypatch):
    monkeypatch.setattr(api_module.dm, "recreate", lambda server, egg, startup, port: "cid-env")
    monkeypatch.setattr(api_module.dm, "status", lambda server: "running")
    uid, headers = _member(client, "v115_env")
    sid = _server(uid, egg="nodejs-app")
    db = SessionLocal()
    db.query(Server).filter_by(id=sid).update({"variables": {"ENTRY": "server.js", "NODE_ENV": "production"}})
    db.commit()
    db.close()
    bad_key = client.patch(f"/api/servers/{sid}", headers=headers, json={"env": {"bad-key": "1"}})
    assert bad_key.status_code == 400
    reserved = client.patch(f"/api/servers/{sid}", headers=headers, json={"env": {"PATH": "/x"}})
    assert reserved.status_code == 400
    clash = client.patch(f"/api/servers/{sid}", headers=headers, json={"env": {"ENTRY": "x.js"}})
    assert clash.status_code == 400
    multi = client.patch(f"/api/servers/{sid}", headers=headers, json={"env": {"DISCORD_TOKEN": "abc", "DEBUG_MODE": "1"}})
    assert multi.status_code == 200, multi.text
    assert multi.json()["env"] == {"DISCORD_TOKEN": "abc", "DEBUG_MODE": "1"}
    again = client.get(f"/api/servers/{sid}", headers=headers)
    assert again.json()["env"]["DISCORD_TOKEN"] == "abc"


def test_store_eggs_are_valid_catalog_entries():
    import yaml
    store = REPO_EGGS / "store"
    names = sorted(p.stem for p in store.glob("*.yaml"))
    assert len(names) >= 8
    for path in store.glob("*.yaml"):
        data = yaml.safe_load(path.read_text(encoding="utf-8"))
        for key in ("name", "category", "docker_image", "startup"):
            assert data.get(key), f"{path.name}: {key} eksik"
        assert all(isinstance(p, int) for p in data.get("ports", [])), path.name
        for v in data.get("variables", []):
            assert v["name"].isupper() or "_" in v["name"] or v["name"].isalnum(), path.name
