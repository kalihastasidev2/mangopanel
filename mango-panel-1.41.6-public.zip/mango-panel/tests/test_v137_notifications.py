"""1.37.0: bildirimler: hedef çözümleme, okundu bilgisi, yalnızca yönetici gönderebilir."""
import pytest
from fastapi.testclient import TestClient

from mango.db import Notification, NotificationRecipient, SessionLocal, User, init_db
from mango.main import app
from mango.notifications import NotifyIn, resolve_recipients
from mango.security import hash_password


@pytest.fixture(scope="module")
def client():
    init_db()
    db = SessionLocal()
    for name, admin in [("v137n_admin", True), ("v137n_user", False), ("v137n_other", False)]:
        if db.query(User).filter_by(username=name).first() is None:
            db.add(User(username=name, email=f"{name}@example.com", password_hash=hash_password("guclu-sifre-1"),
                        is_admin=admin, max_servers=5))
    db.commit()
    db.close()
    return TestClient(app)


def _login(client, name):
    res = client.post("/api/auth/login", json={"username": name, "password": "guclu-sifre-1" if "admin" not in name else "guclu-sifre-1"})
    assert res.status_code == 200, res.text
    return {"Authorization": "Bearer " + res.json()["token"]}


def test_resolve_all_and_users(client):
    db = SessionLocal()
    try:
        everyone = resolve_recipients(db, NotifyIn(title="Merhaba", body="x", target="all"))
        assert len(everyone) >= 2
        picked = resolve_recipients(db, NotifyIn(title="Merhaba", body="x", target="users",
                                                 usernames=["v137n_user"]))
        assert len(picked) == 1
    finally:
        db.close()


def test_plan_target_requires_a_plan(client):
    db = SessionLocal()
    try:
        with pytest.raises(Exception):
            resolve_recipients(db, NotifyIn(title="Merhaba", body="x", target="plan", plan_id=None))
    finally:
        db.close()


def test_only_admin_can_send(client):
    user = _login(client, "v137n_user")
    res = client.post("/api/admin/notifications", headers=user,
                      json={"title": "Duyuru", "body": "Merhaba", "target": "all"})
    assert res.status_code == 403


def test_send_read_and_mark_all(client):
    admin = _login(client, "v137n_admin")
    res = client.post("/api/admin/notifications", headers=admin,
                      json={"title": "Bakım bilgisi", "body": "Yarın gece bakım var.", "target": "users",
                            "usernames": ["v137n_user"]})
    assert res.status_code == 201, res.text
    assert res.json()["recipients"] == 1

    user = _login(client, "v137n_user")
    inbox = client.get("/api/notifications", headers=user).json()
    assert inbox["unread"] >= 1
    rid = inbox["items"][0]["id"]
    assert client.post(f"/api/notifications/{rid}/read", headers=user).status_code == 200
    assert client.post("/api/notifications/read-all", headers=user).status_code == 200
    assert client.get("/api/notifications", headers=user).json()["unread"] == 0

    other = _login(client, "v137n_other")
    assert client.post(f"/api/notifications/{rid}/read", headers=other).status_code == 404


def test_discord_failure_codes():
    import urllib.error
    from mango.discord_login import _failure_code
    http = urllib.error.HTTPError("u", 401, "unauthorized", None, None)
    assert _failure_code(http) == "yetki"
    assert _failure_code(urllib.error.URLError("dns")) == "ag"
    assert _failure_code(RuntimeError("x")) == "hata"
