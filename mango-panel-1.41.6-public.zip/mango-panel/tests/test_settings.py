import pytest
from fastapi.testclient import TestClient

from mango import files_manager as fm
from mango.config import settings
from mango.db import SessionLocal, Server, User, init_db
from mango.main import app
from mango.security import hash_password

RESET = dict(
    max_memory_mb=4096, max_cpu_percent=400, max_disk_mb=5120,
    maintenance_mode=False, announcement="", announcement_enabled=False, disabled_eggs=[],
    self_service_servers=False,
)


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-settings"))
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="set_admin").first() is None:
        db.add(User(username="set_admin", email="set@example.com",
                    password_hash=hash_password("adminpass1"), is_admin=True, max_servers=99))
        db.commit()
    db.close()
    return TestClient(app)


def _admin(client):
    r = client.post("/api/auth/login", json={"username": "set_admin", "password": "adminpass1"})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["token"]}


def _put(client, headers, **changes):
    r = client.put("/api/admin/settings", headers=headers, json=changes)
    assert r.status_code == 200, r.text
    return r.json()


def _reset(client, headers):
    _put(client, headers, **RESET)


def _member(client, name):
    """Üye yoksa oluşturur; (kullanıcı id, giriş başlıkları) döndürür."""
    db = SessionLocal()
    user = db.query(User).filter_by(username=name).first()
    if user is None:
        user = User(username=name, email=f"{name}@example.com",
                    password_hash=hash_password("guclu-sifre-1"), is_admin=False, max_servers=5)
        db.add(user)
        db.commit()
    uid = user.id
    db.close()
    r = client.post("/api/auth/login", json={"username": name, "password": "guclu-sifre-1"})
    assert r.status_code == 200, r.text
    return uid, {"Authorization": "Bearer " + r.json()["token"]}


def _create(client, headers, **overrides):
    body = {"name": "Ayar Testi", "egg": "static-web", "memory_mb": 256, "cpu_percent": 100, "variables": {}}
    body.update(overrides)
    return client.post("/api/servers", headers=headers, json=body)


def test_resource_caps_apply_to_members(client):
    admin = _admin(client)
    _reset(client, admin)
    _put(client, admin, self_service_servers=True)
    _put(client, admin, max_memory_mb=1024, max_cpu_percent=100)
    try:
        _, member = _member(client, "cap_user")
        # 1.27.0: kullanıcılar ücretsiz sunucu oluşturamaz; kota kontrolü yöneticinin verdiği sunucularda geçerli.
        r = _create(client, member, memory_mb=2048)
        assert r.status_code == 403 and "yönetici" in r.json()["detail"].lower()
        r = _create(client, member, cpu_percent=200)
        assert r.status_code == 403 and "yönetici" in r.json()["detail"].lower()
    finally:
        _reset(client, admin)


def test_disabled_egg_blocks_members_but_not_admins(client):
    admin = _admin(client)
    _reset(client, admin)
    with pytest.raises(AssertionError):
        _put(client, admin, disabled_eggs=["Bozuk Egg"])  # geçersiz slug reddedilmeli
    _put(client, admin, disabled_eggs=["static-web"])
    try:
        _, member = _member(client, "egg_user")
        eggs = client.get("/api/eggs", headers=member).json()
        static = next(e for e in eggs if e["slug"] == "static-web")
        assert static["allowed"] is False and static["disabled"] is True
        assert _create(client, member).status_code == 403
        admin_view = next(e for e in client.get("/api/eggs", headers=admin).json() if e["slug"] == "static-web")
        assert admin_view["allowed"] is True and admin_view["disabled"] is True
    finally:
        _reset(client, admin)


def test_maintenance_mode_blocks_members_only(client):
    admin = _admin(client)
    _reset(client, admin)
    _, member = _member(client, "maint_user")
    _put(client, admin, maintenance_mode=True)
    try:
        assert client.post("/api/auth/login", json={"username": "maint_user", "password": "guclu-sifre-1"}).status_code == 503
        assert client.get("/api/me", headers=member).status_code == 503
        assert client.get("/api/me", headers=admin).status_code == 200
        assert client.get("/api/system").json()["maintenance"] is True
        r = client.post("/api/auth/register", json={
            "username": "bakim_yeni", "email": "bakim@example.com", "password": "guclu-sifre-1",
        })
        assert r.status_code == 503
    finally:
        _reset(client, admin)


def test_announcement_shown_only_when_enabled(client):
    admin = _admin(client)
    _reset(client, admin)
    _put(client, admin, announcement="Bakım yarın 22:00", announcement_enabled=False)
    assert client.get("/api/system").json()["announcement"] == ""
    _put(client, admin, announcement_enabled=True)
    assert client.get("/api/system").json()["announcement"] == "Bakım yarın 22:00"
    _reset(client, admin)


def test_suspended_server_hidden_from_owner_but_kept(client):
    admin = _admin(client)
    _reset(client, admin)
    uid, member = _member(client, "susp_user")
    db = SessionLocal()
    server = Server(name="Askida", egg="static-web", owner_id=uid, port=27101,
                    memory_mb=256, cpu_percent=100, variables={})
    db.add(server)
    db.commit()
    sid = server.id
    db.close()
    try:
        assert client.get(f"/api/servers/{sid}", headers=member).status_code == 200
        r = client.post(f"/api/admin/servers/{sid}/suspend", headers=admin, json={"suspended": True})
        assert r.status_code == 200 and r.json()["suspended"] is True
        assert client.get(f"/api/servers/{sid}", headers=member).status_code == 403
        assert client.get(f"/api/servers/{sid}", headers=admin).status_code == 200  # yönetici görmeye devam eder
        client.post(f"/api/admin/servers/{sid}/suspend", headers=admin, json={"suspended": False})
        assert client.get(f"/api/servers/{sid}", headers=member).status_code == 200
    finally:
        db = SessionLocal()
        db.query(Server).filter_by(id=sid).delete()
        db.commit()
        db.close()


def test_disk_quota_blocks_overflow_but_allows_overwrite(tmp_path):
    settings.data_dir = str(tmp_path)
    fm.write_text(42, "a.txt", "x" * 600, quota_bytes=1000)
    with pytest.raises(fm.FileError):
        fm.write_text(42, "b.txt", "y" * 600, quota_bytes=1000)
    # Üzerine yazılan dosyanın eski boyutu kotaya sayılmaz.
    fm.write_text(42, "a.txt", "z" * 900, quota_bytes=1000)
    assert len((fm.server_dir(42) / "a.txt").read_text()) == 900


def test_members_cannot_create_unless_self_service_enabled(client):
    admin = _admin(client)
    _reset(client, admin)
    uid, member = _member(client, "no_self")
    r = _create(client, member)
    assert r.status_code == 403 and "yönetici" in r.json()["detail"]
    _put(client, admin, self_service_servers=True)
    try:
        r = _create(client, member, memory_mb=99999)  # kapı açıldı; doğrulama reddeder
        assert r.status_code == 422
    finally:
        _reset(client, admin)


def test_admin_cannot_grant_to_unknown_user_and_members_cannot_grant(client):
    admin = _admin(client)
    _reset(client, admin)
    _, member = _member(client, "grant_user")
    r = _create(client, admin, owner_id=999999)
    assert r.status_code == 404
    other_uid, _ = _member(client, "grant_other")
    r = _create(client, member, owner_id=other_uid)
    assert r.status_code == 403  # kapı kapalı: önce genel yetki kontrolü
    r = _create(client, member, owner_id=other_uid)
    assert r.status_code == 403  # 1.27.0: ücretsiz self-service kaldırıldı, başkası adına da oluşturamaz
