"""1.35.1: geçici Docker hataları (büyük/küçük harf duyarsız) yeniden denenir ve 503 olur."""
from mango import docker_manager as dm


def test_lowercase_docker_resource_error_is_transient():
    msg = ('500 Server Error for http+docker://localhost/v1.45/containers/abc/start: Internal Server Error '
           '("failed to create task for container: failed to start shim: fork/exec /usr/bin/containerd-shim-runc-v2: '
           'resource temporarily unavailable: unknown")')
    assert dm.is_transient(RuntimeError(msg))


def test_ordinary_errors_are_not_transient():
    assert not dm.is_transient(RuntimeError("No such container: abc"))


def test_with_retry_recovers_from_transient_errors(monkeypatch):
    monkeypatch.setattr(dm.time, "sleep", lambda s: None)
    calls = {"n": 0}

    def action():
        calls["n"] += 1
        if calls["n"] < 3:
            raise RuntimeError("resource temporarily unavailable")
        return "ok"

    assert dm.with_retry(action) == "ok"
    assert calls["n"] == 3


def test_with_retry_gives_up_on_permanent_errors(monkeypatch):
    monkeypatch.setattr(dm.time, "sleep", lambda s: None)
    try:
        dm.with_retry(lambda: (_ for _ in ()).throw(RuntimeError("image not found")))
    except RuntimeError as exc:
        assert "image not found" in str(exc)
    else:
        raise AssertionError("kalıcı hata yeniden denenmemeli")
