"""1.40.22: Discord DM bildirimleri ve çökme tespiti."""
from types import SimpleNamespace

import pytest

from mango import crash_watch
from mango import discord_notify as dn
from mango.config import settings
from mango.db import SessionLocal, Server, User, init_db
from mango.security import hash_password
from mango.store import set_setting


@pytest.fixture(scope="module", autouse=True)
def _db(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-v1422"))
    init_db()
    db = SessionLocal()
    user = User(username="v1422_owner", email="v1422@example.com",
                password_hash=hash_password("adminpass1"), is_admin=False, max_servers=5,
                discord_id="555000111222333444")
    db.add(user)
    db.commit()
    db.add(Server(name="v1422-srv", egg="nodejs-app", owner_id=user.id, port=26001))
    db.commit()
    db.close()


def test_no_discord_link_means_no_send():
    db = SessionLocal()
    user = User(username="v1422_nolink", email="nolink@example.com",
                password_hash="x", is_admin=False, max_servers=1, discord_id=None)
    assert dn.notify_discord(db, user, "merhaba") is False
    db.close()


def test_no_bot_token_means_no_send():
    db = SessionLocal()
    set_setting(db, "discord_bot_token", "")
    db.commit()
    user = db.query(User).filter_by(username="v1422_owner").first()
    assert dn.notify_discord(db, user, "merhaba") is False
    db.close()


def test_crash_is_reported_to_owner_and_clean_stop_is_not(monkeypatch):
    sent = []
    monkeypatch.setattr(crash_watch, "notify_discord", lambda db, user, text: sent.append((user.username, text)))
    mine = lambda: [m for m in sent if m[0] == "v1422_owner"]  # noqa: E731 - aynı DB'deki diğer sunucular hariç
    monkeypatch.setattr(crash_watch, "_exit_code", lambda server: 1)

    down = {"v": False}

    def status(server):  # yalnızca bu testin sunucusu; diğerleri hep çalışıyor sayılır
        if server.name != "v1422-srv":
            return "running"
        return "exited" if down["v"] else "running"

    monkeypatch.setattr(crash_watch.dm, "status", status)
    crash_watch.scan()          # çalışırken görüldü
    down["v"] = True
    assert mine() == []
    crash_watch.scan()          # sonra kapandı, çıkış kodu 1 → çökme
    assert mine() and "beklenmedik" in mine()[0][1]

    sent.clear()
    monkeypatch.setattr(crash_watch, "_exit_code", lambda server: 0)
    down["v"] = False
    crash_watch.scan()
    down["v"] = True
    crash_watch.scan()          # temiz çıkış (kullanıcı durdurdu) → bildirim yok
    assert mine() == []
