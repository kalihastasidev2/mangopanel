"""1.23.0: eksik paket tarayıcısı, kullanım raporu ve güvenli paket adları."""
import shutil
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from mango import account_api
from mango import docker_manager as dm_module
from mango.config import settings
from mango.db import SessionLocal, Server, User, init_db
from mango.main import app
from mango.security import hash_password

REPO_EGGS = Path(__file__).resolve().parent.parent / "eggs"
_next_port = [40000]


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-v123"))
    eggs_copy = tmp_path_factory.mktemp("eggs-v123") / "eggs"
    shutil.copytree(REPO_EGGS, eggs_copy)
    settings.eggs_dir = str(eggs_copy)
    init_db()
    return TestClient(app)


def _login(client, name, password="guclu-sifre-1"):
    r = client.post("/api/auth/login", json={"username": name, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["token"]}


def _owner(client, name):
    db = SessionLocal()
    user = db.query(User).filter_by(username=name).first()
    if user is None:
        user = User(username=name, email=f"{name}@example.com", password_hash=hash_password("guclu-sifre-1"),
                    is_admin=False, max_servers=5)
        db.add(user)
        db.commit()
    uid = user.id
    db.close()
    return uid, _login(client, name)


def _server(owner_id, egg="nodejs-app"):
    _next_port[0] += 1
    db = SessionLocal()
    server = Server(name=f"P{_next_port[0]}", egg=egg, owner_id=owner_id, port=_next_port[0], memory_mb=256,
                    cpu_percent=100, variables={}, container_id=None)
    db.add(server)
    db.commit()
    sid = server.id
    db.close()
    return sid


def test_scanner_finds_missing_npm_packages_only(tmp_path):
    (tmp_path / "index.js").write_text(
        'const express = require("express");\n'
        'const fs = require("fs");\n'
        'const local = require("./lib/util");\n'
        'import { Client } from "discord.js";\n'
        'const scoped = require("@scope/pkg/sub");\n'
        'const lazy = await import("axios");\n',
        encoding="utf-8")
    (tmp_path / "package.json").write_text('{"dependencies": {"express": "^4.0.0"}}', encoding="utf-8")
    result = account_api.scan(tmp_path)
    assert result["npm"] == ["@scope/pkg", "axios", "discord.js"]
    assert result["pip"] == []


def test_scanner_finds_missing_pip_packages_with_aliases(tmp_path):
    (tmp_path / "app.py").write_text(
        "import os\nimport requests\nfrom flask import Flask\nimport PIL.Image\nimport yaml, json\n",
        encoding="utf-8")
    (tmp_path / "requirements.txt").write_text("Flask==3.0.0\n", encoding="utf-8")
    result = account_api.scan(tmp_path)
    assert result["pip"] == ["pillow", "pyyaml", "requests"]


def test_shell_metacharacters_never_reach_the_install_command(tmp_path):
    (tmp_path / "evil.js").write_text('require("ok-pkg; rm -rf /");\nrequire("good-pkg");\n', encoding="utf-8")
    result = account_api.scan(tmp_path)
    assert result["npm"] == ["good-pkg"]


def test_missing_packages_endpoint_respects_access(client, monkeypatch):
    uid, headers = _owner(client, "v123_scan_owner")
    sid = _server(uid)
    root = dm_module.server_dir(sid)
    (root / "bot.js").write_text('require("discord.js");', encoding="utf-8")
    res = client.get(f"/api/servers/{sid}/missing-packages", headers=headers)
    assert res.status_code == 200, res.text
    assert "discord.js" in res.json()["npm"]

    _, other = _owner(client, "v123_scan_other")
    assert client.get(f"/api/servers/{sid}/missing-packages", headers=other).status_code == 404


def test_usage_report_counts_servers_and_purchases(client, monkeypatch):
    monkeypatch.setattr(dm_module, "status_map", lambda: {})
    uid, headers = _owner(client, "v123_usage_owner")
    _server(uid)
    _server(uid)
    usage = client.get("/api/me/usage", headers=headers)
    assert usage.status_code == 200, usage.text
    body = usage.json()
    assert body["servers"] == 2
    assert body["memory_mb"] == 512
    assert body["purchases"] == []
    assert body["discord_linked"] is False
