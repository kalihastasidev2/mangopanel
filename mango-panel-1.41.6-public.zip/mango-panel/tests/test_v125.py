"""1.25.0: Mango maskotu dosyaları sayfaya bağlı ve sunucu tarafından sunuluyor."""
from pathlib import Path

from fastapi.testclient import TestClient

from mango.main import app

WEB = Path(__file__).resolve().parent.parent / "web"


def test_mascot_script_and_styles_exist_and_are_wired_into_page():
    assert (WEB / "mango-pet.js").is_file()
    index = (WEB / "index.html").read_text(encoding="utf-8")
    assert "/static/mango-pet.js" in index
    assert index.index("app.js") < index.index("mango-pet.js")  # maskot, api() yüklendikten sonra gelir
    css = (WEB / "style.css").read_text(encoding="utf-8")
    assert ".mp-bubble.mp-show" in css and "prefers-reduced-motion" in css


def test_mascot_script_is_served():
    client = TestClient(app)
    res = client.get("/static/mango-pet.js")
    assert res.status_code == 200
    assert "statuses" not in res.text  # eski taslak kalıntısı yok
    assert "restarting" in res.text and "dead" in res.text
