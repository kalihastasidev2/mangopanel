"""1.32.0: sunucu yedekleri (oluştur, geri yükle, sil, en fazla 5) ve kötüye kullanım uyarı kapısı."""
import pytest
from fastapi import HTTPException

from mango import abuse, backups
from mango.config import settings
from mango.db import SessionLocal
from mango.store import all_settings, set_setting


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "data_dir", str(tmp_path))
    server_dir = tmp_path / "77"
    server_dir.mkdir()
    (server_dir / "hello.txt").write_text("ilk")
    (server_dir / "klasor").mkdir()
    (server_dir / "klasor" / "a.txt").write_text("alt")
    return server_dir


def test_backup_create_list_restore_and_delete(data_dir):
    name = backups.create_backup(77)
    assert [b["name"] for b in backups.list_backups(77)] == [name]

    (data_dir / "hello.txt").write_text("degisti")
    (data_dir / "yeni.txt").write_text("sonradan")
    backups.restore_backup(77, name)
    assert (data_dir / "hello.txt").read_text() == "ilk"
    assert (data_dir / "klasor" / "a.txt").read_text() == "alt"
    assert not (data_dir / "yeni.txt").exists()

    backups.delete_backup(77, name)
    assert backups.list_backups(77) == []


def test_only_the_last_five_backups_are_kept(data_dir):
    for _ in range(7):
        backups.create_backup(77)
    assert len(backups.list_backups(77)) == backups.MAX_BACKUPS


def test_bad_backup_names_are_refused(data_dir):
    for bad in ["../../etc/passwd", "x.tar.gz", "20260101-000000-000000.zip"]:
        with pytest.raises(HTTPException) as err:
            backups.restore_backup(77, bad)
        assert err.value.status_code == 400


def test_missing_backup_is_404(data_dir):
    with pytest.raises(HTTPException) as err:
        backups.restore_backup(77, "20260101-000000-000000.tar.gz")
    assert err.value.status_code == 404


def test_abuse_check_does_nothing_without_webhook():
    db = SessionLocal()
    set_setting(db, "alert_webhook_url", "")
    db.commit()
    db.close()
    sent = []
    assert abuse.check_once(lambda s: {"running": True, "cpu_percent": 100}, post=lambda u, p: sent.append(p)) == []
    assert sent == []


def test_webhook_setting_is_exposed_to_admin_settings():
    db = SessionLocal()
    try:
        assert "alert_webhook_url" in all_settings(db)
    finally:
        db.close()
