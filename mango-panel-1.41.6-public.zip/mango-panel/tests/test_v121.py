"""1.21.0: Cloudflare for SaaS ile özel domain bağlama (Cloudflare çağrıları taklit edilir)."""
import shutil
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from mango import api as api_module
from mango import cloudflare as cloudflare_module
from mango.config import settings
from mango.db import SessionLocal, Server, User, init_db
from mango.main import app
from mango.security import hash_password

REPO_EGGS = Path(__file__).resolve().parent.parent / "eggs"
_next_port = [36000]


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-v121"))
    eggs_copy = tmp_path_factory.mktemp("eggs-v121") / "eggs"
    shutil.copytree(REPO_EGGS, eggs_copy)
    settings.eggs_dir = str(eggs_copy)
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="v121_admin").first() is None:
        db.add(User(username="v121_admin", email="v121a@example.com",
                    password_hash=hash_password("adminpass1"), is_admin=True, max_servers=99))
        db.commit()
    db.close()
    return TestClient(app)


def _login(client, name, password="guclu-sifre-1"):
    r = client.post("/api/auth/login", json={"username": name, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["token"]}


def _user(client, name):
    db = SessionLocal()
    user = db.query(User).filter_by(username=name).first()
    if user is None:
        user = User(username=name, email=f"{name}@example.com",
                    password_hash=hash_password("guclu-sifre-1"), is_admin=False, max_servers=5)
        db.add(user)
        db.commit()
    uid = user.id
    db.close()
    return uid, _login(client, name)


def _server(owner_id, egg, site_slug=None, container_id=None):
    _next_port[0] += 1
    db = SessionLocal()
    server = Server(name=f"S{_next_port[0]}", egg=egg, owner_id=owner_id, port=_next_port[0], memory_mb=256,
                    cpu_percent=100, variables={}, site_slug=site_slug, container_id=container_id)
    db.add(server)
    db.commit()
    sid = server.id
    db.close()
    return sid


@pytest.fixture
def docker_stub(monkeypatch):
    monkeypatch.setattr(api_module.dm, "status_map", lambda: None)
    monkeypatch.setattr(api_module.dm, "status", lambda s: "running")


@pytest.fixture
def saas(client):
    """Cloudflare ayarlarını açar; test bitince temizler ki diğer testler yedek modda kalsın."""
    admin = _login(client, "v121_admin", "adminpass1")
    saved = client.put("/api/admin/settings", headers=admin, json={
        "cf_api_token": "tok-v121", "cf_zone_id": "zone-v121", "saas_fallback_host": "origin.example-v121.net",
        "domain_cname_target": "", "domain_ip": "",
    })
    assert saved.status_code == 200, saved.text
    yield admin
    client.put("/api/admin/settings", headers=admin, json={
        "cf_api_token": "", "cf_zone_id": "", "saas_fallback_host": "",
    })


@pytest.fixture
def fake_cf(monkeypatch):
    state = {"created": [], "deleted": [], "status": "pending", "ssl": "pending_validation", "fail_create": None}

    def create(zone, token, hostname):
        if state["fail_create"]:
            raise cloudflare_module.CloudflareError(state["fail_create"])
        state["created"].append((zone, token, hostname))
        return {"id": f"cf-{len(state['created'])}", "hostname": hostname}

    def get(zone, token, cf_id):
        return {"id": cf_id, "status": state["status"], "ssl": {"status": state["ssl"]},
                "verification_errors": [] if state["status"] == "active" else ["CNAME bulunamadı"]}

    monkeypatch.setattr(cloudflare_module, "create_hostname", create)
    monkeypatch.setattr(cloudflare_module, "get_hostname", get)
    monkeypatch.setattr(cloudflare_module, "delete_hostname", lambda zone, token, cf_id: state["deleted"].append(cf_id))
    monkeypatch.setattr(cloudflare_module, "find_hostname", lambda zone, token, hostname: None)
    return state


def test_token_is_write_only_and_saas_fields_are_saved(client, saas):
    admin = saas
    settings_view = client.get("/api/admin/settings", headers=admin).json()
    assert "cf_api_token" not in settings_view
    assert settings_view["cf_token_set"] is True
    assert settings_view["cf_zone_id"] == "zone-v121"
    assert settings_view["saas_fallback_host"] == "origin.example-v121.net"


def test_saas_domain_is_registered_and_activated_by_cloudflare(client, docker_stub, saas, fake_cf):
    uid, headers = _user(client, "v121_owner")
    sid = _server(uid, "static-web", site_slug="saas-site-v121", container_id="cid-saas")

    added = client.post(f"/api/servers/{sid}/domains", headers=headers, json={"domain": "shop.example-v121.com"})
    assert added.status_code == 201, added.text
    body = added.json()
    assert body["mode"] == "cloudflare"
    assert fake_cf["created"] == [("zone-v121", "tok-v121", "shop.example-v121.com")]
    cname = next(r for r in body["records"] if r["type"] == "CNAME")
    assert cname["name"] == "shop.example-v121.com"
    assert cname["value"] == "origin.example-v121.net"

    waiting = client.post(f"/api/servers/{sid}/domains/{body['id']}/verify", headers=headers).json()
    assert waiting["verified"] is False
    assert "CNAME bulunamadı" in waiting["message"] or "Henüz" in waiting["message"]

    fake_cf.update(status="active", ssl="active")
    ok = client.post(f"/api/servers/{sid}/domains/{body['id']}/verify", headers=headers).json()
    assert ok["verified"] is True

    assert client.delete(f"/api/servers/{sid}/domains/{body['id']}", headers=headers).status_code == 204
    assert fake_cf["deleted"] == ["cf-1"]


def test_apex_domain_gets_flattening_note_and_www_cname(client, docker_stub, saas, fake_cf):
    uid, headers = _user(client, "v121_apex_owner")
    sid = _server(uid, "static-web", site_slug="apex-site-v121", container_id="cid-apex")
    added = client.post(f"/api/servers/{sid}/domains", headers=headers, json={"domain": "apexsite-v121.com"})
    assert added.status_code == 201, added.text
    records = added.json()["records"]
    assert any(r["name"] == "apexsite-v121.com" and r["value"] == "origin.example-v121.net" for r in records)
    assert any(r["name"] == "www.apexsite-v121.com" and r["type"] == "CNAME" for r in records)


def test_cloudflare_error_stops_domain_creation(client, docker_stub, saas, fake_cf):
    uid, headers = _user(client, "v121_fail_owner")
    sid = _server(uid, "static-web", site_slug="fail-site-v121", container_id="cid-fail")
    fake_cf["fail_create"] = "Zone bulunamadı"
    failed = client.post(f"/api/servers/{sid}/domains", headers=headers, json={"domain": "hata-v121.example.com"})
    assert failed.status_code == 502
    assert "Zone bulunamadı" in failed.text
    listed = client.get(f"/api/servers/{sid}/domains", headers=headers).json()
    assert listed["domains"] == []
    fake_cf["fail_create"] = None


def test_without_cloudflare_settings_txt_mode_is_used(client, docker_stub, fake_cf):
    uid, headers = _user(client, "v121_plain_owner")
    sid = _server(uid, "static-web", site_slug="plain-site-v121", container_id="cid-plain")
    added = client.post(f"/api/servers/{sid}/domains", headers=headers, json={"domain": "duz-v121.example.com"})
    assert added.status_code == 201, added.text
    assert added.json()["mode"] == "dns"
    assert fake_cf["created"] == []
    assert any(r["type"] == "TXT" for r in added.json()["records"])
