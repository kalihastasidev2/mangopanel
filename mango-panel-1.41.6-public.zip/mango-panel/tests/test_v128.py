"""1.28.0: Linux VPS egg'i ve konteyner yetki beyaz listesi."""
from pathlib import Path
from types import SimpleNamespace

import pytest

from mango import docker_manager as dm
from mango.config import settings
from mango.eggs import load_eggs

REPO_EGGS = Path(__file__).resolve().parent.parent / "eggs"


def _server(**extra):
    base = dict(id=7, name="vps", memory_mb=1024, cpu_percent=100, variables={}, env={}, port=2222,
                container_id=None)
    base.update(extra)
    return SimpleNamespace(**base)


def test_vps_egg_is_loaded_with_safe_settings(monkeypatch):
    monkeypatch.setattr(settings, "eggs_dir", str(REPO_EGGS))
    egg = load_eggs()["linux-vps"]
    assert egg["docker_image"] == "ubuntu:24.04"
    assert egg["ports"] == [2222]
    assert set(egg["cap_add"]) <= dm.ALLOWED_EXTRA_CAPS
    assert 0 < egg["pids_limit"] <= dm.MAX_PIDS


def test_unsafe_capabilities_from_an_egg_are_dropped():
    limits = dm._limits(_server(), {"cap_add": ["CHOWN", "NET_ADMIN", "sys_admin", "setuid"], "pids_limit": 4096})
    assert limits["cap_add"] == ["CHOWN", "SETUID"]
    assert limits["pids_limit"] == dm.MAX_PIDS
    assert limits["cap_drop"] == ["ALL"]
    assert "no-new-privileges:true" in limits["security_opt"]


def test_default_limits_add_no_capabilities():
    limits = dm._limits(_server())
    assert limits["cap_add"] == []
    assert limits["pids_limit"] == dm.MAX_PIDS


def test_container_is_created_with_vps_capabilities(monkeypatch, tmp_path):
    captured = {}

    class FakeContainers:
        def list(self, **kwargs):
            return []

        def create(self, **kwargs):
            captured.update(kwargs)
            return SimpleNamespace(id="cid-vps")

    monkeypatch.setattr(settings, "data_dir", str(tmp_path))
    monkeypatch.setattr(dm, "client", lambda: SimpleNamespace(containers=FakeContainers()))
    monkeypatch.setattr(dm, "ensure_image", lambda image: None)
    egg = {"docker_image": "ubuntu:24.04", "pids_limit": 192, "cap_add": ["CHOWN", "SETUID", "NET_RAW"]}
    cid = dm.create(_server(), egg, "bash -i", 2222)
    assert cid == "cid-vps"
    assert captured["cap_add"] == ["CHOWN", "SETUID"]
    assert captured["pids_limit"] == 192
    assert captured["cap_drop"] == ["ALL"]
