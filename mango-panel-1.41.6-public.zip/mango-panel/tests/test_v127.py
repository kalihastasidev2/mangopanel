"""1.27.0: ücretsiz self-service kaldırıldı, oturum yönetimi, paket kategorileri/temaları/özellik satırları."""
import pytest
from fastapi.testclient import TestClient

from mango.db import PremiumPlan, SessionLocal, User, init_db
from mango.main import app
from mango.premium_api import _features, _theme
from mango.security import hash_password
from mango.store import set_setting


@pytest.fixture(scope="module")
def client():
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="v127_admin").first() is None:
        db.add(User(username="v127_admin", email="v127a@example.com",
                    password_hash=hash_password("adminpass1"), is_admin=True, max_servers=99))
    if db.query(User).filter_by(username="v127_user").first() is None:
        db.add(User(username="v127_user", email="v127u@example.com",
                    password_hash=hash_password("guclu-sifre-1"), is_admin=False, max_servers=5))
    db.commit()
    db.close()
    return TestClient(app)


def _login(client, name, password):
    res = client.post("/api/auth/login", json={"username": name, "password": password})
    assert res.status_code == 200, res.text
    return {"Authorization": "Bearer " + res.json()["token"]}


def test_regular_user_cannot_create_server_even_if_old_setting_is_on(client):
    db = SessionLocal()
    set_setting(db, "self_service_servers", "1")
    db.close()
    headers = _login(client, "v127_user", "guclu-sifre-1")
    res = client.post("/api/servers", headers=headers,
                      json={"name": "ucretsiz", "egg": "nodejs-app", "memory_mb": 512, "cpu_percent": 100})
    assert res.status_code == 403
    db = SessionLocal()
    set_setting(db, "self_service_servers", "0")
    db.close()


def test_sessions_are_listed_and_one_can_be_revoked(client):
    first = _login(client, "v127_user", "guclu-sifre-1")
    second = _login(client, "v127_user", "guclu-sifre-1")
    listing = client.get("/api/me/sessions", headers=first).json()
    assert len(listing) >= 2
    assert sum(1 for s in listing if s["current"]) == 1
    other = next(s for s in listing if not s["current"])
    assert client.delete(f"/api/me/sessions/{other['id']}", headers=first).status_code == 204
    assert client.get("/api/me", headers=second).status_code == 401
    assert client.get("/api/me", headers=first).status_code == 200


def test_revoke_others_keeps_current_session(client):
    keep = _login(client, "v127_user", "guclu-sifre-1")
    drop_a = _login(client, "v127_user", "guclu-sifre-1")
    drop_b = _login(client, "v127_user", "guclu-sifre-1")
    res = client.post("/api/me/sessions/revoke-others", headers=keep)
    assert res.status_code == 200 and res.json()["revoked"] >= 2
    assert client.get("/api/me", headers=drop_a).status_code == 401
    assert client.get("/api/me", headers=drop_b).status_code == 401
    assert client.get("/api/me", headers=keep).status_code == 200


def test_theme_follows_the_product():
    assert _theme("nodejs-app", "Node.js Uygulaması")[1] == "#3fb950"
    assert _theme("php-web", "PHP Sitesi")[0] == "PHP"
    assert _theme("python-bot", "Python Bot")[0] == "Python"
    assert _theme(None, None)[0] == "Genel"


def test_features_are_one_per_nonempty_line():
    assert _features("Canlı konsol\n\n  Dosya yöneticisi  \n") == ["Canlı konsol", "Dosya yöneticisi"]


def test_public_plan_exposes_category_free_flag_features_and_accent(client):
    db = SessionLocal()
    db.add(PremiumPlan(name="v127-ucretsiz", description="Birinci özellik\nİkinci özellik",
                       price_text="", egg=None, memory_mb=512, cpu_percent=50, disk_mb=1024,
                       max_servers=1, active=True, category="Deneme", is_free=True, accent="#123456"))
    db.commit()
    db.close()
    plans = TestClient(app).get("/api/public/plans").json()
    plan = next(p for p in plans if p["name"] == "v127-ucretsiz")
    assert plan["category"] == "Deneme" and plan["is_free"] is True
    assert plan["features"] == ["Birinci özellik", "İkinci özellik"]
    assert plan["accent"] == "#123456"
    assert "egg" not in plan


def test_admin_form_fields_are_accepted(client):
    headers = _login(client, "v127_admin", "adminpass1")
    res = client.post("/api/admin/plans", headers=headers, json={
        "name": "v127-admin-paket", "category": "Web", "is_free": False, "accent": "#8b5cf6",
        "description": "Bir\nİki", "max_servers": 2,
    })
    assert res.status_code == 201, res.text
    body = res.json()
    assert body["category"] == "Web" and body["accent"] == "#8b5cf6" and body["features"] == ["Bir", "İki"]
    bad = client.post("/api/admin/plans", headers=headers, json={"name": "v127-bozuk", "accent": "mavi"})
    assert bad.status_code == 422
