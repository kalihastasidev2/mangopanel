"""1.40.9: HTTP tabanlı VPS terminali ve SQLite WAL ayarı."""
import base64

from fastapi.testclient import TestClient

from mango import vps_terminal as vt
from mango.db import engine, init_db
from mango.main import app


def test_session_buffers_and_returns_only_new_chunks():
    s = vt.TermSession(1, 1, api=None, exec_id="x", raw=None)
    s.push(b"abc")
    s.push(b"def")
    chunks, closed, code, last = s.read_after(0, wait=0)
    assert [seq for seq, _ in chunks] == [1, 2]
    assert last == 2 and not closed
    chunks, _, _, _ = s.read_after(1, wait=0)
    assert [d for _, d in chunks] == [b"def"]


def test_session_reports_close_and_exit_code():
    s = vt.TermSession(1, 1, api=None, exec_id="x", raw=None)
    s.finish(127)
    chunks, closed, code, _ = s.read_after(0, wait=0)
    assert closed and code == 127 and chunks == []


def test_session_buffer_is_capped():
    s = vt.TermSession(1, 1, api=None, exec_id="x", raw=None)
    old_limit = vt.BUFFER_LIMIT
    vt.BUFFER_LIMIT = 10
    try:
        for _ in range(5):
            s.push(b"12345")
        assert s.size <= 10
        assert s.next_seq - 1 == 5
    finally:
        vt.BUFFER_LIMIT = old_limit


def test_shell_script_creates_home_and_falls_back_to_sh():
    assert "mkdir -p /home/container" in vt.SHELL_SCRIPT
    assert "command -v bash" in vt.SHELL_SCRIPT
    assert vt.SHELL_SCRIPT.rstrip().endswith("exec sh -i")


def test_terminal_endpoints_require_login():
    client = TestClient(app)
    assert client.post("/api/vps/1/terminal/sessions").status_code in (401, 403)
    assert client.get("/api/vps/1/terminal/sessions/abc/output").status_code in (401, 403, 422)


def test_sqlite_uses_wal_mode():
    init_db()
    if engine.url.get_backend_name() != "sqlite":
        return
    with engine.connect() as conn:
        mode = conn.exec_driver_sql("PRAGMA journal_mode").scalar()
    assert str(mode).lower() == "wal"


def test_full_http_session_flow(monkeypatch):
    """Sahte Docker soketiyle: aç -> çıktı oku -> tuş gönder -> kabuk kapanır -> kapanış kodu -> sil."""
    import time
    from types import SimpleNamespace

    from mango.db import SessionLocal, User
    from mango.security import hash_password

    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="v1409_admin").first() is None:
        db.add(User(username="v1409_admin", email="v1409@example.com",
                    password_hash=hash_password("adminpass1"), is_admin=True, max_servers=5))
        db.commit()
    db.close()

    class FakeRaw:
        def __init__(self):
            self.queue = [b"ok\r\n"]
            self.sent = []
            self.closed = False

        def recv(self, _n):
            if self.queue:
                return self.queue.pop(0)
            time.sleep(0.05)
            return b""  # kabuk kapandı

        def sendall(self, data):
            self.sent.append(data)

        def close(self):
            self.closed = True

    class FakeApi:
        def exec_inspect(self, _id):
            return {"ExitCode": 0}

        def exec_resize(self, *_a, **_k):
            return None

    raw = FakeRaw()
    monkeypatch.setattr(vt, "vps_server", lambda db, sid: SimpleNamespace(id=sid, egg="linux-vps", maintenance=False, maintenance_message=None))
    monkeypatch.setattr(vt, "_visible_server", lambda *a, **k: None)
    monkeypatch.setattr(vt, "_open_shell", lambda server: (FakeApi(), "exec1", raw))

    client = TestClient(app)
    token = client.post("/api/auth/login", json={"username": "v1409_admin", "password": "adminpass1"}).json()["token"]
    h = {"Authorization": f"Bearer {token}"}

    r = client.post("/api/vps/7/terminal/sessions", headers=h)
    assert r.status_code == 201
    sid = r.json()["sid"]

    out = client.get(f"/api/vps/7/terminal/sessions/{sid}/output?after=0&wait=2", headers=h).json()
    assert base64.b64decode(out["chunks"][0][1]) == b"ok\r\n"
    after = out["next"]

    assert client.post(f"/api/vps/7/terminal/sessions/{sid}/input", json={"data": "ls\n"}, headers=h).status_code == 200
    assert raw.sent == [b"ls\n"]

    assert client.post(f"/api/vps/7/terminal/sessions/{sid}/resize", json={"cols": 100, "rows": 30}, headers=h).status_code == 200

    closed = client.get(f"/api/vps/7/terminal/sessions/{sid}/output?after={after}&wait=2", headers=h).json()
    assert closed["closed"] is True and closed["exit_code"] == 0

    assert client.post(f"/api/vps/7/terminal/sessions/{sid}/input", json={"data": "x"}, headers=h).status_code == 409
    assert client.delete(f"/api/vps/7/terminal/sessions/{sid}", headers=h).status_code == 200
    assert client.get(f"/api/vps/7/terminal/sessions/{sid}/output", headers=h).status_code == 404


def test_diagnose_reports_each_step(monkeypatch):
    from types import SimpleNamespace

    from mango.db import SessionLocal, User

    init_db()
    db = SessionLocal()
    assert db.query(User).filter_by(username="v1409_admin").first() is not None
    db.close()

    class Api:
        def __init__(self):
            self.last = ""

        def exec_create(self, cid, cmd, **_k):
            self.last = " ".join(cmd)
            return {"Id": "e-diag"}

        def exec_start(self, _id, **_k):
            return b"mango-ok\nbash\nhome-ok\n"

        def exec_inspect(self, _id):
            return {"ExitCode": 0}

    class TtyRaw:
        def __init__(self):
            self.queue = [b"root@mango:~$ "]

        def settimeout(self, _s):
            pass

        def recv(self, _n):
            if self.queue:
                return self.queue.pop(0)
            raise TimeoutError()

        def sendall(self, data):
            if b"mango-tty-ok" in data:
                self.queue.append(b"mango-tty-ok\r\n")

        def close(self):
            pass

    class Client:
        def ping(self):
            return True

        api = Api()

    monkeypatch.setattr(vt, "vps_server", lambda db, sid: SimpleNamespace(id=sid, egg="linux-vps", maintenance=False, maintenance_message=None))
    monkeypatch.setattr(vt, "_visible_server", lambda *a, **k: None)
    monkeypatch.setattr(vt.dm, "client", lambda: Client())
    monkeypatch.setattr(vt.dm, "status", lambda s: "running")
    monkeypatch.setattr(vt.dm, "_container", lambda s: SimpleNamespace(id="c1", name="mango-7"))
    monkeypatch.setattr(vt, "DIAG_WAIT", 0.2)
    monkeypatch.setattr(vt, "_open_shell", lambda s: (Api(), "e", TtyRaw()))

    client = TestClient(app)
    token = client.post("/api/auth/login", json={"username": "v1409_admin", "password": "adminpass1"}).json()["token"]
    r = client.get("/api/vps/7/terminal/diagnose", headers={"Authorization": f"Bearer {token}"})
    assert r.status_code == 200
    body = r.json()
    names = {c["name"]: c["ok"] for c in body["checks"]}
    assert names["Docker daemon erişimi"] is True
    assert names["konteyner durumu"] is True
    assert names["komut çalıştırma (exec)"] is True
    assert names["bash kurulu"] is True
    assert names["ana klasör /home/container"] is True
    assert names["etkileşimli kabuk açma"] is True
    assert names["tuş girişi ve çıktı"] is True
    assert body["ok"] is True


def test_diagnose_stops_when_vps_is_stopped(monkeypatch):
    from types import SimpleNamespace

    monkeypatch.setattr(vt, "vps_server", lambda db, sid: SimpleNamespace(id=sid, egg="linux-vps", maintenance=False, maintenance_message=None))
    monkeypatch.setattr(vt, "_visible_server", lambda *a, **k: None)
    monkeypatch.setattr(vt.dm, "client", lambda: SimpleNamespace(ping=lambda: True))
    monkeypatch.setattr(vt.dm, "status", lambda s: "exited")
    client = TestClient(app)
    token = client.post("/api/auth/login", json={"username": "v1409_admin", "password": "adminpass1"}).json()["token"]
    body = client.get("/api/vps/7/terminal/diagnose", headers={"Authorization": f"Bearer {token}"}).json()
    assert body["ok"] is False
    assert body["checks"][-1]["name"] == "konteyner durumu" and body["checks"][-1]["ok"] is False
