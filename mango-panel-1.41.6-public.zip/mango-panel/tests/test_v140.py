"""1.40.0: alt alan adı (ad.<site_base_domain>) DNS kaydı, site adresi ve alt alan adı yönlendirmesi."""
from types import SimpleNamespace

import pytest
from fastapi import HTTPException
from fastapi.testclient import TestClient

from mango import site_dns
from mango.api import _site_url
from mango.cloudflare import CloudflareError
from mango.db import Server, SessionLocal, User, init_db
from mango.main import app
from mango.security import hash_password

BASE = "example.com"
CFG = (BASE, "tok", "zone123", "panel.example.com")


def _server(**kw):
    base = dict(site_dns_id=None, site_host=None, site_slug=None, egg="php")
    base.update(kw)
    return SimpleNamespace(**base)


@pytest.fixture
def cf(monkeypatch):
    """Cloudflare çağrılarını kaydeder; cevapları testten ayarlanır."""
    state = {"calls": [], "get": [], "post": None, "post_error": None, "config": CFG}

    def fake_call(method, path, token, body=None):
        state["calls"].append((method, path))
        if method == "GET":
            return state["get"]
        if method == "POST":
            if state["post_error"]:
                raise CloudflareError(state["post_error"])
            return {"id": state["post"] or "rid-new"}
        return None

    monkeypatch.setattr(site_dns, "_call", fake_call)
    monkeypatch.setattr(site_dns, "_cfg", lambda db: state["config"])
    return state


def test_no_cloudflare_settings_means_no_dns_call(cf):
    cf["config"] = None
    s = _server()
    site_dns.assign(None, s, "shop")
    assert cf["calls"] == []
    assert s.site_host is None and s.site_dns_id is None


def test_new_name_creates_cname(cf):
    s = _server()
    site_dns.assign(None, s, "shop1")
    assert s.site_host == f"shop1.{BASE}"
    assert s.site_dns_id == "rid-new"
    assert [c[0] for c in cf["calls"]] == ["GET", "POST"]


def test_taken_name_returns_409(cf):
    cf["get"] = [{"id": "someone-else"}]
    with pytest.raises(HTTPException) as exc:
        site_dns.assign(None, _server(), "shop1")
    assert exc.value.status_code == 409 and "alınmış" in exc.value.detail


def test_reserved_name_returns_409(cf):
    with pytest.raises(HTTPException) as exc:
        site_dns.assign(None, _server(), "panel")
    assert exc.value.status_code == 409
    assert cf["calls"] == []


def test_cloudflare_error_returns_502(cf):
    cf["post_error"] = "zone yetkisi yok"
    with pytest.raises(HTTPException) as exc:
        site_dns.assign(None, _server(), "shop1")
    assert exc.value.status_code == 502


def test_rename_creates_new_then_deletes_old(cf):
    s = _server(site_host=f"old.{BASE}", site_dns_id="rid-old", site_slug="old")
    site_dns.assign(None, s, "fresh")
    assert s.site_host == f"fresh.{BASE}" and s.site_dns_id == "rid-new"
    deletes = [c for c in cf["calls"] if c[0] == "DELETE"]
    assert deletes == [("DELETE", "/zones/zone123/dns_records/rid-old")]


def test_unchanged_name_makes_no_call(cf):
    s = _server(site_host=f"same.{BASE}", site_dns_id="rid-same", site_slug="same")
    site_dns.assign(None, s, "same")
    assert cf["calls"] == []


def test_removing_slug_deletes_record(cf):
    s = _server(site_host=f"gone.{BASE}", site_dns_id="rid-gone", site_slug="gone")
    site_dns.assign(None, s, None)
    assert s.site_host is None and s.site_dns_id is None
    assert ("DELETE", "/zones/zone123/dns_records/rid-gone") in cf["calls"]


def test_site_url_prefers_subdomain():
    s = _server(site_slug="shop1", site_host=f"shop1.{BASE}")
    assert _site_url(s, {}) == f"https://shop1.{BASE}/"


def test_site_url_falls_back_to_path():
    s = _server(site_slug="shop1", site_host=None)
    assert _site_url(s, {}).endswith("/sites/shop1/")


def test_base_domain_setting_is_validated():
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="v140_admin").first() is None:
        db.add(User(username="v140_admin", email="v140_admin@example.com",
                    password_hash=hash_password("guclu-sifre-1"), is_admin=True, max_servers=5))
        db.commit()
    db.close()
    client = TestClient(app)
    res = client.post("/api/auth/login", json={"username": "v140_admin", "password": "guclu-sifre-1"})
    h = {"Authorization": "Bearer " + res.json()["token"]}
    assert client.put("/api/admin/settings", headers=h, json={"site_base_domain": "BAD DOMAIN"}).status_code == 422
    ok = client.put("/api/admin/settings", headers=h, json={"site_subdomains": True, "site_base_domain": BASE,
                                                           "cf_zone_id": "6f0b132113bee38f1334a6bd7742687d",
                                                           "cf_api_token": "test-token-v140"})
    assert ok.status_code == 200
    assert client.get("/api/system").json()["site_base_domain"] == BASE


def test_subdomain_request_is_routed_like_path_request():
    init_db()
    db = SessionLocal()
    owner = db.query(User).filter_by(username="v140_admin").one()
    srv = Server(name="v140-router", egg="php", owner_id=owner.id, port=59140,
                 site_slug="v140-router", site_host="v140-router.example.test")
    db.add(srv)
    db.commit()
    sid = srv.id
    db.close()
    try:
        client = TestClient(app, raise_server_exceptions=False)
        by_host = client.get("/index.html", headers={"host": "v140-router.example.test"})
        by_path = client.get("/api/sites/v140-router/index.html")
        # Alt alan adı isteği, yol isteğiyle aynı sonucu vermeli (ikisi de aynı siteye gider)
        assert by_host.status_code == by_path.status_code
        assert by_host.text == by_path.text
    finally:
        db = SessionLocal()
        db.delete(db.get(Server, sid))
        db.commit()
        db.close()
