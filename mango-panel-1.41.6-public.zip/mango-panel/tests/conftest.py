"""Testler için geçici veritabanı ve gizli anahtar. Gerçek sunucu ayarlarına dokunmaz."""
import os
import tempfile

_tmp = tempfile.mkdtemp(prefix="mango-test-")
os.environ.setdefault("MANGO_CONFIG", os.path.join(_tmp, "missing.json"))
os.environ.setdefault("MANGO_SECRET", "test-secret-" + "x" * 32)
os.environ.setdefault("MANGO_DATABASE_URL", f"sqlite:///{os.path.join(_tmp, 'test.db')}")
