import pytest

from mango import files_manager as fm
from mango.config import settings


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    monkeypatch.setattr(settings, "data_dir", str(tmp_path / "servers"))
    return tmp_path


def test_write_and_read_roundtrip(data_dir):
    fm.write_text(1, "plugins/config.yml", "a: 1\n")
    assert fm.read_text(1, "plugins/config.yml") == "a: 1\n"


def test_listing_shows_dirs_first(data_dir):
    fm.make_dir(1, "world")
    fm.write_text(1, "server.properties", "x=1")
    entries = fm.list_dir(1, "")["entries"]
    assert [e["name"] for e in entries] == ["world", "server.properties"]
    assert entries[0]["is_dir"] is True


def test_path_traversal_rejected(data_dir):
    fm.server_dir(1)  # sunucu klasörünü oluşturur
    for bad in ("../2/secret.txt", "../../etc/passwd", "/../../x"):
        with pytest.raises(fm.FileError):
            fm.resolve(1, bad)


def test_absolute_path_is_treated_as_relative(data_dir):
    # Baştaki '/' kökten sayılır; kök dışına çıkmaz.
    fm.write_text(1, "/a.txt", "ok")
    assert fm.read_text(1, "a.txt") == "ok"


def test_symlink_escape_rejected(data_dir, tmp_path):
    outside = tmp_path / "outside.txt"
    outside.write_text("gizli")
    root = fm.server_dir(1)
    (root / "link").symlink_to(outside)
    with pytest.raises(fm.FileError):
        fm.read_text(1, "link")
    with pytest.raises(fm.FileError):
        fm.write_text(1, "link", "değiştir")
    assert outside.read_text() == "gizli"


def test_root_cannot_be_deleted(data_dir):
    with pytest.raises(fm.FileError):
        fm.delete(1, "")


def test_binary_file_not_editable(data_dir):
    root = fm.server_dir(1)
    (root / "bin.dat").write_bytes(b"\x00\x01\x02")
    with pytest.raises(fm.FileError):
        fm.read_text(1, "bin.dat")


def test_size_limit_enforced(data_dir):
    with pytest.raises(fm.FileError):
        fm.write_text(1, "big.txt", "x" * (fm.MAX_TEXT_BYTES + 1))


def test_delete_directory_recursively(data_dir):
    fm.write_text(1, "a/b/c.txt", "1")
    fm.delete(1, "a")
    assert fm.list_dir(1, "")["entries"] == []


def test_make_dir_conflict(data_dir):
    fm.make_dir(1, "x")
    with pytest.raises(fm.FileError):
        fm.make_dir(1, "x")


def test_dir_size_counts_bytes(data_dir):
    fm.write_text(1, "a.txt", "x" * 2048)
    fm.write_text(1, "sub/b.txt", "y" * 1024)
    assert fm.dir_size_mb(1) == round(3072 / 1048576, 1)


def test_seed_files_does_not_overwrite(tmp_path):
    import mango.files_manager as fm
    fm.seed_files(1, {"index.js": "console.log(1)"})
    assert (fm.server_dir(1) / "index.js").read_text() == "console.log(1)"
    (fm.server_dir(1) / "index.js").write_text("kullanıcı")
    fm.seed_files(1, {"index.js": "yeni", "public/index.php": "<?php"})
    assert (fm.server_dir(1) / "index.js").read_text() == "kullanıcı"
    assert (fm.server_dir(1) / "public" / "index.php").read_text() == "<?php"
