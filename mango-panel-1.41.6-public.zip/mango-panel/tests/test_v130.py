"""1.30.0: VPS terminali sunucu detayında; alt alan adı/DNS/tünel kaldırıldı; Debian egg'i eklendi."""
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from mango.config import settings
from mango.db import User, init_db
from mango.db import SessionLocal
from mango.eggs import load_eggs
from mango.main import app
from mango.security import hash_password
from mango.store import all_settings
from mango.vps_terminal import SHELL_SCRIPT, vps_server

REPO_EGGS = Path(__file__).resolve().parent.parent / "eggs"


def test_ubuntu_egg_keeps_its_slug_so_existing_vps_keep_working(monkeypatch):
    monkeypatch.setattr(settings, "eggs_dir", str(REPO_EGGS))
    egg = load_eggs()["linux-vps"]
    assert egg["docker_image"] == "ubuntu:24.04"
    assert egg["category"] == "vps"
    assert egg["publish_ports"] is False


def test_debian_egg_is_available_as_vps(monkeypatch):
    monkeypatch.setattr(settings, "eggs_dir", str(REPO_EGGS))
    egg = load_eggs()["linux-vps-debian"]
    assert egg["docker_image"] == "debian:12"
    assert egg["category"] == "vps"
    assert egg["publish_ports"] is False
    assert "mango-prompt.sh" in egg["install_script"]


def test_vps_lookup_by_id_refuses_unknown_and_non_vps_servers():
    db = SessionLocal()
    try:
        assert vps_server(db, 999_999_999) is None
    finally:
        db.close()


def test_terminal_refuses_a_bad_token():
    client = TestClient(app)
    r = client.post("/api/vps/1/terminal/sessions", headers={"Authorization": "Bearer bu-gecersiz"})
    assert r.status_code in (401, 403)


def test_vps_settings_are_gone_from_admin_settings():
    db = SessionLocal()
    try:
        keys = all_settings(db).keys()
    finally:
        db.close()
    for key in ("vps_base_domain", "cf_account_id", "cf_tunnel_id"):
        assert key not in keys
    assert "cf_zone_id" in keys  # özel alan adı (SaaS) ayarları korunur


def test_vps_subdomain_host_is_no_longer_special():
    client = TestClient(app)
    res = client.get("/", headers={"host": "vps1.example.com"})
    assert "vps.html" not in res.text
    assert not Path(settings.web_dir, "vps.html").exists()


def test_shell_sets_colored_prompt_on_every_open():
    assert "--rcfile \"$RC\"" in SHELL_SCRIPT
    assert "PS1=" in SHELL_SCRIPT and "\\e[1;32m" in SHELL_SCRIPT
    assert "alias ls='ls --color=auto'" in SHELL_SCRIPT



@pytest.fixture(scope="module")
def panel_client():
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="v130_admin").first() is None:
        db.add(User(username="v130_admin", email="v130a@example.com",
                    password_hash=hash_password("adminpass1"), is_admin=True, max_servers=99))
    if db.query(User).filter_by(username="v130_user").first() is None:
        db.add(User(username="v130_user", email="v130u@example.com",
                    password_hash=hash_password("guclu-sifre-1"), is_admin=False, max_servers=5))
    db.commit()
    db.close()
    return TestClient(app)


def _login(client, name, password):
    res = client.post("/api/auth/login", json={"username": name, "password": password})
    assert res.status_code == 200, res.text
    return {"Authorization": "Bearer " + res.json()["token"]}


def test_admin_analytics_lists_egg_counts_and_daily_signups(panel_client):
    admin = _login(panel_client, "v130_admin", "adminpass1")
    res = panel_client.get("/api/admin/analytics?days=7", headers=admin)
    assert res.status_code == 200
    body = res.json()
    assert len(body["users_per_day"]) == 7
    assert isinstance(body["servers_by_egg"], list)
    assert body["total_servers"] == sum(r["count"] for r in body["servers_by_egg"])


def test_admin_analytics_is_admin_only(panel_client):
    member = _login(panel_client, "v130_user", "guclu-sifre-1")
    assert panel_client.get("/api/admin/analytics", headers=member).status_code == 403
