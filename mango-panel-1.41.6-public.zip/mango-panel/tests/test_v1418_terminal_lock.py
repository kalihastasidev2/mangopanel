import threading
import time

from mango import vps_terminal as vt


class _FakeRaw:
    def close(self):
        pass


def test_reap_inside_open_session_lock_does_not_deadlock():
    # open_session _lock'u tutarken _reap() çağırır; _reap de _close() ile kilidi yeniden alır.
    sess = vt.TermSession(1, 1, None, "exec", _FakeRaw())
    sess.closed = True
    sess.last_seen = time.monotonic() - 120  # 60 sn'den eski kapalı oturum: temizlenmeli
    with vt._lock:
        vt._sessions[sess.sid] = sess

    done = threading.Event()

    def run():
        with vt._lock:
            vt._reap()
        done.set()

    t = threading.Thread(target=run, daemon=True)
    t.start()
    assert done.wait(5), "_reap kilit içinde takıldı (deadlock)"
    assert sess.sid not in vt._sessions
