"""1.40.26: otomatik yedek zamanlaması (günlük/haftalık, saat, saklama sayısı)."""
import datetime as dt

import pytest
from fastapi.testclient import TestClient

from mango import backups, docker_manager as dm
from mango.backups import BACKUP_TZ, create_backup, run_due_backups
from mango.config import settings
from mango.db import Server, SessionLocal, User, init_db
from mango.main import app
from mango.security import hash_password

OWNER = "v1426_owner"
PASSWORD = "adminpass1"


@pytest.fixture()
def env(tmp_path, monkeypatch):
    settings.data_dir = str(tmp_path)
    src = tmp_path / "srv"
    src.mkdir()
    (src / "world.txt").write_text("veri")
    monkeypatch.setattr(dm, "server_dir", lambda sid: src)
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username=OWNER).first() is None:
        db.add(User(username=OWNER, email=f"{OWNER}@example.com",
                    password_hash=hash_password(PASSWORD), is_admin=False, max_servers=9))
        db.commit()
    owner = db.query(User).filter_by(username=OWNER).one()
    db.close()
    return owner.id


def _server(owner_id, port, **kw):
    db = SessionLocal()
    srv = Server(name=f"v1426-{port}", egg="nodejs-app", owner_id=owner_id, port=port, **kw)
    db.add(srv)
    db.commit()
    sid = srv.id
    db.close()
    return sid


def _cleanup(sid):
    db = SessionLocal()
    srv = db.get(Server, sid)
    if srv is not None:
        db.delete(srv)
        db.commit()
    db.close()


def _at(y, mo, d, h):
    return dt.datetime(y, mo, d, h, 0, tzinfo=BACKUP_TZ)


def test_daily_runs_after_hour_and_only_once_per_day(env):
    sid = _server(env, 26601, backup_schedule="daily", backup_hour=4, backup_keep=5)
    try:
        assert sid not in run_due_backups(_at(2026, 11, 17, 3))  # saatten önce
        assert sid in run_due_backups(_at(2026, 11, 17, 4))
        assert sid not in run_due_backups(_at(2026, 11, 17, 9))  # aynı gün tekrar yok
        assert sid in run_due_backups(_at(2026, 11, 18, 4))  # ertesi gün yine alınır
        assert len(backups.list_backups(sid)) == 2
    finally:
        _cleanup(sid)


def test_missed_day_is_caught_up_when_panel_comes_back(env):
    sid = _server(env, 26602, backup_schedule="daily", backup_hour=4, backup_keep=5)
    try:
        # Panel gün içinde kapalıydı; saat 15'te açılınca o günün yedeği telafi edilir.
        assert sid in run_due_backups(_at(2026, 11, 17, 15))
    finally:
        _cleanup(sid)


def test_weekly_only_on_monday(env):
    sid = _server(env, 26603, backup_schedule="weekly", backup_hour=4, backup_keep=5)
    try:
        assert sid not in run_due_backups(_at(2026, 11, 17, 5))  # Salı
        assert sid in run_due_backups(_at(2026, 11, 16, 5))  # Pazartesi
    finally:
        _cleanup(sid)


def test_off_schedule_is_never_run(env):
    sid = _server(env, 26604, backup_schedule="off", backup_hour=0, backup_keep=5)
    try:
        assert sid not in run_due_backups(_at(2026, 11, 16, 23))
    finally:
        _cleanup(sid)


def test_retention_prunes_to_keep(env):
    sid = _server(env, 26605)
    try:
        for _ in range(4):
            create_backup(sid, keep=2)
        assert len(backups.list_backups(sid)) == 2
    finally:
        _cleanup(sid)


def test_schedule_endpoint_saves_and_list_reports_it(env):
    client = TestClient(app)
    sid = _server(env, 26606, backup_schedule="off")
    try:
        tok = client.post("/api/auth/login", json={"username": OWNER, "password": PASSWORD}).json()["token"]
        h = {"Authorization": f"Bearer {tok}"}
        r = client.put(f"/api/servers/{sid}/backups/schedule",
                       json={"schedule": "daily", "hour": 6, "keep": 7}, headers=h)
        assert r.status_code == 200, r.text
        data = client.get(f"/api/servers/{sid}/backups", headers=h).json()
        assert data["max"] == 7
        assert data["schedule"]["mode"] == "daily"
        assert data["schedule"]["hour"] == 6
        assert data["schedule"]["keep"] == 7
    finally:
        _cleanup(sid)


@pytest.mark.parametrize("body", [
    {"schedule": "hourly", "hour": 4, "keep": 5},
    {"schedule": "daily", "hour": 24, "keep": 5},
    {"schedule": "daily", "hour": 4, "keep": 0},
    {"schedule": "daily", "hour": 4, "keep": 31},
])
def test_schedule_endpoint_rejects_bad_values(env, body):
    client = TestClient(app)
    sid = _server(env, 26607)
    try:
        tok = client.post("/api/auth/login", json={"username": OWNER, "password": PASSWORD}).json()["token"]
        r = client.put(f"/api/servers/{sid}/backups/schedule", json=body,
                       headers={"Authorization": f"Bearer {tok}"})
        assert r.status_code == 422
    finally:
        _cleanup(sid)
