"""1.34.0: kuponlar (oluştur, doğrula, süre/limit/paket kontrolü, talebe uygulama)."""
import datetime as dt

import pytest
from fastapi import HTTPException

from mango.coupons import normalize, validate_coupon
from mango.db import Coupon, SessionLocal, init_db


@pytest.fixture
def db():
    init_db()
    session = SessionLocal()
    yield session
    session.query(Coupon).filter(Coupon.code.like("T134%")).delete(synchronize_session=False)
    session.commit()
    session.close()


def _add(db, **kw):
    base = dict(code="T134OK", percent_off=20, plan_id=None, max_uses=None, used_count=0, expires_at=None, active=True)
    base.update(kw)
    c = Coupon(**base)
    db.add(c)
    db.commit()
    return c


def test_code_is_normalized_to_uppercase():
    assert normalize("  yaz20 ") == "YAZ20"


def test_valid_coupon_passes(db):
    _add(db)
    assert validate_coupon(db, "t134ok", None).percent_off == 20


def test_inactive_expired_exhausted_and_wrong_plan_are_refused(db):
    _add(db, code="T134OFF", active=False)
    _add(db, code="T134OLD", expires_at=dt.datetime(2020, 1, 1, tzinfo=dt.timezone.utc))
    _add(db, code="T134FULL", max_uses=2, used_count=2)
    _add(db, code="T134PLAN", plan_id=999)
    for code, plan in [("T134OFF", None), ("T134OLD", None), ("T134FULL", None), ("T134PLAN", 1)]:
        with pytest.raises(HTTPException) as err:
            validate_coupon(db, code, plan)
        assert err.value.status_code == 400


def test_unknown_code_is_refused(db):
    with pytest.raises(HTTPException):
        validate_coupon(db, "T134YOK", None)
