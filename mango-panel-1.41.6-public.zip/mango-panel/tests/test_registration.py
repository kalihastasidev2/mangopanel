import pytest
from fastapi.testclient import TestClient

from mango import ratelimit
from mango.config import settings
from mango.db import SessionLocal, User, init_db
from mango.main import app
from mango.security import hash_password


@pytest.fixture(scope="module")
def client(tmp_path_factory):
    settings.data_dir = str(tmp_path_factory.mktemp("servers-reg"))
    init_db()
    db = SessionLocal()
    if db.query(User).filter_by(username="reg_admin").first() is None:
        db.add(User(username="reg_admin", email="admin@example.com",
                    password_hash=hash_password("adminpass1"), is_admin=True, max_servers=99))
        db.commit()
    db.close()
    return TestClient(app)


def _admin_headers(client):
    r = client.post("/api/auth/login", json={"username": "reg_admin", "password": "adminpass1"})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["token"]}


def _set_registration(client, headers, enabled: bool):
    r = client.put("/api/admin/settings", headers=headers, json={"registration_enabled": enabled})
    assert r.status_code == 200


def test_register_creates_user_and_logs_in(client):
    headers = _admin_headers(client)
    _set_registration(client, headers, True)
    r = client.post("/api/auth/register", json={
        "username": "yeni_kullanici", "email": "yeni@example.com", "password": "guclu-sifre-1",
    })
    assert r.status_code == 201, r.text
    body = r.json()
    assert body["user"]["username"] == "yeni_kullanici"
    assert body["user"]["is_admin"] is False
    assert body["user"]["max_servers"] == 2  # varsayılan limit
    me = client.get("/api/me", headers={"Authorization": "Bearer " + body["token"]})
    assert me.status_code == 200


def test_register_rejects_duplicates_and_bad_input(client):
    _set_registration(client, _admin_headers(client), True)
    base = {"username": "dup_user", "email": "dup@example.com", "password": "guclu-sifre-1"}
    assert client.post("/api/auth/register", json=base).status_code == 201
    assert client.post("/api/auth/register", json=base).status_code == 409
    other_email = dict(base, username="dup_user2")
    assert client.post("/api/auth/register", json=other_email).status_code == 409
    assert client.post("/api/auth/register", json=dict(base, username="mailsiz", email="gecersiz")).status_code == 400
    assert client.post("/api/auth/register", json=dict(base, username="sifresiz1", password="sifresiz1")).status_code == 400


def test_registration_can_be_closed(client):
    headers = _admin_headers(client)
    _set_registration(client, headers, False)
    try:
        assert client.get("/api/system").json()["registration_enabled"] is False
        r = client.post("/api/auth/register", json={
            "username": "kapali_kayit", "email": "kapali@example.com", "password": "guclu-sifre-1",
        })
        assert r.status_code == 403
    finally:
        _set_registration(client, headers, True)


def test_login_is_rate_limited_per_username(client):
    name = "brute_target"
    ratelimit.login_failures.reset(name)
    for _ in range(ratelimit.login_failures.limit):
        r = client.post("/api/auth/login", json={"username": name, "password": "yanlis-sifre"})
        assert r.status_code == 401
    r = client.post("/api/auth/login", json={"username": name, "password": "yanlis-sifre"})
    assert r.status_code == 429
    ratelimit.login_failures.reset(name)


def test_server_limit_enforced_before_docker(client):
    headers = _admin_headers(client)
    _set_registration(client, headers, True)
    client.put("/api/admin/settings", headers=headers, json={"self_service_servers": True})
    r = client.post("/api/auth/register", json={
        "username": "limitli_user", "email": "limit@example.com", "password": "guclu-sifre-1",
    })
    user_headers = {"Authorization": "Bearer " + r.json()["token"]}
    # Yöneticiden limiti sıfıra çek; sunucu oluşturma Docker'a gitmeden reddedilmeli.
    uid = r.json()["user"]["id"]
    assert client.patch(f"/api/users/{uid}", headers=headers, json={"max_servers": 0}).status_code == 200
    created = client.post("/api/servers", headers=user_headers, json={
        "name": "Limit Testi", "egg": "static-web", "memory_mb": 512, "cpu_percent": 100, "variables": {},
    })
    assert created.status_code == 403
    assert "yönetici" in created.json()["detail"].lower()  # 1.27.0: kullanıcılar sunucu oluşturamaz


def test_admin_endpoints_require_admin(client):
    r = client.post("/api/auth/register", json={
        "username": "normal_joe", "email": "joe@example.com", "password": "guclu-sifre-1",
    })
    headers = {"Authorization": "Bearer " + r.json()["token"]}
    assert client.get("/api/admin/stats", headers=headers).status_code == 403
    assert client.get("/api/admin/audit", headers=headers).status_code == 403
    assert client.put("/api/admin/settings", headers=headers, json={"registration_enabled": False}).status_code == 403


def test_admin_stats_and_audit(client):
    headers = _admin_headers(client)
    stats = client.get("/api/admin/stats", headers=headers).json()
    assert stats["users"] >= 2
    assert "registration_enabled" in stats
    log = client.get("/api/admin/audit", headers=headers).json()
    actions = {row["action"] for row in log}
    assert "register" in actions
    assert "settings.update" in actions


def test_user_listing_includes_limits(client):
    headers = _admin_headers(client)
    users = client.get("/api/users", headers=headers).json()
    joe = next(u for u in users if u["username"] == "normal_joe")
    assert joe["email"] == "joe@example.com"
    assert "max_servers" in joe and "server_count" in joe
