"""1.40.27: sessiz kalan terminal kabuğu zaman aşımıyla kapanmamalı."""
import socket

from mango import vps_terminal as vt


class FakeApi:
    def exec_inspect(self, exec_id):
        return {"ExitCode": 0}


class FakeRaw:
    """Önce bir zaman aşımı, sonra veri, en sonda gerçek kapanış (boş okuma) döndürür."""

    def __init__(self, steps):
        self.steps = list(steps)
        self.closed = False

    def recv(self, n):
        step = self.steps.pop(0)
        if isinstance(step, BaseException):
            raise step
        return step

    def close(self):
        self.closed = True


def _run(steps):
    sess = vt.TermSession(1, 1, FakeApi(), "exec", FakeRaw(steps))
    vt._reader(sess)
    return sess


def test_idle_timeout_does_not_close_session():
    sess = _run([socket.timeout("timed out"), b"merhaba", socket.timeout("timed out"), b"", ])
    chunks, closed, code, _ = sess.read_after(0, 0)
    assert [data for _, data in chunks] == [b"merhaba"]
    assert closed is True  # yalnızca gerçek kapanışta (boş okuma) kapanır
    assert code == 0


def test_real_eof_still_closes():
    sess = _run([b""])
    assert sess.closed is True


def test_open_shell_sets_blocking_socket(monkeypatch):
    raw = FakeRaw([])
    seen = {}

    class Sock:
        _sock = raw

    class Api:
        def exec_create(self, *a, **k):
            return {"Id": "x"}

        def exec_start(self, *a, **k):
            return Sock()

    class Cont:
        id = "c"

    class Client:
        api = Api()

    monkeypatch.setattr(vt.dm, "status", lambda server: "running")
    monkeypatch.setattr(vt.dm, "client", lambda: Client())
    monkeypatch.setattr(vt.dm, "_container", lambda server: Cont())

    class Srv:
        id = 1

    raw_timeouts = []
    orig = FakeRaw.__init__

    def settimeout(value):
        raw_timeouts.append(value)

    raw.settimeout = settimeout
    _api, _eid, got = vt._open_shell(Srv())
    assert got is raw
    assert raw_timeouts == [None]
