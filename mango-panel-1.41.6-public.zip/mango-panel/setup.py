#!/usr/bin/env python3
"""Mango Panel - kurulum, teşhis, onarım ve kaldırma aracı (sürüm 6).

Mimari:
  İstemci -> nginx (tek giriş noktası)
               |-- /            -> PHP (arayüz sayfası, php-fpm)
               |-- /static/     -> arayüz dosyaları (JS/CSS)
               '-- /api/        -> Python FastAPI (yalnızca 127.0.0.1)
  Oyun dışı siteler: Node.js ve PHP eggleri (Docker konteynerleri içinde)

Kullanım:
  sudo python3 setup.py --doctor                          Kurulu sistemi teşhis et ve onar
  sudo python3 setup.py                                   Etkileşimli kurulum (plan + onay)
  sudo python3 setup.py --yes                             Sorusuz, doğrudan erişim
  sudo python3 setup.py --cloudflare --domain panel.alanadi.com --yes
  sudo python3 setup.py --uninstall                       Mango'nun kurduklarını kaldır

Güvenlik kuralları:
  * Hostname'e ait mevcut bir DNS kaydı --force-dns olmadan değiştirilmez.
  * Yalnızca "mango-" ile başlayan tüneller silinir.
  * Diğer Cloudflare tünelleri ve DNS kayıtları hiçbir koşulda değiştirilmez.
  * Web dosyaları /var/lib/mango/www altında, herkes okuyabilir; yapılandırma
    (gizli anahtar, veritabanı şifresi) bu klasöre kopyalanmaz.
"""
from __future__ import annotations

import argparse
import getpass
import glob
import json
import os
import platform
import re
import secrets
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse

SETUP_VERSION = "6"
PANEL_VERSION = "1.41.6"

ROOT = Path(__file__).resolve().parent
VENV = ROOT / ".venv"
VENV_PY = VENV / "bin" / "python"
CONFIG_PATH = ROOT / "mango.json"
DATA_DIR = ROOT / "data"
CRED_PATH = ROOT / "mango-admin.txt"
LOG_PATH = ROOT / "install.log"
BIN_DIR = ROOT / "bin"
PHP_SRC = ROOT / "php"
WEB_SRC = ROOT / "web"
PUBLIC_ROOT = Path("/var/lib/mango/www")
NGINX_CONF = Path("/etc/nginx/conf.d/mango.conf")
NGINX_ERROR_LOG = Path("/var/log/nginx/error.log")
CF_DIR = Path.home() / ".cloudflared"
CERT_PATH = CF_DIR / "cert.pem"
UNIT_PANEL = Path("/etc/systemd/system/mango-panel.service")
UNIT_TUNNEL = Path("/etc/systemd/system/mango-tunnel.service")
CLOUDFLARED_URL = (
    "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64"
)
DOCKER_SCRIPT_URL = "https://get.docker.com"
SOURCE_URL = "https://github.com/your-org/mango-panel"
API_PORT_START = 8765            # Python API iç portu (dışarı açılmaz)
TUNNEL_PUBLIC_PORT = 8080        # Cloudflare modunda nginx'in yerel portu
DIRECT_PUBLIC_PORT = 8000
MIN_PYTHON = (3, 10)
MIN_RAM_MB = 1024
MIN_FREE_DISK_MB = 2048
PREFIX = "mango-"

IS_LINUX = platform.system() == "Linux"
IS_ROOT = hasattr(os, "geteuid") and os.geteuid() == 0
HAS_SYSTEMD = IS_LINUX and shutil.which("systemctl") is not None
INTERACTIVE = sys.stdin.isatty()
UUID_RE = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")
DOMAIN_RE = re.compile(r"^(?=.{4,253}$)([a-z0-9-]+\.)+[a-z]{2,}$")
USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,32}$")


class InstallError(Exception):
    pass


@dataclass
class Options:
    access: str = "direct"           # "direct" | "cloudflare"
    domain: str = ""
    public_port: int = DIRECT_PUBLIC_PORT
    admin: str = "admin"
    password: str = ""
    database_url: str = ""
    install_docker: bool = True
    services: bool = True
    assume_yes: bool = False
    reset: bool = False
    force_dns: bool = False


# ---------- çıktı ve günlük ----------
def log(line: str) -> None:
    with LOG_PATH.open("a", encoding="utf-8") as fh:
        fh.write(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {line}\n")


def banner() -> None:
    print("=" * 62)
    print(f"  MANGO PANEL - Kurulum Aracı (setup sürüm {SETUP_VERSION})")
    print("=" * 62)


def section(title: str) -> None:
    print(f"\n--- {title} ---")
    log(f"== {title}")


def ok(msg: str) -> None:
    print(f"  [OK] {msg}")
    log(f"OK: {msg}")


def warn(msg: str) -> None:
    print(f"  [UYARI] {msg}")
    log(f"UYARI: {msg}")


def info(msg: str) -> None:
    print(f"  {msg}")
    log(msg)


def have(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def run_logged(cmd: list, env: dict | None = None, cwd: Path | None = None) -> subprocess.CompletedProcess:
    log("$ " + " ".join(str(c) for c in cmd))
    result = subprocess.run(cmd, capture_output=True, text=True, env=env, cwd=cwd)
    if result.stdout.strip():
        log(result.stdout.rstrip())
    if result.stderr.strip():
        log(result.stderr.rstrip())
    return result


def must(result: subprocess.CompletedProcess, what: str) -> None:
    if result.returncode != 0:
        tail = "\n".join((result.stdout + result.stderr).strip().splitlines()[-12:])
        raise InstallError(f"{what} başarısız (kod {result.returncode}).\n{tail}\nAyrıntı: {LOG_PATH}")


def journal(unit: str, lines: int = 150) -> str:
    return run_logged(["journalctl", "-u", unit, "-n", str(lines), "--no-pager"]).stdout


def nginx_error_tail(lines: int = 60) -> str:
    try:
        return "\n".join(NGINX_ERROR_LOG.read_text(encoding="utf-8", errors="replace").splitlines()[-lines:])
    except OSError:
        return ""


# ---------- girdi ----------
def ask(prompt: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    value = input(f"  {prompt}{suffix}: ").strip()
    return value or default


def ask_yes_no(prompt: str, default: bool = True) -> bool:
    hint = "E/h" if default else "e/H"
    while True:
        answer = input(f"  {prompt} ({hint}): ").strip().lower()
        if not answer:
            return default
        if answer in ("e", "evet", "y", "yes"):
            return True
        if answer in ("h", "hayir", "hayır", "n", "no"):
            return False


def choose(prompt: str, options: list[tuple[str, str]], default_index: int) -> str:
    print(f"  {prompt}")
    for i, (_, label) in enumerate(options, 1):
        marker = " (varsayılan)" if i == default_index else ""
        print(f"    {i}) {label}{marker}")
    while True:
        answer = input(f"  Seçim [{default_index}]: ").strip() or str(default_index)
        if answer.isdigit() and 1 <= int(answer) <= len(options):
            return options[int(answer) - 1][0]
        print("  Geçersiz seçim.")


def port_free(port: int) -> bool:
    with socket.socket() as sock:
        try:
            sock.bind(("0.0.0.0", port))
            return True
        except OSError:
            return False


def free_port(start: int, exclude: set[int] = frozenset()) -> int:
    for port in range(start, start + 300):
        if port not in exclude and port_free(port):
            return port
    raise InstallError("Uygun bir port bulunamadı.")


# ---------- argümanlar ----------
def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Mango Panel kurulum aracı")
    p.add_argument("--cloudflare", action="store_true", help="Cloudflare Tunnel ile yayınla")
    p.add_argument("--domain", default="", help="Panel alan adı (Cloudflare için zorunlu)")
    p.add_argument("--port", type=int, default=DIRECT_PUBLIC_PORT, help="Doğrudan modda dış port")
    p.add_argument("--admin", default="admin", help="Yönetici kullanıcı adı")
    p.add_argument("--database-url", default="", help="PostgreSQL adresi; boşsa SQLite")
    p.add_argument("--no-service", action="store_true", help="systemd servisi kurma")
    p.add_argument("--skip-docker", action="store_true", help="Docker kurmayı atla")
    p.add_argument("--reset", action="store_true", help="Mevcut yapılandırmayı sıfırla")
    p.add_argument("--force-dns", action="store_true", help="Mevcut DNS kaydını değiştirmeye izin ver")
    p.add_argument("-y", "--yes", action="store_true", help="Sormadan, onaysız çalıştır")
    p.add_argument("--uninstall", action="store_true", help="Mango'nun kurduklarını kaldır")
    p.add_argument("--doctor", action="store_true", help="Kurulu sistemi teşhis et ve onar")
    return p.parse_args()


# ---------- ön denetim ----------
def preflight() -> dict:
    section("Ön denetim")
    if not IS_LINUX:
        raise InstallError("Kurulum yalnızca Linux sunucularda desteklenir.")
    ok(f"İşletim sistemi: {platform.system()} {platform.machine()}")
    if sys.version_info < MIN_PYTHON:
        raise InstallError(f"Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} veya üstü gerekli.")
    ok(f"Python {platform.python_version()}")

    try:
        lines = Path("/proc/meminfo").read_text().splitlines()
        mem_mb = int(next(line for line in lines if line.startswith("MemTotal")).split()[1]) // 1024
        if mem_mb < MIN_RAM_MB:
            warn(f"RAM {mem_mb} MB; en az {MIN_RAM_MB} MB önerilir.")
        else:
            ok(f"RAM: {mem_mb} MB")
    except (OSError, StopIteration, ValueError):
        warn("RAM bilgisi okunamadı.")

    free_mb = shutil.disk_usage(ROOT).free // (1024 * 1024)
    if free_mb < MIN_FREE_DISK_MB:
        warn(f"Boş disk {free_mb} MB; en az {MIN_FREE_DISK_MB} MB önerilir.")
    else:
        ok(f"Boş disk: {free_mb} MB")

    try:
        urllib.request.urlopen("https://pypi.org/simple/", timeout=8).close()
        ok("İnternet bağlantısı var")
    except Exception:
        raise InstallError("İnternet bağlantısı yok (pypi.org erişilemiyor).")

    if not (PHP_SRC / "index.php").exists() or not (WEB_SRC / "index.html").exists():
        raise InstallError("php/ veya web/ klasörü eksik. Zip'i eksiksiz açtığınızdan emin olun.")

    return {
        "root": IS_ROOT,
        "systemd": HAS_SYSTEMD,
        "docker": have("docker"),
        "venv": VENV_PY.exists(),
        "cloudflared": have("cloudflared") or (BIN_DIR / "cloudflared").exists(),
        "nginx": have("nginx"),
        "apt": have("apt-get"),
    }


# ---------- seçenekler ----------
def _existing_config() -> dict:
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            return {}
    return {}


def gather_options(args: argparse.Namespace, facts: dict) -> Options:
    existing = _existing_config()
    opts = Options(
        access="cloudflare" if args.cloudflare else "direct",
        domain=args.domain.strip().lower(),
        public_port=args.port,
        admin=args.admin,
        password=os.environ.get("MANGO_ADMIN_PASSWORD", ""),
        database_url=args.database_url,
        install_docker=not args.skip_docker,
        services=not args.no_service,
        assume_yes=args.yes,
        reset=args.reset,
        force_dns=args.force_dns,
    )

    if INTERACTIVE and not args.yes:
        section("Kurulum ayarları (Enter = varsayılan)")
        opts.access = choose(
            "Erişim yöntemi:",
            [
                ("direct", "Doğrudan: sunucu IP'si ve port üzerinden"),
                ("cloudflare", "Cloudflare Tunnel: HTTPS, port açmadan, IP gizli"),
            ],
            default_index=2 if opts.access == "cloudflare" else 1,
        )
        if opts.access == "cloudflare":
            while True:
                opts.domain = ask("Panel alan adı (ör. panel.alanadi.com)", opts.domain).lower()
                if DOMAIN_RE.match(opts.domain):
                    break
                print("  Geçersiz alan adı.")
        else:
            while True:
                port_text = ask("Panel portu", str(opts.public_port))
                if port_text.isdigit() and 1 <= int(port_text) <= 65535:
                    opts.public_port = int(port_text)
                    if port_free(opts.public_port) or opts.public_port == existing.get("public_port"):
                        break
                    print("  Bu port dolu.")
                else:
                    print("  Geçersiz port.")
        while True:
            name = ask("Yönetici kullanıcı adı", opts.admin)
            if USERNAME_RE.match(name):
                opts.admin = name
                break
            print("  3-32 karakter, yalnızca harf, rakam ve alt çizgi.")
        if not opts.password:
            pw = getpass.getpass("  Yönetici şifresi (boş = güçlü şifre üret): ")
            if pw:
                if len(pw) < 8:
                    raise InstallError("Şifre en az 8 karakter olmalı.")
                if getpass.getpass("  Şifreyi tekrar girin: ") != pw:
                    raise InstallError("Şifreler eşleşmedi.")
                opts.password = pw
        if not opts.database_url:
            db = choose(
                "Veritabanı:",
                [("sqlite", "SQLite (tek sunucu için yeterli)"),
                 ("postgres", "PostgreSQL (bağlantı adresi gerekir)")],
                default_index=1,
            )
            if db == "postgres":
                opts.database_url = ask("PostgreSQL adresi (postgresql+psycopg://kullanici:sifre@host/db)")
        if facts["root"]:
            opts.services = ask_yes_no("systemd servisi olarak kurulsun ve otomatik başlasın mı?", opts.services)

    if opts.access == "cloudflare":
        opts.public_port = int(existing.get("public_port", TUNNEL_PUBLIC_PORT))
    return validate(opts, facts)


def validate(opts: Options, facts: dict) -> Options:
    if opts.access == "cloudflare" and (not opts.domain or not DOMAIN_RE.match(opts.domain)):
        raise InstallError("Cloudflare için geçerli bir --domain gerekli (ör. panel.alanadi.com).")
    if not USERNAME_RE.match(opts.admin):
        raise InstallError("Yönetici adı 3-32 karakter olmalı (harf, rakam, _).")
    if opts.password and len(opts.password) < 8:
        raise InstallError("Yönetici şifresi en az 8 karakter olmalı.")
    if opts.database_url:
        if not opts.database_url.startswith("postgresql"):
            raise InstallError("Veritabanı adresi postgresql ile başlamalı.")
        if opts.database_url.startswith("postgresql://"):
            opts.database_url = "postgresql+psycopg://" + opts.database_url[len("postgresql://"):]
    if not facts["apt"]:
        raise InstallError("Bu araç Debian/Ubuntu (apt) sunucuları için tasarlandı.")
    if (opts.services or opts.install_docker) and not facts["root"]:
        raise InstallError("Servis kurmak ve Docker yüklemek için root gerekli (sudo).")
    if opts.services and not facts["systemd"]:
        raise InstallError("Bu sistemde systemd yok; servis kurulumu desteklenmiyor.")
    return opts


# ---------- plan ----------
def print_plan(opts: Options, facts: dict) -> None:
    section("Yapılacaklar")
    items: list[str] = []
    if not facts["venv"]:
        items.append("Python sanal ortamı (.venv) oluşturulacak")
    items.append("Python bağımlılıkları kurulacak/güncellenecek")
    if not facts["docker"]:
        items.append("Docker resmi betikle kurulacak" if opts.install_docker
                     else "Docker bulunamadı ve kurulmayacak (konteynerler çalışmaz)")
    items.append("nginx ve PHP-FPM kurulacak/yapılandırılacak (arayüz ve yönlendirme)")
    items.append(f"Web dosyaları {PUBLIC_ROOT} altına kopyalanacak")
    items.append(f"Yapılandırma yazılacak: {CONFIG_PATH.name} (mevcutsa gizli anahtar korunur)")
    items.append(f"Veritabanı: {'PostgreSQL' if opts.database_url else 'SQLite'}")
    pw_label = "belirttiğiniz şifre" if opts.password else "güçlü şifre otomatik üretilecek"
    items.append(f"Yönetici: {opts.admin} ({pw_label})")
    if opts.access == "cloudflare":
        if not facts["cloudflared"]:
            items.append("cloudflared kurulacak")
        if not CERT_PATH.exists():
            items.append("Cloudflare giriş bağlantısı gösterilecek (tarayıcıda onay gerekir)")
        items.append(f"Tünel '{tunnel_name(opts.domain)}' ve DNS kaydı {opts.domain} oluşturulacak")
    else:
        items.append(f"Dış port: {opts.public_port} (ufw aktifse açılacak)")
    if opts.services:
        items.append("systemd servisleri başlatılacak; hata olursa otomatik onarım denenecek")
    for i, item in enumerate(items, 1):
        print(f"  {i}. {item}")
    print(f"\n  Günlük dosyası: {LOG_PATH}")


def tunnel_name(domain: str) -> str:
    return (PREFIX + re.sub(r"[^a-z0-9-]", "-", domain))[:60]


# ---------- Python ortamı ----------
_apt_ready = False


def apt_install(packages: list[str]) -> None:
    global _apt_ready
    env = {**os.environ, "DEBIAN_FRONTEND": "noninteractive"}
    if not _apt_ready:
        run_logged(["apt-get", "update", "-qq"], env=env)
        _apt_ready = True
    for pkg in packages:
        run_logged(["apt-get", "install", "-y", "-qq", pkg], env=env)


def install_requirements() -> None:
    must(run_logged([str(VENV_PY), "-m", "pip", "install", "--disable-pip-version-check",
                     "-q", "-r", str(ROOT / "requirements.txt")]), "Bağımlılık kurulumu")


def step_venv() -> None:
    section("Python ortamı")
    if VENV_PY.exists():
        ok("Mevcut sanal ortam kullanılıyor")
    else:
        result = run_logged([sys.executable, "-m", "venv", str(VENV)])
        if result.returncode != 0 or not VENV_PY.exists():
            shutil.rmtree(VENV, ignore_errors=True)
            version = f"{sys.version_info.major}.{sys.version_info.minor}"
            warn("venv modülü eksik olabilir; python venv paketi kuruluyor...")
            apt_install([f"python{version}-venv", "python3-venv"])
            result = run_logged([sys.executable, "-m", "venv", str(VENV)])
            if result.returncode != 0 or not VENV_PY.exists():
                shutil.rmtree(VENV, ignore_errors=True)
                raise InstallError("Sanal ortam oluşturulamadı. 'apt install python3-venv' deneyin.")
        ok("Sanal ortam oluşturuldu")
    info("Bağımlılıklar kuruluyor (birkaç dakika sürebilir)...")
    install_requirements()
    ok("Bağımlılıklar hazır")


# ---------- web katmanı: nginx + PHP-FPM ----------
def php_socket() -> str | None:
    socks = sorted(glob.glob("/run/php/php*-fpm.sock"))
    return socks[-1] if socks else None


def php_fpm_units() -> list[str]:
    units = []
    for pattern in ("/lib/systemd/system/php*-fpm.service", "/usr/lib/systemd/system/php*-fpm.service"):
        for path in glob.glob(pattern):
            units.append(Path(path).name)
    return sorted(set(units))


def step_webstack() -> str:
    section("Web katmanı (nginx + PHP)")
    apt_install(["nginx", "php-fpm", "php-cli"])
    for unit in php_fpm_units():
        run_logged(["systemctl", "enable", "--now", unit])
    run_logged(["systemctl", "enable", "--now", "nginx"])
    default_site = Path("/etc/nginx/sites-enabled/default")
    if default_site.exists() or default_site.is_symlink():
        default_site.unlink()
        ok("nginx varsayılan sitesi kaldırıldı")

    deadline = time.time() + 30
    sock = php_socket()
    while not sock and time.time() < deadline:
        time.sleep(2)
        sock = php_socket()
    if not sock:
        raise InstallError("PHP-FPM soketi bulunamadı (/run/php/). 'systemctl status php*-fpm' kontrol edin.")
    ok(f"PHP-FPM hazır: {sock}")
    return sock


def publish_web(config: dict) -> None:
    """Web dosyalarını www-data'nın okuyabileceği klasöre kopyalar. Gizli bilgi kopyalanmaz."""
    section("Web dosyaları")
    PUBLIC_ROOT.mkdir(parents=True, exist_ok=True)
    for f in PHP_SRC.glob("*.php"):
        shutil.copy2(f, PUBLIC_ROOT / f.name)
    shutil.copytree(WEB_SRC, PUBLIC_ROOT / "static", dirs_exist_ok=True)
    public_cfg = {
        "version": PANEL_VERSION,
        "access_mode": config["access_mode"],
        "public_url": config["public_url"],
        "source_url": config["source_url"],
    }
    (PUBLIC_ROOT / "app-config.json").write_text(json.dumps(public_cfg, indent=2), encoding="utf-8")
    for path in [PUBLIC_ROOT, *PUBLIC_ROOT.rglob("*")]:
        os.chmod(path, 0o755 if path.is_dir() else 0o644)
    ok(f"Web dosyaları yayınlandı: {PUBLIC_ROOT}")


def nginx_conf(config: dict, sock: str) -> str:
    if config["access_mode"] == "cloudflare":
        listen = f"127.0.0.1:{config['public_port']}"
    else:
        listen = f"{config['public_port']}"
    return f"""map $http_upgrade $connection_upgrade {{
    default upgrade;
    ''      close;
}}

server {{
    listen {listen};
    server_name _;
    root {PUBLIC_ROOT};
    index index.php;
    client_max_body_size 16m;
    server_tokens off;

    location /api/ {{
        proxy_pass http://127.0.0.1:{config['port']};
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection $connection_upgrade;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 3600s;
    }}

    # Sunucuda yayınlanan siteler: /sites/<ad>/ -> panel, o da konteynere iletir.
    location /sites/ {{
        proxy_pass http://127.0.0.1:{config['port']}/api/sites/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 60s;
    }}

    location /static/ {{
        expires 1h;
        try_files $uri =404;
    }}

    location ~ \\.php$ {{
        try_files $uri =404;
        include fastcgi_params;
        fastcgi_pass unix:{sock};
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    }}

    location / {{
        try_files $uri /index.php?$args;
    }}

    location ~ /\\. {{
        deny all;
    }}
}}
"""


def write_nginx(config: dict, sock: str) -> None:
    NGINX_CONF.write_text(nginx_conf(config, sock), encoding="utf-8")
    test = run_logged(["nginx", "-t"])
    if test.returncode != 0:
        raise InstallError(f"nginx yapılandırması geçersiz:\n{test.stderr.strip()}")
    must(run_logged(["systemctl", "restart", "nginx"]), "nginx yeniden başlatma")
    ok(f"nginx yapılandırıldı (dış port: {config['public_port']}, API: 127.0.0.1:{config['port']})")


# ---------- yapılandırma ----------
def public_ip() -> str:
    for url in ("https://api.ipify.org", "https://ifconfig.me/ip"):
        try:
            with urllib.request.urlopen(url, timeout=5) as resp:
                ip = resp.read().decode().strip()
                if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", ip):
                    return ip
        except Exception:
            continue
    warn("Genel IP bulunamadı; adres localhost olarak yazılacak.")
    return "localhost"


def write_config(config: dict) -> None:
    CONFIG_PATH.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")
    os.chmod(CONFIG_PATH, 0o600)


def step_config(opts: Options) -> dict:
    section("Yapılandırma")
    existing = {} if opts.reset else _existing_config()
    if existing:
        ok("Mevcut yapılandırma bulundu; gizli anahtar korunuyor")

    public_port = opts.public_port
    if public_port != existing.get("public_port") and not port_free(public_port):
        if opts.assume_yes:
            public_port = free_port(public_port)
            warn(f"Port {opts.public_port} dolu; {public_port} kullanılacak.")
        else:
            raise InstallError(f"{public_port} portu dolu.")

    api_port = existing.get("port") or free_port(API_PORT_START, exclude={public_port})
    if api_port == public_port:
        api_port = free_port(api_port + 1, exclude={public_port})

    database_url = (opts.database_url or existing.get("database_url")
                    or f"sqlite:///{DATA_DIR / 'mango.db'}")
    if database_url.startswith("postgresql"):
        must(run_logged([str(VENV_PY), "-m", "pip", "install", "-q", "psycopg[binary]"]),
             "PostgreSQL sürücüsü kurulumu")
        ok("PostgreSQL sürücüsü kuruldu")

    if opts.access == "cloudflare":
        public_url = f"https://{opts.domain}"
    else:
        public_url = f"http://{public_ip()}:{public_port}"

    config = {
        "secret_key": existing.get("secret_key") or secrets.token_urlsafe(48),
        "access_mode": opts.access,
        "database_url": database_url,
        "host": "127.0.0.1",
        "port": api_port,
        "public_port": public_port,
        "public_url": public_url,
        "source_url": existing.get("source_url", SOURCE_URL),
        "data_dir": str(DATA_DIR / "servers"),
    }
    (DATA_DIR / "servers").mkdir(parents=True, exist_ok=True)
    write_config(config)
    ok(f"Yapılandırma yazıldı (API: 127.0.0.1:{api_port}, dış port: {public_port})")
    return config


# ---------- yönetici ----------
def step_admin(opts: Options) -> str | None:
    section("Yönetici hesabı")
    generated = not opts.password
    password = opts.password or secrets.token_urlsafe(14)
    env = {**os.environ, "MANGO_CONFIG": str(CONFIG_PATH), "MANGO_ADMIN_PASSWORD": password}
    result = run_logged([str(VENV_PY), "-m", "mango", "create-admin", opts.admin], env=env, cwd=ROOT)
    output = (result.stdout + result.stderr).strip()
    if result.returncode == 0:
        CRED_PATH.write_text(f"Kullanıcı: {opts.admin}\nŞifre: {password}\n", encoding="utf-8")
        os.chmod(CRED_PATH, 0o600)
        ok(f"Yönetici oluşturuldu: {opts.admin}")
        return password if generated else None
    if "zaten var" in output:
        ok(f"Yönetici zaten var: {opts.admin} (mevcut şifre geçerli)")
        return None
    raise InstallError(f"Yönetici oluşturulamadı:\n{output}")


# ---------- Docker ----------
def step_docker(opts: Options) -> None:
    section("Docker")
    if not have("docker"):
        if not opts.install_docker:
            warn("Docker yok; panel çalışır ama sunucu oluşturulamaz.")
            return
        info("Docker resmi betikle kuruluyor (birkaç dakika sürebilir)...")
        with tempfile.TemporaryDirectory() as tmp:
            script = Path(tmp) / "get-docker.sh"
            urllib.request.urlretrieve(DOCKER_SCRIPT_URL, script)
            must(run_logged(["sh", str(script)]), "Docker kurulumu")
        ok("Docker kuruldu")
    run_logged(["systemctl", "enable", "--now", "docker"])
    deadline = time.time() + 60
    while time.time() < deadline:
        if have("docker") and run_logged(["docker", "info"]).returncode == 0:
            ok("Docker çalışıyor")
            return
        time.sleep(2)
    raise InstallError("Docker çalışmıyor. 'systemctl status docker' ile kontrol edin.")


# ---------- cloudflared ----------
def step_cloudflared() -> str:
    section("cloudflared")
    local = BIN_DIR / "cloudflared"
    found = shutil.which("cloudflared") or (str(local) if local.exists() else None)
    if found:
        ok(f"Bulundu: {found}")
        return found
    if platform.machine() not in ("x86_64", "amd64"):
        raise InstallError("cloudflared otomatik kurulamıyor (yalnızca x86_64). Elle kurun.")
    target_dir = Path("/usr/local/bin") if IS_ROOT else BIN_DIR
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / "cloudflared"
    info("cloudflared indiriliyor...")
    urllib.request.urlretrieve(CLOUDFLARED_URL, target)
    target.chmod(0o755)
    ok(f"Kuruldu: {target}")
    return str(target)


def cloudflare_login(cf: str) -> None:
    section("Cloudflare girişi")
    if CERT_PATH.exists():
        ok("Cloudflare girişi zaten yapılmış")
        return
    proc = subprocess.Popen([cf, "tunnel", "login"], stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True)
    shown = False
    assert proc.stdout is not None
    for line in proc.stdout:
        text = line.rstrip()
        log(f"login: {text}")
        url = re.search(r"https://\S+", text)
        if url and not shown:
            shown = True
            print("\n" + "!" * 62)
            print("  CLOUDFLARE GİRİŞ BAĞLANTISI (TEK MANUEL ADIM):")
            print()
            print(f"  {url.group(0)}")
            print()
            print("  Tarayıcıda açın, Cloudflare hesabınızla giriş yapın, alan adını")
            print("  seçin. Onaydan sonra kurulum kendiliğinden devam eder.")
            print("!" * 62 + "\n")
        elif text:
            print(f"  {text}")
    if proc.wait() != 0 or not CERT_PATH.exists():
        raise InstallError("Cloudflare girişi tamamlanamadı. Kurulumu yeniden çalıştırın.")
    ok("Cloudflare girişi tamamlandı")


def find_tunnel_id(cf: str, name: str) -> str | None:
    result = run_logged([cf, "tunnel", "list", "-o", "json"])
    if result.returncode != 0 or not result.stdout.strip():
        return None
    for tunnel in json.loads(result.stdout):
        if tunnel.get("name") == name and not tunnel.get("deleted_at"):
            return tunnel["id"]
    return None


def dns_cname_target(host: str) -> str | None:
    dig = shutil.which("dig")
    if dig is None and IS_ROOT:
        apt_install(["dnsutils"])
        dig = shutil.which("dig")
    if dig is None:
        return None
    result = run_logged([dig, "+short", "CNAME", host, "@1.1.1.1"])
    lines = [line.strip() for line in result.stdout.splitlines() if line.strip()]
    return lines[0].rstrip(".").lower() if lines else None


def dns_has_records(host: str) -> bool:
    """Hostname herhangi bir kayıtla (CNAME veya A) çözülüyor mu?"""
    dig = shutil.which("dig")
    if dig is None:
        return False
    result = run_logged([dig, "+short", host, "@1.1.1.1"])
    return bool(result.stdout.strip())


def read_tunnel_config(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    return {
        "tunnel": re.search(r"^tunnel:\s*(\S+)", text, re.M).group(1),
        "creds": re.search(r"^credentials-file:\s*(\S+)", text, re.M).group(1),
        "domain": re.search(r"hostname:\s*(\S+)", text).group(1),
    }


def write_tunnel_config(path: Path, tunnel_id: str, creds: str, domain: str, port: int) -> None:
    path.write_text(
        f"tunnel: {tunnel_id}\n"
        f"credentials-file: {creds}\n"
        "ingress:\n"
        f"  - hostname: {domain}\n"
        f"    service: http://127.0.0.1:{port}\n"
        "  - service: http_status:404\n",
        encoding="utf-8",
    )
    os.chmod(path, 0o600)


def cloudflare_tunnel(cf: str, opts: Options, public_port: int) -> Path:
    section("Cloudflare tüneli ve DNS")
    name = tunnel_name(opts.domain)

    tunnel_id = find_tunnel_id(cf, name)
    if tunnel_id and not (CF_DIR / f"{tunnel_id}.json").exists():
        warn("Tünelin kimlik dosyası yok; tünel yeniden oluşturuluyor.")
        run_logged([cf, "tunnel", "cleanup", name])
        run_logged([cf, "tunnel", "delete", "-f", name])
        tunnel_id = None

    if tunnel_id:
        ok(f"Mevcut tünel kullanılıyor: {name} ({tunnel_id})")
    else:
        created = run_logged([cf, "tunnel", "create", name])
        must(created, "Tünel oluşturma")
        match = UUID_RE.search(created.stdout + created.stderr)
        if not match:
            raise InstallError("Tünel kimliği çıktıdan okunamadı.")
        tunnel_id = match.group(0)
        ok(f"Tünel oluşturuldu: {name} ({tunnel_id})")

    creds = CF_DIR / f"{tunnel_id}.json"
    if not creds.exists():
        raise InstallError(f"Tünel kimlik dosyası bulunamadı: {creds}")

    expected = f"{tunnel_id}.cfargotunnel.com"
    current = dns_cname_target(opts.domain)
    if current == expected:
        ok(f"DNS kaydı zaten bu tünele bağlı: {opts.domain}")
    else:
        config_path = CF_DIR / f"config-{name}.yml"
        previous = read_tunnel_config(config_path)["tunnel"] if config_path.exists() else None
        ours = current is not None and previous is not None and current == f"{previous}.cfargotunnel.com"
        if current and not ours and not opts.force_dns:
            raise InstallError(
                f"{opts.domain} kaydı başka bir hedefe bağlı: {current}\n"
                "Bu kayıt başka bir servise ait olabilir; DEĞİŞTİRİLMEDİ.\n"
                "Bilerek değiştirmek için --force-dns ekleyip tekrar çalıştırın."
            )
        dns = run_logged([cf, "tunnel", "route", "dns", "--overwrite-dns", name, opts.domain])
        must(dns, "DNS kaydı oluşturma (alan adı bu Cloudflare hesabında olmalı)")
        ok(f"DNS kaydı hazır: {opts.domain} -> tünel (proxy açık)")

    config_path = CF_DIR / f"config-{name}.yml"
    write_tunnel_config(config_path, tunnel_id, str(creds), opts.domain, public_port)
    ok(f"Tünel yapılandırması: {config_path}")
    return config_path


# ---------- servisler ----------
def write_unit(path: Path, description: str, exec_start: str, after: str, env: dict | None = None) -> None:
    env_lines = "".join(f"Environment={k}={v}\n" for k, v in (env or {}).items())
    path.write_text(
        "[Unit]\n"
        f"Description={description}\n"
        f"After={after}\n"
        "Wants=network-online.target\n\n"
        "[Service]\n"
        f"WorkingDirectory={ROOT}\n"
        f"{env_lines}"
        f"ExecStart={exec_start}\n"
        "Restart=always\n"
        "RestartSec=5\n"
        "LimitNOFILE=65535\n\n"
        "[Install]\n"
        "WantedBy=multi-user.target\n",
        encoding="utf-8",
    )


def panel_env(config: dict) -> dict:
    return {"MANGO_CONFIG": str(CONFIG_PATH), "PYTHONUNBUFFERED": "1"}


def check_panel_import(config: dict) -> None:
    env = {**os.environ, **panel_env(config)}
    result = run_logged([str(VENV_PY), "-c", "import mango.main"], env=env, cwd=ROOT)
    if result.returncode != 0:
        warn("Panel kodu içe aktarılamadı; bağımlılıklar yeniden kuruluyor...")
        install_requirements()
        must(run_logged([str(VENV_PY), "-c", "import mango.main"], env=env, cwd=ROOT),
             "Panel kodunun içe aktarılması")
    ok("Panel kodu doğrulandı")


def step_services(opts: Options, config: dict, cf: str | None, cf_config: Path | None) -> bool:
    section("Servisler")
    if not opts.services:
        warn("Servis kurulmadı. Elle başlatmak için:")
        info(f"cd {ROOT} && MANGO_CONFIG={CONFIG_PATH} {VENV_PY} -m mango serve")
        return False
    check_panel_import(config)
    units = ["mango-panel"]
    write_unit(UNIT_PANEL, "Mango Panel API", f"{VENV_PY} -m mango serve",
               "network-online.target docker.service", panel_env(config))
    if cf and cf_config:
        write_unit(UNIT_TUNNEL, "Mango Panel Cloudflare Tunnel",
                   f"{cf} tunnel --config {cf_config} --no-autoupdate run", "network-online.target")
        units.insert(0, "mango-tunnel")
    must(run_logged(["systemctl", "daemon-reload"]), "systemd yeniden yükleme")
    must(run_logged(["systemctl", "enable", "--now", *units]), "Servis başlatma")
    for unit in units:
        ok(f"{unit} başlatıldı")
    return True


def step_firewall(opts: Options, config: dict) -> None:
    if opts.access != "direct" or not have("ufw"):
        return
    if "Status: active" in run_logged(["ufw", "status"]).stdout:
        run_logged(["ufw", "allow", f"{config['public_port']}/tcp"])
        ok(f"Güvenlik duvarı: {config['public_port']}/tcp açıldı")


# ---------- doğrulama ve otomatik onarım ----------
def http_ok(url: str, timeout: float = 8) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return resp.status == 200
    except Exception:
        return False


def wait_http(url: str, seconds: int) -> bool:
    deadline = time.time() + seconds
    while time.time() < deadline:
        if http_ok(url):
            return True
        time.sleep(3)
    return False


def tunnel_registered() -> bool:
    return "Registered tunnel connection" in journal("mango-tunnel", 200)


def heal_stack(config: dict, cf_config: Path | None) -> dict:
    """API, nginx ve PHP katmanlarını kontrol eder; bilinen sorunları düzeltir."""
    for attempt in range(1, 4):
        api_ok = wait_http(f"http://127.0.0.1:{config['port']}/api/system", 30)
        web_ok = wait_http(f"http://127.0.0.1:{config['public_port']}/health.php", 15)
        if api_ok and web_ok:
            ok("API ve web katmanı yerel olarak yanıt veriyor")
            return config

        if not api_ok:
            logs = journal("mango-panel")
            warn(f"Python API yanıt vermiyor (deneme {attempt}/3). Günlük inceleniyor...")
            if re.search(r"Address already in use|\[Errno 98\]", logs):
                config["port"] = free_port(config["port"] + 1, exclude={config["public_port"]})
                write_config(config)
                warn(f"API portu değiştirildi: {config['port']}")
                sock = php_socket()
                if sock:
                    write_nginx(config, sock)
            elif re.search(r"ModuleNotFoundError|ImportError", logs):
                warn("Eksik Python modülü; bağımlılıklar yeniden kuruluyor.")
                install_requirements()
            elif re.search(r"unable to open database|OperationalError", logs):
                warn("Veritabanı erişim sorunu; veri klasörü hazırlanıyor.")
                (DATA_DIR / "servers").mkdir(parents=True, exist_ok=True)
            run_logged(["systemctl", "restart", "mango-panel"])

        if not web_ok:
            errors = nginx_error_tail()
            warn(f"Web katmanı yanıt vermiyor (deneme {attempt}/3). nginx günlüğü inceleniyor...")
            if re.search(r"bind\(\) to .* failed|Address already in use", errors):
                config["public_port"] = free_port(config["public_port"] + 1, exclude={config["port"]})
                write_config(config)
                warn(f"Dış port değiştirildi: {config['public_port']}")
                sock = php_socket()
                if sock:
                    write_nginx(config, sock)
                if cf_config and cf_config.exists():
                    data = read_tunnel_config(cf_config)
                    write_tunnel_config(cf_config, data["tunnel"], data["creds"],
                                        data["domain"], config["public_port"])
                    run_logged(["systemctl", "restart", "mango-tunnel"])
            elif re.search(r"php|fastcgi", errors, re.I):
                warn("PHP-FPM sorunu; yeniden başlatılıyor.")
                for unit in php_fpm_units():
                    run_logged(["systemctl", "restart", unit])
            run_logged(["systemctl", "restart", "nginx"])
        time.sleep(3)

    print("\n  --- panel günlüğünün son satırları ---")
    print("\n".join(journal("mango-panel", 25).splitlines()[-25:]))
    print("\n  --- nginx hata günlüğünün son satırları ---")
    print("\n".join(nginx_error_tail(25).splitlines()[-25:]))
    raise InstallError("Web/API katmanı başlatılamadı. Yukarıdaki günlükleri ve install.log'u inceleyin.")


def heal_tunnel(cf: str, cf_config: Path | None) -> None:
    for attempt in range(1, 3):
        if tunnel_registered():
            ok("Cloudflare tüneli bağlandı")
            return
        logs = journal("mango-tunnel", 150)
        warn(f"Tünel henüz bağlanmadı (deneme {attempt}/2). Günlük inceleniyor...")
        if re.search(r"cert\.pem|certificate|not authorized|login", logs, re.I) and not CERT_PATH.exists():
            warn("Cloudflare girişi geçersiz; yeniden giriş istenecek.")
            cloudflare_login(cf)
        run_logged(["systemctl", "restart", "mango-tunnel"])
        time.sleep(15)
    if not tunnel_registered():
        print("\n  --- tünel günlüğünün son satırları ---")
        print("\n".join(journal("mango-tunnel", 25).splitlines()[-25:]))
        raise InstallError("Tünel bağlanamadı. journalctl -u mango-tunnel -n 100 ile inceleyin.")


def step_verify(opts: Options, config: dict, cf: str | None, cf_config: Path | None, started: bool) -> dict:
    section("Doğrulama ve otomatik onarım")
    if not started:
        info("Servis kurulmadığı için doğrulama atlandı.")
        return config
    config = heal_stack(config, cf_config)
    if opts.access == "cloudflare" and cf:
        heal_tunnel(cf, cf_config)
        if wait_http(f"https://{opts.domain}/api/system", 120):
            ok(f"Dış adres HTTPS ile yanıt veriyor: https://{opts.domain}")
        else:
            warn("Dış adres henüz yanıt vermiyor.")
            info(f"Teşhis için: sudo python3 {Path(__file__).name} --doctor")
    return config


# ---------- teşhis (--doctor) ----------
def doctor() -> None:
    section("Teşhis (doctor)")
    if not CONFIG_PATH.exists():
        raise InstallError("mango.json yok; önce kurulum yapın.")
    config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    failures: list[str] = []

    def check(label: str, passed: bool, detail: str = "") -> bool:
        suffix = f" -- {detail}" if detail else ""
        print(f"  [{'OK' if passed else 'HATA'}] {label}{suffix}")
        log(f"DOCTOR {'OK' if passed else 'HATA'}: {label}{suffix}")
        if not passed:
            failures.append(label)
        return passed

    def active(unit: str) -> bool:
        return run_logged(["systemctl", "is-active", unit]).stdout.strip() == "active"

    check("Python API servisi aktif", active("mango-panel"))
    check("API yerelde yanıt veriyor", http_ok(f"http://127.0.0.1:{config['port']}/api/system"),
          f"127.0.0.1:{config['port']}")
    check("nginx servisi aktif", active("nginx"))
    check("PHP-FPM servisi aktif", any(active(u) for u in php_fpm_units()) if php_fpm_units() else False)
    check("Web katmanı yanıt veriyor", http_ok(f"http://127.0.0.1:{config['public_port']}/health.php"),
          f"127.0.0.1:{config['public_port']}")
    check("Arayüz sayfası (PHP) çalışıyor",
          http_ok(f"http://127.0.0.1:{config['public_port']}/"), "PHP index.php")

    if config.get("access_mode") != "cloudflare":
        print("\n  Doğrudan erişim modu: Cloudflare kontrolü yapılmadı.")
        print(f"  Dış adres: {config['public_url']}")
        return

    domain = urlparse(config["public_url"]).hostname or ""
    name = tunnel_name(domain)
    cfg_path = CF_DIR / f"config-{name}.yml"
    if not cfg_path.exists():
        check("Tünel yapılandırması var", False, str(cfg_path))
        return
    tunnel = read_tunnel_config(cfg_path)
    tunnel_port = re.search(r"127\.0\.0\.1:(\d+)", cfg_path.read_text()).group(1)
    check("Tünel, nginx'in dış portuna bakıyor", tunnel_port == str(config["public_port"]),
          f"tünel {tunnel_port}, nginx {config['public_port']}")

    tunnel_active = active("mango-tunnel")
    check("mango-tunnel servisi aktif", tunnel_active)
    registered = tunnel_registered()
    check("Tünel Cloudflare'e bağlı", registered,
          "" if registered else "'Registered tunnel connection' günlükte yok")

    expected = f"{tunnel['tunnel']}.cfargotunnel.com"
    current = dns_cname_target(domain)
    # Cloudflare turuncu bulutlu (proxy) kayıtlar CNAME yerine A kaydı olarak çözülür.
    proxied = current is None and dns_has_records(domain)
    dns_ok = check("DNS kaydı bu tünele bakıyor", current == expected or proxied,
                   f"CNAME: {current or 'yok (proxy kaydı olabilir)'} | beklenen tünel: {expected}")
    parent = ".".join(domain.split(".")[1:])
    if parent and dns_has_records(f"mango-wildcard-test-{secrets.token_hex(4)}.{parent}"):
        warn(f"{parent} alanında wildcard (*) DNS kaydı var; diğer servislerle çakışabilir.")

    cf = shutil.which("cloudflared") or str(BIN_DIR / "cloudflared")
    rule = run_logged([cf, "tunnel", "--config", str(cfg_path), "ingress", "rule", f"https://{domain}/"])
    rule_ok = rule.returncode == 0 and f"127.0.0.1:{config['public_port']}" in rule.stdout
    check("Ingress kuralı nginx'e yönlendiriyor", rule_ok)

    print()
    if not tunnel_active or not registered:
        warn("Tünel yeniden başlatılıyor...")
        run_logged(["systemctl", "restart", "mango-tunnel"])
        time.sleep(15)
        check("Tünel bağlandı (yeniden başlatma sonrası)", tunnel_registered())
    if not dns_ok:
        warn("DNS kaydı bu tünele yönlendiriliyor (yalnızca bu alan adı)...")
        dns = run_logged([cf, "tunnel", "route", "dns", "--overwrite-dns", name, domain])
        check("DNS kaydı düzeltildi", dns.returncode == 0)
        time.sleep(5)
        check("DNS kaydı artık var", dns_has_records(domain))

    public_ok = wait_http(f"https://{domain}/api/system", 60)
    check("Dış adres HTTPS ile yanıt veriyor", public_ok, f"https://{domain}")
    if not public_ok:
        print("\n  Dış adres hâlâ hata veriyorsa:")
        print("   1) Cloudflare panelinde bu alan adında başka DNS kaydı, Worker veya Page Rule var mı?")
        print("   2) journalctl -u mango-tunnel -n 80 --no-pager")
        print(f"   3) Günlük: {LOG_PATH}")
    print("\n  Sonuç: " + ("TÜM KONTROLLER GEÇTİ" if not failures else f"{len(failures)} kontrol başarısız"))


# ---------- kaldırma ----------
def uninstall(assume_yes: bool) -> None:
    section("Kaldırma")
    print("  Silinecekler:")
    print("   - mango-panel ve mango-tunnel servisleri")
    print("   - nginx Mango yapılandırması ve /var/lib/mango/www")
    print("   - .venv, data/ (sunucu verileri dahil), mango.json, mango-admin.txt, bin/")
    print("   - Mango'nun oluşturduğu Cloudflare tünelleri (yalnızca 'mango-' ile başlayan)")
    print("  Silinmeyecekler: proje kodu, nginx/PHP paketleri, Cloudflare girişi, diğer tüneller.")
    if not assume_yes and INTERACTIVE and not ask_yes_no("Devam edilsin mi?", False):
        print("  İptal edildi.")
        return

    for unit, path in (("mango-panel", UNIT_PANEL), ("mango-tunnel", UNIT_TUNNEL)):
        if path.exists():
            run_logged(["systemctl", "disable", "--now", unit])
            path.unlink()
            ok(f"{unit} servisi kaldırıldı")
    if HAS_SYSTEMD:
        run_logged(["systemctl", "daemon-reload"])
        run_logged(["systemctl", "reset-failed"])

    if NGINX_CONF.exists():
        NGINX_CONF.unlink()
        if have("nginx") and run_logged(["nginx", "-t"]).returncode == 0:
            run_logged(["systemctl", "reload", "nginx"])
        ok("nginx Mango yapılandırması kaldırıldı")
    if PUBLIC_ROOT.exists():
        shutil.rmtree(PUBLIC_ROOT, ignore_errors=True)

    if have("docker"):
        ids = run_logged(["docker", "ps", "-aq", "--filter", "label=mango.server"]).stdout.split()
        if ids:
            run_logged(["docker", "rm", "-f", *ids])
            ok(f"{len(ids)} sunucu konteyneri silindi")

    cf = shutil.which("cloudflared") or str(BIN_DIR / "cloudflared")
    if Path(cf).exists():
        for cfg in CF_DIR.glob(f"config-{PREFIX}*.yml"):
            name = cfg.stem.replace("config-", "", 1)
            run_logged([cf, "tunnel", "cleanup", name])
            run_logged([cf, "tunnel", "delete", "-f", name])
            ok(f"Cloudflare tüneli silindi: {name}")

    for path in (VENV, DATA_DIR, BIN_DIR, CONFIG_PATH, CRED_PATH):
        if path.is_dir():
            shutil.rmtree(path, ignore_errors=True)
        elif path.exists():
            path.unlink()
    for cfg in CF_DIR.glob(f"config-{PREFIX}*.yml"):
        cfg.unlink()
    ok("Üretilen dosyalar silindi")
    info("DNS kaydı Cloudflare panelinde kalabilir; Mango'ya aitse elle silebilirsiniz.")


# ---------- ana akış ----------
def main() -> None:
    args = parse_args()
    banner()

    if args.uninstall:
        if not IS_ROOT:
            raise InstallError("Kaldırma için root gerekli (sudo).")
        uninstall(args.yes)
        return
    if args.doctor:
        if not IS_ROOT:
            raise InstallError("Teşhis için root gerekli (sudo).")
        doctor()
        return

    facts = preflight()
    opts = gather_options(args, facts)
    print_plan(opts, facts)
    if not opts.assume_yes:
        if not INTERACTIVE:
            raise InstallError("Etkileşimsiz ortamda onay alınamaz; --yes ekleyin.")
        if not ask_yes_no("\nBu plan uygulansın mı?", True):
            print("İptal edildi. Hiçbir değişiklik yapılmadı.")
            return

    log(f"--- Kurulum başladı (sürüm {SETUP_VERSION}): access={opts.access} admin={opts.admin} ---")
    step_venv()
    step_docker(opts)
    sock = step_webstack()
    config = step_config(opts)
    shown_password = step_admin(opts)
    publish_web(config)
    write_nginx(config, sock)

    cf = cf_config = None
    if opts.access == "cloudflare":
        cf = step_cloudflared()
        cloudflare_login(cf)
        cf_config = cloudflare_tunnel(cf, opts, config["public_port"])

    started = step_services(opts, config, cf, cf_config)
    step_firewall(opts, config)
    config = step_verify(opts, config, cf, cf_config, started)

    print("\n" + "=" * 62)
    print("  KURULUM TAMAMLANDI")
    print("=" * 62)
    print(f"  Panel adresi : {config['public_url']}")
    print(f"  Erişim modu  : {config['access_mode']}")
    print(f"  Yönetici     : {opts.admin}")
    if shown_password:
        print(f"  Şifre        : {shown_password}")
        print(f"  Kaydedildi   : {CRED_PATH}")
    else:
        print("  Şifre        : mevcut şifre geçerli")
    if opts.access == "cloudflare":
        print("  Not          : Cloudflare modunda oyun sunucusu oluşturulamaz (web/PHP/Node/Python).")
    print(f"  Teşhis       : sudo python3 {Path(__file__).name} --doctor")
    print(f"  Günlük       : {LOG_PATH}")
    print(f"  Kaldırmak için: sudo python3 {Path(__file__).name} --uninstall")
    print("=" * 62)


if __name__ == "__main__":
    try:
        main()
    except InstallError as exc:
        print(f"\n[HATA] {exc}", file=sys.stderr)
        log(f"HATA: {exc}")
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nKurulum iptal edildi.", file=sys.stderr)
        sys.exit(130)
