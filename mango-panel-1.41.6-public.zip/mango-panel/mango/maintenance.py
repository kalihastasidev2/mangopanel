"""Sunucuya özel bakım modu (1.35.0). Yalnızca yönetici açıp kapatır.

Bakımdaki sunucunun herkese açık sitesi bakım sayfası gösterir, VPS terminali açılmaz.
Sunucu sahibi sayfada bir bilgi bandı görür."""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from .api import audit
from .db import Server, User
from .security import admin_only, get_db

router = APIRouter(prefix="/api")


class ServerMaintenanceIn(BaseModel):
    on: bool
    message: str | None = Field(None, max_length=300)


@router.patch("/admin/servers/{server_id}/maintenance")
def set_server_maintenance(server_id: int, body: ServerMaintenanceIn,
                           admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    server = db.get(Server, server_id)
    if server is None:
        raise HTTPException(404, "Sunucu bulunamadı")
    server.maintenance = body.on
    server.maintenance_message = (body.message or "").strip() or None
    audit(db, admin.username, "server.maintenance", server.name, "açık" if body.on else "kapalı")
    db.commit()
    return {"ok": True, "maintenance": server.maintenance, "maintenance_message": server.maintenance_message or ""}
