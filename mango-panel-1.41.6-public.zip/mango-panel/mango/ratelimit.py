"""Basit bellek içi hız sınırlayıcı (giriş ve kayıt denemeleri için).

Not: Tek süreçli kurulum için yeterlidir. Süreç yeniden başlarsa sayaçlar sıfırlanır.
Panel Cloudflare/nginx arkasında çalıştığından istemci IP'si güvenilir değildir; bu yüzden
giriş denemeleri kullanıcı adına, kayıtlar ise genel olarak sınırlandırılır."""
import threading
import time


class RateLimiter:
    def __init__(self, limit: int, window_seconds: int):
        self.limit = limit
        self.window = window_seconds
        self._hits: dict[str, list[float]] = {}
        self._lock = threading.Lock()

    def _recent(self, key: str, now: float) -> list[float]:
        return [t for t in self._hits.get(key, []) if now - t < self.window]

    def blocked(self, key: str) -> bool:
        with self._lock:
            now = time.monotonic()
            hits = self._recent(key, now)
            self._hits[key] = hits
            return len(hits) >= self.limit

    def hit(self, key: str) -> None:
        with self._lock:
            now = time.monotonic()
            hits = self._recent(key, now)
            hits.append(now)
            self._hits[key] = hits

    def reset(self, key: str) -> None:
        with self._lock:
            self._hits.pop(key, None)


# Yanlış şifre denemeleri: kullanıcı adı başına 10 denemede 15 dakika kilit.
login_failures = RateLimiter(limit=10, window_seconds=15 * 60)
# Kayıt: tüm panel genelinde saatte en fazla 20 yeni hesap.
registrations = RateLimiter(limit=20, window_seconds=60 * 60)


class WindowCounter:
    """Anahtar başına kayan pencere sayacı. allow() sınır içindeyse isteği sayar ve True döner."""

    def __init__(self, window_seconds: int = 60):
        self.window = window_seconds
        self._hits: dict[str, list[float]] = {}
        self._lock = threading.Lock()

    def allow(self, key: str, limit: int) -> bool:
        with self._lock:
            now = time.monotonic()
            hits = [t for t in self._hits.get(key, []) if now - t < self.window]
            if len(hits) >= limit:
                self._hits[key] = hits
                return False
            hits.append(now)
            self._hits[key] = hits
            if len(self._hits) > 10000:  # bellek: süresi dolmuş anahtarları at
                self._hits = {k: v for k, v in self._hits.items() if v and now - v[-1] < self.window}
            return True


# API ve site adresleri: IP başına, sunucu başına dakikalık sınır (ayarlardan değiştirilir).
app_requests = WindowCounter(60)
