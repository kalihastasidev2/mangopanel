"""Discord REST API istemcisi (yalnızca standart kütüphane kullanır)."""
import json
import urllib.error
import urllib.request

API = "https://discord.com/api/v10"
PERM_VIEW_CHANNEL = 1 << 10  # 1024: @everyone bu kanalları göremesin


class DiscordError(Exception):
    """Discord isteği başarısız olduğunda fırlatılır; mesaj kullanıcıya gösterilebilir."""


def _call(method: str, path: str, token: str, body: dict | None = None):
    data = json.dumps(body).encode() if body is not None else None
    request = urllib.request.Request(
        API + path, data=data, method=method,
        headers={
            "Authorization": f"Bot {token}",
            "Content-Type": "application/json",
            "User-Agent": "MangoPanel (https://github.com/your-org/mango-panel, 1.22.0)",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as resp:
            raw = resp.read()
            return json.loads(raw) if raw else None
    except urllib.error.HTTPError as exc:
        try:
            message = json.loads(exc.read() or b"{}").get("message", "")
        except (ValueError, AttributeError):
            message = ""
        if exc.code == 401:
            message = "Bot token'ı geçersiz"
        raise DiscordError(message or f"Discord hatası ({exc.code})")
    except (urllib.error.URLError, TimeoutError):
        raise DiscordError("Discord'a ulaşılamadı")


def me(token: str) -> dict:
    return _call("GET", "/users/@me", token)


def guild(token: str, guild_id: str) -> dict:
    return _call("GET", f"/guilds/{guild_id}", token)


def create_category(token: str, guild_id: str, name: str) -> dict:
    return _call("POST", f"/guilds/{guild_id}/channels", token, {"name": name, "type": 4})


def create_text_channel(token: str, guild_id: str, name: str, parent_id: str) -> dict:
    """Kanalı oluşturur; herkes göremesin diye @everyone için görüntüleme yetkisini kapatır."""
    return _call("POST", f"/guilds/{guild_id}/channels", token, {
        "name": name,
        "type": 0,
        "parent_id": parent_id,
        "permission_overwrites": [{"id": guild_id, "type": 0, "deny": str(PERM_VIEW_CHANNEL)}],
    })


def add_role(token: str, guild_id: str, user_id: str, role_id: str) -> None:
    _call("PUT", f"/guilds/{guild_id}/members/{user_id}/roles/{role_id}", token)
