"""Panel ayarları ve denetim kaydı için küçük yardımcılar."""
from sqlalchemy.orm import Session

from .db import AppSetting, AuditLog

DEFAULTS = {
    "registration_enabled": "1",    # kayıt açık mı
    "registration_approval": "0",   # 1.40.4: yeni kayıtlar yönetici onayı beklesin mi
    "default_max_servers": "2",     # yeni kullanıcıların sunucu limiti
    "max_memory_mb": "4096",        # kullanıcıların bir sunucuya verebileceği en fazla RAM
    "max_cpu_percent": "400",       # kullanıcıların bir sunucuya verebileceği en fazla CPU
    "max_disk_mb": "5120",          # kullanıcıların sunucu klasörü için en fazla disk
    "maintenance_mode": "0",        # 1: yalnızca yöneticiler kullanabilir
    "announcement": "",             # ana sayfada gösterilen duyuru metni
    "announcement_enabled": "0",    # duyuru bandı açık mı
    "disabled_eggs": "",            # kapatılmış egg'lerin virgülle ayrılmış listesi
    "site_name": "Mango Panel",     # başlıkta ve sekmede görünen ad
    "logo_text": "",                # boşsa panelin kendi simgesi; doluysa kısa metin/simge
    "self_service_servers": "0",    # 1: kullanıcılar kendi sunucusunu oluşturabilir
    "discord_client_id": "",        # Discord uygulaması (1.36.0)
    "discord_client_secret": "",    # Discord client secret (yalnızca yazılır, geri okunmaz)
    "alert_webhook_url": "",        # kötüye kullanım uyarıları için https webhook (1.32.0)
    "domain_cname_target": "",      # özel domain: alt alanlar için CNAME hedefi (boşsa panel adresi)
    "domain_ip": "",                # özel domain: kök domain için A kaydı IP'si
    "cf_api_token": "",             # Cloudflare for SaaS API token (yalnızca yazılır, geri okunmaz)
    "cf_zone_id": "",               # Cloudflare zone kimliği (custom hostname'lerin oluşturulduğu zone)
    "site_subdomains": "0",         # 1.40.6: alt alan adı DNS kaydı açılsın mı (kapalıysa /sites/<ad>)
    "site_base_domain": "",         # 1.40.0: alt alan adlarının zone'u (ör. example.com)
    "saas_fallback_host": "",       # Cloudflare for SaaS fallback origin adı (tünele bağlı panel adresi)
    "discord_bot_token": "",        # Discord bot token'ı (yalnızca yönetici yazar, geri okunmaz)
    "discord_guild_id": "",         # botun çalıştığı Discord sunucusu
    "discord_customer_role_id": "1554895980045017274",  # bağlanan müşterilere verilen rol
    "discord_bot_secret": "",       # bot ile panel arasındaki paylaşılan anahtar (kurulumda üretilir)
    "discord_bot_server_id": "",    # botu çalıştıran panel sunucusu
    "discord_category_id": "",      # oluşturulan "Mango Panel" kategorisi
    "discord_ch_alerts": "",        # sunucu bildirim kanalı
    "discord_ch_tickets": "",       # destek talepleri kanalı
    "discord_ch_purchases": "",     # satın alma talepleri kanalı
    "discord_ch_status": "",        # sunucu durumu kanalı
    "app_rate_per_min": "120",      # API ve site adresleri: IP başına, sunucu başına dakikada en fazla istek
}


def get_setting(db: Session, key: str) -> str:
    row = db.get(AppSetting, key)
    return row.value if row else DEFAULTS[key]


def set_setting(db: Session, key: str, value: str) -> None:
    if key not in DEFAULTS:
        raise KeyError(key)
    row = db.get(AppSetting, key)
    if row is None:
        db.add(AppSetting(key=key, value=value))
    else:
        row.value = value


def flag(db: Session, key: str) -> bool:
    return get_setting(db, key) == "1"


def setting_int(db: Session, key: str) -> int:
    return int(get_setting(db, key))


def registration_enabled(db: Session) -> bool:
    return flag(db, "registration_enabled")


def approval_required(db: Session) -> bool:
    return flag(db, "registration_approval")


def default_max_servers(db: Session) -> int:
    return setting_int(db, "default_max_servers")


def maintenance_on(db: Session) -> bool:
    return flag(db, "maintenance_mode")


def disabled_eggs(db: Session) -> set[str]:
    return {slug for slug in get_setting(db, "disabled_eggs").split(",") if slug}


def announcement_text(db: Session) -> str:
    """Duyuru bandında gösterilecek metin; bant kapalıysa boş döner."""
    if not flag(db, "announcement_enabled"):
        return ""
    return get_setting(db, "announcement").strip()


def all_settings(db: Session) -> dict:
    return {
        "registration_enabled": flag(db, "registration_enabled"),
        "registration_approval": flag(db, "registration_approval"),
        "site_subdomains": flag(db, "site_subdomains"),
        "default_max_servers": setting_int(db, "default_max_servers"),
        "max_memory_mb": setting_int(db, "max_memory_mb"),
        "alert_webhook_url": get_setting(db, "alert_webhook_url"),
        "discord_client_id": get_setting(db, "discord_client_id"),
        "discord_secret_set": bool(get_setting(db, "discord_client_secret")),
        "max_cpu_percent": setting_int(db, "max_cpu_percent"),
        "max_disk_mb": setting_int(db, "max_disk_mb"),
        "maintenance_mode": flag(db, "maintenance_mode"),
        "announcement": get_setting(db, "announcement"),
        "announcement_enabled": flag(db, "announcement_enabled"),
        "disabled_eggs": sorted(disabled_eggs(db)),
        "site_name": get_setting(db, "site_name"),
        "logo_text": get_setting(db, "logo_text"),
        "self_service_servers": flag(db, "self_service_servers"),
        "app_rate_per_min": setting_int(db, "app_rate_per_min"),
        "domain_cname_target": get_setting(db, "domain_cname_target"),
        "domain_ip": get_setting(db, "domain_ip"),
        "cf_token_set": bool(get_setting(db, "cf_api_token")),
        "cf_zone_id": get_setting(db, "cf_zone_id"),
        "site_base_domain": get_setting(db, "site_base_domain"),
        "saas_fallback_host": get_setting(db, "saas_fallback_host"),
    }


def audit(db: Session, actor: str, action: str, target: str = "", detail: str = "") -> None:
    """Kaydı mevcut işlemle birlikte yazar; çağıran taraf commit eder."""
    db.add(AuditLog(actor=actor[:40], action=action[:48], target=target[:120], detail=detail[:500]))
