"""Mango Panel - AGPL-3.0-or-later. See LICENSE."""

__version__ = "1.41.6"
