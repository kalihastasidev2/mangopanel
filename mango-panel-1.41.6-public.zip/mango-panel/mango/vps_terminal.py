"""VPS web terminali (1.40.9): HTTP tabanlı oturumlar.

WebSocket yerine düz HTTP kullanılır: Cloudflare Tunnel ve nginx zincirinde Upgrade başlığı
kaybolduğunda websocket 404 ile düşüyordu. Düz HTTP her zaman çalışır.

- POST   /api/vps/{id}/terminal/sessions                       oturum açar -> {"sid": "..."}
- GET    /api/vps/{id}/terminal/sessions/{sid}/output?after=N  yeni çıktı (uzun sorgulama)
- POST   /api/vps/{id}/terminal/sessions/{sid}/input           {"data": "..."}
- POST   /api/vps/{id}/terminal/sessions/{sid}/resize          {"cols": 80, "rows": 24}
- DELETE /api/vps/{id}/terminal/sessions/{sid}                 oturumu kapatır

Kabuk konteynerin içinde docker exec ile açılır; konteyner dışına çıkılamaz (Docker yetkileri zaten kapalı)."""
import base64
import contextlib
import logging
import socket
import threading
import time
import uuid
from collections import deque

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from . import docker_manager as dm
from .api import _visible_server
from .db import Server
from .eggs import load_eggs
from .security import current_user, get_db

router = APIRouter(prefix="/api")
log = logging.getLogger("mango.vps_terminal")

MAX_TERMINALS_PER_VPS = 4
IDLE_SECONDS = 600
BUFFER_LIMIT = 1_000_000  # bayt; eski çıktı atılır
MAX_WAIT = 25  # saniye; uzun sorgulama üst sınırı
DIAG_WAIT = 2.5  # tanılama: etkileşimli kabuk için bekleme süresi (sn)
_sessions: dict[str, "TermSession"] = {}
_lock = threading.RLock()  # _reap() kilit içinde _close() çağırır; yeniden girilebilir olmalı (1.40.18)

_RC_LINES = [
    "[ -f ~/.bashrc ] && . ~/.bashrc",
    r'cd() { builtin cd "$@" || return; case "$PWD" in /home/container|/home/container/*) ;; *) builtin cd /home/container; echo "Bu VPS /home/container klasörünün dışına çıkamaz." ;; esac; }',
    "cd /home/container 2>/dev/null",
    r"PS1='\[\e[1;32m\]\u@mango\[\e[0m\]:\[\e[1;34m\]\w\[\e[0m\]\$ '",
    "alias ls='ls --color=auto'",
    "alias grep='grep --color=auto'",
]
# Her oturum kendi rc dosyasını kullanır; bash yoksa sh'e düşer.
SHELL_SCRIPT = (
    "mkdir -p /home/container 2>/dev/null; "
    'RC="/tmp/.mango-rc-$$"; '
    "cat > \"$RC\" 2>/dev/null <<'MANGORC'\n" + "\n".join(_RC_LINES) + "\nMANGORC\n"
    'if command -v bash >/dev/null 2>&1; then exec bash --rcfile "$RC" -i; fi\n'
    "exec sh -i"
)


class InputIn(BaseModel):
    data: str = Field(max_length=8192)


class ResizeIn(BaseModel):
    cols: int = Field(80, ge=10, le=400)
    rows: int = Field(24, ge=5, le=200)


class TermSession:
    """Bir kabuk oturumunun çıktı tamponu. Okuyucu iş parçacığı yazar, HTTP istekleri okur."""

    def __init__(self, server_id: int, user_id: int, api, exec_id: str, raw):
        self.sid = uuid.uuid4().hex
        self.server_id = server_id
        self.user_id = user_id
        self.api = api
        self.exec_id = exec_id
        self.raw = raw
        self.cond = threading.Condition()
        self.chunks: deque = deque()
        self.size = 0
        self.next_seq = 1
        self.closed = False
        self.exit_code = None
        self.last_seen = time.monotonic()

    def push(self, data: bytes) -> None:
        with self.cond:
            self.chunks.append((self.next_seq, data))
            self.next_seq += 1
            self.size += len(data)
            while self.size > BUFFER_LIMIT and len(self.chunks) > 1:
                _, old = self.chunks.popleft()
                self.size -= len(old)
            self.cond.notify_all()

    def finish(self, code) -> None:
        with self.cond:
            self.closed = True
            self.exit_code = code
            self.cond.notify_all()

    def read_after(self, after: int, wait: float):
        with self.cond:
            if not self.closed and not any(seq > after for seq, _ in self.chunks):
                self.cond.wait(timeout=wait)
            out = [(seq, data) for seq, data in self.chunks if seq > after]
            return out, self.closed, self.exit_code, self.next_seq - 1


_vps_slugs_cache: tuple[float, set] = (0.0, set())
VPS_SLUG_TTL = 30  # saniye; her tuşta egg dosyalarını yeniden okumamak için (1.40.23)


def _vps_slugs() -> set:
    global _vps_slugs_cache
    now = time.monotonic()
    if now - _vps_slugs_cache[0] > VPS_SLUG_TTL:
        slugs = {slug for slug, egg in load_eggs().items() if str(egg.get("category", "")).lower() == "vps"}
        _vps_slugs_cache = (now, slugs)
    return _vps_slugs_cache[1]


def vps_server(db: Session, server_id: int) -> Server | None:
    slugs = _vps_slugs()
    if not slugs:
        return None
    return db.query(Server).filter(Server.id == server_id, Server.egg.in_(slugs)).first()


def _vps_for(user, db: Session, server_id: int) -> Server:
    server = vps_server(db, server_id)
    if server is None:
        raise HTTPException(404, "VPS bulunamadı")
    _visible_server(user, db, server.id, "console")
    if server.maintenance and not user.is_admin:
        raise HTTPException(503, server.maintenance_message or "Bu VPS şu an bakımda.")
    return server


def _exit_code(api, exec_id):
    try:
        return api.exec_inspect(exec_id).get("ExitCode")
    except Exception:
        return None


def _open_shell(server):
    if dm.status(server) != "running":
        raise HTTPException(409, "VPS kapalı. Önce panelden başlatın.")
    try:
        api = dm.client().api
        cont = dm._container(server)
        exec_id = api.exec_create(
            cont.id, cmd=["sh", "-c", SHELL_SCRIPT], stdin=True, tty=True,
            environment={"TERM": "xterm-256color", "COLORTERM": "truecolor"},
        )["Id"]
        sock = api.exec_start(exec_id, socket=True, tty=True)
    except HTTPException:
        raise
    except Exception as exc:
        log.exception("VPS %s için kabuk açılamadı", server.id)
        raise HTTPException(500, f"Terminal açılamadı: {exc}")
    raw = getattr(sock, "_sock", sock)
    # Docker SDK soketi 60 sn zaman aşımıyla açar; sessiz kalan kabuk bu yüzden
    # "kapandı" sanılıyordu (1.40.27). Okuma bloke modda kalmalı.
    with contextlib.suppress(Exception):
        raw.settimeout(None)
    return api, exec_id, raw


def _reader(sess: TermSession) -> None:
    try:
        while True:
            try:
                data = sess.raw.recv(4096)
            except (socket.timeout, TimeoutError):
                continue  # kabuk sessiz; bu bir kapanma değil
            if not data:
                break
            sess.push(data)
    except Exception:
        log.exception("VPS terminal okuma hatası (oturum %s)", sess.sid)
    finally:
        code = _exit_code(sess.api, sess.exec_id)
        log.info("VPS %s kabuğu kapandı, çıkış kodu=%s", sess.server_id, code)
        sess.finish(code)
        with contextlib.suppress(Exception):
            sess.raw.close()


def _close(sid: str) -> None:
    with _lock:
        sess = _sessions.pop(sid, None)
    if sess is not None:
        with contextlib.suppress(Exception):
            sess.raw.close()


def _reap() -> None:
    now = time.monotonic()
    for sid, sess in list(_sessions.items()):
        if now - sess.last_seen > IDLE_SECONDS or (sess.closed and now - sess.last_seen > 60):
            _close(sid)


def _get(server_id: int, sid: str, user) -> TermSession:
    with _lock:
        sess = _sessions.get(sid)
    if sess is None or sess.server_id != server_id or sess.user_id != user.id:
        raise HTTPException(404, "Oturum bulunamadı. Yeniden bağlanın.")
    sess.last_seen = time.monotonic()
    return sess


@router.post("/vps/{server_id}/terminal/sessions", status_code=201)
def open_session(server_id: int, user=Depends(current_user), db: Session = Depends(get_db)):
    server = _vps_for(user, db, server_id)
    with _lock:
        _reap()
        active = [s for s in _sessions.values() if s.server_id == server_id and not s.closed]
        if len(active) >= MAX_TERMINALS_PER_VPS:
            raise HTTPException(429, f"Bu VPS için açık terminal sayısı doldu (en fazla {MAX_TERMINALS_PER_VPS}).")
    api, exec_id, raw = _open_shell(server)
    sess = TermSession(server_id, user.id, api, exec_id, raw)
    with _lock:
        _sessions[sess.sid] = sess
    threading.Thread(target=_reader, args=(sess,), daemon=True).start()
    return {"sid": sess.sid}


@router.get("/vps/{server_id}/terminal/sessions/{sid}/output")
def read_output(server_id: int, sid: str, after: int = Query(0, ge=0),
                wait: float = Query(15, ge=0, le=MAX_WAIT),
                user=Depends(current_user), db: Session = Depends(get_db)):
    _vps_for(user, db, server_id)
    sess = _get(server_id, sid, user)
    chunks, closed, code, last = sess.read_after(after, wait)
    return {
        "chunks": [[seq, base64.b64encode(data).decode("ascii")] for seq, data in chunks],
        "next": last,
        "closed": closed,
        "exit_code": code,
    }


@router.post("/vps/{server_id}/terminal/sessions/{sid}/input")
def send_input(server_id: int, sid: str, body: InputIn, user=Depends(current_user), db: Session = Depends(get_db)):
    _vps_for(user, db, server_id)
    sess = _get(server_id, sid, user)
    if sess.closed:
        raise HTTPException(409, "Kabuk kapalı. Yeniden bağlanın.")
    try:
        sess.raw.sendall(body.data.encode("utf-8"))
    except OSError:
        raise HTTPException(409, "Kabuk kapalı. Yeniden bağlanın.")
    return {"ok": True}


@router.post("/vps/{server_id}/terminal/sessions/{sid}/resize")
def resize(server_id: int, sid: str, body: ResizeIn, user=Depends(current_user), db: Session = Depends(get_db)):
    _vps_for(user, db, server_id)
    sess = _get(server_id, sid, user)
    with contextlib.suppress(Exception):
        sess.api.exec_resize(sess.exec_id, height=body.rows, width=body.cols)
    return {"ok": True}


@router.delete("/vps/{server_id}/terminal/sessions/{sid}")
def close_session(server_id: int, sid: str, user=Depends(current_user), db: Session = Depends(get_db)):
    _vps_for(user, db, server_id)
    _get(server_id, sid, user)
    _close(sid)
    return {"ok": True}


def _run_once(api, cont_id, cmd: list[str]) -> tuple[str, int | None]:
    exec_id = api.exec_create(cont_id, cmd=cmd, stdin=False, tty=False)["Id"]
    out = api.exec_start(exec_id, detach=False, tty=False)
    text = out.decode("utf-8", "replace") if isinstance(out, (bytes, bytearray)) else str(out)
    return text, _exit_code(api, exec_id)


def _read_for(raw, seconds: float) -> bytes:
    """Soketten bir süre okur; süre dolunca ya da bağlantı kapanınca döner."""
    data = b""
    end = time.monotonic() + seconds
    with contextlib.suppress(Exception):
        raw.settimeout(0.5)
    while time.monotonic() < end:
        try:
            chunk = raw.recv(4096)
        except (socket.timeout, TimeoutError):
            continue
        except OSError:
            break
        if not chunk:
            break
        data += chunk
    return data


@router.get("/vps/{server_id}/terminal/diagnose")
def diagnose(server_id: int, user=Depends(current_user), db: Session = Depends(get_db)):
    """Terminalin hangi adımda takıldığını gösterir: daemon, konteyner, exec, bash, etkileşimli kabuk."""
    server = _vps_for(user, db, server_id)
    checks: list[dict] = []

    def add(name: str, ok: bool, detail: str = "") -> None:
        checks.append({"name": name, "ok": bool(ok), "detail": detail[:300]})

    try:
        dm.client().ping()
        add("Docker daemon erişimi", True)
    except Exception as exc:
        add("Docker daemon erişimi", False, str(exc))
        return {"ok": False, "checks": checks}

    status = dm.status(server)
    add("konteyner durumu", status == "running", str(status))
    if status != "running":
        return {"ok": False, "checks": checks}

    try:
        cont = dm._container(server)
    except Exception as exc:
        add("konteyner bulundu", False, str(exc))
        return {"ok": False, "checks": checks}
    add("konteyner bulundu", True, cont.name)

    api = dm.client().api
    try:
        out, code = _run_once(api, cont.id, ["sh", "-c", "echo mango-ok; command -v bash || echo no-bash; test -d /home/container && echo home-ok || echo no-home"])
        add("komut çalıştırma (exec)", code == 0 and "mango-ok" in out, out.strip())
        add("bash kurulu", "no-bash" not in out, "bash bulunamadı, sh kullanılacak" if "no-bash" in out else "")
        add("ana klasör /home/container", "home-ok" in out, "" if "home-ok" in out else "klasör yok; kabuk açılırken oluşturulacak")
    except Exception as exc:
        add("komut çalıştırma (exec)", False, str(exc))

    try:
        _api, exec_id, raw = _open_shell(server)
    except HTTPException as exc:
        add("etkileşimli kabuk açma", False, str(exc.detail))
        return {"ok": False, "checks": checks}
    try:
        first = _read_for(raw, DIAG_WAIT)
        add("etkileşimli kabuk açma", bool(first), "kabuk çıktı vermedi" if not first else "")
        with contextlib.suppress(Exception):
            raw.sendall(b"echo mango-tty-ok\n")
        second = _read_for(raw, DIAG_WAIT)
        add("tuş girişi ve çıktı", b"mango-tty-ok" in second, "" if b"mango-tty-ok" in second else "girilen komutun çıktısı gelmedi")
    except Exception as exc:
        add("etkileşimli kabuk", False, str(exc))
    finally:
        with contextlib.suppress(Exception):
            raw.close()
    return {"ok": all(c["ok"] for c in checks), "checks": checks}
