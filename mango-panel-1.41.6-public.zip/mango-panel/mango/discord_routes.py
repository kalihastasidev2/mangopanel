"""Discord entegrasyonu uç noktaları (1.22.0): yönetici kurulumu, bot API'si ve hesap bağlama."""
import datetime as dt

from fastapi import APIRouter, Depends, Header, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import func
from sqlalchemy.orm import Session

from . import discord_api
from . import discord_bot as bot
from . import docker_manager as dm
from .api import _visible_server
from .db import DiscordEvent, SessionLocal, Server, Ticket, TicketMessage, User
from .security import admin_only, current_user, get_db
from .store import audit, get_setting, set_setting

router = APIRouter(prefix="/api")
SNOWFLAKE_RE = r"^[0-9]{5,25}$"


class DiscordSettingsIn(BaseModel):
    token: str | None = Field(None, max_length=100)
    guild_id: str | None = Field(None, pattern=r"^$|^[0-9]{5,25}$")  # boş = henüz ayarlanmadı
    customer_role_id: str | None = Field(None, pattern=r"^$|^[0-9]{5,25}$")


class DiscordIdIn(BaseModel):
    discord_id: str = Field(pattern=SNOWFLAKE_RE)


class LinkIn(BaseModel):
    code: str = Field(min_length=4, max_length=16)


class BotPowerIn(BaseModel):
    action: str = Field(pattern=r"^(start|stop|restart)$")


class BotTicketIn(BaseModel):
    subject: str = Field(min_length=2, max_length=120)
    message: str = Field(min_length=2, max_length=2000)


def _bot_auth(db: Session, secret: str | None) -> None:
    bot.verify_bot_secret(db, secret)


# ---------- Yönetici ----------

@router.get("/admin/discord")
def get_discord(_: User = Depends(admin_only), db: Session = Depends(get_db)):
    bot_server_id = get_setting(db, "discord_bot_server_id")
    return {
        "token_set": bool(get_setting(db, "discord_bot_token")),
        "guild_id": get_setting(db, "discord_guild_id"),
        "customer_role_id": get_setting(db, "discord_customer_role_id"),
        "setup_done": bool(get_setting(db, "discord_category_id")),
        "bot_server_id": int(bot_server_id) if bot_server_id else None,
        "channels": {
            "alerts": get_setting(db, "discord_ch_alerts"),
            "tickets": get_setting(db, "discord_ch_tickets"),
            "purchases": get_setting(db, "discord_ch_purchases"),
            "status": get_setting(db, "discord_ch_status"),
        },
        "linked_users": db.query(User).filter(User.discord_id.isnot(None)).count(),
    }


@router.put("/admin/discord")
def put_discord(body: DiscordSettingsIn, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    if body.token:  # boş bırakılırsa mevcut token korunur
        set_setting(db, "discord_bot_token", body.token.strip())
    if body.guild_id is not None:
        set_setting(db, "discord_guild_id", body.guild_id)
    if body.customer_role_id is not None:
        set_setting(db, "discord_customer_role_id", body.customer_role_id)
    audit(db, admin.username, "discord.settings", "", "token,guild,role")
    db.commit()
    return get_discord(admin, db)


@router.post("/admin/discord/setup")
def setup_discord(admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    return bot.setup(db, admin)


# ---------- Bot API'si (X-Bot-Secret ile) ----------

@router.post("/discord/link-code")
def bot_link_code(body: DiscordIdIn, x_bot_secret: str | None = Header(None), db: Session = Depends(get_db)):
    _bot_auth(db, x_bot_secret)
    return {"code": bot.new_link_code(db, body.discord_id), "expires_in": int(bot.CODE_TTL.total_seconds())}


@router.get("/discord/events")
def bot_events(after: int = Query(0, ge=-1), limit: int = Query(50, ge=1, le=100),
               x_bot_secret: str | None = Header(None), db: Session = Depends(get_db)):
    _bot_auth(db, x_bot_secret)
    latest = db.query(func.max(DiscordEvent.id)).scalar() or 0
    if after < 0:  # bot ilk açıldığında eski olayları yeniden göndermez
        return {"events": [], "latest": latest}
    rows = db.query(DiscordEvent).filter(DiscordEvent.id > after).order_by(DiscordEvent.id).limit(limit).all()
    events = []
    for row in rows:
        owner = db.get(User, row.user_id) if row.user_id else None
        events.append({
            "id": row.id, "kind": row.kind, "text": row.text, "server_id": row.server_id,
            "discord_id": owner.discord_id if owner else None,
            "created_at": row.created_at.isoformat() if row.created_at else None,
        })
    return {"events": events, "latest": latest}


@router.get("/discord/user/{discord_id}")
def bot_user(discord_id: str, x_bot_secret: str | None = Header(None), db: Session = Depends(get_db)):
    _bot_auth(db, x_bot_secret)
    user = db.query(User).filter_by(discord_id=discord_id).first()
    if user is None:
        return {"linked": False, "servers": []}
    return {"linked": True, "username": user.username, "servers": bot.servers_for_user(db, user)}


@router.post("/discord/user/{discord_id}/servers/{server_id}/power")
def bot_power(discord_id: str, server_id: int, body: BotPowerIn,
              x_bot_secret: str | None = Header(None), db: Session = Depends(get_db)):
    _bot_auth(db, x_bot_secret)
    user = bot.linked_user(db, discord_id)
    server = _visible_server(user, db, server_id, "power")
    try:
        state = dm.power(server, body.action)
    except Exception as exc:
        raise HTTPException(409, f"İşlem başarısız: {exc}")
    if body.action != "start":
        bot.mark_intentional(server.id)
    return {"status": state}


@router.get("/discord/user/{discord_id}/servers/{server_id}/logs")
def bot_logs(discord_id: str, server_id: int, tail: int = Query(40, ge=5, le=200),
             x_bot_secret: str | None = Header(None), db: Session = Depends(get_db)):
    _bot_auth(db, x_bot_secret)
    user = bot.linked_user(db, discord_id)
    server = _visible_server(user, db, server_id)
    try:
        text = dm.logs(server, tail=tail)
    except Exception as exc:
        raise HTTPException(409, f"Konsol okunamadı: {exc}")
    return {"text": text[-3000:]}


@router.post("/discord/user/{discord_id}/tickets", status_code=201)
def bot_ticket(discord_id: str, body: BotTicketIn, x_bot_secret: str | None = Header(None),
               db: Session = Depends(get_db)):
    _bot_auth(db, x_bot_secret)
    user = bot.linked_user(db, discord_id)
    now = dt.datetime.now(dt.timezone.utc)
    ticket = Ticket(user_id=user.id, subject=body.subject.strip(), category="support", status="open",
                    created_at=now, updated_at=now)
    db.add(ticket)
    db.flush()
    db.add(TicketMessage(ticket_id=ticket.id, author=user.username, is_admin=False,
                         text=body.message.strip(), created_at=now))
    bot.emit_event(db, "ticket_new", f"Yeni destek talebi #{ticket.id} ({user.username}): {ticket.subject}",
                   user_id=user.id)
    audit(db, user.username, "ticket.create", ticket.subject, "support via discord")
    db.commit()
    return {"id": ticket.id, "subject": ticket.subject}


# ---------- Kullanıcı: hesap bağlama ----------

def _me_status(user: User) -> dict:
    return {"linked": bool(user.discord_id), "discord_id": user.discord_id}


@router.get("/me/discord")
def me_discord(user: User = Depends(current_user)):
    return _me_status(user)


@router.post("/me/discord/link")
def me_discord_link(body: LinkIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    discord_id = bot.redeem_link_code(db, user, body.code)
    token = get_setting(db, "discord_bot_token").strip()
    guild_id = get_setting(db, "discord_guild_id").strip()
    role_id = get_setting(db, "discord_customer_role_id").strip()
    role_granted = False
    message = "Hesap bağlandı."
    if token and guild_id and role_id:
        try:
            discord_api.add_role(token, guild_id, discord_id, role_id)
            role_granted = True
            message = "Hesap bağlandı ve müşteri rolü verildi."
        except discord_api.DiscordError:
            message = "Hesap bağlandı, ancak müşteri rolü verilemedi. Discord sunucusunda olduğunuzdan emin olun."
    return {"linked": True, "discord_id": discord_id, "role_granted": role_granted, "message": message}


@router.delete("/me/discord")
def me_discord_unlink(user: User = Depends(current_user), db: Session = Depends(get_db)):
    user.discord_id = None
    db.commit()
    return _me_status(user)
