import hashlib
import asyncio
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles

from . import __version__
from .api import prepull_eggs, router
from .config import settings
from .domains import PANEL_HOST, router as domains_router, site_slug_for_host
from .discord_routes import router as discord_router
from .account_api import router as account_router
from .chat_api import router as chat_router
from . import discord_bot
from .premium_api import router as premium_router
from .vps_terminal import router as vps_router
from .backups import router as backups_router
from .reinstall import router as reinstall_router
from .coupons import router as coupons_router
from .maintenance import router as maintenance_router
from .discord_login import router as discord_login_router
from .notifications import router as notifications_router
from .funnel import router as funnel_router
from .cf_check import router as cf_check_router
from . import site_dns
from .db import Server as SiteServer, SessionLocal as SiteSession
from . import demo as demo_mod
from . import abuse
from . import crash_watch
from . import expiry
from . import backups
from . import docker_manager as _dm_for_abuse
from .db import init_db


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    Path(settings.data_dir).mkdir(parents=True, exist_ok=True)
    prepull_eggs()
    discord_bot.start_watcher()
    abuse.start_watcher(_dm_for_abuse.stats)
    demo_mod.start_watcher(_dm_for_abuse.power)
    crash_watch.start_watcher()
    expiry.start_watcher()
    from . import vpsdebug
    vpsdebug.start_watcher()
    backups.start_scheduler()
    # Terminal uzun sorguları iş parçacığı tutar; varsayılan 40 sınırı birkaç terminalde tıkanmaya yol açıyordu (1.40.26).
    from anyio import to_thread

    to_thread.current_default_thread_limiter().total_tokens = 60  # 1.41.6: sunucunun toplam süreç/thread sınırı (256) için; konsol ve terminal yoklamaları da burada bekler
    yield


app = FastAPI(
    title="Mango Panel",
    version=__version__,
    lifespan=lifespan,
    docs_url="/api/docs" if settings.access_mode == "direct" else None,
    redoc_url=None,
    openapi_url="/api/openapi.json" if settings.access_mode == "direct" else None,
)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; style-src 'self' 'unsafe-inline'; "
        "script-src 'self'; connect-src 'self' ws: wss:; img-src 'self' data:"
    )
    return response


app.include_router(router)
app.include_router(premium_router)
app.include_router(domains_router)
app.include_router(discord_router)
app.include_router(account_router)
app.include_router(chat_router)
app.include_router(vps_router)
app.include_router(backups_router)
app.include_router(reinstall_router)
app.include_router(coupons_router)
app.include_router(maintenance_router)
app.include_router(discord_login_router)
app.include_router(notifications_router)
app.include_router(funnel_router)
app.include_router(cf_check_router)


@app.middleware("http")
async def site_host_router(request, call_next):
    """ad.example.com adresine gelen site isteklerini /api/sites/<ad> yoluna yönlendirir (1.40.0)."""
    host = request.headers.get("host", "").split(":")[0].lower()
    path = request.scope.get("path", "/")
    if host and host != site_dns.panel_host() and not path.startswith("/api/"):
        db = SiteSession()
        try:
            slug = db.query(SiteServer.site_slug).filter(SiteServer.site_host == host).scalar()
        finally:
            db.close()
        if slug:
            request.scope["path"] = f"/api/sites/{slug}{path}"
    return await call_next(request)


@app.middleware("http")
async def custom_domain_sites(request: Request, call_next):
    """Doğrulanmış özel domain'den gelen istekler, o sitenin /sites/<ad> adresine yönlenir (1.20.0)."""
    host = (request.headers.get("host") or "").split(":")[0].strip().lower()
    path = request.url.path
    if host and host != PANEL_HOST and not path.startswith("/api"):
        slug = await asyncio.to_thread(site_slug_for_host, host)
        if slug:
            request.scope["path"] = f"/api/sites/{slug}{path}"  # site uç noktası /api öneki altında
    return await call_next(request)

WEB_DIR = Path(settings.web_dir)


def _asset_version() -> str:
    """JS/CSS içeriğinden sürüm üretir; dosya değişince adres değişir, eski önbellek kullanılmaz."""
    parts = []
    for name in ("app.js", "platform.js", "style.css"):
        path = WEB_DIR / name
        parts.append(hashlib.md5(path.read_bytes()).hexdigest() if path.is_file() else "-")
    return hashlib.md5("|".join(parts).encode()).hexdigest()[:12]


@app.get("/")
def index():
    html = (WEB_DIR / "index.html").read_text(encoding="utf-8").replace("{{VERSION}}", _asset_version())
    return HTMLResponse(html, headers={"Cache-Control": "no-cache"})


app.mount("/static", StaticFiles(directory=WEB_DIR), name="static")
