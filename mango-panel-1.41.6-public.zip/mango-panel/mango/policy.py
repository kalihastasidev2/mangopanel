"""İçerik politikası.

Cloudflare Tunnel üzerinden yayınlanan bir panelde oyun sunucusu (Minecraft vb.)
çalıştırılmasına izin verilmez. Tünel HTTP(S) trafiğini taşır; oyun sunucuları
ham TCP/UDP kullanır ve bu mod, tünel arkasında hem çalışmaz hem de kötüye
kullanım riski taşır. Bu nedenle tünel modunda yalnızca izin listesindeki
kategoriler kullanılabilir.
"""
from .config import settings

TUNNEL_ALLOWED_CATEGORIES = {"web", "php", "nodejs", "python", "bot", "vps"}  # vps: 1.28.1, içerik sunucuda, port gerekmez
GAME_CATEGORIES = {"game"}

TUNNEL_BLOCK_MESSAGE = (
    "Cloudflare Tunnel modunda oyun sunucusu çalıştırılamaz. "
    "Yalnızca web, Node.js, Python, bot ve VPS eggleri kullanılabilir."
)


def egg_allowed(egg: dict) -> tuple[bool, str]:
    category = str(egg.get("category", "")).lower()
    if settings.access_mode == "cloudflare":
        if category in GAME_CATEGORIES or category not in TUNNEL_ALLOWED_CATEGORIES:
            return False, TUNNEL_BLOCK_MESSAGE
    return True, ""
