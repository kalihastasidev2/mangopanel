import datetime as dt
import hashlib
import hmac
import os
import secrets

import jwt
from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from .config import settings
from .db import ApiKey, SessionLocal, User, UserSession
from .store import maintenance_on

PBKDF2_ITERATIONS = 260_000
_bearer = HTTPBearer(auto_error=False)


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, PBKDF2_ITERATIONS)
    return f"pbkdf2${PBKDF2_ITERATIONS}${salt.hex()}${digest.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _, iterations, salt_hex, digest_hex = stored.split("$")
        calc = hashlib.pbkdf2_hmac(
            "sha256", password.encode(), bytes.fromhex(salt_hex), int(iterations)
        )
        return hmac.compare_digest(calc.hex(), digest_hex)
    except ValueError:
        return False


def create_token(user: User, db=None, request=None) -> str:
    """Oturum jetonu üretir. db verilirse oturum kaydı açılır ve jetona sid eklenir (1.27.0)."""
    now = dt.datetime.now(dt.timezone.utc)
    payload = {
        "sub": str(user.id),
        "exp": now + dt.timedelta(hours=settings.token_hours),
        "iat": now,
    }
    if db is not None:
        sid = secrets.token_urlsafe(18)
        agent = (request.headers.get("user-agent", "") if request else "")[:200]
        ip = request.client.host if request and request.client else ""
        db.add(UserSession(id=sid, user_id=user.id, created_at=now, last_seen=now,
                           user_agent=agent, ip=ip, revoked=False))
        db.commit()
        payload["sid"] = sid
    return jwt.encode(payload, settings.secret_key, algorithm="HS256")


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


API_KEY_PREFIX = "mgp_"


def api_key_hash(raw: str) -> str:
    return hashlib.sha256(raw.encode()).hexdigest()


def user_from_token(token: str, db) -> User:
    if token.startswith(API_KEY_PREFIX):
        # API anahtarı: oturum jetonu gibi çalışır ama süresi dolmaz; iptal edilebilir.
        row = db.query(ApiKey).filter_by(key_hash=api_key_hash(token)).first()
        user = db.get(User, row.user_id) if row else None
        if user is None:
            raise HTTPException(401, "Geçersiz API anahtarı")
        row.last_used = dt.datetime.now(dt.timezone.utc)
        db.commit()
        user.key_scope = row.scope  # yalnızca bu istek için; veritabanına yazılmaz
        user.session_id = None
    else:
        try:
            payload = jwt.decode(token, settings.secret_key, algorithms=["HS256"])
        except jwt.PyJWTError:
            raise HTTPException(401, "Geçersiz oturum")
        user = db.get(User, int(payload["sub"]))
        if user is None:
            raise HTTPException(401, "Kullanıcı bulunamadı")
        sid = payload.get("sid")
        if sid:  # eski jetonlarda sid yoktur; onlar süresi dolana kadar çalışır
            row = db.get(UserSession, sid)
            if row is None or row.revoked or row.user_id != user.id:
                raise HTTPException(401, "Oturum kapatıldı. Lütfen tekrar giriş yapın.")
            now = dt.datetime.now(dt.timezone.utc)
            seen = row.last_seen if row.last_seen.tzinfo else row.last_seen.replace(tzinfo=dt.timezone.utc)
            if (now - seen).total_seconds() > 60:  # her istekte yazmamak için
                row.last_seen = now
                db.commit()
            user.session_id = sid
    if not user.is_admin and maintenance_on(db):
        raise HTTPException(503, "Panel bakım modunda. Lütfen daha sonra tekrar deneyin.")
    return user


def current_user(
    creds: HTTPAuthorizationCredentials | None = Depends(_bearer),
    db=Depends(get_db),
) -> User:
    if creds is None:
        raise HTTPException(401, "Giriş gerekli")
    return user_from_token(creds.credentials, db)


def admin_only(user: User = Depends(current_user)) -> User:
    if not user.is_admin:
        raise HTTPException(403, "Bu işlem yalnızca yöneticiye açık")
    # "client" kapsamlı API anahtarı yönetici uç noktalarını kullanamaz.
    if getattr(user, "key_scope", "application") == "client":
        raise HTTPException(403, "Bu API anahtarı yönetici işlemleri için yetkili değil (uygulama anahtarı gerekir)")
    return user
