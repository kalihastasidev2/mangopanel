"""1.20.0 / 1.21.0: statik ve PHP siteleri için özel domain bağlama.

İki mod var:
- Cloudflare for SaaS (1.21.0): yönetici API token, zone ve fallback adresini girdiyse domain Cloudflare'e
  custom hostname olarak kaydedilir, sertifikayı Cloudflare alır. Kullanıcı yalnızca CNAME ekler.
- Yedek mod: ayarlar boşsa kullanıcı TXT kaydıyla sahipliği kanıtlar, hedefleri yönetici elle verir.

Doğrulanan domain sitenin adresine yönlenir.
"""
import datetime as dt
import re
import secrets
from urllib.parse import urlparse

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from . import cloudflare
from .api import WEB_CATEGORIES, _egg_for, _visible_server
from .config import settings
from .db import CustomDomain, SessionLocal, Server, User
from .security import current_user, get_db
from .store import get_setting

router = APIRouter(prefix="/api")
DOMAIN_RE = re.compile(r"^(?=.{4,253}$)([a-z0-9-]{1,63}\.)+[a-z]{2,63}$")
MAX_DOMAINS_PER_SERVER = 5
VERIFY_LABEL = "_mango-verify"
PANEL_HOST = (urlparse(settings.public_url).hostname or "").lower()


class DomainIn(BaseModel):
    domain: str = Field(min_length=4, max_length=253)


def _now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _iso(value):
    return value.isoformat() if value else None


def lookup_txt(name: str) -> list[str]:
    """DNS TXT kayıtlarını okur. dnspython gerekir; yoksa açık bir hata verir."""
    try:
        import dns.resolver  # dnspython
    except ImportError:
        raise HTTPException(500, "Sunucuda dnspython kurulu değil. Yönetici 'pip install dnspython' çalıştırmalı.")
    try:
        answers = dns.resolver.resolve(name, "TXT", lifetime=6)
    except Exception:
        return []
    return [b"".join(record.strings).decode("utf-8", "replace") for record in answers]


def _is_subdomain(domain: str) -> bool:
    # www.siteniz.com gibi alt alanlar CNAME ile; siteniz.com gibi kök domainler A kaydı ile yönlenir.
    return domain.count(".") >= 2


def _cf_config(db: Session) -> dict | None:
    """Cloudflare for SaaS ayarları tamamsa bilgileri döndürür; eksikse None."""
    token = get_setting(db, "cf_api_token").strip()
    zone = get_setting(db, "cf_zone_id").strip()
    fallback = get_setting(db, "saas_fallback_host").strip().lower()
    if token and zone and fallback:
        return {"token": token, "zone": zone, "fallback": fallback}
    return None


def _targets(db: Session) -> tuple[str, str]:
    cf = _cf_config(db)
    default = cf["fallback"] if cf else PANEL_HOST
    cname = get_setting(db, "domain_cname_target").strip() or default
    return cname, get_setting(db, "domain_ip").strip()


def _dns_records(d: CustomDomain, cname: str, ip: str) -> list[dict]:
    if d.cf_id:
        # Cloudflare for SaaS: sahiplik ve sertifika CNAME üzerinden Cloudflare tarafından doğrulanır.
        target = cname or "(yönetici hedefi ayarlamadı)"
        if _is_subdomain(d.domain):
            return [{"type": "CNAME", "name": d.domain, "value": target, "purpose": "Sitenin adresi (zorunlu)"}]
        return [
            {"type": "CNAME", "name": d.domain, "value": target,
             "purpose": "Kök domain: DNS sağlayıcınız CNAME flattening destekliyorsa (Cloudflare DNS destekler)"},
            {"type": "CNAME", "name": f"www.{d.domain}", "value": target, "purpose": "www adresi (isteğe bağlı)"},
        ]
    records = [{
        "type": "TXT", "name": f"{VERIFY_LABEL}.{d.domain}", "value": f"mango-verify={d.token}",
        "purpose": "Sahiplik doğrulaması (önce eklenmeli)",
    }]
    if _is_subdomain(d.domain):
        records.append({"type": "CNAME", "name": d.domain, "value": cname or "(yönetici hedefi ayarlamadı)",
                        "purpose": "Sitenin adresi"})
    else:
        records.append({"type": "A", "name": d.domain, "value": ip or "(yönetici IP'yi ayarlamadı)",
                        "purpose": "Sitenin adresi"})
        records.append({"type": "CNAME", "name": f"www.{d.domain}", "value": cname or "(yönetici hedefi ayarlamadı)",
                        "purpose": "www adresi (isteğe bağlı)"})
    return records


def _domain_json(d: CustomDomain, cname: str, ip: str) -> dict:
    return {
        "id": d.id, "domain": d.domain, "verified": bool(d.verified),
        "created_at": _iso(d.created_at), "verified_at": _iso(d.verified_at),
        "mode": "cloudflare" if d.cf_id else "dns",
        "records": _dns_records(d, cname, ip),
    }


def _site_capable(server: Server) -> bool:
    egg = _egg_for(server)
    return str(egg.get("category", "")).lower() in WEB_CATEGORIES


def _domain_row(db: Session, server: Server, domain_id: int) -> CustomDomain:
    d = db.get(CustomDomain, domain_id)
    if d is None or d.server_id != server.id:
        raise HTTPException(404, "Domain bulunamadı")
    return d


def _create_remote(cf: dict, domain: str) -> str:
    """Domaini Cloudflare'de kaydeder ve kimliğini döndürür."""
    try:
        result = cloudflare.create_hostname(cf["zone"], cf["token"], domain)
    except cloudflare.CloudflareError as exc:
        # Aynı ad Cloudflare'de zaten varsa mevcut kaydı kullan.
        try:
            result = cloudflare.find_hostname(cf["zone"], cf["token"], domain)
        except cloudflare.CloudflareError:
            result = None
        if not result:
            raise HTTPException(502, f"Cloudflare domaini kaydedemedi: {exc}")
    return result["id"]


def _remote_status(cf: dict, cf_id: str) -> tuple[bool, str]:
    """Cloudflare'de hostname ve sertifika aktif mi? (ok, kullanıcıya gösterilecek mesaj)"""
    try:
        data = cloudflare.get_hostname(cf["zone"], cf["token"], cf_id)
    except cloudflare.CloudflareError as exc:
        return False, f"Cloudflare durumu alınamadı: {exc}"
    status = data.get("status")
    ssl_status = (data.get("ssl") or {}).get("status")
    if status == "active" and ssl_status == "active":
        return True, "Domain doğrulandı; adres artık siteye yönleniyor."
    errors = [str(e.get("message", e)) if isinstance(e, dict) else str(e)
              for e in (data.get("verification_errors") or [])]
    hint = "; ".join(errors) if errors else "CNAME kaydının yayılması ve sertifika onayı bekleniyor."
    return False, f"Henüz hazır değil (durum: {status}, sertifika: {ssl_status}). {hint} Birkaç dakika sonra tekrar deneyin."


@router.get("/servers/{server_id}/domains")
def list_domains(server_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "settings")
    cname, ip = _targets(db)
    rows = db.query(CustomDomain).filter_by(server_id=server.id).order_by(CustomDomain.id).all()
    return {
        "site_capable": _site_capable(server),
        "site_slug": server.site_slug,
        "saas_mode": _cf_config(db) is not None,
        "domains": [_domain_json(d, cname, ip) for d in rows],
    }


@router.post("/servers/{server_id}/domains", status_code=201)
def add_domain(server_id: int, body: DomainIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "settings")
    domain = body.domain.strip().lower().rstrip(".")
    if not DOMAIN_RE.match(domain):
        raise HTTPException(400, "Geçersiz domain adı. Örnek: siteniz.com veya www.siteniz.com")
    if PANEL_HOST and domain == PANEL_HOST:
        raise HTTPException(400, "Bu adres panelin kendisine ait")
    if not _site_capable(server):
        raise HTTPException(400, "Özel domain yalnızca statik ve PHP sitelerinde kullanılabilir")
    if not server.site_slug:
        raise HTTPException(400, "Önce Ayarlar sekmesinden bir site adı verin")
    if db.query(CustomDomain).filter_by(server_id=server.id).count() >= MAX_DOMAINS_PER_SERVER:
        raise HTTPException(400, f"Bir sunucuya en fazla {MAX_DOMAINS_PER_SERVER} domain bağlanabilir")
    if db.query(CustomDomain).filter_by(domain=domain).first():
        raise HTTPException(409, "Bu domain başka bir sunucuda kullanılıyor")
    cf = _cf_config(db)
    cf_id = _create_remote(cf, domain) if cf else None
    d = CustomDomain(server_id=server.id, domain=domain, token=secrets.token_hex(16), verified=False,
                     created_at=_now(), cf_id=cf_id)
    db.add(d)
    db.commit()
    cname, ip = _targets(db)
    return _domain_json(d, cname, ip)


@router.post("/servers/{server_id}/domains/{domain_id}/verify")
def verify_domain(server_id: int, domain_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "settings")
    d = _domain_row(db, server, domain_id)
    if d.cf_id:
        cf = _cf_config(db)
        if cf is None:
            raise HTTPException(400, "Cloudflare ayarları eksik. Yönetici Domain ayarlarını kontrol etmeli.")
        ok, message = _remote_status(cf, d.cf_id)
    else:
        values = lookup_txt(f"{VERIFY_LABEL}.{d.domain}")
        ok = f"mango-verify={d.token}" in values
        message = ("Domain doğrulandı; adres artık siteye yönleniyor." if ok else
                   "TXT kaydı henüz görünmüyor. DNS değişikliklerinin yayılması birkaç dakika sürebilir; sonra tekrar deneyin.")
    if ok and not d.verified:
        d.verified = True
        d.verified_at = _now()
        db.commit()
    cname, ip = _targets(db)
    return {"verified": ok, "message": message, "domain": _domain_json(d, cname, ip)}


@router.delete("/servers/{server_id}/domains/{domain_id}", status_code=204)
def delete_domain(server_id: int, domain_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "settings")
    d = _domain_row(db, server, domain_id)
    cf = _cf_config(db)
    if d.cf_id and cf:
        try:
            cloudflare.delete_hostname(cf["zone"], cf["token"], d.cf_id)
        except cloudflare.CloudflareError:
            pass  # Panelden yine silinir; Cloudflare'de kalan kayıt elle temizlenebilir
    db.delete(d)
    db.commit()


def site_slug_for_host(host: str) -> str | None:
    """Gelen Host başlığı doğrulanmış bir özel domain ise sitenin adını döndürür."""
    db = SessionLocal()
    try:
        row = (db.query(CustomDomain, Server)
               .join(Server, Server.id == CustomDomain.server_id)
               .filter(CustomDomain.domain == host, CustomDomain.verified.is_(True))
               .first())
        if row is None:
            return None
        _, server = row
        if server.suspended or not server.site_slug:
            return None
        return server.site_slug
    finally:
        db.close()
