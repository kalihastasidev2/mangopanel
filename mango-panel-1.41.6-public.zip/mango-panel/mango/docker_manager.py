"""Docker konteyner yönetimi. Her sunucu kendi konteyneri ve veri klasörüyle çalışır."""
import logging
import shutil
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

import docker
from docker.errors import ImageNotFound, NotFound

from .config import settings

_client = None
CONTAINER_HOME = "/home/container"
# Her sunucu için açık stdin bağlantısı (konsoldan komut göndermek için).
_stdin_sockets: dict[int, object] = {}
_stdin_lock = threading.Lock()


log = logging.getLogger("mango.docker")
# Süreç/kaynak sınırına çarpıldığında veya runtime geçici hata verdiğinde görülen mesajlar.
# Küçük harfle karşılaştırılır (1.35.1): Docker mesajları büyük/küçük harf karışık gelebilir.
TRANSIENT_MARKERS = (
    "pthread_create", "resource temporarily unavailable", "can't get final child",
    "did not terminate successfully", "shim task", "exit status 134", "oci runtime",
    "failed to create task", "failed to start shim", "fork/exec", "eagain",
    "containerd-shim", "cannot fork",
)
RETRY_DELAYS = (2, 4, 8, 15)  # ilk denemeden sonra beklenecek saniyeler
# Aynı anda çok sayıda konteyner başlatmak süreç sınırını zorlar; başlatmalar sıraya girer (1.35.1).
START_LOCK = threading.Lock()


def is_transient(exc: Exception) -> bool:
    text = str(exc).lower()
    return any(marker in text for marker in TRANSIENT_MARKERS)


def with_retry(action, cleanup=None):
    """Geçici Docker hatalarında işlemi otomatik yeniden dener (1.26.0).
    cleanup verilirse her başarısız denemeden sonra çağrılır (yarım kalan konteynerleri temizler)."""
    for delay in RETRY_DELAYS:
        try:
            return action()
        except Exception as exc:
            if not is_transient(exc):
                raise
            log.warning("Geçici Docker hatası, yeniden denenecek: %s", exc)
            if cleanup:
                try:
                    cleanup()
                except Exception:
                    pass
            time.sleep(delay)
    return action()  # son deneme: hata olursa çağırana aynen iletilir


def _cleanup_named(server_id: int) -> None:
    """mango-<id> adlı her konteyneri siler: etiketi olsun olmasın, çalışıyor olsun olmasın (1.41.2).
    Yeni oluşturulurken ad çakışması (409 Conflict) kalmasın diye. Veriler klasörde kalır."""
    name = f"mango-{server_id}"
    for c in client().containers.list(all=True):
        if c.name == name:
            c.remove(force=True)


def _cleanup_install(server_id: int) -> None:
    for c in client().containers.list(all=True, filters={"label": f"mango.install={server_id}"}):
        if c.status != "running":
            c.remove(force=True)


def client() -> docker.DockerClient:
    global _client
    if _client is None:
        _client = docker.from_env()
    return _client


def server_dir(server_id: int) -> Path:
    path = Path(settings.data_dir) / str(server_id)
    path.mkdir(parents=True, exist_ok=True)
    return path


def _bind_ip() -> str:
    # Tünel modunda port dışarı açılmaz; yalnızca cloudflared localhost'tan erişir.
    return "127.0.0.1" if settings.access_mode == "cloudflare" else "0.0.0.0"


def _volumes(server_id: int) -> dict:
    return {str(server_dir(server_id)): {"bind": CONTAINER_HOME, "mode": "rw"}}


# Egg'lerin (ör. Linux VPS) ekleyebileceği tek yetkiler. Bunların dışındaki istekler yok sayılır.
ALLOWED_EXTRA_CAPS = {"CHOWN", "DAC_OVERRIDE", "FOWNER", "SETUID", "SETGID"}
MAX_PIDS = 512


def _limits(server, egg: dict | None = None) -> dict:
    """Konteyner kaynak ve güvenlik sınırları. Tüm yetkiler düşürülür; yalnızca beyaz listedeki
    yetkiler egg üzerinden geri eklenebilir (1.28.0)."""
    egg = egg or {}
    extra = [str(c).upper() for c in egg.get("cap_add", []) if str(c).upper() in ALLOWED_EXTRA_CAPS]
    return {
        "mem_limit": f"{server.memory_mb}m",
        "nano_cpus": int(server.cpu_percent / 100 * 1_000_000_000),
        "pids_limit": min(int(egg.get("pids_limit", MAX_PIDS)), MAX_PIDS),
        "security_opt": ["no-new-privileges:true"],
        "cap_drop": ["ALL"],
        "cap_add": extra,
    }


def run_install(server, egg: dict, script: str) -> str:
    """Kurulum betiğini geçici bir konteynerde çalıştırır ve çıktısını döndürür (geçici hatalarda yeniden dener)."""
    if not script.strip():
        return ""
    output = with_retry(
        lambda: client().containers.run(
            egg["docker_image"],
            command=["sh", "-c", script],
            working_dir=CONTAINER_HOME,
            volumes=_volumes(server.id),
            network_mode="bridge",
            remove=True,
            stdout=True,
            stderr=True,
            labels={"mango.install": str(server.id)},
            **_limits(server, egg),
        ),
        cleanup=lambda: _cleanup_install(server.id),
    )
    return output.decode(errors="replace") if isinstance(output, bytes) else str(output)


def ensure_image(image: str) -> None:
    """İmaj yerelde yoksa indirir. containers.create imajı kendiliğinden indirmez."""
    try:
        client().images.get(image)
        return
    except ImageNotFound:
        pass
    if image.startswith("mango/"):
        # Panelin kendi imajları (ör. VPS) Docker Hub'da yoktur; sunucuda yerelde derlenir.
        raise RuntimeError(
            f"Yerel imaj bulunamadı: {image}. Sunucuda 'docker build -t {image} /opt/mango/docker/vps' çalıştırın."
        )
    repo, tag = image, "latest"
    if ":" in image.rsplit("/", 1)[-1]:
        repo, tag = image.rsplit(":", 1)
    client().images.pull(repo, tag=tag)


def _ports(server, container_port: int, egg: dict) -> dict:
    """publish_ports: false olan egg'lerde (Linux VPS) dışarıya port açılmaz; erişim tünel veya içeriden yapılır."""
    if egg.get("publish_ports", True) is False:
        return {}
    return {f"{container_port}/tcp": (_bind_ip(), server.port)}


def create(server, egg: dict, startup: str, container_port: int) -> str:
    ensure_image(egg["docker_image"])
    _cleanup_named(server.id)  # önceki yarım kalmış konteyner adı çakışmasın

    def _make():
        return client().containers.create(
            image=egg["docker_image"],
            name=f"mango-{server.id}",
            command=["sh", "-c", startup],
            working_dir=CONTAINER_HOME,
            environment={k: str(v) for k, v in server.variables.items()}
            | {k: str(v) for k, v in (server.env or {}).items()}
            | {"SERVER_PORT": str(container_port), "PYTHONUNBUFFERED": "1"},
            volumes=_volumes(server.id),
            ports=_ports(server, container_port, egg),
            restart_policy={"Name": "unless-stopped"},
            labels={"mango.server": str(server.id)},
            stdin_open=True,  # konsoldan komut gönderebilmek için
            **_limits(server, egg),
        )

    with START_LOCK:
        cont = with_retry(_make, cleanup=lambda: _cleanup_named(server.id))
    return cont.id


def recreate(server, egg: dict, startup: str, container_port: int) -> str:
    """Mevcut konteyneri siler ve ayarlarla yeniden oluşturur. Veriler korunur."""
    _forget_stdin(server.id)
    try:
        _container(server).remove(force=True)
    except NotFound:
        pass
    return create(server, egg, startup, container_port)


def _container(server):
    if not server.container_id:
        raise NotFound("Konteyner yok")
    return client().containers.get(server.container_id)


def _forget_stdin(server_id: int) -> None:
    with _stdin_lock:
        sock = _stdin_sockets.pop(server_id, None)
    if sock is not None:
        try:
            sock.close()
        except Exception:
            pass


def power(server, action: str) -> str:
    cont = _container(server)
    _forget_stdin(server.id)
    if action == "start":
        with START_LOCK:
            with_retry(cont.start)
    elif action == "stop":
        cont.stop(timeout=20)
    elif action == "restart":
        with START_LOCK:
            with_retry(lambda: cont.restart(timeout=20))
    elif action == "kill":
        cont.kill()
    else:
        raise ValueError("Geçersiz işlem")
    cont.reload()
    return cont.status


def last_failure(server) -> dict:
    """Başlatma başarısız olduğunda konteynerin çıkış kodunu, hata metnini ve son log satırlarını döndürür (1.40.28)."""
    try:
        cont = _container(server)
        cont.reload()
        st = cont.attrs.get("State", {}) or {}
        try:
            tail = cont.logs(tail=20).decode("utf-8", "replace")
        except Exception:
            tail = ""
        return {
            "exit_code": st.get("ExitCode"),
            "error": (st.get("Error") or "")[:300],
            "log": tail[-1500:].strip(),
        }
    except Exception as exc:
        return {"exit_code": None, "error": str(exc)[:300], "log": ""}


def status_map() -> dict[str, str] | None:
    """Tüm panel konteynerlerinin durumunu tek istekte döndürür (sunucu listesi için).
    Docker'a ulaşılamazsa None döner; çağıran taraf tek tek sorgulamaya geçer."""
    try:
        containers = client().containers.list(all=True, filters={"label": "mango.server"})
    except Exception:
        return None
    return {c.id: c.status for c in containers}


def status(server) -> str:
    try:
        return _container(server).status
    except NotFound:
        return "missing"


def health(server) -> dict:
    """Uyarılar için: durum, son çıkış kodu ve otomatik yeniden başlatma sayısı."""
    try:
        cont = _container(server)
        cont.reload()
    except NotFound:
        return {"status": "missing", "exit_code": None, "restarts": 0}
    state = cont.attrs.get("State", {})
    return {
        "status": cont.status,
        "exit_code": state.get("ExitCode"),
        "restarts": int(cont.attrs.get("RestartCount", 0) or 0),
    }


def _uptime_seconds(cont) -> int:
    """Konteynerin son başlatılma zamanından bu yana geçen süre (saniye)."""
    try:
        started = cont.attrs["State"]["StartedAt"]  # RFC3339, nanosaniyeli olabilir
        base = started.split(".")[0].rstrip("Z")
        began = datetime.strptime(base, "%Y-%m-%dT%H:%M:%S").replace(tzinfo=timezone.utc)
        return max(0, int((datetime.now(timezone.utc) - began).total_seconds()))
    except Exception:
        return 0


def stats(server) -> dict:
    """CPU yüzdesi, bellek ve çalışma süresi. Çalışmayan sunucuda sıfırlar döner."""
    empty = {
        "running": False, "cpu_percent": 0.0, "memory_mb": 0.0,
        "memory_limit_mb": server.memory_mb, "uptime_seconds": 0,
    }
    try:
        cont = _container(server)
    except NotFound:
        return empty
    if cont.status != "running":
        return empty
    s = cont.stats(stream=False)
    cpu = s.get("cpu_stats", {})
    pre = s.get("precpu_stats", {})
    cpu_delta = cpu.get("cpu_usage", {}).get("total_usage", 0) - pre.get("cpu_usage", {}).get("total_usage", 0)
    sys_delta = cpu.get("system_cpu_usage", 0) - pre.get("system_cpu_usage", 0)
    ncpu = cpu.get("online_cpus") or len(cpu.get("cpu_usage", {}).get("percpu_usage") or []) or 1
    cpu_pct = (cpu_delta / sys_delta) * ncpu * 100.0 if cpu_delta > 0 and sys_delta > 0 else 0.0
    mem = s.get("memory_stats", {})
    usage = mem.get("usage", 0)
    # cgroup v2 'inactive_file', v1 'cache' önbelleği temsil eder; kullanımdan düşülür.
    detail = mem.get("stats", {})
    cache = detail.get("inactive_file", detail.get("cache", 0))
    return {
        "running": True,
        "cpu_percent": round(cpu_pct, 1),
        "memory_mb": round(max(usage - cache, 0) / 1024 / 1024, 1),
        "memory_limit_mb": server.memory_mb,
        "uptime_seconds": _uptime_seconds(cont),
    }


def send_command(server, text: str) -> None:
    """Çalışan sunucunun stdin'ine bir satır yazar."""
    cont = _container(server)
    if cont.status != "running":
        raise RuntimeError("Sunucu çalışmıyor")
    data = (text + "\n").encode()
    with _stdin_lock:
        sock = _stdin_sockets.get(server.id)
        for attempt in range(2):
            try:
                if sock is None:
                    sock = cont.attach_socket(params={"stdin": 1, "stream": 1, "stdout": 0, "stderr": 0})
                    _stdin_sockets[server.id] = sock
                raw = getattr(sock, "_sock", None)
                if raw is not None:
                    raw.sendall(data)
                else:
                    sock.write(data)
                    sock.flush()
                return
            except OSError:
                _stdin_sockets.pop(server.id, None)
                sock = None
                if attempt == 1:
                    raise RuntimeError("Komut gönderilemedi")


EXEC_TIMEOUT_SECONDS = 600


def exec_stream(server, command: str, loop, queue) -> None:
    """Konteyner içinde ayrı bir süreçte kabuk komutu çalıştırır ve çıktısını konsola akıtır.
    Komutun stdin'i yoktur; çalışan uygulamanın girdisine dokunmaz."""

    def push(text: str) -> None:
        loop.call_soon_threadsafe(queue.put_nowait, text)

    def worker():
        try:
            cont = _container(server)
            if cont.status != "running":
                raise RuntimeError("Sunucu çalışmıyor")
            api = client().api
            ex = api.exec_create(cont.id, ["sh", "-c", command], workdir=CONTAINER_HOME, stdout=True, stderr=True)
            deadline = time.time() + EXEC_TIMEOUT_SECONDS
            for out, err in api.exec_start(ex["Id"], stream=True, demux=True):
                for part in (out, err):
                    if part:
                        push(part.decode(errors="replace"))
                if time.time() > deadline:
                    push("\n[zaman aşımı: komut hâlâ çalışıyor olabilir]\n")
                    break
            code = api.exec_inspect(ex["Id"]).get("ExitCode")
            push(f"\n[çıkış kodu: {code}]\n")
        except Exception as exc:
            push(f"\n[komut çalıştırılamadı: {exc}]\n")

    threading.Thread(target=worker, daemon=True, name="console-exec").start()


def stream_logs(server, loop, queue, stop: threading.Event) -> None:
    """Konteyner logunu canlı akıtır. Konteyner yeniden başlarsa ya da log akışı koparsa
    otomatik olarak yeniden bağlanır; yalnızca konsol kapanınca (stop) biter."""
    first = True
    since = int(time.time())
    try:
        while not stop.is_set():
            try:
                cont = _container(server)
                options = {"stream": True, "follow": True}
                if first:
                    options["tail"] = 200
                    first = False
                else:
                    options["since"] = since
                for chunk in cont.logs(**options):
                    if stop.is_set():
                        return
                    since = int(time.time())
                    loop.call_soon_threadsafe(queue.put_nowait, chunk.decode(errors="replace"))
            except Exception:
                pass  # konteyner henüz yok ya da akış koptu: bekleyip yeniden dene
            if stop.wait(2):
                return
    finally:
        loop.call_soon_threadsafe(queue.put_nowait, None)


def logs(server, tail: int = 200) -> str:
    try:
        return _container(server).logs(tail=tail).decode(errors="replace")
    except NotFound:
        return ""


def delete(server) -> None:
    delete_by_id(server.id, server.container_id)


def delete_by_id(server_id: int, container_id: str | None = None) -> None:
    """Konteyneri ve veri klasörünü kimliğe göre siler (kayıt geri alındıktan sonra da çalışır)."""
    _forget_stdin(server_id)
    try:
        ref = container_id or f"mango-{server_id}"
        client().containers.get(ref).remove(force=True)
    except NotFound:
        pass
    shutil.rmtree(Path(settings.data_dir) / str(server_id), ignore_errors=True)


def prepull_async(images: list[str]) -> None:
    """Egg imajlarını arka planda indirir. Hata olursa sessizce geçer; ilk oluşturmada yine denenir."""
    unique = sorted({img for img in images if img})

    def worker():
        for image in unique:
            try:
                ensure_image(image)
            except Exception:
                pass

    threading.Thread(target=worker, daemon=True, name="egg-prepull").start()
