"""Komut satırı: sunucuyu başlatma, veritabanı ve yönetici oluşturma."""
import argparse
import os
import sys


def _create_admin(username: str) -> None:
    from .db import SessionLocal, User, init_db
    from .security import hash_password

    password = os.environ.get("MANGO_ADMIN_PASSWORD", "")
    if len(password) < 8:
        sys.exit("MANGO_ADMIN_PASSWORD ortam değişkeni en az 8 karakter olmalı.")
    init_db()
    with SessionLocal() as db:
        if db.query(User).filter_by(username=username).first():
            sys.exit(f"'{username}' zaten var.")
        db.add(User(username=username, password_hash=hash_password(password), is_admin=True))
        db.commit()
    print(f"Yönetici '{username}' oluşturuldu.")


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(prog="mango", description="Mango Panel")
    sub = parser.add_subparsers(dest="cmd")
    sub.add_parser("serve", help="Paneli başlat (varsayılan)")
    sub.add_parser("init-db", help="Veritabanı tablolarını oluştur")
    admin = sub.add_parser("create-admin", help="Yönetici hesabı oluştur")
    admin.add_argument("username")
    args = parser.parse_args(argv)

    if args.cmd == "init-db":
        from .db import init_db
        init_db()
        print("Veritabanı hazır.")
    elif args.cmd == "create-admin":
        _create_admin(args.username)
    else:
        import uvicorn
        from .config import settings
        uvicorn.run("mango.main:app", host=settings.host, port=settings.port, proxy_headers=True, timeout_graceful_shutdown=10)


if __name__ == "__main__":
    main()
