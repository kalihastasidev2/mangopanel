"""Bildirim sistemi (1.37.0).

Yönetici bir bildirim yazar ve hedef seçer: tüm kullanıcılar, belirli bir paketi satın alanlar
veya kullanıcı adıyla seçilen kişiler. Her alıcı için ayrı bir kayıt tutulur; okundu bilgisi kişiye özeldir.
Paket alıcıları: o paket için satın alma talebi açanlar ile o paketin egg'iyle sunucusu olanlar."""
import datetime as dt

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from .api import audit
from .db import Notification, NotificationRecipient, PremiumPlan, Server, Ticket, User
from .security import admin_only, current_user, get_db

router = APIRouter(prefix="/api")
MAX_USERNAMES = 500


class NotifyIn(BaseModel):
    title: str = Field(min_length=2, max_length=120)
    body: str = Field(min_length=1, max_length=2000)
    target: str = Field(pattern=r"^(all|plan|users)$")
    plan_id: int | None = None
    usernames: list[str] = Field(default_factory=list, max_length=MAX_USERNAMES)


def resolve_recipients(db: Session, body: NotifyIn) -> set[int]:
    if body.target == "all":
        return {uid for (uid,) in db.query(User.id).all()}
    if body.target == "plan":
        plan = db.get(PremiumPlan, body.plan_id) if body.plan_id else None
        if plan is None:
            raise HTTPException(400, "Paket seçin")
        ids = {uid for (uid,) in db.query(Ticket.user_id).filter(
            Ticket.plan_id == plan.id, Ticket.category == "purchase").all()}
        if plan.egg:
            ids |= {uid for (uid,) in db.query(Server.owner_id).filter(Server.egg == plan.egg).all()}
        return ids
    names = [n.strip() for n in body.usernames if n.strip()]
    if not names:
        raise HTTPException(400, "En az bir kullanıcı adı girin")
    return {uid for (uid,) in db.query(User.id).filter(User.username.in_(names)).all()}


@router.post("/admin/notifications", status_code=201)
def send_notification(body: NotifyIn, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    recipients = resolve_recipients(db, body)
    if not recipients:
        raise HTTPException(400, "Alıcı bulunamadı")
    note = Notification(title=body.title.strip(), body=body.body.strip(), target=body.target,
                        plan_id=body.plan_id if body.target == "plan" else None,
                        created_by=admin.username, created_at=dt.datetime.now(dt.timezone.utc))
    db.add(note)
    db.flush()
    for uid in recipients:
        db.add(NotificationRecipient(notification_id=note.id, user_id=uid))
    audit(db, admin.username, "notification.send", note.title, f"hedef={body.target} alıcı={len(recipients)}")
    db.commit()
    return {"id": note.id, "recipients": len(recipients)}


@router.get("/admin/notifications")
def list_sent(_: User = Depends(admin_only), db: Session = Depends(get_db)):
    out = []
    for note in db.query(Notification).order_by(Notification.id.desc()).limit(50).all():
        total = db.query(NotificationRecipient).filter_by(notification_id=note.id).count()
        read = db.query(NotificationRecipient).filter(
            NotificationRecipient.notification_id == note.id, NotificationRecipient.read_at.isnot(None)).count()
        out.append({"id": note.id, "title": note.title, "target": note.target, "created_by": note.created_by,
                    "created_at": note.created_at.isoformat() if note.created_at else None,
                    "recipients": total, "read": read})
    return out


@router.get("/notifications")
def my_notifications(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = (db.query(NotificationRecipient, Notification)
            .join(Notification, Notification.id == NotificationRecipient.notification_id)
            .filter(NotificationRecipient.user_id == user.id)
            .order_by(NotificationRecipient.id.desc()).limit(100).all())
    items = [{"id": r.id, "title": n.title, "body": n.body, "read": r.read_at is not None,
              "created_at": n.created_at.isoformat() if n.created_at else None} for r, n in rows]
    unread = sum(1 for i in items if not i["read"])
    return {"items": items, "unread": unread}


@router.post("/notifications/{recipient_id}/read")
def mark_read(recipient_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    row = db.get(NotificationRecipient, recipient_id)
    if row is None or row.user_id != user.id:
        raise HTTPException(404, "Bildirim bulunamadı")
    if row.read_at is None:
        row.read_at = dt.datetime.now(dt.timezone.utc)
        db.commit()
    return {"ok": True}


@router.post("/notifications/read-all")
def mark_all_read(user: User = Depends(current_user), db: Session = Depends(get_db)):
    now = dt.datetime.now(dt.timezone.utc)
    db.query(NotificationRecipient).filter(
        NotificationRecipient.user_id == user.id, NotificationRecipient.read_at.is_(None)).update(
        {NotificationRecipient.read_at: now}, synchronize_session=False)
    db.commit()
    return {"ok": True}
