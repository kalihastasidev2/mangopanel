"""Alt alan adı (1.40.0): web sitesi sunucusuna <ad>.<site_base_domain> CNAME kaydı açar.

- Ayarlar eksikse (zone, token veya base domain) hiçbir Cloudflare çağrısı yapılmaz; site /sites/<ad> adresinde kalır.
- Ad alınmışsa (Cloudflare'de bu isimde herhangi bir kayıt varsa) 409 döner.
- Ad değişince yeni kayıt önce açılır, sonra eski kayıt silinir."""
import logging
from urllib.parse import quote, urlparse

from fastapi import HTTPException
from sqlalchemy.orm import Session

from .cloudflare import CloudflareError, _call
from .config import settings
from .store import flag, get_setting

log = logging.getLogger("mango.site_dns")
RESERVED = {"www", "panel", "api", "mail", "admin", "ns1", "ns2", "sites", "static", "mango"}


def panel_host() -> str:
    return (urlparse(settings.public_url).hostname or "").lower()


def base_domain(db: Session) -> str:
    """Alt alan adı zone'u: ayarda yazılıysa o, değilse panel adresinin üst alan adı (panel.example.com → example.com)."""
    explicit = get_setting(db, "site_base_domain").strip().lower().strip(".")
    if explicit:
        return explicit
    host = panel_host()
    return host.split(".", 1)[1] if host.count(".") >= 2 else ""


def public_base(db: Session) -> str:
    """Arayüzün gösterdiği alt alan adı zone'u. Token ve Zone ID girilmeden boş döner."""
    if not flag(db, "site_subdomains"):
        return ""
    if not (get_setting(db, "cf_api_token").strip() and get_setting(db, "cf_zone_id").strip()):
        return ""
    return base_domain(db)


def _creds(db: Session):
    token = get_setting(db, "cf_api_token").strip()
    zone = get_setting(db, "cf_zone_id").strip()
    return (token, zone) if token and zone else None


def _cfg(db: Session):
    if not flag(db, "site_subdomains"):
        return None
    base = base_domain(db)
    token = get_setting(db, "cf_api_token").strip()
    zone = get_setting(db, "cf_zone_id").strip()
    if not (base and token and zone):
        return None
    target = get_setting(db, "domain_cname_target").strip().lower() or panel_host()
    return base, token, zone, target


def _delete(zone: str, token: str, rid: str) -> None:
    try:
        _call("DELETE", f"/zones/{zone}/dns_records/{rid}", token)
    except CloudflareError as exc:
        log.warning("DNS kaydı silinemedi (%s): %s", rid, exc)


def release(db: Session, rid: str | None) -> None:
    """Oluşturma yarıda kalırsa Cloudflare'de açılmış kaydı geri alır."""
    cfg = _cfg(db)
    if rid and cfg:
        _delete(cfg[2], cfg[1], rid)


def assign(db: Session, server, slug: str | None) -> None:
    """Sunucunun alt alan adını ayarlar. slug boşsa mevcut kaydı siler. Hata olursa HTTPException fırlatır."""
    cfg = _cfg(db)
    if not slug or not cfg:
        if server.site_dns_id:
            creds = (cfg[1], cfg[2]) if cfg else _creds(db)
            if creds:
                _delete(creds[1], creds[0], server.site_dns_id)
        server.site_dns_id = None
        server.site_host = None
        return
    base, token, zone, target = cfg
    host = f"{slug}.{base}"
    if server.site_host == host and server.site_dns_id:
        return  # değişmedi
    if slug in RESERVED:
        raise HTTPException(409, "Bu alt alan adı ayrılmış, başka bir ad seçin")
    try:
        existing = _call("GET", f"/zones/{zone}/dns_records?name={quote(host)}", token) or []
        if existing:
            raise HTTPException(409, "Bu alt alan adı alınmış, başka bir ad seçin")
        result = _call("POST", f"/zones/{zone}/dns_records", token,
                       {"type": "CNAME", "name": host, "content": target, "proxied": True, "ttl": 1})
    except CloudflareError as exc:
        raise HTTPException(502, f"Cloudflare kaydı oluşturulamadı: {exc}")
    old = server.site_dns_id
    server.site_dns_id = result["id"]
    server.site_host = host
    if old:
        _delete(zone, token, old)
