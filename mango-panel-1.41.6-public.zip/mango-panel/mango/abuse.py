"""Kötüye kullanım uyarıları (1.32.0).

Çalışan sunucuların CPU kullanımı periyodik olarak ölçülür. Bir sunucu eşik üstünde
ardışık birkaç ölçümde kalırsa (ör. kripto madenciliği belirtisi) Ayarlar'daki webhook'a
bildirim gönderilir. Sunucu otomatik olarak askıya ALINMAZ; karar yöneticiye aittir.
Webhook adresi boşsa hiçbir şey yapılmaz."""
import json
import logging
import threading
import time
import urllib.request

from .db import SessionLocal, Server, User
from .store import get_setting

log = logging.getLogger("mango.abuse")
CPU_THRESHOLD = 90.0      # yüzde
SUSTAINED_CHECKS = 5      # ardışık ölçüm (60 sn aralıkla ~5 dk)
COOLDOWN_SECONDS = 1800   # aynı sunucu için 30 dk'da bir bildirim
INTERVAL_SECONDS = 60

_streak: dict[int, int] = {}
_last_alert: dict[int, float] = {}


def _post(url: str, payload: dict) -> None:
    req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"),
                                 headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=5) as resp:  # noqa: S310 - adres yönetici tarafından ayarlanır, https zorunlu
        resp.read(1024)


def check_once(stats_for, post=_post, now=None) -> list[dict]:
    """Bir tur ölçüm yapar, uyarı gönderilenleri döndürür. Testlerde stats_for ve post enjekte edilir."""
    now = time.time() if now is None else now
    db = SessionLocal()
    alerts = []
    try:
        url = get_setting(db, "alert_webhook_url").strip()
        if not url:
            return alerts
        servers = db.query(Server).all()
        for server in servers:
            try:
                st = stats_for(server)
            except Exception:  # noqa: BLE001 - tek sunucunun hatası diğerlerini durdurmaz
                continue
            if not st.get("running"):
                _streak.pop(server.id, None)
                continue
            if st.get("cpu_percent", 0) >= CPU_THRESHOLD:
                _streak[server.id] = _streak.get(server.id, 0) + 1
            else:
                _streak[server.id] = 0
            if _streak[server.id] >= SUSTAINED_CHECKS and now - _last_alert.get(server.id, 0) >= COOLDOWN_SECONDS:
                owner = db.get(User, server.owner_id)
                payload = {
                    "event": "abuse.suspected",
                    "server_id": server.id,
                    "server_name": server.name,
                    "owner": owner.username if owner else None,
                    "egg": server.egg,
                    "cpu_percent": st.get("cpu_percent"),
                    "reason": f"CPU {CPU_THRESHOLD:.0f}% üzerinde {SUSTAINED_CHECKS} ardışık ölçüm",
                    "action": "none",  # otomatik askıya alma yok
                }
                try:
                    post(url, payload)
                    _last_alert[server.id] = now
                    _streak[server.id] = 0
                    alerts.append(payload)
                except Exception as exc:  # noqa: BLE001
                    log.warning("Uyarı webhook'a gönderilemedi: %s", exc)
    finally:
        db.close()
    return alerts


def start_watcher(stats_for) -> None:
    def loop():
        while True:
            try:
                check_once(stats_for)
            except Exception as exc:  # noqa: BLE001
                log.warning("Kötüye kullanım taraması hatası: %s", exc)
            time.sleep(INTERVAL_SECONDS)

    threading.Thread(target=loop, name="mango-abuse", daemon=True).start()
