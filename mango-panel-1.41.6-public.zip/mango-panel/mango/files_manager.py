"""Sunucu dosya yöneticisi. Tüm yollar sunucunun kendi klasörüne kilitlidir."""
import os
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from .docker_manager import server_dir

MAX_TEXT_BYTES = 1_000_000  # düzenleyicide açılabilen en büyük dosya
MAX_LIST_ENTRIES = 1000


class FileError(ValueError):
    pass


def _root(server_id: int) -> Path:
    return server_dir(server_id).resolve()


def resolve(server_id: int, rel: str) -> Path:
    """Göreli yolu mutlak yola çevirir. Kök klasörden dışarı çıkan yollar reddedilir.
    Sembolik bağlantılar çözüldükten sonra kontrol edilir, bu yüzden bağlantıyla kaçılamaz."""
    rel = (rel or "").strip().replace("\\", "/").lstrip("/")
    if "\x00" in rel:
        raise FileError("Geçersiz yol")
    root = _root(server_id)
    target = (root / rel).resolve()
    if target != root and root not in target.parents:
        raise FileError("Yol sunucu klasörünün dışında")
    return target


def _rel(root: Path, path: Path) -> str:
    return "" if path == root else path.relative_to(root).as_posix()


def list_dir(server_id: int, rel: str) -> dict:
    root = _root(server_id)
    target = resolve(server_id, rel)
    if not target.exists():
        if target == root:
            return {"path": "", "entries": []}
        raise FileError("Klasör bulunamadı")
    if not target.is_dir():
        raise FileError("Bu bir klasör değil")
    entries = []
    for child in sorted(target.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower())):
        if len(entries) >= MAX_LIST_ENTRIES:
            break
        try:
            st = child.stat()
        except OSError:
            continue
        entries.append({
            "name": child.name,
            "path": _rel(root, child),
            "is_dir": child.is_dir(),
            "size": 0 if child.is_dir() else st.st_size,
            "modified": datetime.fromtimestamp(st.st_mtime, timezone.utc).isoformat(),
        })
    return {"path": _rel(root, target), "entries": entries}


def dir_size_mb(server_id: int, cap_files: int = 50_000) -> float:
    """Sunucu klasörünün boyutu (MB). Çok dosyalı klasörlerde taramayı sınırlar."""
    total = 0
    count = 0
    for dirpath, _dirnames, filenames in os.walk(_root(server_id)):  # sembolik bağlantıları izlemez
        for name in filenames:
            try:
                total += os.lstat(os.path.join(dirpath, name)).st_size
            except OSError:
                pass
            count += 1
            if count >= cap_files:
                return round(total / 1048576, 1)
    return round(total / 1048576, 1)


def seed_files(server_id: int, files: dict[str, str]) -> None:
    """Egg'in örnek dosyalarını yazar. Var olan dosyanın üzerine yazmaz."""
    root = _root(server_id)
    for rel, content in files.items():
        target = resolve(server_id, rel)
        if target.exists() or target == root:
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content.encode("utf-8"))


def read_text(server_id: int, rel: str) -> str:
    target = resolve(server_id, rel)
    if not target.is_file():
        raise FileError("Dosya bulunamadı")
    if target.stat().st_size > MAX_TEXT_BYTES:
        raise FileError("Dosya düzenleyici için çok büyük (en fazla 1 MB)")
    data = target.read_bytes()
    if b"\x00" in data:
        raise FileError("İkili dosya düzenlenemez")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        raise FileError("Dosya UTF-8 değil, düzenlenemez")


def _used_bytes(root: Path, exclude: Path | None = None) -> int:
    """Klasördeki toplam boyut. 'exclude' yolu (üzerine yazılacak dosya) hesaba katılmaz."""
    total = 0
    skip = str(exclude) if exclude is not None else None
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in filenames:
            path = os.path.join(dirpath, name)
            if path == skip:
                continue
            try:
                total += os.lstat(path).st_size
            except OSError:
                pass
    return total


def write_text(server_id: int, rel: str, content: str, quota_bytes: int | None = None) -> None:
    root = _root(server_id)
    target = resolve(server_id, rel)
    if target == root or target.is_dir():
        raise FileError("Bir klasör üzerine yazılamaz")
    data = content.encode("utf-8")
    if len(data) > MAX_TEXT_BYTES:
        raise FileError("İçerik çok büyük (en fazla 1 MB)")
    if target.parent != root and root not in target.parent.parents:
        raise FileError("Geçersiz yol")
    if quota_bytes is not None and _used_bytes(root, exclude=target) + len(data) > quota_bytes:
        raise FileError("Disk kotası aşıldı. Dosya silin ya da yöneticinizden kota isteyin.")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)


def make_dir(server_id: int, rel: str) -> None:
    root = _root(server_id)
    target = resolve(server_id, rel)
    if target == root:
        raise FileError("Kök klasör zaten var")
    if target.exists():
        raise FileError("Bu isimde bir öğe zaten var")
    target.mkdir(parents=True)


def delete(server_id: int, rel: str) -> None:
    root = _root(server_id)
    target = resolve(server_id, rel)
    if target == root:
        raise FileError("Sunucu kök klasörü silinemez")
    if not target.exists() and not target.is_symlink():
        raise FileError("Öğe bulunamadı")
    if target.is_symlink() or target.is_file():
        target.unlink()
    else:
        shutil.rmtree(target)


MAX_UPLOAD_BYTES = 100 * 1024 * 1024  # tek dosya yüklemesi için üst sınır


def save_bytes(server_id: int, rel: str, data: bytes, quota_bytes: int | None = None) -> None:
    """İkili dahil her dosyayı kaydeder (yükleme). Üzerine yazma ve kota kuralları write_text ile aynıdır."""
    root = _root(server_id)
    target = resolve(server_id, rel)
    if target == root or target.is_dir():
        raise FileError("Bir klasör üzerine yazılamaz")
    if len(data) > MAX_UPLOAD_BYTES:
        raise FileError("Dosya çok büyük (en fazla 100 MB)")
    if target.parent != root and root not in target.parent.parents:
        raise FileError("Geçersiz yol")
    if quota_bytes is not None and _used_bytes(root, exclude=target) + len(data) > quota_bytes:
        raise FileError("Disk kotası aşıldı. Dosya silin ya da yöneticinizden kota isteyin.")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)


def file_for_download(server_id: int, rel: str) -> Path:
    target = resolve(server_id, rel)
    if not target.is_file():
        raise FileError("Dosya bulunamadı")
    return target


def copy_tree(src_server_id: int, dst_server_id: int) -> None:
    """Klonlama: sunucu klasörünün tamamını kopyalar. Sembolik bağlantılar bağlantı olarak kalır."""
    shutil.copytree(_root(src_server_id), _root(dst_server_id), dirs_exist_ok=True, symlinks=True)


MAX_EXTRACT_BYTES = 500 * 1024 * 1024  # arşivin açılmış toplam boyutu
MAX_EXTRACT_FILES = 5000


def extract_zip(server_id: int, rel: str, quota_bytes: int | None = None) -> int:
    """Zip arşivini arşivin bulunduğu klasöre açar. Yol kaçışı, sembolik bağlantı ve boyut sınırları denetlenir."""
    archive = file_for_download(server_id, rel)
    if archive.suffix.lower() != ".zip":
        raise FileError("Yalnızca .zip dosyaları açılabilir")
    root = _root(server_id)
    dest = archive.parent
    try:
        zf = zipfile.ZipFile(archive)
    except zipfile.BadZipFile:
        raise FileError("Geçersiz zip dosyası")
    with zf:
        infos = [i for i in zf.infolist() if not i.is_dir()]
        if len(infos) > MAX_EXTRACT_FILES:
            raise FileError(f"Arşivde çok fazla dosya (en fazla {MAX_EXTRACT_FILES})")
        declared = sum(i.file_size for i in infos)
        if declared > MAX_EXTRACT_BYTES:
            raise FileError("Arşiv açılınca çok büyük (en fazla 500 MB)")
        if quota_bytes is not None and _used_bytes(root) + declared > quota_bytes:
            raise FileError("Disk kotası aşılacak. Dosya silin ya da yöneticinizden kota isteyin.")
        written_total = 0
        count = 0
        for info in infos:
            name = info.filename.replace("\\", "/")
            if name.startswith("/") or "\x00" in name or ".." in name.split("/"):
                raise FileError(f"Güvenli olmayan yol içeriyor: {name}")
            if (info.external_attr >> 16) & 0o170000 == 0o120000:
                continue  # sembolik bağlantılar atlanır
            target = (dest / name).resolve()
            if root not in target.parents:
                raise FileError(f"Güvenli olmayan yol içeriyor: {name}")
            try:
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info) as src, open(target, "wb") as out:
                    while chunk := src.read(64 * 1024):
                        written_total += len(chunk)
                        if written_total > MAX_EXTRACT_BYTES:
                            raise FileError("Arşiv açılırken boyut sınırı aşıldı")
                        out.write(chunk)
            except OSError:
                raise FileError(f"Dosya yazılamadı: {name}")
            count += 1
    return count
