"""1.18.0: premium paketler, destek/satın alma talepleri ve node yönetimi.

Node kurulumu: yönetici bir node oluşturur, panel tek satırlık bir kurulum komutu üretir.
Komut VPS'te ajanı (agent.py) kurar ve panele periyodik olarak durum bildirmesini sağlar.
"""
import datetime as dt
import hashlib
import json
import re
import secrets
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse, PlainTextResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from . import discord_bot

from .api import ServerIn, create_server
from .config import settings
from .db import Node, PremiumPlan, Server, Ticket, TicketMessage, User
from .eggs import EggError, load_eggs
from .security import admin_only, current_user, get_db
from .store import audit

router = APIRouter(prefix="/api")
NODE_ONLINE_SECONDS = 90
MAX_STATS_BYTES = 8192


def _now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _utc(value: dt.datetime | None) -> dt.datetime | None:
    if value is None:
        return None
    return value if value.tzinfo else value.replace(tzinfo=dt.timezone.utc)


def _iso(value: dt.datetime | None) -> str | None:
    return value.isoformat() if value else None


# ---------- şemalar ----------
class PlanIn(BaseModel):
    name: str = Field(min_length=2, max_length=48)
    description: str = Field("", max_length=1000)
    price_text: str = Field("", max_length=60)
    egg: str | None = Field(None, max_length=64)  # boşsa serbest paket; doluysa bu egg'den sunucu verilir
    memory_mb: int = Field(1024, ge=128, le=16384)
    cpu_percent: int = Field(100, ge=10, le=800)
    disk_mb: int = Field(2048, ge=256, le=102400)
    max_servers: int = Field(2, ge=0, le=100)
    sort_order: int = Field(0, ge=-1000, le=1000)
    active: bool = True
    category: str = Field("Genel", min_length=1, max_length=32)
    is_free: bool = False
    accent: str = Field("", pattern=r"^$|^#[0-9a-fA-F]{6}$")


class PlanUpdate(BaseModel):
    name: str | None = Field(None, min_length=2, max_length=48)
    description: str | None = Field(None, max_length=1000)
    price_text: str | None = Field(None, max_length=60)
    egg: str | None = Field(None, max_length=64)
    memory_mb: int | None = Field(None, ge=128, le=16384)
    cpu_percent: int | None = Field(None, ge=10, le=800)
    disk_mb: int | None = Field(None, ge=256, le=102400)
    max_servers: int | None = Field(None, ge=0, le=100)
    sort_order: int | None = Field(None, ge=-1000, le=1000)
    active: bool | None = None
    category: str | None = Field(None, min_length=1, max_length=32)
    is_free: bool | None = None
    accent: str | None = Field(None, pattern=r"^$|^#[0-9a-fA-F]{6}$")


class TicketIn(BaseModel):
    subject: str = Field(min_length=3, max_length=120)
    message: str = Field(min_length=3, max_length=2000)
    category: str = Field("support", pattern=r"^(support|purchase)$")
    plan_id: int | None = None
    coupon_code: str | None = Field(None, max_length=32)


class MessageIn(BaseModel):
    text: str = Field(min_length=1, max_length=2000)


class NodeIn(BaseModel):
    name: str = Field(min_length=2, max_length=48)
    description: str = Field("", max_length=255)
    max_memory_mb: int = Field(8192, ge=512, le=10_000_000)
    max_disk_mb: int = Field(102400, ge=1024, le=100_000_000)


class NodeUpdate(BaseModel):
    name: str | None = Field(None, min_length=2, max_length=48)
    description: str | None = Field(None, max_length=255)
    max_memory_mb: int | None = Field(None, ge=512, le=10_000_000)
    max_disk_mb: int | None = Field(None, ge=1024, le=100_000_000)
    rotate_token: bool = False  # True: eski anahtar geçersiz olur, yeni kurulum komutu üretilir


class HeartbeatIn(BaseModel):
    version: str = Field("", max_length=20)
    stats: dict = Field(default_factory=dict)


class GrantIn(BaseModel):
    node_id: int | None = None  # sunucunun bağlanacağı node (kayıt amaçlı)
    demo: bool = False  # 1.38.0: 3 günlük demo sunucusu
    duration: str | None = Field(None, max_length=16)  # 1.40.24: sunucu süresi (boş = süresiz)
    duration_days: int | None = Field(None, ge=1, le=3650)
    server_name: str | None = Field(None, min_length=2, max_length=48, pattern=r"^[A-Za-z0-9 _-]+$")


# ---------- yardımcılar ----------
def _egg_name(slug: str | None) -> str | None:
    if not slug:
        return None
    try:
        egg = load_eggs().get(slug)
    except EggError:
        return slug
    return egg.get("name", slug) if egg else slug


def _normalize_egg(value: str | None) -> str | None:
    """Boş değer serbest paket demektir. Dolu değer mevcut bir egg olmalı."""
    if not value or not value.strip():
        return None
    slug = value.strip()
    try:
        eggs = load_eggs()
    except EggError as exc:
        raise HTTPException(500, str(exc))
    if slug not in eggs:
        raise HTTPException(400, "Seçilen egg bulunamadı")
    return slug


# Ürüne göre görsel tema: Node.js yeşil, PHP mor, Python mavi; diğerleri turuncu.
THEMES = [("node", "Node.js", "#3fb950"), ("php", "PHP", "#8b5cf6"), ("python", "Python", "#3b82f6")]
DEFAULT_THEME = ("Genel", "#f5a524")


def _theme(egg_slug: str | None, egg_name: str | None) -> tuple[str, str]:
    text = f"{egg_slug or ''} {egg_name or ''}".lower()
    for key, label, color in THEMES:
        if key in text:
            return label, color
    return DEFAULT_THEME


def _features(description: str | None) -> list[str]:
    """Açıklamanın her boş olmayan satırı bir özellik maddesidir."""
    return [line.strip() for line in (description or "").splitlines() if line.strip()]


def _plan_public(p: PremiumPlan) -> dict:
    """Müşterilere gösterilebilir alanlar (egg slug'ı ve yönetim bilgileri hariç)."""
    egg_name = _egg_name(p.egg) or ""
    label, color = _theme(p.egg, egg_name)
    return {
        "id": p.id, "name": p.name, "description": p.description or "", "features": _features(p.description),
        "price_text": p.price_text or "", "category": p.category or "Genel", "is_free": bool(p.is_free),
        "kind": label if p.egg else "Serbest paket", "accent": p.accent or color, "egg_name": egg_name,
        "memory_mb": p.memory_mb, "cpu_percent": p.cpu_percent, "disk_mb": p.disk_mb,
        "max_servers": p.max_servers,
    }


def _plan_json(p: PremiumPlan) -> dict:
    """Yönetici görünümü: herkese açık alanlar + egg slug'ı, sıra ve satış durumu."""
    return {**_plan_public(p), "egg": p.egg or "", "sort_order": p.sort_order, "active": bool(p.active)}


def _ticket_row(t: Ticket, owner: User | None, plan: PremiumPlan | None) -> dict:
    return {
        "id": t.id, "subject": t.subject, "category": t.category, "status": t.status,
        "user_id": t.user_id, "username": owner.username if owner else "?",
        "plan_id": t.plan_id, "plan_name": plan.name if plan else None,
        "plan_egg": (plan.egg or None) if plan else None,
        "plan_price": (plan.price_text or "") if plan else "",
        "coupon_code": t.coupon_code,
        "created_at": _iso(t.created_at), "updated_at": _iso(t.updated_at),
    }


def _ticket_detail(db: Session, t: Ticket) -> dict:
    owner = db.get(User, t.user_id)
    plan = db.get(PremiumPlan, t.plan_id) if t.plan_id else None
    messages = db.query(TicketMessage).filter_by(ticket_id=t.id).order_by(TicketMessage.id).all()
    data = _ticket_row(t, owner, plan)
    data["messages"] = [
        {"id": m.id, "author": m.author, "is_admin": bool(m.is_admin), "text": m.text, "created_at": _iso(m.created_at)}
        for m in messages
    ]
    return data


def _visible_ticket(db: Session, user: User, ticket_id: int) -> Ticket:
    t = db.get(Ticket, ticket_id)
    if t is None or (not user.is_admin and t.user_id != user.id):
        raise HTTPException(404, "Talep bulunamadı")
    return t


def _hash(token: str) -> str:
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def _bearer(request: Request) -> str:
    auth = request.headers.get("authorization", "")
    return auth[7:].strip() if auth.startswith("Bearer ") else ""


def _node_json(n: Node) -> dict:
    last = _utc(n.last_seen)
    online = bool(last and (_now() - last).total_seconds() <= NODE_ONLINE_SECONDS)
    return {
        "id": n.id, "name": n.name, "description": n.description or "",
        "max_memory_mb": n.max_memory_mb, "max_disk_mb": n.max_disk_mb,
        "version": n.version or "", "last_seen": _iso(last), "online": online,
        "stats": n.stats or {}, "created_at": _iso(n.created_at),
    }


def _public_base(request: Request) -> str:
    host = request.headers.get("x-forwarded-host") or request.headers.get("host") or ""
    scheme = "https" if settings.access_mode == "cloudflare" else request.url.scheme
    base = f"{scheme}://{host}"
    if not re.fullmatch(r"https?://[A-Za-z0-9.-]+(:\d{1,5})?", base):
        raise HTTPException(400, "Geçersiz panel adresi")
    return base


def _install_command(request: Request, token: str) -> str:
    return f"curl -fsSL {_public_base(request)}/api/nodes/install/{token} | sudo bash"


# ---------- premium paketler ----------
@router.get("/plans")
def list_plans(_: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = (db.query(PremiumPlan).filter_by(active=True)
            .order_by(PremiumPlan.sort_order, PremiumPlan.id).all())
    return [_plan_json(p) for p in rows]


@router.get("/admin/plans")
def admin_list_plans(_: User = Depends(admin_only), db: Session = Depends(get_db)):
    rows = db.query(PremiumPlan).order_by(PremiumPlan.sort_order, PremiumPlan.id).all()
    return [_plan_json(p) for p in rows]


@router.post("/admin/plans", status_code=201)
def create_plan(body: PlanIn, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    data = body.model_dump()
    data["egg"] = _normalize_egg(data.get("egg"))
    plan = PremiumPlan(**data, created_at=_now())
    db.add(plan)
    db.flush()
    audit(db, admin.username, "plan.create", plan.name, f"limit={plan.max_servers}")
    db.commit()
    return _plan_json(plan)


@router.patch("/admin/plans/{plan_id}")
def update_plan(plan_id: int, body: PlanUpdate, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    plan = db.get(PremiumPlan, plan_id)
    if plan is None:
        raise HTTPException(404, "Paket bulunamadı")
    changes = body.model_dump(exclude_unset=True)
    if "egg" in changes:
        changes["egg"] = _normalize_egg(changes["egg"])
    for key, value in changes.items():
        setattr(plan, key, value)
    audit(db, admin.username, "plan.update", plan.name)
    db.commit()
    return _plan_json(plan)


@router.delete("/admin/plans/{plan_id}", status_code=204)
def delete_plan(plan_id: int, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    plan = db.get(PremiumPlan, plan_id)
    if plan is None:
        raise HTTPException(404, "Paket bulunamadı")
    db.query(Ticket).filter_by(plan_id=plan.id).update({"plan_id": None})
    audit(db, admin.username, "plan.delete", plan.name)
    db.delete(plan)
    db.commit()


# ---------- destek ve satın alma talepleri ----------
@router.get("/tickets")
def list_tickets(user: User = Depends(current_user), db: Session = Depends(get_db)):
    q = (db.query(Ticket, User, PremiumPlan)
         .join(User, User.id == Ticket.user_id)
         .outerjoin(PremiumPlan, PremiumPlan.id == Ticket.plan_id))
    if not user.is_admin:
        q = q.filter(Ticket.user_id == user.id)
    rows = q.order_by(Ticket.updated_at.desc()).limit(300).all()
    return [_ticket_row(t, owner, plan) for t, owner, plan in rows]


@router.post("/tickets", status_code=201)
def create_ticket(body: TicketIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    plan = None
    if body.plan_id is not None:
        plan = db.get(PremiumPlan, body.plan_id)
        if plan is None or not plan.active:
            raise HTTPException(400, "Seçilen paket bulunamadı")
    if body.category == "purchase" and plan is None:
        raise HTTPException(400, "Satın alma talebi için bir paket seçin")
    coupon = None
    if body.coupon_code and body.coupon_code.strip():
        if body.category != "purchase":
            raise HTTPException(400, "Kupon yalnızca satın alma talebinde kullanılabilir")
        from .coupons import validate_coupon, normalize
        coupon = validate_coupon(db, body.coupon_code, plan.id if plan else None)
        coupon.used_count = (coupon.used_count or 0) + 1
    now = _now()
    t = Ticket(user_id=user.id, subject=body.subject.strip(), category=body.category,
               plan_id=plan.id if plan else None, status="open", created_at=now, updated_at=now,
               coupon_code=coupon.code if coupon else None)
    db.add(t)
    db.flush()
    note = f"\n\n[Kupon: {coupon.code} · %{coupon.percent_off} indirim]" if coupon else ""
    db.add(TicketMessage(ticket_id=t.id, author=user.username, is_admin=bool(user.is_admin),
                         text=body.message.strip() + note, created_at=now))
    discord_bot.emit_event(db, "purchase_new" if body.category == "purchase" else "ticket_new",
                           f"Yeni {'satın alma' if body.category == 'purchase' else 'destek'} talebi #{t.id} ({user.username}): {t.subject}",
                           user_id=user.id)
    audit(db, user.username, "ticket.create", t.subject, body.category)
    db.commit()
    return _ticket_detail(db, t)


@router.get("/tickets/{ticket_id}")
def get_ticket(ticket_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    return _ticket_detail(db, _visible_ticket(db, user, ticket_id))


@router.post("/tickets/{ticket_id}/messages", status_code=201)
def add_ticket_message(ticket_id: int, body: MessageIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    t = _visible_ticket(db, user, ticket_id)
    if t.status == "closed":
        raise HTTPException(409, "Bu talep kapatılmış")
    now = _now()
    db.add(TicketMessage(ticket_id=t.id, author=user.username, is_admin=bool(user.is_admin),
                         text=body.text.strip(), created_at=now))
    t.status = "answered" if user.is_admin else "open"
    t.updated_at = now
    db.commit()
    if user.is_admin:
        from .discord_notify import notify_discord

        owner = db.get(User, t.user_id)
        notify_discord(db, owner, f"💬 Destek talebinize yanıt geldi: **{t.subject}**. Panelden okuyabilirsiniz.")
    return _ticket_detail(db, t)


@router.post("/tickets/{ticket_id}/close")
def close_ticket(ticket_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    t = _visible_ticket(db, user, ticket_id)
    t.status = "closed"
    t.updated_at = _now()
    db.commit()
    return _ticket_detail(db, t)


def _default_server_name(plan: PremiumPlan, owner: User) -> str:
    base = re.sub(r"[^A-Za-z0-9 _-]", "", plan.name).strip() or "Paket"
    return f"{base[:30]} {owner.username}"[:48]


@router.post("/admin/tickets/{ticket_id}/grant")
def grant_plan(ticket_id: int, body: GrantIn | None = None, admin: User = Depends(admin_only),
               db: Session = Depends(get_db)):
    """Satın alma talebindeki paketi onaylar.
    - Serbest paket: kullanıcının sunucu limiti paketteki değere ayarlanır.
    - Egg'li paket: limit ayarlanır ve paketteki egg'den bir sunucu oluşturulup kullanıcıya verilir."""
    body = body or GrantIn()
    t = db.get(Ticket, ticket_id)
    if t is None:
        raise HTTPException(404, "Talep bulunamadı")
    plan = db.get(PremiumPlan, t.plan_id) if t.plan_id else None
    if plan is None:
        raise HTTPException(400, "Bu talepte geçerli bir paket yok")
    owner = db.get(User, t.user_id)
    if owner is None:
        raise HTTPException(404, "Kullanıcı bulunamadı")

    if body.demo and not plan.egg:
        raise HTTPException(400, "Demo yalnızca sunucu içeren paketlerde verilebilir")
    old_limit = owner.max_servers
    created_name = None
    if plan.egg:
        owned = db.query(Server).filter_by(owner_id=owner.id).count()
        owner.max_servers = max(plan.max_servers, owned + 1)  # sunucu oluşturabilmek için yer açılır
        created_name = body.server_name or _default_server_name(plan, owner)
        made = create_server(ServerIn(
            name=created_name, egg=plan.egg, memory_mb=plan.memory_mb, cpu_percent=plan.cpu_percent,
            variables={}, owner_id=owner.id, node_id=body.node_id,
            duration=body.duration, duration_days=body.duration_days,
        ), user=admin, db=db)  # kendi commit'ini yapar; hata olursa HTTP hatası olarak döner
        if body.demo:
            from .demo import DEMO_DAYS, mark_demo
            server = db.get(Server, made["id"])
            if server is not None:
                mark_demo(db, server)
                db.commit()
            created_name = f"{created_name} (demo {DEMO_DAYS} gün)"
    else:
        owner.max_servers = plan.max_servers

    now = _now()
    text = f"Paket hesaba tanımlandı: {plan.name}. Sunucu limiti {old_limit} → {owner.max_servers}."
    if body.demo:
        text += " Bu bir 3 günlük demo."
    if created_name:
        text += f" Sunucu oluşturuldu: {created_name}."
    db.add(TicketMessage(ticket_id=t.id, author=admin.username, is_admin=True, created_at=now, text=text))
    t.status = "answered"
    t.updated_at = now
    audit(db, admin.username, "plan.grant", owner.username, f"plan={plan.name} limit={owner.max_servers}"
          + (f" sunucu={created_name}" if created_name else ""))
    db.commit()
    return _ticket_detail(db, t)


# ---------- node yönetimi (yönetici) ----------
@router.get("/admin/nodes")
def list_nodes(_: User = Depends(admin_only), db: Session = Depends(get_db)):
    return [_node_json(n) for n in db.query(Node).order_by(Node.id).all()]


@router.post("/admin/nodes", status_code=201)
def create_node(body: NodeIn, request: Request, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    token = secrets.token_urlsafe(32)
    node = Node(name=body.name.strip(), description=body.description.strip(), token_hash=_hash(token),
                max_memory_mb=body.max_memory_mb, max_disk_mb=body.max_disk_mb, created_at=_now())
    db.add(node)
    db.flush()
    audit(db, admin.username, "node.create", node.name)
    db.commit()
    return {"node": _node_json(node), "install_command": _install_command(request, token)}


@router.patch("/admin/nodes/{node_id}")
def update_node(node_id: int, body: NodeUpdate, request: Request, admin: User = Depends(admin_only),
                db: Session = Depends(get_db)):
    node = db.get(Node, node_id)
    if node is None:
        raise HTTPException(404, "Node bulunamadı")
    changes = body.model_dump(exclude_unset=True, exclude={"rotate_token"})
    for key, value in changes.items():
        setattr(node, key, value.strip() if isinstance(value, str) else value)
    install = None
    if body.rotate_token:
        token = secrets.token_urlsafe(32)
        node.token_hash = _hash(token)
        install = _install_command(request, token)
    audit(db, admin.username, "node.update", node.name, ",".join(sorted(changes)) + (" token" if install else ""))
    db.commit()
    return {"node": _node_json(node), "install_command": install}


@router.delete("/admin/nodes/{node_id}", status_code=204)
def delete_node(node_id: int, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    node = db.get(Node, node_id)
    if node is None:
        raise HTTPException(404, "Node bulunamadı")
    audit(db, admin.username, "node.delete", node.name)
    db.delete(node)
    db.commit()


# ---------- node ajanı uç noktaları ----------
@router.get("/nodes/agent.py")
def node_agent_file():
    """Ajan kodu sırrı içermez; kurulum betiği bunu indirir."""
    return FileResponse(Path(__file__).with_name("node_agent.py"),
                        media_type="text/x-python; charset=utf-8", filename="agent.py")


@router.get("/nodes/install/{token}")
def node_install_script(token: str, request: Request, db: Session = Depends(get_db)):
    node = db.query(Node).filter_by(token_hash=_hash(token)).first()
    if node is None:
        raise HTTPException(404, "Kurulum bağlantısı geçersiz. Node'u yenileyip yeni komut alın.")
    script = INSTALL_TEMPLATE.replace("__PANEL_URL__", _public_base(request)).replace("__NODE_TOKEN__", token)
    return PlainTextResponse(script, media_type="text/x-shellscript; charset=utf-8")


@router.post("/nodes/heartbeat")
def node_heartbeat(body: HeartbeatIn, request: Request, db: Session = Depends(get_db)):
    token = _bearer(request)
    node = db.query(Node).filter_by(token_hash=_hash(token)).first() if token else None
    if node is None:
        raise HTTPException(401, "Geçersiz node anahtarı")
    if len(json.dumps(body.stats)) > MAX_STATS_BYTES:
        raise HTTPException(413, "Durum verisi çok büyük")
    node.stats = body.stats
    node.version = body.version
    node.last_seen = _now()
    db.commit()
    return {"ok": True, "name": node.name}


INSTALL_TEMPLATE = r'''#!/usr/bin/env bash
# Mango Panel node kurulumu. Panel tarafından otomatik oluşturuldu.
set -euo pipefail
PANEL_URL="__PANEL_URL__"
NODE_TOKEN="__NODE_TOKEN__"
DIR=/opt/mango-node

if [ "$(id -u)" -ne 0 ]; then
  echo "Bu betik root olarak çalıştırılmalı: curl ... | sudo bash"
  exit 1
fi

echo "==> Gerekli paketler kontrol ediliyor"
if ! command -v python3 >/dev/null 2>&1; then
  apt-get update -y
  apt-get install -y python3
fi
if ! command -v docker >/dev/null 2>&1; then
  echo "==> Docker kuruluyor (ileride sunucu barındırmak için)"
  curl -fsSL https://get.docker.com | sh
fi
systemctl enable --now docker >/dev/null 2>&1 || true

echo "==> Ajan indiriliyor"
mkdir -p "$DIR"
curl -fsSL "$PANEL_URL/api/nodes/agent.py" -o "$DIR/agent.py"

echo "==> Yapılandırma yazılıyor"
umask 077
cat > "$DIR/config.json" <<EOF
{"panel_url": "$PANEL_URL", "node_token": "$NODE_TOKEN"}
EOF

echo "==> Servis kuruluyor"
cat > /etc/systemd/system/mango-node.service <<EOF
[Unit]
Description=Mango Panel Node Ajanı
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=/usr/bin/python3 $DIR/agent.py
WorkingDirectory=$DIR
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now mango-node
sleep 4
if systemctl is-active --quiet mango-node; then
  echo "==> Node ajanı çalışıyor. Panelde node'un 'çevrimiçi' görünmesi birkaç saniye sürebilir."
else
  echo "==> Ajan başlamadı. Hata için: journalctl -u mango-node -n 50 --no-pager"
  exit 1
fi
'''


@router.get("/public/plans")
def public_plans(db: Session = Depends(get_db)):
    """Ana sayfa ve paket sayfası için, giriş gerektirmeyen paket listesi (1.26.0, 1.27.0 alanlarıyla)."""
    rows = (db.query(PremiumPlan).filter_by(active=True)
            .order_by(PremiumPlan.sort_order, PremiumPlan.id).all())
    return [_plan_public(p) for p in rows]
