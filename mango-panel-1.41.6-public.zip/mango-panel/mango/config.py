"""Yapılandırma. Öncelik: ortam değişkenleri > mango.json > varsayılanlar."""
import json
import os
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONFIG_FILE = Path(os.environ.get("MANGO_CONFIG", ROOT / "mango.json"))


@dataclass
class Settings:
    secret_key: str = "CHANGE-ME"
    database_url: str = f"sqlite:///{ROOT / 'data' / 'mango.db'}"
    # "direct": panel doğrudan porttan açılır, oyunlar dış IP'ye bağlanabilir.
    # "cloudflare": panel Cloudflare Tunnel arkasında; yalnızca web/Node.js/Python eggleri.
    access_mode: str = "direct"
    host: str = "0.0.0.0"
    port: int = 8000
    public_url: str = "http://localhost:8000"
    source_url: str = "https://github.com/your-org/mango-panel"  # AGPL 13. madde
    data_dir: str = str(ROOT / "data" / "servers")
    eggs_dir: str = str(ROOT / "eggs")
    web_dir: str = str(ROOT / "web")
    port_range_start: int = 25000
    port_range_end: int = 25999
    token_hours: int = 12


def load_settings() -> Settings:
    raw = {}
    if CONFIG_FILE.exists():
        raw = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    known = {k: v for k, v in raw.items() if k in Settings.__dataclass_fields__}
    s = Settings(**known)
    if os.environ.get("MANGO_SECRET"):
        s.secret_key = os.environ["MANGO_SECRET"]
    if os.environ.get("MANGO_DATABASE_URL"):
        s.database_url = os.environ["MANGO_DATABASE_URL"]
    if os.environ.get("MANGO_ACCESS_MODE"):
        s.access_mode = os.environ["MANGO_ACCESS_MODE"]
    if s.access_mode not in ("direct", "cloudflare"):
        raise ValueError("access_mode 'direct' veya 'cloudflare' olmalı")
    return s


settings = load_settings()
