"""1.24.0: Genel Sohbet. Müşteriler mesaj yazar, sunucu logunu paylaşıp yardım isteyebilir.

Canlı akış: istemci ~2 sn'de bir yeni mesajları ister (after = son mesaj no, since = son eşitleme zamanı).
Silinen mesajlar da since sayesinde tüm açık sayfalardan kaldırılır.
"""
import datetime as dt
import re
import time

from fastapi import APIRouter, Depends, HTTPException, Query, Response
from pydantic import BaseModel, Field
from sqlalchemy import func
from sqlalchemy.orm import Session

from . import docker_manager as dm
from .api import _visible_server
from .db import ChatMessage, User
from .security import current_user, get_db

router = APIRouter(prefix="/api")
MAX_KEEP = 1000        # toplam saklanan mesaj
INITIAL = 60           # sayfa açılınca gösterilen son mesaj
POLL_LIMIT = 200
SEND_COOLDOWN = 1.5    # saniye: aynı kullanıcı en hızlı bu aralıkla yazabilir
LOG_TAIL = 80
LOG_CHARS = 4000
_last_sent: dict[int, float] = {}

# Paylaşılan logda ve mesajda gizli bilgileri maskeler.
REDACTIONS = [
    (re.compile(r"[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{20,}"), "[gizlendi]"),  # Discord token
    (re.compile(r"cfut_[A-Za-z0-9]+"), "[gizlendi]"),                                          # Cloudflare token
    (re.compile(r"Bearer\s+[A-Za-z0-9._~+/=-]+", re.IGNORECASE), "Bearer [gizlendi]"),
    # DISCORD_TOKEN=..., db_password: ... gibi anahtarlarda da yakalar (\b kullanılmaz: "_" bir kelime karakteridir)
    (re.compile(r"(?i)([\w-]*(?:token|secret|password|passwd|api[_-]?key|authorization)[\w-]*)(\s*[:=]\s*)\S+"),
     lambda m: m.group(1) + m.group(2) + "[gizlendi]"),
]


def redact(text: str) -> str:
    for pattern, repl in REDACTIONS:
        text = pattern.sub(repl, text)
    return text


class ChatIn(BaseModel):
    text: str = Field(default="", max_length=1000)
    help: bool = False
    server_id: int | None = None


def _now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _item(m: ChatMessage) -> dict:
    return {
        "id": m.id,
        "user_id": m.user_id,
        "username": m.username,
        "help": bool(m.help),
        "hidden": bool(m.hidden),
        "text": "" if m.hidden else m.text,
        "server_name": None if m.hidden else m.server_name,
        "log_text": None if m.hidden else m.log_text,
        "created_at": m.created_at.isoformat() if m.created_at else None,
    }


def _prune(db: Session) -> None:
    max_id = db.query(func.max(ChatMessage.id)).scalar() or 0
    if max_id > MAX_KEEP:
        db.query(ChatMessage).filter(ChatMessage.id <= max_id - MAX_KEEP).delete(synchronize_session=False)


@router.get("/chat/messages")
def list_messages(after: int = Query(0, ge=0), since: int = Query(0, ge=0),
                  user: User = Depends(current_user), db: Session = Depends(get_db)):
    if after == 0 and since == 0:
        rows = (db.query(ChatMessage).filter(ChatMessage.hidden.is_(False))
                .order_by(ChatMessage.id.desc()).limit(INITIAL).all())
        rows.reverse()
    else:
        rows = db.query(ChatMessage).filter(ChatMessage.id > after).order_by(ChatMessage.id).limit(POLL_LIMIT).all()
        if since:
            since_dt = dt.datetime.fromtimestamp(since / 1000, tz=dt.timezone.utc)
            changed = (db.query(ChatMessage)
                       .filter(ChatMessage.id <= after, ChatMessage.hidden.is_(True),
                               ChatMessage.changed_at > since_dt)
                       .limit(POLL_LIMIT).all())
            rows = changed + rows
    last_id = db.query(func.max(ChatMessage.id)).scalar() or 0
    return {"items": [_item(m) for m in rows], "last_id": last_id, "now": int(time.time() * 1000)}


@router.post("/chat/messages", status_code=201)
def send_message(body: ChatIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    text = body.text.strip()
    if not text and body.server_id is None:
        raise HTTPException(400, "Mesaj boş olamaz")
    now_mono = time.monotonic()
    if now_mono - _last_sent.get(user.id, -SEND_COOLDOWN - 1) < SEND_COOLDOWN:
        raise HTTPException(429, "Çok hızlı yazıyorsunuz, birkaç saniye bekleyin.")
    _last_sent[user.id] = now_mono

    log_text = server_name = None
    server_id = None
    if body.server_id is not None:
        server = _visible_server(user, db, body.server_id, "console")
        try:
            raw = dm.logs(server, tail=LOG_TAIL)
        except Exception:
            raw = ""
        log_text = redact(raw)[-LOG_CHARS:] or "(konsol boş)"
        server_name = server.name
        server_id = server.id

    now = _now()
    msg = ChatMessage(user_id=user.id, username=user.username, text=redact(text)[:2000], help=bool(body.help),
                      server_id=server_id, server_name=server_name, log_text=log_text, hidden=False,
                      created_at=now, changed_at=now)
    db.add(msg)
    db.flush()
    _prune(db)
    db.commit()
    return _item(msg)


@router.delete("/chat/messages/{msg_id}", status_code=204)
def delete_message(msg_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    msg = db.get(ChatMessage, msg_id)
    if msg is None or msg.hidden:
        raise HTTPException(404, "Mesaj bulunamadı")
    if msg.user_id != user.id and not user.is_admin:
        raise HTTPException(403, "Bu mesajı silemezsiniz")
    msg.hidden = True
    msg.changed_at = _now()
    db.commit()
    return Response(status_code=204)
