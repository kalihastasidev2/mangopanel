"""Kuponlar (1.34.0).

Yönetici kupon oluşturur, etkinleştirir, siler. Satın alma talebi açılırken kupon kodu girilirse
geçerlilik kontrol edilir ve kullanım sayısı artırılır. İndirim tutarı talebe kaydedilir; paket
fiyatı serbest metin olduğu için gerçek tahsilat yönetici tarafından yapılır."""
import datetime as dt
import re

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from .db import Coupon, PremiumPlan, User
from .security import admin_only, current_user, get_db

router = APIRouter(prefix="/api")
CODE_RE = re.compile(r"^[A-Z0-9_-]{3,32}$")


class CouponIn(BaseModel):
    code: str = Field(min_length=3, max_length=32)
    percent_off: int = Field(10, ge=1, le=100)
    plan_id: int | None = None
    max_uses: int | None = Field(None, ge=1)
    expires_at: dt.datetime | None = None
    active: bool = True


class CouponCheckIn(BaseModel):
    code: str = Field(min_length=1, max_length=32)
    plan_id: int | None = None


def normalize(code: str) -> str:
    return code.strip().upper()


def validate_coupon(db: Session, code: str, plan_id: int | None) -> Coupon:
    """Geçerli kuponu döndürür; değilse 400 verir. Kullanım sayısını artırmaz."""
    c = db.query(Coupon).filter_by(code=normalize(code)).first()
    if c is None or not c.active:
        raise HTTPException(400, "Kupon geçersiz")
    if c.expires_at is not None:
        exp = c.expires_at if c.expires_at.tzinfo else c.expires_at.replace(tzinfo=dt.timezone.utc)
        if exp < dt.datetime.now(dt.timezone.utc):
            raise HTTPException(400, "Kuponun süresi dolmuş")
    if c.max_uses is not None and c.used_count >= c.max_uses:
        raise HTTPException(400, "Kuponun kullanım sınırı dolmuş")
    if c.plan_id is not None and c.plan_id != plan_id:
        raise HTTPException(400, "Bu kupon seçilen pakette geçerli değil")
    return c


def _json(c: Coupon, plan_names: dict) -> dict:
    return {
        "id": c.id, "code": c.code, "percent_off": c.percent_off,
        "plan_id": c.plan_id, "plan_name": plan_names.get(c.plan_id) if c.plan_id else "Tüm paketler",
        "max_uses": c.max_uses, "used_count": c.used_count,
        "expires_at": c.expires_at.isoformat() if c.expires_at else None, "active": bool(c.active),
    }


@router.get("/admin/coupons")
def list_coupons(_: User = Depends(admin_only), db: Session = Depends(get_db)):
    plan_names = {p.id: p.name for p in db.query(PremiumPlan).all()}
    return [_json(c, plan_names) for c in db.query(Coupon).order_by(Coupon.id.desc()).all()]


@router.post("/admin/coupons", status_code=201)
def create_coupon(body: CouponIn, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    code = normalize(body.code)
    if not CODE_RE.match(code):
        raise HTTPException(400, "Kod 3-32 karakter olmalı: harf, rakam, - ve _")
    if db.query(Coupon).filter_by(code=code).first():
        raise HTTPException(409, "Bu kod zaten var")
    if body.plan_id is not None and db.get(PremiumPlan, body.plan_id) is None:
        raise HTTPException(400, "Paket bulunamadı")
    c = Coupon(code=code, percent_off=body.percent_off, plan_id=body.plan_id, max_uses=body.max_uses,
               expires_at=body.expires_at, active=body.active)
    db.add(c)
    db.commit()
    return _json(c, {p.id: p.name for p in db.query(PremiumPlan).all()})


@router.patch("/admin/coupons/{coupon_id}")
def toggle_coupon(coupon_id: int, active: bool, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    c = db.get(Coupon, coupon_id)
    if c is None:
        raise HTTPException(404, "Kupon bulunamadı")
    c.active = active
    db.commit()
    return {"ok": True, "active": active}


@router.delete("/admin/coupons/{coupon_id}", status_code=204)
def delete_coupon(coupon_id: int, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    c = db.get(Coupon, coupon_id)
    if c is None:
        raise HTTPException(404, "Kupon bulunamadı")
    db.delete(c)
    db.commit()
    from fastapi import Response
    return Response(status_code=204)


@router.post("/coupons/check")
def check_coupon(body: CouponCheckIn, _: User = Depends(current_user), db: Session = Depends(get_db)):
    c = validate_coupon(db, body.code, body.plan_id)
    return {"code": c.code, "percent_off": c.percent_off}
