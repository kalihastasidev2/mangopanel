"""1.40.24: Sunucu süresi. Süresiz (None) varsayılandır; diğer seçenekler bitiş tarihini belirler."""
import datetime as dt

PRESETS = {"3d": 3, "1w": 7, "1m": 30, "3m": 90, "1y": 365}
LABELS = {"3d": "3 gün", "1w": "1 hafta", "1m": "1 ay", "3m": "3 ay", "1y": "1 yıl",
          "unlimited": "Süresiz", "custom": "Özel (gün)"}
MAX_CUSTOM_DAYS = 3650


def resolve_days(duration: str | None, days: int | None) -> int | None:
    if duration in (None, "", "unlimited"):
        return None
    if duration == "custom":
        if days is None or not (1 <= int(days) <= MAX_CUSTOM_DAYS):
            raise ValueError(f"Özel süre 1 ile {MAX_CUSTOM_DAYS} gün arasında olmalı")
        return int(days)
    if duration in PRESETS:
        return PRESETS[duration]
    raise ValueError("Geçersiz süre seçimi")


def set_expiry(server, days: int | None, now: dt.datetime | None = None) -> None:
    if days is None:
        server.expires_at = None
        return
    now = now or dt.datetime.now(dt.timezone.utc)
    server.expires_at = now + dt.timedelta(days=days)


def days_left(expires_at, now: dt.datetime | None = None) -> int | None:
    if expires_at is None:
        return None
    now = now or dt.datetime.now(dt.timezone.utc)
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=dt.timezone.utc)
    return int(max(0, -(-(expires_at - now).total_seconds() // 86400)))  # yukarı yuvarla
