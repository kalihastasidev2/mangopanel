"""Panel sağlık kontrolleri: veritabanı, Docker, servisler (nginx, tünel) ve disk.

Her kontrol bağımsızdır; biri başarısız olsa bile diğerleri çalışır. Sonuç:
{"name": ..., "ok": True | False | None, "detail": ...}  (None = bu kurulumda kontrol edilmez)
"""
import shutil
import subprocess

from sqlalchemy import text

from . import docker_manager as dm
from .config import settings
from .db import engine

MIN_FREE_PERCENT = 10


def _service_state(unit: str) -> tuple[bool | None, str]:
    try:
        out = subprocess.run(["systemctl", "is-active", unit], capture_output=True, text=True, timeout=5)
    except (OSError, subprocess.TimeoutExpired):
        return None, "systemctl kullanılamıyor"
    state = out.stdout.strip() or out.stderr.strip() or "bilinmiyor"
    return state == "active", state


def _service(name: str, unit: str) -> dict:
    ok, state = _service_state(unit)
    return {"name": name, "ok": ok, "detail": "çalışıyor" if ok else f"durum: {state}"}


def check_database() -> dict:
    try:
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        return {"name": "Veritabanı", "ok": True, "detail": "bağlantı var"}
    except Exception as exc:
        return {"name": "Veritabanı", "ok": False, "detail": str(exc)[:200]}


def check_docker() -> dict:
    try:
        version = dm.client().version().get("Version", "?")
        return {"name": "Docker", "ok": True, "detail": f"sürüm {version}, erişilebilir"}
    except Exception as exc:
        return {"name": "Docker", "ok": False, "detail": str(exc)[:200]}


def check_disk() -> dict:
    try:
        usage = shutil.disk_usage(settings.data_dir)
    except OSError as exc:
        return {"name": "Sunucu diski", "ok": False, "detail": str(exc)[:200]}
    free_pct = round(usage.free / usage.total * 100, 1)
    free_gb = round(usage.free / 1024 ** 3, 1)
    return {
        "name": "Sunucu diski",
        "ok": free_pct >= MIN_FREE_PERCENT,
        "detail": f"{free_gb} GB boş (%{free_pct})",
    }


def check_tunnel() -> dict:
    if settings.access_mode != "cloudflare":
        return {"name": "Cloudflare Tüneli", "ok": None, "detail": "tünel modu kapalı"}
    return _service("Cloudflare Tüneli", "mango-tunnel")


def run_all() -> list[dict]:
    return [
        check_database(),
        check_docker(),
        _service("Mango paneli", "mango-panel"),
        check_tunnel(),
        _service("nginx", "nginx"),
        check_disk(),
    ]
