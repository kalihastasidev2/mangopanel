"""Discord botunun panel tarafı (1.22.0): kurulum, hesap bağlama, olaylar ve sunucu durumu izleme."""
import datetime as dt
import hmac
import secrets
import threading
import time
from pathlib import Path

from fastapi import HTTPException
from sqlalchemy.orm import Session

from . import discord_api
from . import docker_manager as dm
from . import files_manager as fm
from .config import settings
from .db import DiscordEvent, DiscordLinkCode, Server, ServerAccess, SessionLocal, User
from .store import audit, get_setting, set_setting

TEMPLATE_DIR = Path(__file__).resolve().parent / "bot_template"
CATEGORY_NAME = "Mango Panel"
# (kanal adı, ayar anahtarı) — kurulumda Discord'da bu kanallar oluşturulur.
CHANNEL_SPECS = [
    ("sunucu-bildirim", "discord_ch_alerts"),
    ("destek-talepleri", "discord_ch_tickets"),
    ("satin-alma", "discord_ch_purchases"),
    ("durum-paneli", "discord_ch_status"),
]
BOT_SERVER_NAME = "Discord Bot"
BOT_ENTRY = "index.js"
BOT_STARTUP = "npm install --omit=dev && node index.js"
CODE_TTL = dt.timedelta(minutes=10)
CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # karışabilecek 0, O, 1, I, L harfleri yok
EVENT_KINDS = {"server_down", "server_up", "ticket_new", "purchase_new"}
INTENTIONAL_WINDOW = 90  # panelden yapılan durdurma/yeniden başlatma sonrası saniye: çökme sayılmaz
_intentional: dict[int, float] = {}
_last_status: dict[int, str] = {}


def _now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def mark_intentional(server_id: int) -> None:
    """Panelden kasıtlı durdurma yapıldığında çağrılır; izleyici bunu çökme olarak bildirmez."""
    _intentional[server_id] = time.monotonic()


def emit_event(db: Session, kind: str, text: str, server_id: int | None = None, user_id: int | None = None) -> None:
    """Olayı kaydeder; commit çağıranın sorumluluğundadır."""
    if kind not in EVENT_KINDS:
        raise ValueError(f"Bilinmeyen olay türü: {kind}")
    db.add(DiscordEvent(kind=kind, text=text[:500], server_id=server_id, user_id=user_id, created_at=_now()))


def verify_bot_secret(db: Session, given: str | None) -> None:
    stored = get_setting(db, "discord_bot_secret")
    if not stored:
        raise HTTPException(503, "Discord botu henüz kurulmadı")
    if not given or not hmac.compare_digest(stored, given):
        raise HTTPException(403, "Geçersiz bot anahtarı")


def linked_user(db: Session, discord_id: str) -> User:
    user = db.query(User).filter_by(discord_id=discord_id).first()
    if user is None:
        raise HTTPException(403, "Bu Discord hesabı bir panel hesabına bağlı değil. /bagla ile bağlayın.")
    return user


def new_link_code(db: Session, discord_id: str) -> str:
    db.query(DiscordLinkCode).filter_by(discord_id=discord_id).delete()
    code = "".join(secrets.choice(CODE_ALPHABET) for _ in range(8))
    now = _now()
    db.add(DiscordLinkCode(code=code, discord_id=discord_id, created_at=now, expires_at=now + CODE_TTL))
    db.commit()
    return code


def redeem_link_code(db: Session, user: User, code: str) -> str:
    row = db.get(DiscordLinkCode, code.strip().upper())
    expires = row.expires_at.replace(tzinfo=dt.timezone.utc) if row and row.expires_at.tzinfo is None else (row.expires_at if row else None)
    if row is None or expires < _now():
        raise HTTPException(400, "Kod geçersiz veya süresi dolmuş. Discord'da /bagla ile yeni kod alın.")
    discord_id = row.discord_id
    # Bir Discord hesabı aynı anda yalnızca bir panel hesabına bağlı olur.
    db.query(User).filter(User.discord_id == discord_id, User.id != user.id).update({"discord_id": None})
    user.discord_id = discord_id
    db.delete(row)
    db.commit()
    return discord_id


def servers_for_user(db: Session, user: User) -> list[dict]:
    owned = db.query(Server).filter_by(owner_id=user.id)
    shared_ids = [a.server_id for a in db.query(ServerAccess).filter_by(user_id=user.id).all()]
    servers = {s.id: s for s in owned.all()}
    if shared_ids:
        for s in db.query(Server).filter(Server.id.in_(shared_ids)).all():
            servers.setdefault(s.id, s)
    result = []
    for s in sorted(servers.values(), key=lambda x: x.id):
        try:
            status = dm.status(s)
        except Exception:
            status = "bilinmiyor"
        result.append({"id": s.id, "name": s.name, "egg": s.egg, "status": status})
    return result


def bot_env(token: str, guild_id: str, role_id: str, secret: str, channels: dict[str, str]) -> dict[str, str]:
    return {
        "DISCORD_TOKEN": token,
        "DISCORD_GUILD_ID": guild_id,
        "DISCORD_CUSTOMER_ROLE_ID": role_id,
        "PANEL_URL": settings.public_url.rstrip("/"),
        "PANEL_BOT_SECRET": secret,
        "ALERT_CHANNEL_ID": channels.get("discord_ch_alerts", ""),
        "TICKET_CHANNEL_ID": channels.get("discord_ch_tickets", ""),
        "PURCHASE_CHANNEL_ID": channels.get("discord_ch_purchases", ""),
        "STATUS_CHANNEL_ID": channels.get("discord_ch_status", ""),
    }


def setup(db: Session, admin: User) -> dict:
    """Discord kurulumu: kanalları oluşturur, bot sunucusunu (nodejs) yönetici hesabına verir,
    bot kodunu sunucu dosyalarına yazar ve ortam değişkenlerini doldurur."""
    from .api import ServerIn, create_server  # döngüsel içe aktarmayı önlemek için burada
    from .eggs import load_eggs

    token = get_setting(db, "discord_bot_token").strip()
    guild_id = get_setting(db, "discord_guild_id").strip()
    role_id = get_setting(db, "discord_customer_role_id").strip()
    if not token or not guild_id:
        raise HTTPException(400, "Önce bot token'ı ve sunucu (guild) kimliğini kaydedin")

    try:
        bot = discord_api.me(token)
        discord_api.guild(token, guild_id)
    except discord_api.DiscordError as exc:
        raise HTTPException(400, f"Discord: {exc}. Botun sunucuda olduğundan emin olun.")

    channels: dict[str, str] = {}
    if not get_setting(db, "discord_category_id"):
        try:
            category = discord_api.create_category(token, guild_id, CATEGORY_NAME)
            set_setting(db, "discord_category_id", category["id"])
            for name, key in CHANNEL_SPECS:
                channel = discord_api.create_text_channel(token, guild_id, name, category["id"])
                set_setting(db, key, channel["id"])
        except discord_api.DiscordError as exc:
            db.rollback()
            raise HTTPException(502, f"Kanallar oluşturulamadı: {exc}")
    for _, key in CHANNEL_SPECS:
        channels[key] = get_setting(db, key)

    if not get_setting(db, "discord_bot_secret"):
        set_setting(db, "discord_bot_secret", secrets.token_urlsafe(32))
    secret = get_setting(db, "discord_bot_secret")

    bot_server = db.get(Server, int(get_setting(db, "discord_bot_server_id") or 0)) if get_setting(db, "discord_bot_server_id") else None
    if bot_server is None:
        created = create_server(ServerIn(
            name=BOT_SERVER_NAME, egg="nodejs-app", memory_mb=512, cpu_percent=100,
            variables={"ENTRY": BOT_ENTRY}, owner_id=admin.id,
        ), user=admin, db=db)
        bot_server = db.get(Server, created["id"])
        set_setting(db, "discord_bot_server_id", str(bot_server.id))

    # Kodu yaz, ortam değişkenlerini doldur, konteyneri bu ayarlarla yeniden oluştur.
    fm.write_text(bot_server.id, "index.js", (TEMPLATE_DIR / "index.js").read_text(encoding="utf-8"))
    fm.write_text(bot_server.id, "package.json", (TEMPLATE_DIR / "package.json").read_text(encoding="utf-8"))
    bot_server.env = bot_env(token, guild_id, role_id, secret, channels)
    bot_server.startup_override = BOT_STARTUP
    db.commit()
    egg = load_eggs()["nodejs-app"]
    try:
        bot_server.container_id = dm.recreate(bot_server, egg, BOT_STARTUP, int(egg["ports"][0]))
        db.commit()
    except Exception as exc:
        db.rollback()
        raise HTTPException(500, f"Bot sunucusu yeniden oluşturulamadı: {exc}")

    audit(db, admin.username, "discord.setup", bot_server.name, f"bot={bot.get('username', '')} guild={guild_id}")
    db.commit()
    return {"bot_name": bot.get("username", ""), "bot_server_id": bot_server.id, "channels": channels}


def watch_once() -> None:
    """Konteyner durumlarını izler; çalışırken durmuş sunucular için olay üretir."""
    statuses = dm.status_map()
    if statuses is None:
        return
    db = SessionLocal()
    try:
        for server in db.query(Server).filter(Server.container_id.isnot(None)).all():
            now = statuses.get(server.container_id)
            if now is None:
                continue
            before = _last_status.get(server.id)
            _last_status[server.id] = now
            if before is None or before == now:
                continue
            if before == "running" and now in ("exited", "dead"):
                started = _intentional.get(server.id)
                if started is not None and time.monotonic() - started < INTENTIONAL_WINDOW:
                    continue  # panelden durduruldu, çökme değil
                emit_event(db, "server_down", f"{server.name} sunucusu beklenmedik şekilde durdu ({now}).",
                           server_id=server.id, user_id=server.owner_id)
            elif before in ("exited", "dead") and now == "running":
                emit_event(db, "server_up", f"{server.name} sunucusu yeniden çalışıyor.",
                           server_id=server.id, user_id=server.owner_id)
        db.commit()
    finally:
        db.close()


def _watch_forever() -> None:
    while True:
        try:
            watch_once()
        except Exception:
            pass
        time.sleep(30)


def start_watcher() -> None:
    threading.Thread(target=_watch_forever, name="discord-watcher", daemon=True).start()
