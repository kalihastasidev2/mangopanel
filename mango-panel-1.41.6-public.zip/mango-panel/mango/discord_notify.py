"""1.40.22: Discord üzerinden kullanıcıya özel bildirim (DM). Gönderim arka planda yapılır,
hata panel işlemini asla durdurmaz."""
import logging
import threading

from .discord_api import _call
from .store import get_setting

log = logging.getLogger("mango.notify")


def _send(token: str, discord_id: str, text: str) -> None:
    try:
        channel = _call("POST", "/users/@me/channels", token, {"recipient_id": discord_id})
        _call("POST", f"/channels/{channel['id']}/messages", token, {"content": text[:1900]})
    except Exception:  # noqa: BLE001 - bildirim başarısızlığı panelde hataya dönüşmemeli
        log.exception("Discord bildirimi gönderilemedi (kullanıcı %s)", discord_id)


def notify_discord(db, user, text: str) -> bool:
    """Kullanıcının Discord hesabına mesaj gönderir. Bağlı değilse ya da bot tokenı yoksa False döner."""
    if user is None or not user.discord_id:
        return False
    token = get_setting(db, "discord_bot_token").strip()
    if not token:
        return False
    threading.Thread(target=_send, args=(token, user.discord_id, text), daemon=True, name="discord-dm").start()
    return True
