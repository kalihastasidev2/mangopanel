"""Egg (şablon) yükleyici ve değişken doğrulayıcı."""
import re
from pathlib import Path

import yaml

from .config import settings

REQUIRED_KEYS = ("name", "category", "docker_image", "startup")
SLUG_RE = re.compile(r"^[a-z0-9-]{1,64}$")
# Kullanıcı değerleri shell'e gider; bu yüzden metakarakterlere izin verilmez.
SAFE_VALUE_RE = re.compile(r"^[A-Za-z0-9._\-/:=@,]{0,200}$")
PLACEHOLDER_RE = re.compile(r"\{\{\s*([A-Z0-9_]+)\s*\}\}")


class EggError(ValueError):
    pass


def load_eggs() -> dict[str, dict]:
    eggs: dict[str, dict] = {}
    for path in sorted(Path(settings.eggs_dir).glob("*.yaml")):
        slug = path.stem
        if not SLUG_RE.match(slug):
            raise EggError(f"Geçersiz egg adı: {path.name}")
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        missing = [k for k in REQUIRED_KEYS if k not in data]
        if missing:
            raise EggError(f"{path.name}: eksik alanlar {missing}")
        data.setdefault("description", "")
        data.setdefault("variables", [])
        data.setdefault("ports", [8080])
        data.setdefault("memory_mb", 512)
        data.setdefault("install_script", "")
        # Oluşturulan sunucuya ilk kez yazılan örnek dosyalar: {"yol": "içerik"}
        starter = data.get("starter_files") or {}
        if not isinstance(starter, dict):
            raise EggError(f"{path.name}: starter_files bir sözlük olmalı")
        data["starter_files"] = {str(k): str(v) for k, v in starter.items()}
        eggs[slug] = data
    return eggs


def build_variables(egg: dict, supplied: dict[str, str]) -> dict[str, str]:
    """Varsayılanları ve kullanıcı değerlerini birleştirir, doğrular."""
    declared = {v["name"]: v for v in egg["variables"]}
    result: dict[str, str] = {}
    for name, spec in declared.items():
        value = str(supplied.get(name, spec.get("default", "")))
        if not SAFE_VALUE_RE.match(value):
            raise EggError(f"'{name}' değeri geçersiz karakter içeriyor")
        result[name] = value
    unknown = set(supplied) - set(declared)
    if unknown:
        raise EggError(f"Bilinmeyen değişkenler: {sorted(unknown)}")
    return result


def render(template: str, values: dict[str, str]) -> str:
    """{{ANAHTAR}} yer tutucularını değerlerle doldurur. Eksik anahtar hata verir."""
    def repl(match: re.Match) -> str:
        key = match.group(1)
        if key not in values:
            raise EggError(f"Yer tutucu doldurulamadı: {key}")
        return values[key]
    return PLACEHOLDER_RE.sub(repl, template)
