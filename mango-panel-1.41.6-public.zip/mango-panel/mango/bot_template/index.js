// Mango Panel Discord botu (1.22.0). Ortam değişkenleri panel tarafından otomatik doldurulur.
const {
  Client,
  EmbedBuilder,
  GatewayIntentBits,
  REST,
  Routes,
  SlashCommandBuilder,
} = require("discord.js");

const TOKEN = process.env.DISCORD_TOKEN;
const GUILD_ID = process.env.DISCORD_GUILD_ID;
const PANEL_URL = (process.env.PANEL_URL || "").replace(/\/$/, "");
const SECRET = process.env.PANEL_BOT_SECRET;
const CHANNELS = {
  alerts: process.env.ALERT_CHANNEL_ID,
  tickets: process.env.TICKET_CHANNEL_ID,
  purchases: process.env.PURCHASE_CHANNEL_ID,
  status: process.env.STATUS_CHANNEL_ID,
};
const POLL_MS = 15000;

if (!TOKEN || !GUILD_ID || !PANEL_URL || !SECRET) {
  console.error("Eksik ortam değişkeni: DISCORD_TOKEN, DISCORD_GUILD_ID, PANEL_URL, PANEL_BOT_SECRET");
  process.exit(1);
}

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const serverOption = (opt) =>
  opt.setName("sunucu").setDescription("Sunucu adı veya numarası (#id)").setRequired(true);

const commands = [
  new SlashCommandBuilder().setName("bagla").setDescription("Discord hesabını panel hesabına bağlar"),
  new SlashCommandBuilder().setName("sunucular").setDescription("Bağlı hesabındaki sunucuları listeler"),
  new SlashCommandBuilder().setName("durum").setDescription("Bir sunucunun durumunu gösterir").addStringOption(serverOption),
  new SlashCommandBuilder().setName("baslat").setDescription("Sunucuyu başlatır").addStringOption(serverOption),
  new SlashCommandBuilder().setName("durdur").setDescription("Sunucuyu durdurur").addStringOption(serverOption),
  new SlashCommandBuilder().setName("yeniden").setDescription("Sunucuyu yeniden başlatır").addStringOption(serverOption),
  new SlashCommandBuilder()
    .setName("log")
    .setDescription("Sunucunun son konsol çıktısını gösterir")
    .addStringOption(serverOption)
    .addIntegerOption((o) => o.setName("satir").setDescription("Kaç satır (5-200)").setMinValue(5).setMaxValue(200)),
  new SlashCommandBuilder()
    .setName("destek")
    .setDescription("Panel için destek talebi açar")
    .addStringOption((o) => o.setName("konu").setDescription("Kısa konu").setRequired(true).setMaxLength(120))
    .addStringOption((o) => o.setName("mesaj").setDescription("Sorununuz").setRequired(true).setMaxLength(2000)),
].map((c) => c.toJSON());

async function panel(method, path, body) {
  const res = await fetch(`${PANEL_URL}/api${path}`, {
    method,
    headers: { "X-Bot-Secret": SECRET, "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const detail = typeof data.detail === "string" ? data.detail : `Panel hatası (${res.status})`;
    throw new Error(detail);
  }
  return data;
}

async function findServer(discordId, query) {
  const me = await panel("GET", `/discord/user/${discordId}`);
  if (!me.linked) throw new Error("Önce `/bagla` ile hesabını bağla.");
  const q = query.trim().replace(/^#/, "").toLowerCase();
  const found = me.servers.find((s) => String(s.id) === q || s.name.toLowerCase() === q);
  if (!found) throw new Error(`"${query}" adında bir sunucun yok. /sunucular ile listeye bak.`);
  return found;
}

const POWER = { baslat: "start", durdur: "stop", yeniden: "restart" };
const POWER_LABEL = { start: "başlatıldı", stop: "durduruldu", restart: "yeniden başlatıldı" };

client.on("interactionCreate", async (i) => {
  if (!i.isChatInputCommand()) return;
  const ephemeral = { ephemeral: true };
  try {
    switch (i.commandName) {
      case "bagla": {
        const data = await panel("POST", "/discord/link-code", { discord_id: i.user.id });
        return i.reply({
          content: `Bağlama kodun: **${data.code}**\nPanelde **Hesabım → Discord bağlantısı** bölümüne bu kodu gir. Kod ${Math.round(data.expires_in / 60)} dakika geçerli.`,
          ...ephemeral,
        });
      }
      case "sunucular": {
        const me = await panel("GET", `/discord/user/${i.user.id}`);
        if (!me.linked) return i.reply({ content: "Önce `/bagla` ile hesabını bağla.", ...ephemeral });
        if (!me.servers.length) return i.reply({ content: "Hesabında henüz sunucu yok.", ...ephemeral });
        const lines = me.servers.map((s) => `• **${s.name}** (#${s.id}) — ${s.status}`).join("\n");
        return i.reply({ content: lines, ...ephemeral });
      }
      case "durum": {
        const s = await findServer(i.user.id, i.options.getString("sunucu"));
        const embed = new EmbedBuilder().setTitle(s.name).setColor(s.status === "running" ? 0x2ecc71 : 0xe74c3c)
          .addFields({ name: "Durum", value: s.status, inline: true }, { name: "Tür", value: s.egg, inline: true }, { name: "Numara", value: `#${s.id}`, inline: true });
        return i.reply({ embeds: [embed], ...ephemeral });
      }
      case "baslat":
      case "durdur":
      case "yeniden": {
        const s = await findServer(i.user.id, i.options.getString("sunucu"));
        const action = POWER[i.commandName];
        const data = await panel("POST", `/discord/user/${i.user.id}/servers/${s.id}/power`, { action });
        return i.reply({ content: `**${s.name}** ${POWER_LABEL[action]}. Durum: ${data.status}`, ...ephemeral });
      }
      case "log": {
        const s = await findServer(i.user.id, i.options.getString("sunucu"));
        const tail = i.options.getInteger("satir") || 40;
        const data = await panel("GET", `/discord/user/${i.user.id}/servers/${s.id}/logs?tail=${tail}`);
        const text = (data.text || "(konsol boş)").slice(-1800);
        return i.reply({ content: "```\n" + text + "\n```", ...ephemeral });
      }
      case "destek": {
        const data = await panel("POST", `/discord/user/${i.user.id}/tickets`, {
          subject: i.options.getString("konu"),
          message: i.options.getString("mesaj"),
        });
        return i.reply({ content: `Destek talebin #${data.id} açıldı. Ekibimiz en kısa sürede dönecek.`, ...ephemeral });
      }
    }
  } catch (err) {
    const content = `Hata: ${err.message}`;
    if (i.deferred || i.replied) return i.followUp({ content, ...ephemeral });
    return i.reply({ content, ...ephemeral });
  }
});

const TITLES = {
  server_down: "Sunucu durdu",
  server_up: "Sunucu çalışıyor",
  ticket_new: "Yeni destek talebi",
  purchase_new: "Yeni satın alma talebi",
};
const COLORS = { server_down: 0xe74c3c, server_up: 0x2ecc71, ticket_new: 0x3498db, purchase_new: 0xf39c12 };

async function deliver(ev) {
  const embed = new EmbedBuilder()
    .setTitle(TITLES[ev.kind] || "Panel bildirimi")
    .setDescription(ev.text)
    .setColor(COLORS[ev.kind] || 0x95a5a6)
    .setTimestamp(new Date(ev.created_at || Date.now()));
  const channelKey = { server_down: "status", server_up: "status", ticket_new: "tickets", purchase_new: "purchases" }[ev.kind];
  const channelId = channelKey && CHANNELS[channelKey];
  if (channelId) {
    const channel = await client.channels.fetch(channelId).catch(() => null);
    if (channel) await channel.send({ embeds: [embed] }).catch((e) => console.error("Kanal mesajı:", e.message));
  }
  if (ev.discord_id && (ev.kind === "server_down" || ev.kind === "server_up")) {
    const user = await client.users.fetch(ev.discord_id).catch(() => null);
    if (user) await user.send({ embeds: [embed] }).catch(() => {});
  }
}

let lastEventId = null;
async function pollEvents() {
  try {
    if (lastEventId === null) {
      // İlk açılışta yalnızca mevcut son olayın numarasını alır; eski olaylar tekrar gönderilmez.
      const start = await panel("GET", "/discord/events?after=-1");
      lastEventId = start.latest;
      return;
    }
    const data = await panel("GET", `/discord/events?after=${lastEventId}`);
    for (const ev of data.events) {
      lastEventId = Math.max(lastEventId, ev.id);
      await deliver(ev);
    }
  } catch (err) {
    console.error("Olaylar alınamadı:", err.message);
  }
}

client.once("ready", async () => {
  console.log(`Bot hazır: ${client.user.tag}`);
  const rest = new REST({ version: "10" }).setToken(TOKEN);
  await rest
    .put(Routes.applicationGuildCommands(client.user.id, GUILD_ID), { body: commands })
    .then(() => console.log("Komutlar kaydedildi."))
    .catch((e) => console.error("Komutlar kaydedilemedi:", e.message));
  await pollEvents();
  setInterval(pollEvents, POLL_MS);
});

client.login(TOKEN);
