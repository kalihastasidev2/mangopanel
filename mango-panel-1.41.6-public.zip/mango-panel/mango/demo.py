"""3 günlük demo sunucuları (1.38.0).

Demo, bir paket talebi onaylanırken verilir ve sunucuya bitiş tarihi (expires_at) yazılır.
Arka plandaki tarayıcı süresi dolan sunucuyu durdurur, sahibine bildirim gönderir ve tarihi temizler.
Sunucu silinmez; kullanıcı paket talebi açarak devam edebilir."""
import datetime as dt
import logging
import threading
import time

from .db import Notification, NotificationRecipient, Server, SessionLocal

log = logging.getLogger("mango.demo")
DEMO_DAYS = 3
INTERVAL_SECONDS = 300


def mark_demo(db, server: Server) -> None:
    server.expires_at = dt.datetime.now(dt.timezone.utc) + dt.timedelta(days=DEMO_DAYS)


def check_expired(stopper, now: dt.datetime | None = None) -> int:
    """Süresi dolan demo sunucularını durdurur ve sahibine bildirir. Dönen değer: işlenen sunucu sayısı."""
    now = now or dt.datetime.now(dt.timezone.utc)
    db = SessionLocal()
    done = 0
    try:
        expired = db.query(Server).filter(Server.expires_at.isnot(None), Server.expires_at <= now).all()
        for server in expired:
            try:
                stopper(server, "stop")
            except Exception as exc:  # noqa: BLE001 - durdurulamasa bile süre kaydı temizlenir
                log.warning("Demo sunucusu durdurulamadı (%s): %s", server.id, exc)
            note = Notification(title="Sunucu süreniz doldu",
                                body=f"'{server.name}' sunucunuzun süresi doldu ve sunucu durduruldu. "
                                     "Devam etmek için yöneticinizle iletişime geçin.",
                                target="users", created_by="sistem", created_at=now)
            db.add(note)
            db.flush()
            db.add(NotificationRecipient(notification_id=note.id, user_id=server.owner_id))
            server.expires_at = None
            done += 1
        db.commit()
    finally:
        db.close()
    return done


def start_watcher(stopper) -> None:
    def loop():
        while True:
            try:
                check_expired(stopper)
            except Exception as exc:  # noqa: BLE001
                log.warning("Demo taraması hatası: %s", exc)
            time.sleep(INTERVAL_SECONDS)

    threading.Thread(target=loop, name="mango-demo", daemon=True).start()
