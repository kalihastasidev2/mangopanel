"""1.40.24: Süresi yaklaşan sunucuların sahiplerine hatırlatma (panel bildirimi + Discord).
Her sunucu için bitiş tarihi başına bir kez gönderilir."""
import datetime as dt
import logging
import threading
import time

from .db import Notification, NotificationRecipient, SessionLocal, Server, User
from .discord_notify import notify_discord

log = logging.getLogger("mango.expiry")
REMIND_DAYS = 3
INTERVAL_SECONDS = 3600


def remind(db, now: dt.datetime | None = None) -> int:
    now = now or dt.datetime.now(dt.timezone.utc)
    horizon = now + dt.timedelta(days=REMIND_DAYS)
    rows = db.query(Server).filter(
        Server.expires_at.isnot(None), Server.expires_at > now, Server.expires_at <= horizon,
    ).all()
    count = 0
    for server in rows:
        marker = server.expires_at.date().isoformat()
        if server.expiry_notified_for == marker:
            continue
        owner = db.get(User, server.owner_id)
        left = max(1, -(-(server.expires_at.replace(tzinfo=dt.timezone.utc) - now).total_seconds() // 86400))
        text = (f"'{server.name}' sunucunuzun süresi {int(left)} gün sonra ({marker}) dolacak. "
                "Süre dolunca sunucu durdurulur; yenilemek için yöneticinizle iletişime geçin.")
        note = Notification(title="Sunucu süresi yaklaşıyor", body=text, target="users",
                            created_by="sistem", created_at=now)
        db.add(note)
        db.flush()
        db.add(NotificationRecipient(notification_id=note.id, user_id=server.owner_id))
        notify_discord(db, owner, f"⏳ {text}")
        server.expiry_notified_for = marker
        count += 1
    db.commit()
    return count


def start_watcher() -> None:
    def loop():
        while True:
            db = SessionLocal()
            try:
                remind(db)
            except Exception as exc:  # noqa: BLE001
                log.warning("Süre hatırlatma taraması hatası: %s", exc)
            finally:
                db.close()
            time.sleep(INTERVAL_SECONDS)

    threading.Thread(target=loop, name="mango-expiry", daemon=True).start()
