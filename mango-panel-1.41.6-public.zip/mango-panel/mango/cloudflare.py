"""Cloudflare for SaaS (Custom Hostnames) istemcisi. Yalnızca standart kütüphane kullanır."""
import json
import urllib.error
import urllib.request
from urllib.parse import quote

API = "https://api.cloudflare.com/client/v4"


class CloudflareError(Exception):
    """Cloudflare isteği başarısız olduğunda fırlatılır; mesaj kullanıcıya gösterilebilir."""


def _messages(payload: dict) -> str:
    errors = payload.get("errors") or []
    return "; ".join(str(e.get("message", e)) if isinstance(e, dict) else str(e) for e in errors)


def _call(method: str, path: str, token: str, body: dict | None = None):
    data = json.dumps(body).encode() if body is not None else None
    request = urllib.request.Request(
        API + path, data=data, method=method,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as resp:
            payload = json.loads(resp.read() or b"{}")
    except urllib.error.HTTPError as exc:
        try:
            payload = json.loads(exc.read() or b"{}")
        except ValueError:
            payload = {}
        raise CloudflareError(_messages(payload) or f"Cloudflare hatası ({exc.code})")
    except (urllib.error.URLError, TimeoutError, ValueError):
        raise CloudflareError("Cloudflare'e ulaşılamadı")
    if not payload.get("success", False):
        raise CloudflareError(_messages(payload) or "Cloudflare isteği başarısız")
    return payload.get("result")


def create_hostname(zone: str, token: str, hostname: str) -> dict:
    """Domaini Cloudflare'de custom hostname olarak kaydeder; sertifika HTTP doğrulamasıyla alınır."""
    return _call("POST", f"/zones/{zone}/custom_hostnames", token, {
        "hostname": hostname,
        "ssl": {"method": "http", "type": "dv", "settings": {"min_tls_version": "1.2"}},
    })


def find_hostname(zone: str, token: str, hostname: str) -> dict | None:
    result = _call("GET", f"/zones/{zone}/custom_hostnames?hostname={quote(hostname)}", token)
    return result[0] if result else None


def get_hostname(zone: str, token: str, cf_id: str) -> dict:
    return _call("GET", f"/zones/{zone}/custom_hostnames/{cf_id}", token)


def delete_hostname(zone: str, token: str, cf_id: str) -> None:
    _call("DELETE", f"/zones/{zone}/custom_hostnames/{cf_id}", token)
