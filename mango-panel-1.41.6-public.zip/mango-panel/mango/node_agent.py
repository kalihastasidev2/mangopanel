"""Mango Panel node ajanı. Yalnızca Python standart kütüphanesini kullanır.

Kurulum betiği bu dosyayı /opt/mango-node/agent.py olarak yerleştirir ve bir systemd servisi olarak çalıştırır.
Ajan, panele periyodik olarak durum bildirir; panel node'u 'çevrimiçi' olarak gösterir.
"""
import json
import os
import platform
import shutil
import time
import urllib.error
import urllib.request
from pathlib import Path

VERSION = "1.18.0"
INTERVAL_SECONDS = 15
CONFIG_PATH = Path(__file__).with_name("config.json")


def read_config() -> dict:
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))


def memory_stats() -> dict:
    info = {}
    for line in Path("/proc/meminfo").read_text(encoding="utf-8").splitlines():
        key, _, value = line.partition(":")
        parts = value.strip().split()
        if parts:
            info[key] = int(parts[0])  # kB
    total = info.get("MemTotal", 0) // 1024
    available = info.get("MemAvailable", 0) // 1024
    return {"memory_total_mb": total, "memory_used_mb": max(0, total - available)}


def disk_stats(path: str = "/") -> dict:
    usage = shutil.disk_usage(path)
    return {"disk_total_mb": usage.total // (1024 * 1024), "disk_used_mb": usage.used // (1024 * 1024)}


def collect() -> dict:
    try:
        load = round(os.getloadavg()[0], 2)
    except OSError:
        load = 0.0
    stats = {"load": load, "cpus": os.cpu_count() or 1, "os": platform.platform()[:120]}
    stats.update(memory_stats())
    stats.update(disk_stats())
    return stats


def heartbeat(config: dict) -> dict:
    body = json.dumps({"version": VERSION, "stats": collect()}).encode("utf-8")
    request = urllib.request.Request(
        config["panel_url"].rstrip("/") + "/api/nodes/heartbeat",
        data=body,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer " + config["node_token"],
            "User-Agent": "mango-node/" + VERSION,
        },
    )
    with urllib.request.urlopen(request, timeout=20) as response:
        return json.loads(response.read().decode("utf-8") or "{}")


def main() -> None:
    config = read_config()
    print(f"Mango node ajanı {VERSION} başlatıldı; panel: {config['panel_url']}", flush=True)
    while True:
        try:
            result = heartbeat(config)
            print(f"bildirim gönderildi: {result.get('name', '?')}", flush=True)
        except urllib.error.HTTPError as exc:
            print(f"panel isteği reddetti: HTTP {exc.code} (anahtarı kontrol edin)", flush=True)
        except Exception as exc:  # ağ kesintisi vb.; döngü devam eder
            print(f"bağlantı hatası: {exc}", flush=True)
        time.sleep(INTERVAL_SECONDS)


if __name__ == "__main__":
    main()
