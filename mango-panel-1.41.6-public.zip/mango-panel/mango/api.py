import logging
import asyncio
import contextlib
import json
import os
from datetime import datetime, timedelta, timezone
import re
import secrets
import shutil
import socket
import sqlite3
import tarfile
import tempfile
import threading
import urllib.error
import urllib.request
from pathlib import Path
from urllib.parse import urlparse

import yaml
from fastapi import APIRouter, Depends, HTTPException, Query, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from starlette.background import BackgroundTask
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from . import __version__
from . import discord_login
from . import docker_manager as dm
from . import files_manager as fm
from . import discord_bot
from . import site_dns
from .config import settings
from . import health as health_checks
from .db import ApiKey, AuditLog, Node, ServerAccess, ServerNote, ServerTemplate, SessionLocal, Server, User
from .eggs import EggError, build_variables, load_eggs, render
from .policy import egg_allowed
from .ratelimit import app_requests, login_failures, registrations
from .security import (
    admin_only,
    api_key_hash,
    create_token,
    current_user,
    get_db,
    hash_password,
    user_from_token,
    verify_password,
)
from .store import (
    all_settings,
    announcement_text,
    approval_required,
    audit,
    default_max_servers,
    disabled_eggs,
    flag,
    get_setting,
    maintenance_on,
    registration_enabled,
    set_setting,
    setting_int,
)

log = logging.getLogger("mango.api")
router = APIRouter(prefix="/api")
NAME_PATTERN = r"^[A-Za-z0-9 _-]+$"
EMAIL_RE = re.compile(r"^[^@\s]{1,64}@[^@\s]{1,190}\.[^@\s]{2,}$")
SLUG_RE = re.compile(r"^[a-z0-9-]{1,64}$")


# ---------- şemalar ----------
class LoginIn(BaseModel):
    username: str = Field(max_length=32)
    password: str = Field(max_length=128)


class RegisterIn(BaseModel):
    username: str = Field(min_length=3, max_length=32, pattern=r"^[A-Za-z0-9_]+$")
    email: str = Field(max_length=120)
    password: str = Field(min_length=8, max_length=128)


class ServerIn(BaseModel):
    name: str = Field(min_length=2, max_length=48, pattern=NAME_PATTERN)
    egg: str = Field(max_length=64)
    memory_mb: int = Field(512, ge=128, le=16384)
    cpu_percent: int = Field(100, ge=10, le=800)
    variables: dict[str, str] = {}
    site_slug: str | None = Field(None, max_length=40)  # web eggleri için: /sites/<slug>
    owner_id: int | None = None  # yalnızca yönetici: sunucuyu başka bir kullanıcı adına oluşturur
    duration: str | None = Field(None, max_length=16)  # 1.40.24: 3d|1w|1m|3m|1y|custom|unlimited (boş = süresiz)
    duration_days: int | None = Field(None, ge=1, le=3650)  # yalnızca duration=custom iken
    node_id: int | None = None  # yalnızca yönetici: sunucunun bağlı olduğu node (1.19.0'da kayıt amaçlı)


class ServerUpdate(BaseModel):
    name: str | None = Field(None, min_length=2, max_length=48, pattern=NAME_PATTERN)
    memory_mb: int | None = Field(None, ge=128, le=16384)
    cpu_percent: int | None = Field(None, ge=10, le=800)
    variables: dict[str, str] | None = None
    site_slug: str | None = Field(None, max_length=40)  # boş gönderilirse site yayından kalkar
    env: dict[str, str] | None = None  # kullanıcı ortam değişkenleri (KEY=VALUE); değişince konteyner yeniden oluşur
    startup: str | None = Field(None, max_length=500)  # boşsa egg'in varsayılan başlatma komutu kullanılır


class NoteIn(BaseModel):
    text: str = Field(min_length=1, max_length=500)


class ApiKeyIn(BaseModel):
    name: str = Field(min_length=1, max_length=48)
    scope: str = Field("client", pattern=r"^(client|application)$")


class AccessIn(BaseModel):
    username: str = Field(min_length=3, max_length=32)
    permissions: list[str] = Field(default_factory=list, max_length=4)


class TemplateIn(BaseModel):
    name: str = Field(min_length=2, max_length=48, pattern=NAME_PATTERN)
    egg: str = Field(max_length=64)
    memory_mb: int = Field(512, ge=128, le=16384)
    cpu_percent: int = Field(100, ge=10, le=800)
    variables: dict[str, str] = {}


class CloneIn(BaseModel):
    name: str = Field(min_length=2, max_length=48, pattern=NAME_PATTERN)


class FilesDeleteIn(BaseModel):
    paths: list[str] = Field(min_length=1, max_length=200)


class RebuildIn(BaseModel):
    reinstall: bool = False  # True: kurulum betiğini de yeniden çalıştır (veriler korunur)


class PowerIn(BaseModel):
    action: str = Field(pattern=r"^(start|stop|restart|kill)$")


class CommandIn(BaseModel):
    command: str = Field(min_length=1, max_length=500)


class FileWriteIn(BaseModel):
    path: str = Field(max_length=512)
    content: str


class FolderIn(BaseModel):
    path: str = Field(max_length=512)


class UserIn(BaseModel):
    username: str = Field(min_length=3, max_length=32, pattern=r"^[A-Za-z0-9_]+$")
    email: str = Field("", max_length=120)
    password: str = Field(min_length=8, max_length=128)
    is_admin: bool = False
    max_servers: int = Field(2, ge=0, le=100)


class UserUpdate(BaseModel):
    approved: bool | None = None
    email: str | None = Field(None, max_length=120)
    password: str | None = Field(None, min_length=8, max_length=128)
    is_admin: bool | None = None
    max_servers: int | None = Field(None, ge=0, le=100)


class AdminSettingsIn(BaseModel):
    discord_client_id: str | None = Field(None, max_length=20, pattern=r"^$|^\d{17,20}$")
    discord_client_secret: str | None = Field(None, max_length=100)
    registration_enabled: bool | None = None
    registration_approval: bool | None = None
    default_max_servers: int | None = Field(None, ge=0, le=100)
    alert_webhook_url: str | None = Field(None, max_length=300, pattern=r"^$|^https://[^\s]+$")
    max_memory_mb: int | None = Field(None, ge=128, le=16384)
    max_cpu_percent: int | None = Field(None, ge=10, le=800)
    max_disk_mb: int | None = Field(None, ge=256, le=102400)
    self_service_servers: bool | None = None
    domain_cname_target: str | None = Field(None, max_length=253)  # özel domain CNAME hedefi
    domain_ip: str | None = Field(None, max_length=45)  # özel domain kök A kaydı IP'si
    cf_api_token: str | None = Field(None, max_length=200)  # Cloudflare API token (boş gönderilirse silinir)
    cf_zone_id: str | None = Field(None, max_length=40)
    saas_fallback_host: str | None = Field(None, max_length=253)
    site_subdomains: bool | None = None
    site_base_domain: str | None = Field(None, max_length=253, pattern=r"^$|^[a-z0-9-]+(\.[a-z0-9-]+)+$")
    maintenance_mode: bool | None = None
    announcement: str | None = Field(None, max_length=255)
    announcement_enabled: bool | None = None
    disabled_eggs: list[str] | None = Field(None, max_length=100)
    site_name: str | None = Field(None, min_length=1, max_length=40)
    logo_text: str | None = Field(None, max_length=8)
    app_rate_per_min: int | None = Field(None, ge=10, le=10000)


class SuspendIn(BaseModel):
    suspended: bool


# ---------- yardımcılar ----------
def _user_json(u: User) -> dict:
    return {
        "id": u.id,
        "username": u.username,
        "email": u.email or "",
        "is_admin": u.is_admin,
        "max_servers": u.max_servers,
        "approved": bool(u.approved),
        "created_at": u.created_at.isoformat() if u.created_at else None,
        "onboarded": bool(u.onboarded),
    }


def _address(s: Server) -> str:
    """Oyuncuların/ziyaretçilerin bağlanacağı adres. Tünel modunda port dışarı açık değildir."""
    if settings.access_mode == "cloudflare":
        return "Cloudflare Tunnel (yalnızca web)"
    host = urlparse(settings.public_url).hostname or "localhost"
    return f"{host}:{s.port}"


RENAME_LIMIT = 3
SITE_RE = re.compile(r"^[a-z0-9-]{3,40}$")
WEB_CATEGORIES = {"web", "php"}  # /sites/ üzerinden yayınlanabilen eggler (statik ve PHP siteleri)
APP_CATEGORIES = {"nodejs", "python"}  # /api/apps/ üzerinden REST API olarak yayınlanabilen eggler
ROUTE_CATEGORIES = WEB_CATEGORIES | APP_CATEGORIES  # yayın adı alabilen tüm eggler


def _slugify(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug[:40].strip("-")


def _egg_category_of(s: Server, eggs: dict | None = None) -> str:
    try:
        table = eggs if eggs is not None else load_eggs()
        return str(table.get(s.egg, {}).get("category", "")).lower()
    except EggError:
        return ""


def _safe_eggs() -> dict:
    """Liste ekranları için: egg dosyaları bir kez okunur; hatalıysa boş döner."""
    try:
        return load_eggs()
    except EggError:
        return {}


def _site_url(s: Server, eggs: dict | None = None) -> str | None:
    if not s.site_slug:
        return None
    if getattr(s, "site_host", None) and _egg_category_of(s, eggs) not in APP_CATEGORIES:
        return f"https://{s.site_host}/"
    base = settings.public_url.rstrip("/")
    if _egg_category_of(s, eggs) in APP_CATEGORIES:
        return f"{base}/api/apps/{s.site_slug}/"
    return f"{base}/sites/{s.site_slug}/"


def _check_site_slug(db: Session, slug: str, egg: dict, server_id: int | None) -> None:
    if str(egg.get("category", "")).lower() not in (set(ROUTE_CATEGORIES)):
        raise HTTPException(400, "Bu egg için yayın adı verilemez")
    if not SITE_RE.match(slug):
        raise HTTPException(400, "Site adı 3-40 karakter olmalı; yalnızca küçük harf, rakam ve tire içerebilir")
    clash = db.query(Server).filter(Server.site_slug == slug)
    if server_id is not None:
        clash = clash.filter(Server.id != server_id)
    if clash.first():
        raise HTTPException(409, "Bu site adı başka bir sunucuda kullanılıyor")


def _server_json(s: Server, with_status: bool = True, eggs: dict | None = None) -> dict:
    data = {
        "id": s.id,
        "name": s.name,
        "egg": s.egg,
        "owner_id": s.owner_id,
        "port": s.port,
        "node_id": s.node_id,
        "memory_mb": s.memory_mb,
        "cpu_percent": s.cpu_percent,
        "variables": s.variables,
        "address": _address(s),
        "suspended": bool(s.suspended),
        "expires_at": (s.expires_at.isoformat() + ("" if s.expires_at.tzinfo else "Z")) if getattr(s, "expires_at", None) else None,
        "maintenance": bool(s.maintenance),
        "maintenance_message": s.maintenance_message or "",
        "site_slug": s.site_slug,
        "site_url": _site_url(s, eggs),
        "rename_left": max(0, RENAME_LIMIT - (s.rename_count or 0)),
        "env": s.env or {},
        "startup_override": s.startup_override or "",
    }
    if with_status:
        data["status"] = dm.status(s)
    return data


PERMISSIONS = {"console", "power", "files", "settings"}  # alt kullanıcıya verilebilen yetkiler


def _perms_for(user: User, server: Server, db: Session) -> set[str]:
    """Kullanıcının bu sunucudaki yetkileri. Sahip ve yönetici her şeyi yapar ('owner' dahil)."""
    if user.is_admin or server.owner_id == user.id:
        return PERMISSIONS | {"owner"}
    row = db.query(ServerAccess).filter_by(server_id=server.id, user_id=user.id).first()
    return (set(row.permissions.split(",")) & PERMISSIONS) if row else set()


def _visible_server(user: User, db: Session, server_id: int, perm: str | None = None) -> Server:
    """Sunucuyu yetkiye göre getirir. Hiç erişimi olmayan için 404 (varlığı sızdırılmaz);
    erişimi var ama bu işlem için yetkisi yoksa 403."""
    server = db.get(Server, server_id)
    perms = _perms_for(user, server, db) if server is not None else set()
    if server is None or not perms:
        raise HTTPException(404, "Sunucu bulunamadı")
    if server.suspended and not user.is_admin:
        raise HTTPException(403, "Bu sunucu askıya alındı. Yöneticinizle iletişime geçin.")
    if perm and perm not in perms:
        raise HTTPException(403, "Bu işlem için yetkiniz yok")
    return server


def _egg_for(server: Server) -> dict:
    try:
        egg = load_eggs().get(server.egg)
    except EggError as exc:
        raise HTTPException(500, str(exc))
    if egg is None:
        raise HTTPException(409, "Bu sunucunun egg'i artık mevcut değil")
    return egg


def _startup_for(server: Server, egg: dict) -> str:
    """Sunucuya özel başlatma komutu varsa o, yoksa egg'in komutu (değişkenleri yerleştirilmiş)."""
    if server.startup_override:
        return server.startup_override
    return render(egg["startup"], server.variables)


def _clean_startup(value: str | None) -> str | None:
    """Boş değer egg varsayılanına döner. Komut tek satır olmalı; konteynerde 'sh -c' ile çalışır."""
    if value is None:
        return None
    cleaned = value.strip()
    if not cleaned:
        return None
    if "\n" in cleaned or "\r" in cleaned or "\x00" in cleaned:
        raise HTTPException(400, "Başlatma komutu tek satır olmalı")
    return cleaned


def _allocate_port(db: Session) -> int:
    used = {p for (p,) in db.query(Server.port).all()}
    for port in range(settings.port_range_start, settings.port_range_end + 1):
        if port in used:
            continue
        with socket.socket() as sock:
            try:
                sock.bind(("0.0.0.0", port))
                return port
            except OSError:
                continue
    raise HTTPException(503, "Boş port kalmadı")


def _file_call(func_, *args):
    try:
        return func_(*args)
    except fm.FileError as exc:
        raise HTTPException(400, str(exc))


def _validate_command(text: str) -> str | None:
    if "\n" in text or "\r" in text or "\x00" in text:
        return "Komut tek satır olmalı"
    if not text.strip():
        return "Komut boş olamaz"
    return None


def _check_email(email: str) -> None:
    if not EMAIL_RE.match(email):
        raise HTTPException(400, "Geçerli bir e-posta adresi girin")


def _safe_status(s: Server) -> str:
    try:
        return dm.status(s)
    except Exception:
        return "unknown"


def _check_limits(user: User, db: Session, memory_mb: int | None, cpu_percent: int | None) -> None:
    """Yönetici dışındaki kullanıcılar, yöneticinin belirlediği RAM/CPU sınırını aşamaz."""
    if user.is_admin:
        return
    max_mem = setting_int(db, "max_memory_mb")
    max_cpu = setting_int(db, "max_cpu_percent")
    if memory_mb is not None and memory_mb > max_mem:
        raise HTTPException(403, f"RAM en fazla {max_mem} MB olabilir (yönetici sınırı)")
    if cpu_percent is not None and cpu_percent > max_cpu:
        raise HTTPException(403, f"CPU en fazla %{max_cpu} olabilir (yönetici sınırı)")


def _egg_block(slug: str, egg: dict, user: User, db: Session) -> str:
    """Egg kullanılamıyorsa nedenini döndürür; kullanılabilirse boş metin."""
    ok, reason = egg_allowed(egg)
    if not ok:
        return reason
    if not user.is_admin and slug in disabled_eggs(db):
        return "Bu egg yönetici tarafından kapatıldı"
    return ""


# ---------- kimlik ----------
@router.post("/auth/login")
def login(body: LoginIn, request: Request, db: Session = Depends(get_db)):
    key = body.username.lower()
    if login_failures.blocked(key):
        raise HTTPException(429, "Çok fazla hatalı deneme. 15 dakika sonra tekrar deneyin.")
    user = db.query(User).filter_by(username=body.username).first()
    if user is None or not verify_password(body.password, user.password_hash):
        login_failures.hit(key)
        raise HTTPException(401, "Hatalı kullanıcı adı veya şifre")
    if not user.is_admin and maintenance_on(db):
        raise HTTPException(503, "Panel bakım modunda. Lütfen daha sonra tekrar deneyin.")
    if not user.is_admin and not user.approved:
        raise HTTPException(403, "Hesabınız yönetici onayı bekliyor.")
    login_failures.reset(key)
    return {"token": create_token(user, db, request), "user": _user_json(user)}


@router.post("/auth/register", status_code=201)
def register(body: RegisterIn, request: Request, db: Session = Depends(get_db)):
    if maintenance_on(db):
        raise HTTPException(503, "Panel bakım modunda. Kayıt şu an alınmıyor.")
    if not registration_enabled(db):
        raise HTTPException(403, "Kayıt şu an kapalı")
    _check_email(body.email)
    if body.password.lower() == body.username.lower():
        raise HTTPException(400, "Şifre kullanıcı adıyla aynı olamaz")
    if registrations.blocked("all"):
        raise HTTPException(429, "Çok fazla kayıt yapıldı. Daha sonra tekrar deneyin.")
    if db.query(User).filter_by(username=body.username).first():
        raise HTTPException(409, "Kullanıcı adı alınmış")
    if db.query(User).filter_by(email=body.email).first():
        raise HTTPException(409, "Bu e-posta ile zaten bir hesap var")
    user = User(
        username=body.username,
        email=body.email,
        password_hash=hash_password(body.password),
        is_admin=False,
        max_servers=default_max_servers(db),
        onboarded=False,  # ilk girişte kısa rehber gösterilir
        approved=not approval_required(db),
    )
    db.add(user)
    db.flush()
    audit(db, user.username, "register", user.username)
    db.commit()
    registrations.hit("all")
    if not user.approved:
        return {"pending": True, "message": "Kaydınız alındı. Yönetici onayından sonra giriş yapabilirsiniz."}
    return {"token": create_token(user, db, request), "user": _user_json(user)}


@router.get("/me")
def me(user: User = Depends(current_user), db: Session = Depends(get_db)):
    data = _user_json(user)
    data["discord_linked"] = bool(user.discord_id)
    data["discord_suggest"] = (not user.discord_id) and bool(
        get_setting(db, "discord_client_id").strip() and get_setting(db, "discord_client_secret").strip())
    return data


@router.post("/me/onboarded")
def finish_onboarding(user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Yeni kullanıcının ilk kayıt rehberini kapatır."""
    row = db.get(User, user.id)
    row.onboarded = True
    db.commit()
    return _user_json(row)


@router.get("/system")
def system(db: Session = Depends(get_db)):
    return {
        "version": __version__,
        "access_mode": settings.access_mode,
        "site_base_domain": site_dns.public_base(db),
        "public_url": settings.public_url,
        "source_url": settings.source_url,
        "registration_enabled": registration_enabled(db),
        "discord_login": discord_login.enabled(db),
        "self_service_servers": False,
        "maintenance": maintenance_on(db),
        "announcement": announcement_text(db),
        "max_memory_mb": setting_int(db, "max_memory_mb"),
        "max_cpu_percent": setting_int(db, "max_cpu_percent"),
        "max_disk_mb": setting_int(db, "max_disk_mb"),
        "site_name": get_setting(db, "site_name"),
        "logo_text": get_setting(db, "logo_text"),
    }


# ---------- eggler ----------
@router.get("/eggs")
def list_eggs(user: User = Depends(current_user), db: Session = Depends(get_db)):
    try:
        eggs = load_eggs()
    except EggError as exc:
        raise HTTPException(500, str(exc))
    closed = disabled_eggs(db)
    out = []
    for slug, egg in eggs.items():
        reason = _egg_block(slug, egg, user, db)
        out.append({
            "slug": slug,
            "name": egg["name"],
            "category": egg["category"],
            "description": egg["description"],
            "variables": egg["variables"],
            "memory_mb": egg["memory_mb"],
            "allowed": not reason,
            "reason": reason,
            "disabled": slug in closed,
        })
    return out


# ---------- sunucular ----------
def _status_from_map(statuses: dict[str, str], container_id: str | None) -> str:
    if not container_id:
        return "missing"
    if container_id in statuses:
        return statuses[container_id]
    for full_id, value in statuses.items():
        if full_id.startswith(container_id) or container_id.startswith(full_id):
            return value
    return "missing"


@router.get("/servers")
def list_servers(scope: str = "auto", user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Yönetici varsayılan olarak tüm sunucuları görür; scope=mine yalnızca kendi ve paylaşılan sunucuları döndürür.
    Durumlar tek Docker isteğiyle, egg dosyaları bir kez okunarak alınır (1.20.0)."""
    q = db.query(Server)
    if not user.is_admin or scope == "mine":
        shared = select(ServerAccess.server_id).where(ServerAccess.user_id == user.id)
        q = q.filter(or_(Server.owner_id == user.id, Server.id.in_(shared)))
    servers = q.order_by(Server.id).all()
    access = {row.server_id: row.permissions or "" for row in
              db.query(ServerAccess).filter_by(user_id=user.id).all()}
    eggs = _safe_eggs()
    statuses = dm.status_map()  # None: Docker'a ulaşılamadı; durumlar tek tek sorgulanır
    out = []
    for s in servers:
        data = _server_json(s, with_status=False, eggs=eggs)
        data["status"] = dm.status(s) if statuses is None else _status_from_map(statuses, s.container_id)
        if user.is_admin or s.owner_id == user.id:
            perms = PERMISSIONS | {"owner"}
        else:
            perms = set(access.get(s.id, "").split(",")) & PERMISSIONS
        data["my_permissions"] = sorted(perms)
        out.append(data)
    return out


@router.post("/servers", status_code=201)
def create_server(body: ServerIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    # Kullanıcılar varsayılan olarak kendi sunucusunu oluşturamaz; sunucuyu yönetici verir.
    if not user.is_admin:
        raise HTTPException(403, "Sunucu oluşturma yalnızca yönetici tarafından yapılır.")
    if body.owner_id is not None and body.owner_id != user.id and not user.is_admin:
        raise HTTPException(403, "Başka bir kullanıcı adına sunucu oluşturamazsınız.")
    owner = user
    if body.owner_id is not None and body.owner_id != user.id:
        owner = db.get(User, body.owner_id)
        if owner is None:
            raise HTTPException(404, "Sahip kullanıcı bulunamadı")
    try:
        eggs = load_eggs()
    except EggError as exc:
        raise HTTPException(500, str(exc))
    egg = eggs.get(body.egg)
    if egg is None:
        raise HTTPException(404, "Egg bulunamadı")
    reason = _egg_block(body.egg, egg, user, db)
    if reason:
        raise HTTPException(403, reason)
    _check_limits(owner, db, body.memory_mb, body.cpu_percent)
    if not owner.is_admin:
        owned = db.query(Server).filter_by(owner_id=owner.id).count()
        if owned >= owner.max_servers:
            if user.is_admin:
                raise HTTPException(403, f"{owner.username} kullanıcısının sunucu limiti dolu ({owner.max_servers}). Limiti artırın.")
            raise HTTPException(403, f"Sunucu limitinize ulaştınız ({owner.max_servers}). Yöneticinizle iletişime geçin.")
    if body.node_id is not None:
        if not user.is_admin:
            raise HTTPException(403, "Node seçimi yalnızca yönetici tarafından yapılabilir")
        if db.get(Node, body.node_id) is None:
            raise HTTPException(400, "Seçilen node bulunamadı")
    try:
        variables = build_variables(egg, body.variables)
    except EggError as exc:
        raise HTTPException(400, str(exc))

    site_slug = None
    if str(egg.get("category", "")).lower() in ROUTE_CATEGORIES:
        site_slug = body.site_slug or _slugify(body.name)
        _check_site_slug(db, site_slug, egg, None)
    elif body.site_slug:
        raise HTTPException(400, "Bu egg için yayın adı verilemez")

    from .duration import resolve_days, set_expiry

    try:
        days = resolve_days(body.duration, body.duration_days)
    except ValueError as exc:
        raise HTTPException(400, str(exc))
    server = Server(
        name=body.name,
        egg=body.egg,
        owner_id=owner.id,
        port=_allocate_port(db),
        memory_mb=body.memory_mb,
        cpu_percent=body.cpu_percent,
        variables=variables,
        site_slug=site_slug,
        node_id=body.node_id,
    )
    db.add(server)
    db.flush()
    set_expiry(server, days)
    if site_slug:
        try:
            site_dns.assign(db, server, site_slug)
        except HTTPException:
            db.rollback()
            raise
    dns_rid = server.site_dns_id
    sid = server.id
    try:
        # Egg'in örnek dosyaları (ör. index.js, public/index.php) ilk kez yazılır.
        fm.seed_files(sid, egg.get("starter_files", {}))
        install_script = render(egg["install_script"], variables)
        dm.run_install(server, egg, install_script)
        startup = render(egg["startup"], variables)
        primary_port = int(egg["ports"][0])
        server.container_id = dm.create(server, egg, startup, primary_port)
        try:  # 1.40.2: kurulum bitince otomatik başlat; başlatma hatası sunucuyu silmez
            dm.power(server, "start")
        except Exception as start_exc:  # noqa: BLE001
            log.warning("Sunucu otomatik başlatılamadı (%s): %s", server.id, start_exc)
            try:  # 1.41.1: yarım kalmış konteyneri sıfırdan kurup bir kez daha dene
                server.container_id = _rebuild_and_start(server, egg, startup, primary_port)
            except Exception as again:  # noqa: BLE001
                log.warning("Sıfırdan kurulumla da başlatılamadı (%s): %s", server.id, again)
        audit(db, user.username, "server.create", server.name, f"{body.egg} sahip={owner.username}")
        db.commit()
    except Exception as exc:  # kurulum/oluşturma hatası: kaydı geri al
        db.rollback()
        site_dns.release(db, dns_rid)
        try:
            dm.delete_by_id(sid)
        except Exception:
            pass
        if dm.is_transient(exc):
            log.warning("Sunucu oluşturulamadı (geçici): %s", exc)
            raise HTTPException(503, "Sunucu şu an hazırlanamadı, sistem yoğun. Birkaç dakika sonra tekrar deneyin.")
        log.error("Sunucu oluşturulamadı: %s", exc)
        raise HTTPException(500, "Sunucu oluşturulamadı. Ayrıntı yönetici günlüklerinde.")
    return _server_json(server)


@router.get("/servers/{server_id}")
def get_server(server_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id)
    data = _server_json(server)
    data["my_permissions"] = sorted(_perms_for(user, server, db))
    return data


@router.patch("/servers/{server_id}")
def update_server(server_id: int, body: ServerUpdate, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "settings")
    changes = body.model_dump(exclude_unset=True)
    if not changes:
        return _server_json(server)
    _check_limits(user, db, changes.get("memory_mb"), changes.get("cpu_percent"))

    if "site_slug" in changes:
        slug = (changes["site_slug"] or "").strip().lower()
        if not slug:
            server.site_slug = None
        else:
            _check_site_slug(db, slug, _egg_for(server), server.id)
            server.site_slug = slug
        site_dns.assign(db, server, server.site_slug)

    needs_recreate = False
    if changes.get("name") and changes["name"] != server.name:
        if not user.is_admin and (server.rename_count or 0) >= RENAME_LIMIT:
            raise HTTPException(403, f"Sunucu adını en fazla {RENAME_LIMIT} kez değiştirebilirsiniz")
        server.name = changes["name"]
        server.rename_count = (server.rename_count or 0) + 1
    if changes.get("memory_mb") is not None and changes["memory_mb"] != server.memory_mb:
        server.memory_mb = changes["memory_mb"]
        needs_recreate = True
    if changes.get("cpu_percent") is not None and changes["cpu_percent"] != server.cpu_percent:
        server.cpu_percent = changes["cpu_percent"]
        needs_recreate = True
    if changes.get("variables") is not None:
        egg = _egg_for(server)
        try:
            new_vars = build_variables(egg, {**server.variables, **changes["variables"]})
        except EggError as exc:
            raise HTTPException(400, str(exc))
        if new_vars != server.variables:
            server.variables = new_vars
            needs_recreate = True

    if changes.get("env") is not None:
        new_env = _validate_env(changes["env"], _egg_for(server))
        if new_env != (server.env or {}):
            server.env = new_env
            needs_recreate = True

    if "startup" in changes:
        new_startup = _clean_startup(changes["startup"])
        if new_startup != server.startup_override:
            server.startup_override = new_startup
            needs_recreate = True

    if needs_recreate:
        # Limitler, ortam değişkenleri ve başlatma komutu yalnızca konteyner oluşturulurken uygulanır.
        egg = _egg_for(server)
        try:
            server.container_id = dm.recreate(server, egg, _startup_for(server, egg), int(egg["ports"][0]))
        except Exception as exc:
            db.rollback()
            raise HTTPException(500, f"Konteyner yeniden oluşturulamadı: {exc}")
    db.commit()
    return _server_json(server)


@router.post("/servers/{server_id}/rebuild")
def rebuild_server(server_id: int, body: RebuildIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Konteyneri ayarlarla yeniden oluşturur. reinstall=True ise kurulum betiğini de çalıştırır.
    Dosyalar korunur. Eski sunucuları konsol desteğine geçirmek için de kullanılır."""
    server = _visible_server(user, db, server_id, "settings")
    egg = _egg_for(server)
    try:
        if body.reinstall:
            dm.run_install(server, egg, render(egg["install_script"], server.variables))
        server.container_id = dm.recreate(server, egg, _startup_for(server, egg), int(egg["ports"][0]))
        db.commit()
    except Exception as exc:
        db.rollback()
        raise HTTPException(500, f"Yeniden oluşturma başarısız: {exc}")
    return _server_json(server)


def _rebuild_and_start(server, egg: dict, startup: str, port: int) -> str:
    """1.41.1: Konteyner başlamıyorsa (ör. 'created' ya da bozuk yarım konteyner) eski konteyneri silip
    aynı ayarlarla sıfırdan oluşturur ve başlatır. Veriler klasörde kaldığı için kayıp olmaz."""
    cid = dm.recreate(server, egg, startup, port)
    server.container_id = cid  # başlatma yeni konteynerı görmeli (eski kimlik 404 verirdi)
    dm.power(server, "start")
    return cid


def _auto_rebuild(server, db: Session, exc: Exception) -> str:
    egg = load_eggs().get(server.egg)
    if egg is None:
        raise HTTPException(409, f"İşlem başarısız: {exc}")
    try:
        server.container_id = _rebuild_and_start(server, egg, _startup_for(server, egg), int(egg["ports"][0]))
        db.commit()
    except Exception as again:  # noqa: BLE001
        db.rollback()
        raise HTTPException(409, f"Sunucu başlatılamadı (ilk deneme: {exc}; sıfırdan kurulum: {again})")
    return dm.status(server)


@router.post("/servers/{server_id}/power")
def power(server_id: int, body: PowerIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "power")
    try:
        state = dm.power(server, body.action)
    except Exception as exc:
        if dm.is_transient(exc):
            log.warning("Güç işlemi geçici hata verdi: %s", exc)
            raise HTTPException(503, "Sunucu şu an başlatılamadı, sistem yoğun. Birkaç saniye sonra tekrar deneyin.")
        if body.action != "start":
            raise HTTPException(409, f"İşlem başarısız: {exc}")
        log.warning("Başlatma başarısız (%s), sıfırdan kurulup denenecek: %s", server.id, exc)
        state = _auto_rebuild(server, db, exc)
    if body.action in ("start", "restart") and state != "running":
        info = dm.last_failure(server)
        code = info.get("exit_code")
        reason = info.get("error") or ""
        tail = info.get("log") or ""
        msg = f"Sunucu başlatılamadı (çıkış kodu {code})."
        if reason:
            msg += f" Hata: {reason}"
        if tail:
            msg += f" Son kayıtlar: {tail[-600:]}"
        raise HTTPException(409, msg)
    if body.action != "start":
        discord_bot.mark_intentional(server.id)  # kasıtlı durdurma çökme olarak bildirilmez
    return {"status": state}


@router.get("/servers/{server_id}/stats")
def server_stats(server_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id)
    st = dm.stats(server)
    st["disk_mb"] = fm.dir_size_mb(server.id)
    return st


@router.post("/servers/{server_id}/command")
def send_command(server_id: int, body: CommandIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "console")
    error = _validate_command(body.command)
    if error:
        raise HTTPException(400, error)
    try:
        dm.send_command(server, body.command)
    except RuntimeError as exc:
        raise HTTPException(409, str(exc))
    return {"sent": True}


@router.get("/servers/{server_id}/logs")
def get_logs(server_id: int, tail: int = 200, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "console")
    return {"logs": dm.logs(server, tail=min(max(tail, 1), 2000))}


# ---------- dosyalar ----------
@router.get("/servers/{server_id}/files")
def list_files(server_id: int, path: str = "", user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "files")
    return _file_call(fm.list_dir, server.id, path)


@router.get("/servers/{server_id}/files/content")
def read_file(server_id: int, path: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "files")
    return {"path": path, "content": _file_call(fm.read_text, server.id, path)}


@router.put("/servers/{server_id}/files/content")
def write_file(server_id: int, body: FileWriteIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "files")
    quota = None if user.is_admin else setting_int(db, "max_disk_mb") * 1048576
    _file_call(fm.write_text, server.id, body.path, body.content, quota)
    return {"saved": True}


@router.post("/servers/{server_id}/files/folder", status_code=201)
def create_folder(server_id: int, body: FolderIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "files")
    _file_call(fm.make_dir, server.id, body.path)
    return {"created": True}


@router.delete("/servers/{server_id}/files", status_code=204)
def delete_file(server_id: int, path: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "files")
    _file_call(fm.delete, server.id, path)


@router.delete("/servers/{server_id}", status_code=204)
def delete_server(server_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "owner")
    name = server.name
    dm.delete(server)
    db.query(ServerAccess).filter_by(server_id=server.id).delete()
    db.query(ServerNote).filter_by(server_id=server.id).delete()
    db.delete(server)
    audit(db, user.username, "server.delete", name)
    db.commit()


# ---------- sunucu notları (yalnızca sahip ve yönetici) ----------
def _note_json(n: ServerNote) -> dict:
    return {
        "id": n.id,
        "author": n.author,
        "text": n.text,
        "created_at": n.created_at.isoformat() if n.created_at else None,
    }


@router.get("/servers/{server_id}/notes")
def list_notes(server_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "owner")
    rows = (db.query(ServerNote).filter_by(server_id=server.id)
            .order_by(ServerNote.id.desc()).limit(200).all())
    return [_note_json(n) for n in rows]


@router.post("/servers/{server_id}/notes", status_code=201)
def add_note(server_id: int, body: NoteIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "owner")
    text = body.text.strip()
    if not text:
        raise HTTPException(400, "Not boş olamaz")
    if db.query(ServerNote).filter_by(server_id=server.id).count() >= 200:
        raise HTTPException(409, "En fazla 200 not saklanır; eski notları silin")
    note = ServerNote(server_id=server.id, author=user.username[:32], text=text)
    db.add(note)
    db.commit()
    return _note_json(note)


@router.delete("/servers/{server_id}/notes/{note_id}", status_code=204)
def delete_note(server_id: int, note_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "owner")
    note = db.get(ServerNote, note_id)
    if note is None or note.server_id != server.id:
        raise HTTPException(404, "Not bulunamadı")
    db.delete(note)
    db.commit()


# ---------- konsol (canlı log + komut) ----------
def _console_route(text: str) -> tuple[str, str]:
    """'$' ile başlayan satır konteyner içinde kabuk komutu olarak çalışır.
    Diğer satırlar çalışan programın stdin'ine gider (ör. Python input() cevabı)."""
    stripped = text.strip()
    if stripped.startswith("$"):
        return "exec", stripped[1:].strip()
    return "stdin", text

@router.websocket("/servers/{server_id}/console")
async def console(ws: WebSocket, server_id: int, token: str):
    """Sunucudan giden mesajlar: {"type":"log","data":...} | {"type":"error","message":...}
    İstemciden gelen mesajlar: {"type":"command","data":"..."}"""
    await ws.accept()
    db = SessionLocal()
    try:
        user = user_from_token(token, db)
        server = _visible_server(user, db, server_id, "console")
    except Exception:
        await ws.close(code=4401)
        return
    finally:
        db.close()

    loop = asyncio.get_running_loop()
    queue: asyncio.Queue = asyncio.Queue()
    stop = threading.Event()
    threading.Thread(target=dm.stream_logs, args=(server, loop, queue, stop), daemon=True).start()

    async def pump():
        while True:
            chunk = await queue.get()
            if chunk is None:
                break
            await ws.send_text(json.dumps({"type": "log", "data": chunk}))

    async def receive():
        while True:
            msg = json.loads(await ws.receive_text())
            if msg.get("type") != "command":
                continue
            text = str(msg.get("data", ""))
            error = _validate_command(text)
            if error:
                await ws.send_text(json.dumps({"type": "error", "message": error}))
                continue
            kind, payload = _console_route(text)
            try:
                if kind == "exec":
                    if not payload:
                        await ws.send_text(json.dumps({"type": "error", "message": "Komut boş olamaz ($ sonrası)"}))
                        continue
                    dm.exec_stream(server, payload, loop, queue)
                else:
                    await asyncio.to_thread(dm.send_command, server, text)
            except Exception as exc:
                await ws.send_text(json.dumps({"type": "error", "message": str(exc)}))

    tasks = [asyncio.create_task(pump()), asyncio.create_task(receive())]
    try:
        await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
    except WebSocketDisconnect:
        pass
    finally:
        stop.set()
        for t in tasks:
            t.cancel()


# ---------- hesap: API anahtarları ----------
MAX_KEYS = 5


@router.get("/keys")
def list_keys(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.query(ApiKey).filter_by(user_id=user.id).order_by(ApiKey.id).all()
    return [
        {
            "id": r.id,
            "name": r.name,
            "prefix": r.prefix,
            "scope": r.scope,
            "created_at": r.created_at.isoformat() if r.created_at else None,
            "last_used": r.last_used.isoformat() if r.last_used else None,
        }
        for r in rows
    ]


@router.post("/keys", status_code=201)
def create_key(body: ApiKeyIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if db.query(ApiKey).filter_by(user_id=user.id).count() >= MAX_KEYS:
        raise HTTPException(409, f"En fazla {MAX_KEYS} API anahtarınız olabilir. Birini silin.")
    if body.scope == "application" and not user.is_admin:
        raise HTTPException(403, "Uygulama anahtarını yalnızca yönetici oluşturabilir")
    raw = "mgp_" + secrets.token_urlsafe(32)
    row = ApiKey(user_id=user.id, name=body.name.strip(), prefix=raw[:12],
                 key_hash=api_key_hash(raw), scope=body.scope)
    db.add(row)
    db.flush()
    audit(db, user.username, "apikey.create", f"{row.name} ({body.scope})")
    db.commit()
    # Anahtar yalnızca bu yanıtta gösterilir; veritabanında özeti saklanır.
    return {"id": row.id, "name": row.name, "prefix": row.prefix, "scope": row.scope, "key": raw}


# ---------- alt kullanıcılar (sunucu paylaşımı) ----------
@router.get("/servers/{server_id}/access")
def list_access(server_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "owner")
    rows = (db.query(ServerAccess, User)
            .join(User, User.id == ServerAccess.user_id)
            .filter(ServerAccess.server_id == server.id)
            .order_by(User.username).all())
    return [
        {"user_id": u.id, "username": u.username,
         "permissions": sorted(set(a.permissions.split(",")) & PERMISSIONS)}
        for a, u in rows
    ]


@router.post("/servers/{server_id}/access", status_code=201)
def grant_access(server_id: int, body: AccessIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "owner")
    target = db.query(User).filter_by(username=body.username).first()
    if target is None:
        raise HTTPException(404, "Kullanıcı bulunamadı")
    if target.id == server.owner_id:
        raise HTTPException(409, "Sunucu sahibinin zaten tam yetkisi var")
    unknown = set(body.permissions) - PERMISSIONS
    if unknown:
        raise HTTPException(400, f"Bilinmeyen yetki: {sorted(unknown)}")
    perms = sorted(set(body.permissions))
    if not perms:
        raise HTTPException(400, "En az bir yetki seçin")
    row = db.query(ServerAccess).filter_by(server_id=server.id, user_id=target.id).first()
    if row is None:
        row = ServerAccess(server_id=server.id, user_id=target.id, permissions="")
        db.add(row)
    row.permissions = ",".join(perms)
    audit(db, user.username, "server.access", f"{server.name}:{target.username}", ",".join(perms))
    db.commit()
    return {"user_id": target.id, "username": target.username, "permissions": perms}


@router.delete("/servers/{server_id}/access/{user_id}", status_code=204)
def revoke_access(server_id: int, user_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "owner")
    row = db.query(ServerAccess).filter_by(server_id=server.id, user_id=user_id).first()
    if row is None:
        raise HTTPException(404, "Alt kullanıcı bulunamadı")
    target = db.get(User, user_id)
    audit(db, user.username, "server.unaccess", f"{server.name}:{target.username if target else user_id}")
    db.delete(row)
    db.commit()


@router.delete("/keys/{key_id}", status_code=204)
def delete_key(key_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    row = db.query(ApiKey).filter_by(id=key_id, user_id=user.id).first()
    if row is None:
        raise HTTPException(404, "Anahtar bulunamadı")
    audit(db, user.username, "apikey.delete", row.name)
    db.delete(row)
    db.commit()


# ---------- hesap: sunucu şablonları ----------
MAX_TEMPLATES = 20


@router.get("/templates")
def list_templates(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.query(ServerTemplate).filter_by(owner_id=user.id).order_by(ServerTemplate.id).all()
    return [
        {"id": r.id, "name": r.name, "egg": r.egg, "memory_mb": r.memory_mb,
         "cpu_percent": r.cpu_percent, "variables": r.variables}
        for r in rows
    ]


@router.post("/templates", status_code=201)
def create_template(body: TemplateIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    try:
        egg = load_eggs().get(body.egg)
    except EggError as exc:
        raise HTTPException(500, str(exc))
    if egg is None:
        raise HTTPException(404, "Egg bulunamadı")
    reason = _egg_block(body.egg, egg, user, db)
    if reason:
        raise HTTPException(403, reason)
    _check_limits(user, db, body.memory_mb, body.cpu_percent)
    try:
        variables = build_variables(egg, body.variables)
    except EggError as exc:
        raise HTTPException(400, str(exc))
    if db.query(ServerTemplate).filter_by(owner_id=user.id).count() >= MAX_TEMPLATES:
        raise HTTPException(409, f"En fazla {MAX_TEMPLATES} şablon kaydedebilirsiniz")
    row = ServerTemplate(owner_id=user.id, name=body.name, egg=body.egg, memory_mb=body.memory_mb,
                         cpu_percent=body.cpu_percent, variables=variables)
    db.add(row)
    db.flush()
    db.commit()
    return {"id": row.id, "name": row.name, "egg": row.egg, "memory_mb": row.memory_mb,
            "cpu_percent": row.cpu_percent, "variables": row.variables}


@router.delete("/templates/{template_id}", status_code=204)
def delete_template(template_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    row = db.query(ServerTemplate).filter_by(id=template_id, owner_id=user.id).first()
    if row is None:
        raise HTTPException(404, "Şablon bulunamadı")
    db.delete(row)
    db.commit()


# ---------- siteler (/sites/<ad> → konteyner) ----------
SITE_MAX_BYTES = 20 * 1024 * 1024


def _site_fetch(port: int, path: str, query: str) -> tuple[int, str, bytes]:
    """Konteynerdeki web sunucusundan yanıtı alır. Yalnızca 127.0.0.1 üzerindeki sunucunun portuna gider."""
    url = f"http://127.0.0.1:{port}/{path}" + (f"?{query}" if query else "")
    try:
        with urllib.request.urlopen(urllib.request.Request(url), timeout=15) as resp:
            return resp.status, resp.headers.get("Content-Type", "application/octet-stream"), resp.read(SITE_MAX_BYTES)
    except urllib.error.HTTPError as exc:
        return exc.code, exc.headers.get("Content-Type", "text/plain"), exc.read(SITE_MAX_BYTES)
    except OSError:
        raise HTTPException(503, "Site şu an erişilemiyor. Sunucunun çalıştığından emin olun.")


@router.api_route("/sites/{slug}", methods=["GET", "HEAD"], include_in_schema=False)
@router.api_route("/sites/{slug}/{path:path}", methods=["GET", "HEAD"], include_in_schema=False)
async def public_site(slug: str, request: Request, path: str = ""):
    """Herkese açık site yönlendirmesi. nginx /sites/ isteğini bu adrese /api/sites/ olarak iletir."""
    db = SessionLocal()
    try:
        server = db.query(Server).filter_by(site_slug=slug).first()
        if server is None:
            raise HTTPException(404, "Site bulunamadı")
        if server.suspended:
            raise HTTPException(403, "Bu site askıya alındı")
        if server.maintenance:
            from fastapi.responses import HTMLResponse
            from html import escape
            msg = escape(server.maintenance_message or "Bu site şu an bakımda. Kısa süre sonra tekrar deneyin.")
            return HTMLResponse(
                f"<!doctype html><html lang=\"tr\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
                f"<title>Bakım</title><style>body{{margin:0;min-height:100vh;display:grid;place-items:center;background:#0b0d10;color:#e6edf3;font-family:system-ui,sans-serif;padding:16px;box-sizing:border-box}}"
                f".box{{max-width:460px;text-align:center}}h1{{font-size:24px}}p{{color:#9aa4b2;line-height:1.6}}</style></head>"
                f"<body><div class=\"box\"><h1>🛠️ Bakımdayız</h1><p>{msg}</p></div></body></html>",
                status_code=503, headers={"Retry-After": "600"})
        egg = load_eggs().get(server.egg, {})
        if str(egg.get("category", "")).lower() not in WEB_CATEGORIES:
            raise HTTPException(404, "Site bulunamadı")
        if dm.status(server) != "running":
            raise HTTPException(503, "Bu site şu an çevrimdışı")
        if not app_requests.allow(f"site{server.id}:{_client_ip(request)}", setting_int(db, "app_rate_per_min")):
            raise HTTPException(429, "Çok fazla istek. Bir dakika sonra tekrar deneyin.", headers={"Retry-After": "60"})
        port = server.port
    finally:
        db.close()
    status_code, ctype, body = await asyncio.to_thread(_site_fetch, port, path, request.url.query)
    return Response(content=body if request.method == "GET" else b"", status_code=status_code, media_type=ctype)


# ---------- REST API (Node.js ve Python uygulamaları) ----------
APP_MAX_REQUEST_BYTES = 10 * 1024 * 1024
APP_MAX_RESPONSE_BYTES = 50 * 1024 * 1024
APP_TIMEOUT_SECONDS = 30
API_METHODS = ["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"]
# Bağlantıya özgü başlıklar uçtan uca iletilmez (RFC 7230).
HOP_BY_HOP = {"connection", "keep-alive", "proxy-authenticate", "proxy-authorization", "te",
              "trailer", "trailers", "transfer-encoding", "upgrade", "host", "content-length"}
ENV_KEY_RE = re.compile(r"^[A-Z_][A-Z0-9_]{0,63}$")
RESERVED_ENV = {"SERVER_PORT", "PYTHONUNBUFFERED", "PATH", "HOME"}


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """Yönlendirmeleri uygulamanın kendisine bırakır; panel onları kendisi takip etmez."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


_app_opener = urllib.request.build_opener(_NoRedirect)


def _validate_env(env: dict[str, str], egg: dict) -> dict[str, str]:
    """Kullanıcı ortam değişkenlerini denetler. Egg değişkenleriyle çakışan ya da ayrılmış adlar reddedilir."""
    if len(env) > 50:
        raise HTTPException(400, "En fazla 50 ortam değişkeni eklenebilir")
    declared = {v["name"] for v in egg.get("variables", [])}
    for key, value in env.items():
        if not ENV_KEY_RE.match(key):
            raise HTTPException(400, f"Geçersiz ad: {key} (yalnızca büyük harf, rakam ve _; harf ya da _ ile başlamalı)")
        if key in RESERVED_ENV:
            raise HTTPException(400, f"{key} sistem tarafından ayrılmış")
        if key in declared:
            raise HTTPException(400, f"{key} egg değişkeni; Değişkenler bölümünden düzenleyin")
        if len(value) > 1000 or any(c in value for c in "\r\n\x00"):
            raise HTTPException(400, f"{key} değeri geçersiz (en fazla 1000 karakter, tek satır)")
    return dict(env)


def _client_ip(request: Request) -> str:
    """Hız sınırı için istemci adresi. Cloudflare arkasında cf-connecting-ip, değilse X-Forwarded-For.
    Doğrudan (tünelsiz) kurulumda X-Forwarded-For istemci tarafından sahte gönderilebilir; bu durumda sınır kolayca aşılır."""
    if settings.access_mode == "cloudflare":
        ip = request.headers.get("cf-connecting-ip", "")
        if ip:
            return ip
    forwarded = request.headers.get("x-forwarded-for", "").split(",")[0].strip()
    if forwarded:
        return forwarded
    return request.client.host if request.client else "bilinmiyor"


def _pass_headers(headers) -> list[tuple[str, str]]:
    return [(k, v) for k, v in headers.items() if k.lower() not in HOP_BY_HOP]


def _forward(port: int, method: str, path: str, query: str, headers: dict, body: bytes | None) -> tuple[int, list, bytes]:
    """Konteynerdeki uygulamaya gerçek bir port gibi istek iletir: yöntem, başlıklar, çerezler, durum kodu ve gövde aynen geçer.
    Yalnızca 127.0.0.1 üzerindeki sunucunun portuna gider. WebSocket yükseltmesi desteklenmez."""
    url = f"http://127.0.0.1:{port}/{path}" + (f"?{query}" if query else "")
    req = urllib.request.Request(url, data=body, method=method, headers=headers)
    try:
        with _app_opener.open(req, timeout=APP_TIMEOUT_SECONDS) as resp:
            return resp.status, _pass_headers(resp.headers), resp.read(APP_MAX_RESPONSE_BYTES)
    except urllib.error.HTTPError as exc:
        return exc.code, _pass_headers(exc.headers), exc.read(APP_MAX_RESPONSE_BYTES)
    except OSError:
        raise HTTPException(503, "Uygulama yanıt vermiyor. Sunucunun çalıştığından emin olun.")


@router.api_route("/apps/{slug}", methods=API_METHODS, include_in_schema=False)
@router.api_route("/apps/{slug}/{path:path}", methods=API_METHODS, include_in_schema=False)
async def public_app(slug: str, request: Request, path: str = ""):
    """Herkese açık REST API adresi: /api/apps/<ad>/... istekleri konteynerdeki uygulamaya iletilir.
    Panel kimlik doğrulaması yapmaz; Authorization dahil tüm başlıklar uygulamaya geçer."""
    raw = await request.body()
    if len(raw) > APP_MAX_REQUEST_BYTES:
        raise HTTPException(413, "İstek gövdesi çok büyük (en fazla 10 MB)")
    ip = _client_ip(request)
    db = SessionLocal()
    try:
        server = db.query(Server).filter_by(site_slug=slug).first()
        if server is None:
            raise HTTPException(404, "API bulunamadı")
        if server.suspended:
            raise HTTPException(403, "Bu API askıya alındı")
        if _egg_category_of(server) not in APP_CATEGORIES:
            raise HTTPException(404, "API bulunamadı")
        if not app_requests.allow(f"api{server.id}:{ip}", setting_int(db, "app_rate_per_min")):
            raise HTTPException(429, "Çok fazla istek. Bir dakika sonra tekrar deneyin.", headers={"Retry-After": "60"})
        if dm.status(server) != "running":
            raise HTTPException(503, "Bu API şu an çevrimdışı")
        port = server.port
    finally:
        db.close()
    headers = {k: v for k, v in request.headers.items()
               if k.lower() not in HOP_BY_HOP and not k.lower().startswith("x-forwarded-")}
    headers["X-Forwarded-For"] = ip
    headers["X-Forwarded-Proto"] = "https"
    headers["X-Forwarded-Host"] = request.headers.get("host", "")
    status_code, resp_headers, body = await asyncio.to_thread(
        _forward, port, request.method, path, request.url.query, headers, raw or None)
    response = Response(content=b"" if request.method == "HEAD" else body, status_code=status_code)
    for key, value in resp_headers:
        response.headers.append(key, value)  # Set-Cookie gibi tekrarlanan başlıklar korunur
    return response


class HttpTestIn(BaseModel):
    method: str = Field("GET", pattern=r"^(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)$")
    path: str = Field("/", max_length=512)
    body: str = Field("", max_length=65536)


@router.post("/servers/{server_id}/http")
def test_app_request(server_id: int, body: HttpTestIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Panelden kendi uygulamanıza istek gönderip yanıtı görmek için. Yol / ile başlamalı; tam adres kabul edilmez."""
    server = _visible_server(user, db, server_id, "console")
    path = body.path
    if not path.startswith("/") or path.startswith("//") or any(c in path for c in "\r\n\x00"):
        raise HTTPException(400, "Yol / ile başlamalı (ör. /api/kullanicilar)")
    if dm.status(server) != "running":
        raise HTTPException(409, "Sunucu çalışmıyor; önce başlatın")
    target, _, query = path[1:].partition("?")
    headers: dict = {}
    data = None
    if body.body.strip():
        data = body.body.encode("utf-8")
        headers["Content-Type"] = "application/json" if body.body.strip()[0] in "{[" else "text/plain; charset=utf-8"
    status_code, resp_headers, raw = _forward(server.port, body.method, target, query, headers, data)
    ctype = next((v for k, v in resp_headers if k.lower() == "content-type"), "")
    return {
        "status": status_code,
        "content_type": ctype,
        "body": raw.decode("utf-8", "replace")[:65536],
        "truncated": len(raw) > 65536,
    }


# ---------- dosya: yükleme, indirme, toplu silme ----------
@router.put("/servers/{server_id}/files/upload", status_code=201)
async def upload_file(server_id: int, request: Request, path: str, user: User = Depends(current_user),
                      db: Session = Depends(get_db)):
    """Ham gövde olarak dosya yükler. path: hedef yol (ör. plugins/ornek.jar)."""
    server = _visible_server(user, db, server_id, "files")
    declared = int(request.headers.get("content-length", "0") or 0)
    if declared > fm.MAX_UPLOAD_BYTES:
        raise HTTPException(413, "Dosya çok büyük (en fazla 100 MB)")
    data = await request.body()
    quota = None if user.is_admin else setting_int(db, "max_disk_mb") * 1048576
    _file_call(fm.save_bytes, server.id, path, data, quota)
    return {"saved": True, "size": len(data)}


@router.get("/servers/{server_id}/files/download")
def download_file(server_id: int, path: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "files")
    target = _file_call(fm.file_for_download, server.id, path)
    return FileResponse(target, filename=target.name, media_type="application/octet-stream")


@router.post("/servers/{server_id}/files/delete-many")
def delete_many(server_id: int, body: FilesDeleteIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Her yolu ayrı ayrı dener; biri başarısız olsa diğerleri silinir. Sonuç satır satır döner."""
    server = _visible_server(user, db, server_id, "files")
    results = []
    for path in body.paths:
        try:
            fm.delete(server.id, path)
            results.append({"path": path, "ok": True})
        except fm.FileError as exc:
            results.append({"path": path, "ok": False, "error": str(exc)})
    return results


@router.post("/servers/{server_id}/files/extract")
def extract_archive(server_id: int, path: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Bir .zip dosyasını bulunduğu klasöre açar."""
    server = _visible_server(user, db, server_id, "files")
    quota = None if user.is_admin else setting_int(db, "max_disk_mb") * 1048576
    count = _file_call(fm.extract_zip, server.id, path, quota)
    return {"extracted": count}


# ---------- sunucu klonlama ----------
@router.post("/servers/{server_id}/clone", status_code=201)
def clone_server(server_id: int, body: CloneIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Ayarları ve tüm dosyaları yeni bir sunucuya kopyalar. Yeni sunucu kaynağın sahibine ait olur."""
    src = _visible_server(user, db, server_id, "owner")
    if not user.is_admin:
        raise HTTPException(403, "Sunucu oluşturma yönetici tarafından yapılır")
    egg = _egg_for(src)
    reason = _egg_block(src.egg, egg, user, db)
    if reason:
        raise HTTPException(403, reason)
    owner = db.get(User, src.owner_id)
    if owner is None:
        raise HTTPException(404, "Sahip kullanıcı bulunamadı")
    _check_limits(owner, db, src.memory_mb, src.cpu_percent)
    if not owner.is_admin:
        owned = db.query(Server).filter_by(owner_id=owner.id).count()
        if owned >= owner.max_servers:
            raise HTTPException(403, "Sahibin sunucu limiti dolu; klonlama yapılamaz")
    site_slug = None
    if str(egg.get("category", "")).lower() in ROUTE_CATEGORIES:
        site_slug = _slugify(body.name)
        _check_site_slug(db, site_slug, egg, None)
    variables = build_variables(egg, dict(src.variables or {}))
    clone = Server(
        name=body.name, egg=src.egg, owner_id=owner.id, port=_allocate_port(db),
        memory_mb=src.memory_mb, cpu_percent=src.cpu_percent,
        variables=variables, site_slug=site_slug, env=dict(src.env or {}),
        startup_override=src.startup_override,
    )
    db.add(clone)
    db.flush()
    new_id = clone.id
    try:
        fm.copy_tree(src.id, new_id)
        clone.container_id = dm.create(clone, egg, _startup_for(clone, egg), int(egg["ports"][0]))
        audit(db, user.username, "server.clone", clone.name, f"kaynak={src.name}")
        db.commit()
    except Exception as exc:
        db.rollback()
        with contextlib.suppress(Exception):
            dm.delete_by_id(new_id)
        raise HTTPException(500, f"Klonlama başarısız: {exc}")
    return _server_json(clone)


# ---------- egg mağazası (yönetici) ----------
def _store_dir() -> Path:
    return Path(settings.eggs_dir) / "store"


@router.get("/admin/egg-store")
def egg_store(_: User = Depends(admin_only)):
    try:
        installed = set(load_eggs().keys())
    except EggError as exc:
        raise HTTPException(500, str(exc))
    out = []
    for path in sorted(_store_dir().glob("*.yaml")):
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        out.append({
            "slug": path.stem,
            "name": data.get("name", path.stem),
            "category": data.get("category", ""),
            "description": data.get("description", ""),
            "installed": path.stem in installed,
        })
    return out


@router.post("/admin/egg-store/{slug}/install", status_code=201)
def install_store_egg(slug: str, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    if not SLUG_RE.match(slug):
        raise HTTPException(400, "Geçersiz egg adı")
    src = _store_dir() / f"{slug}.yaml"
    if not src.is_file():
        raise HTTPException(404, "Mağazada böyle bir egg yok")
    dst = Path(settings.eggs_dir) / f"{slug}.yaml"
    if dst.exists():
        raise HTTPException(409, "Bu egg zaten kurulu")
    shutil.copyfile(src, dst)
    try:
        fresh = load_eggs()
    except EggError as exc:
        dst.unlink(missing_ok=True)
        raise HTTPException(400, f"Egg doğrulanamadı: {exc}")
    audit(db, admin.username, "egg.install", slug)
    db.commit()
    dm.prepull_async([fresh[slug]["docker_image"]])
    return {"installed": slug}


@router.delete("/admin/eggs/{slug}", status_code=204)
def uninstall_egg(slug: str, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    if not SLUG_RE.match(slug):
        raise HTTPException(400, "Geçersiz egg adı")
    dst = Path(settings.eggs_dir) / f"{slug}.yaml"
    if not dst.is_file():
        raise HTTPException(404, "Egg kurulu değil")
    if db.query(Server).filter_by(egg=slug).count():
        raise HTTPException(409, "Bu egg'i kullanan sunucular var; önce onları silin ya da klonlayın")
    dst.unlink()
    audit(db, admin.username, "egg.uninstall", slug)
    db.commit()


# ---------- uyarılar ----------

@router.get("/alerts")
def alerts(user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Disk kotasının dolmasına yakın sunucular için uyarılar.
    Çökme ve yeniden başlatma bildirimleri kaldırıldı (1.18.1).
    Yönetici tüm sunucuları, diğer kullanıcılar yalnızca kendi sunucularını görür."""
    q = db.query(Server)
    if not user.is_admin:
        q = q.filter(Server.owner_id == user.id)
    max_disk = setting_int(db, "max_disk_mb")
    out = []
    for s in q.order_by(Server.id).all():
        used = fm.dir_size_mb(s.id)
        if max_disk and used >= max_disk * 0.9:
            out.append({"server_id": s.id, "server": s.name, "level": "danger" if used >= max_disk else "warning",
                        "message": f"Disk kullanımı {used} MB / {max_disk} MB sınırına yakın."})
    return out


# ---------- yedekler ----------
def _db_snapshot() -> Path | None:
    """SQLite veritabanının tutarlı bir kopyasını (çalışırken de güvenli) geçici dosyaya alır."""
    if not settings.database_url.startswith("sqlite"):
        return None
    src = settings.database_url.split("///", 1)[-1]
    fd, tmp = tempfile.mkstemp(prefix="mango-db-", suffix=".db")
    os.close(fd)
    with contextlib.closing(sqlite3.connect(src)) as a, contextlib.closing(sqlite3.connect(tmp)) as b:
        a.backup(b)
    return Path(tmp)


def _archive(entries: list[tuple[str, Path]]) -> str:
    """Verilen (arşiv içi ad, kaynak) çiftlerini tar.gz olarak geçici bir dosyaya yazar."""
    fd, tmp = tempfile.mkstemp(prefix="mango-backup-", suffix=".tar.gz")
    os.close(fd)
    with tarfile.open(tmp, "w:gz") as tar:
        for arcname, src in entries:
            if src.exists():
                tar.add(src, arcname=arcname)
    return tmp


def _download(path: str, filename: str) -> FileResponse:
    # Yanıt gönderildikten sonra geçici arşiv silinir.
    return FileResponse(path, filename=filename, media_type="application/gzip",
                        background=BackgroundTask(os.unlink, path))


@router.get("/admin/backup")
def admin_backup(admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    """Tam yedek: veritabanı + tüm sunucu klasörleri. mango.json (gizli anahtar) dahil değildir."""
    snapshot = _db_snapshot()
    try:
        entries = [("data", Path(settings.data_dir))]
        if snapshot is not None:
            entries.insert(0, ("mango.db", snapshot))
        archive = _archive(entries)
    finally:
        if snapshot is not None:
            snapshot.unlink(missing_ok=True)
    audit(db, admin.username, "backup.create", "tam yedek")
    db.commit()
    stamp = dt_stamp()
    return _download(archive, f"mango-yedek-{stamp}.tar.gz")


@router.get("/servers/{server_id}/backup")
def server_backup(server_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Tek sunucunun dosyalarını indirir (sahibi ve yönetici)."""
    server = _visible_server(user, db, server_id, "files")
    archive = _archive([(f"server-{server.id}", dm.server_dir(server.id))])
    return _download(archive, f"sunucu-{server.id}-{dt_stamp()}.tar.gz")


def dt_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")


# ---------- yönetici: kullanıcılar ----------
def _usage(user: User, servers: list, db: Session) -> dict:
    """Kullanıcının kotası: sunucu hakkı × sunucu başına sınır. Canlı değerler çalışan konteynerlerden okunur."""
    max_mem = setting_int(db, "max_memory_mb")
    max_cpu = setting_int(db, "max_cpu_percent")
    max_disk = setting_int(db, "max_disk_mb")
    slots = max(user.max_servers or 0, 0)
    live_mem = 0.0
    live_cpu = 0.0
    disk_mb = 0.0
    for s in servers:
        try:
            st = dm.stats(s)
            live_mem += float(st.get("memory_mb", 0) or 0)
            live_cpu += float(st.get("cpu_percent", 0) or 0)
        except Exception:
            pass
        try:
            disk_mb += fm.dir_size_mb(s.id)
        except Exception:
            pass
    return {
        "servers": len(servers),
        "server_slots": slots,
        "allocated_memory_mb": sum(s.memory_mb for s in servers),
        "allocated_cpu_percent": sum(s.cpu_percent for s in servers),
        "live_memory_mb": round(live_mem, 1),
        "live_cpu_percent": round(live_cpu, 1),
        "disk_mb": round(disk_mb, 1),
        "memory_cap_mb": slots * max_mem,
        "cpu_cap_percent": slots * max_cpu,
        "disk_cap_mb": slots * max_disk,
    }


def prepull_eggs() -> None:
    """Açılışta tüm egg imajlarını arka planda indirir; ilk sunucu oluşturma hızlanır."""
    try:
        images = [egg["docker_image"] for egg in load_eggs().values()]
    except EggError:
        return
    dm.prepull_async(images)


@router.get("/users")
def list_users(_: User = Depends(admin_only), db: Session = Depends(get_db)):
    out = []
    for u in db.query(User).order_by(User.id).all():
        row = _user_json(u)
        owned = db.query(Server).filter_by(owner_id=u.id).order_by(Server.id).all()
        row["server_count"] = len(owned)
        row["usage"] = _usage(u, owned, db)
        out.append(row)
    return out


@router.post("/users", status_code=201)
def create_user(body: UserIn, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    if body.email:
        _check_email(body.email)
        if db.query(User).filter_by(email=body.email).first():
            raise HTTPException(409, "Bu e-posta ile zaten bir hesap var")
    if db.query(User).filter_by(username=body.username).first():
        raise HTTPException(409, "Kullanıcı adı alınmış")
    user = User(
        username=body.username,
        email=body.email or None,
        password_hash=hash_password(body.password),
        is_admin=body.is_admin,
        max_servers=body.max_servers,
        onboarded=False,
    )
    db.add(user)
    db.flush()
    audit(db, admin.username, "user.create", user.username, f"admin={body.is_admin} limit={body.max_servers}")
    db.commit()
    return _user_json(user)


@router.patch("/users/{user_id}")
def update_user(user_id: int, body: UserUpdate, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    target = db.get(User, user_id)
    if target is None:
        raise HTTPException(404, "Kullanıcı bulunamadı")
    changes = body.model_dump(exclude_unset=True)
    if changes.get("is_admin") is False and target.is_admin:
        if target.id == admin.id:
            raise HTTPException(409, "Kendi yönetici yetkinizi kaldıramazsınız")
        if db.query(User).filter_by(is_admin=True).count() <= 1:
            raise HTTPException(409, "Son yöneticinin yetkisi kaldırılamaz")
    if changes.get("email"):
        _check_email(changes["email"])
        clash = db.query(User).filter(User.email == changes["email"], User.id != target.id).first()
        if clash:
            raise HTTPException(409, "Bu e-posta ile zaten bir hesap var")
        target.email = changes["email"]
    elif "email" in changes:
        target.email = None
    if changes.get("password"):
        target.password_hash = hash_password(changes["password"])
    if changes.get("is_admin") is not None:
        target.is_admin = changes["is_admin"]
    if changes.get("max_servers") is not None:
        target.max_servers = changes["max_servers"]
    if changes.get("approved") is not None:
        target.approved = changes["approved"]
    audit(db, admin.username, "user.update", target.username, ",".join(k for k in changes if k != "password"))
    db.commit()
    return _user_json(target)


@router.delete("/users/{user_id}", status_code=204)
def delete_user(user_id: int, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    target = db.get(User, user_id)
    if target is None:
        raise HTTPException(404, "Kullanıcı bulunamadı")
    if target.id == admin.id:
        raise HTTPException(409, "Kendi hesabınızı silemezsiniz")
    if db.query(Server).filter_by(owner_id=target.id).count():
        raise HTTPException(409, "Bu kullanıcının sunucuları var. Önce sunucuları silin.")
    name = target.username
    db.query(ServerAccess).filter_by(user_id=target.id).delete()
    db.query(ApiKey).filter_by(user_id=target.id).delete()
    db.query(ServerTemplate).filter_by(owner_id=target.id).delete()
    db.delete(target)
    audit(db, admin.username, "user.delete", name)
    db.commit()


# ---------- yönetici: genel bakış, sunucular, ayarlar, kayıtlar ----------
@router.get("/admin/stats")
def admin_stats(_: User = Depends(admin_only), db: Session = Depends(get_db)):
    servers = db.query(Server).all()
    running = sum(1 for s in servers if _safe_status(s) == "running")
    return {
        "users": db.query(User).count(),
        "admins": db.query(User).filter_by(is_admin=True).count(),
        "servers": len(servers),
        "running_servers": running,
        "allocated_memory_mb": sum(s.memory_mb for s in servers),
        "registration_enabled": registration_enabled(db),
        "default_max_servers": default_max_servers(db),
    }


@router.get("/admin/analytics")
def admin_analytics(days: int = Query(14, ge=7, le=90), _: User = Depends(admin_only), db: Session = Depends(get_db)):
    """Yönetim istatistikleri (1.31.0): egg'e göre sunucu dağılımı ve son N gün kayıtları."""
    eggs = _safe_eggs()
    by_egg: dict[str, int] = {}
    for (slug,) in db.query(Server.egg).all():
        by_egg[slug] = by_egg.get(slug, 0) + 1
    egg_rows = sorted(
        ({"slug": slug, "name": (eggs.get(slug) or {}).get("name", slug),
          "category": (eggs.get(slug) or {}).get("category", ""), "count": n}
         for slug, n in by_egg.items()),
        key=lambda r: r["count"], reverse=True,
    )
    today = datetime.now(timezone.utc).date()
    daily = {(today - timedelta(days=i)).isoformat(): 0 for i in range(days)}
    for (created,) in db.query(User.created_at).all():
        if created is None:
            continue
        key = created.astimezone(timezone.utc).date().isoformat()
        if key in daily:
            daily[key] += 1
    return {
        "servers_by_egg": egg_rows,
        "users_per_day": [{"date": k, "count": v} for k, v in sorted(daily.items())],
        "total_servers": sum(by_egg.values()),
    }


@router.get("/admin/servers")
def admin_servers(_: User = Depends(admin_only), db: Session = Depends(get_db)):
    rows = db.query(Server, User).join(User, User.id == Server.owner_id).order_by(Server.id).all()
    out = []
    for server, owner in rows:
        data = _server_json(server, with_status=False)
        data["status"] = _safe_status(server)
        data["owner"] = owner.username
        out.append(data)
    return out


@router.get("/admin/health")
def admin_health(_: User = Depends(admin_only)):
    """Veritabanı, Docker, servisler ve disk durumu. Blok çağrılar olduğu için iş parçacığında çalışır."""
    return health_checks.run_all()


@router.get("/admin/settings")
def get_admin_settings(_: User = Depends(admin_only), db: Session = Depends(get_db)):
    return all_settings(db)


@router.put("/admin/settings")
def put_admin_settings(body: AdminSettingsIn, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    changes = body.model_dump(exclude_none=True)
    stored: dict[str, str] = {}
    secret = (changes.pop("discord_client_secret", None) or "").strip()
    if secret:  # boş bırakılan secret mevcut değeri değiştirmez
        stored["discord_client_secret"] = secret
    for key, value in changes.items():
        if key == "disabled_eggs":
            for slug in value:
                if not SLUG_RE.match(slug):
                    raise HTTPException(400, f"Geçersiz egg adı: {slug}")
            joined = ",".join(sorted(set(value)))
            if len(joined) > 255:
                raise HTTPException(400, "Çok fazla egg kapatıldı")
            stored[key] = joined
        elif isinstance(value, bool):
            stored[key] = "1" if value else "0"
        else:
            stored[key] = str(value)
    for key, value in stored.items():
        set_setting(db, key, value)
    if changes:
        # Duyuru metni kayda girmez; yalnızca değişen anahtarlar yazılır.
        audit(db, admin.username, "settings.update", "", ",".join(sorted(changes)))
    db.commit()
    return all_settings(db)


@router.post("/admin/servers/{server_id}/suspend")
def suspend_server(server_id: int, body: SuspendIn, admin: User = Depends(admin_only), db: Session = Depends(get_db)):
    """Askıya alınan sunucunun sahibi erişemez; konteyner durdurulur, veriler silinmez."""
    server = db.get(Server, server_id)
    if server is None:
        raise HTTPException(404, "Sunucu bulunamadı")
    server.suspended = body.suspended
    if body.suspended:
        try:
            dm.power(server, "stop")
        except Exception:
            pass  # konteyner yoksa ya da zaten duruyorsa sorun değil
    audit(db, admin.username, "server.suspend" if body.suspended else "server.unsuspend", server.name)
    db.commit()
    return _server_json(server)


@router.get("/admin/audit")
def admin_audit(limit: int = 100, _: User = Depends(admin_only), db: Session = Depends(get_db)):
    rows = db.query(AuditLog).order_by(AuditLog.id.desc()).limit(min(max(limit, 1), 500)).all()
    return [
        {
            "id": r.id,
            "created_at": r.created_at.isoformat() if r.created_at else None,
            "actor": r.actor,
            "action": r.action,
            "target": r.target,
            "detail": r.detail,
        }
        for r in rows
    ]
