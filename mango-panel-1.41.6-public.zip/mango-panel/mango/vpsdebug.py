"""VPS onarım aracı (1.41.3).

Tüm VPS sunucularını tarar ve sorunlu olanları otomatik onarır:
- Konteyner yoksa: sıfırdan kurulur ve başlatılır.
- Hiç başlamamışsa (created): başlatılır; olmazsa sıfırdan kurulur.
- Çalışıyor ama terminal (exec) bozuksa: yeniden başlatılır; o da olmazsa sıfırdan kurulur.
- Kullanıcının bilerek durdurduğu (exited) VPS'lere dokunulmaz.

Sunucuda elle çalıştırmak için:
  /root/mango-panel/.venv/bin/python -m mango.vpsdebug

Panel de bunu her 10 dakikada bir kendiliğinden çalıştırır."""
import logging
import threading
import time

from docker.errors import NotFound

from . import docker_manager as dm
from .api import _rebuild_and_start, _startup_for
from .db import Server, SessionLocal, init_db
from .eggs import load_eggs

log = logging.getLogger("mango.vpsdebug")
INTERVAL = 600  # saniye
FIRST_DELAY = 90  # panel açıldıktan sonra ilk tarama
COOLDOWN = 3600  # saniye: aynı VPS için iki onarım denemesi arasında en az bu kadar beklenir
_last_attempt: dict[int, float] = {}  # sunucu id -> son onarım denemesi (monotonic)


def vps_servers(db) -> list[Server]:
    slugs = {slug for slug, egg in load_eggs().items() if str(egg.get("category", "")).lower() == "vps"}
    if not slugs:
        return []
    return db.query(Server).filter(Server.egg.in_(slugs)).all()


def _probe(cont) -> bool:
    """Konteynerde komut çalıştırılabiliyor mu? Terminal de aynı yolu kullanır."""
    try:
        return cont.exec_run(["sh", "-c", "true"]).exit_code == 0
    except Exception:  # noqa: BLE001
        return False


def _rebuild(server, db, egg: dict, reason: str) -> str:
    _last_attempt[server.id] = time.monotonic()
    try:
        server.container_id = _rebuild_and_start(server, egg, _startup_for(server, egg), int(egg["ports"][0]))
        db.commit()
        log.info("VPS %s sıfırdan kuruldu (%s)", server.id, reason)
        return "onarıldı"
    except Exception as exc:  # noqa: BLE001
        db.rollback()
        log.warning("VPS %s onarılamadı (%s): %s", server.id, reason, exc)
        return f"onarılamadı: {reason}; {str(exc)[:200]}"


def _in_cooldown(server_id: int) -> bool:
    last = _last_attempt.get(server_id)
    return last is not None and time.monotonic() - last < COOLDOWN


def check_and_fix(server, db) -> str:
    """Tek bir VPS'i denetleyip gerekirse onarır. Dönüş: 'sağlıklı', 'onarıldı', 'atlandı' ya da 'onarılamadı: ...'.
    Son onarım denemesinden beri COOLDOWN geçmediyse hiçbir şey yapmaz (1.41.5): her deneme sunucuda
    süreç/thread sızıntısı yaratıyordu, bu yüzden denemeler seyrekleştirildi."""
    if _in_cooldown(server.id):
        return "beklemede"
    egg = load_eggs().get(server.egg)
    if egg is None:
        return "atlandı"
    try:
        cont = dm._container(server)
        cont.reload()
    except NotFound:
        return _rebuild(server, db, egg, "konteyner yok")
    except Exception as exc:  # noqa: BLE001
        return _rebuild(server, db, egg, f"konteyner okunamadı: {str(exc)[:120]}")

    if cont.status == "running":
        if _probe(cont):
            return "sağlıklı"
        _last_attempt[server.id] = time.monotonic()
        try:  # terminal bozuk: yeniden başlatmayı dene
            cont.restart(timeout=20)
            cont.reload()
            if cont.status == "running" and _probe(cont):
                log.info("VPS %s yeniden başlatılarak terminali onarıldı", server.id)
                return "onarıldı"
        except Exception as exc:  # noqa: BLE001
            log.warning("VPS %s yeniden başlatılamadı: %s", server.id, exc)
        return _rebuild(server, db, egg, "terminal (exec) bozuk")

    if cont.status == "created":  # hiç başlamamış: başlat, olmazsa sıfırdan kur
        _last_attempt[server.id] = time.monotonic()
        try:
            if dm.power(server, "start") == "running":
                return "onarıldı"
        except Exception as exc:  # noqa: BLE001
            return _rebuild(server, db, egg, f"başlatılamadı: {str(exc)[:120]}")
        return _rebuild(server, db, egg, "başlatma sonrası çalışmıyor")

    return "atlandı"  # exited/paused: kullanıcı bilerek durdurmuş olabilir


def scan_and_fix() -> list[dict]:
    db = SessionLocal()
    report: list[dict] = []
    try:
        for server in vps_servers(db):
            try:
                result = check_and_fix(server, db)
            except Exception as exc:  # noqa: BLE001 - bir VPS'in hatası diğerlerini durdurmasın
                db.rollback()
                result = f"onarılamadı: {str(exc)[:200]}"
            report.append({"id": server.id, "name": server.name, "result": result})
    finally:
        db.close()
    return report


def start_watcher() -> None:
    def loop():
        time.sleep(FIRST_DELAY)
        while True:
            try:
                scan_and_fix()
            except Exception:  # noqa: BLE001
                log.exception("VPS tarama hatası")
            time.sleep(INTERVAL)

    threading.Thread(target=loop, daemon=True, name="vps-debug").start()


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    init_db()
    report = scan_and_fix()
    fixed = [r for r in report if r["result"] == "onarıldı"]
    broken = [r for r in report if r["result"].startswith("onarılamadı")]
    for r in report:
        print(f"VPS {r['id']:>4}  {r['name'][:30]:<30}  {r['result']}")
    print(f"\nToplam VPS: {len(report)} | onarılan: {len(fixed)} | hâlâ sorunlu: {len(broken)}")


if __name__ == "__main__":
    main()
