"""Yeniden kurulum ve formatlama (1.33.0).

Sunucunun konteyneri silinip seçilen egg ile yeniden kurulur. "Formatla" seçeneğiyle sunucu
klasöründeki tüm dosyalar da silinir. Egg değiştirmek yalnızca yöneticiye açıktır.
Sahip, sunucu ayarlarına erişimi olan kullanıcı ise aynı egg ile yeniden kurabilir."""
import shutil
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from . import docker_manager as dm
from . import files_manager as fm
from .api import _egg_block, _visible_server, audit
from .db import User
from .eggs import EggError, load_eggs, render
from .security import current_user, get_db

router = APIRouter(prefix="/api")


class ReinstallIn(BaseModel):
    egg: str | None = Field(None, max_length=64)
    wipe: bool = True


def _clear_server_dir(server_id: int) -> None:
    root: Path = dm.server_dir(server_id)
    for item in root.iterdir():
        if item.is_dir() and not item.is_symlink():
            shutil.rmtree(item)
        else:
            item.unlink()


@router.post("/servers/{server_id}/reinstall")
def reinstall(server_id: int, body: ReinstallIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "settings")
    slug = body.egg or server.egg
    if slug != server.egg and not user.is_admin:
        raise HTTPException(403, "Egg değiştirme yalnızca yönetici tarafından yapılabilir")
    try:
        eggs = load_eggs()
    except EggError as exc:
        raise HTTPException(500, str(exc))
    egg = eggs.get(slug)
    if egg is None:
        raise HTTPException(404, "Egg bulunamadı")
    reason = _egg_block(slug, egg, user, db)
    if reason:
        raise HTTPException(403, reason)

    # 1) Eski konteyneri kaldır
    try:
        dm.delete_by_id(server.id, server.container_id)
    except Exception:
        pass
    server.container_id = None

    # 2) İstenirse dosyaları temizle (formatla)
    if body.wipe:
        _clear_server_dir(server.id)
        fm.seed_files(server.id, egg.get("starter_files", {}))

    # 3) Yeni egg ile kur ve başlat
    server.egg = slug
    variables = server.variables or {}
    try:
        install_script = render(egg["install_script"], variables)
        dm.run_install(server, egg, install_script)
        startup = render(egg["startup"], variables)
        primary_port = int(egg["ports"][0])
        server.container_id = dm.create(server, egg, startup, primary_port)
        audit(db, user.username, "server.reinstall", server.name,
              f"egg={slug} formatla={'evet' if body.wipe else 'hayır'}")
        db.commit()
    except Exception as exc:
        db.rollback()
        if dm.is_transient(exc):
            raise HTTPException(503, "Sunucu şu an yeniden kurulamadı, sistem yoğun. Birkaç dakika sonra deneyin.")
        raise HTTPException(500, "Yeniden kurulum başarısız. Ayrıntı yönetici günlüklerinde.")
    return {"ok": True, "egg": slug, "wiped": body.wipe}
