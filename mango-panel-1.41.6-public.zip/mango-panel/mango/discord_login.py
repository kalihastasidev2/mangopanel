"""Discord ile giriş ve kayıt (1.36.0).

Akış: /api/auth/discord/start -> Discord yetkilendirme -> /api/auth/discord/callback.
Hesap Discord kimliğiyle (discord_id) eşleştirilir. Kayıt modunda yeni hesap açılır, giriş modunda
kayıtlı değilse kullanıcı kayıt olmaya yönlendirilir. Client Secret yalnızca sunucuda tutulur ve asla
geri gönderilmez. Redirect adresi: <panel adresi>/api/auth/discord/callback"""
import json
import logging
import re
import urllib.error
import secrets
import time
import urllib.parse
import urllib.request

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import RedirectResponse

from .config import settings
from .db import User
from .security import create_token, current_user, get_db, hash_password
from .store import approval_required, default_max_servers, get_setting, maintenance_on, registration_enabled

router = APIRouter(prefix="/api/auth/discord")
AUTHORIZE_URL = "https://discord.com/oauth2/authorize"
TOKEN_URL = "https://discord.com/api/oauth2/token"
ME_URL = "https://discord.com/api/users/@me"
STATE_TTL = 600
_states: dict[str, tuple[str, float]] = {}
UA = "MangoPanel/1.36 (+panel)"
log = logging.getLogger("mango.discord_login")


def _failure_code(exc: Exception) -> str:
    """Hatayı kullanıcıya anlamlı bir kodla eşler (1.37.2)."""
    if isinstance(exc, urllib.error.HTTPError):
        return "yetki" if exc.code in (400, 401, 403) else "hata"
    if isinstance(exc, urllib.error.URLError):
        return "ag"
    return "hata"


def enabled(db) -> bool:
    return bool(get_setting(db, "discord_client_id").strip() and get_setting(db, "discord_client_secret").strip())


def _redirect_uri() -> str:
    return settings.public_url.rstrip("/") + "/api/auth/discord/callback"


def _panel(fragment: str) -> str:
    return settings.public_url.rstrip("/") + "/" + fragment


def _exchange(code: str, db) -> dict:
    form = urllib.parse.urlencode({
        "client_id": get_setting(db, "discord_client_id").strip(),
        "client_secret": get_setting(db, "discord_client_secret").strip(),
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": _redirect_uri(),
    }).encode()
    req = urllib.request.Request(TOKEN_URL, data=form, method="POST",
                                 headers={"Content-Type": "application/x-www-form-urlencoded", "User-Agent": UA})
    with urllib.request.urlopen(req, timeout=10) as resp:  # noqa: S310 - sabit Discord adresi
        token = json.loads(resp.read())
    req2 = urllib.request.Request(ME_URL, headers={"Authorization": "Bearer " + token["access_token"], "User-Agent": UA})
    with urllib.request.urlopen(req2, timeout=10) as resp:  # noqa: S310
        return json.loads(resp.read())


def _unique_username(db, profile: dict) -> str:
    raw = profile.get("global_name") or profile.get("username") or "discord"
    base = re.sub(r"[^A-Za-z0-9_]", "_", raw)[:24]
    if len(base) < 3:
        base = (base + "_user")[:24]
    name, n = base, 1
    while db.query(User).filter_by(username=name).first():
        n += 1
        name = f"{base[:24 - len(str(n)) - 1]}_{n}"
    return name


@router.get("/start")
def start(mode: str = "login", db=Depends(get_db)):
    if not enabled(db):
        raise HTTPException(404, "Discord ile giriş kapalı")
    mode = "register" if mode == "register" else "login"
    now = time.time()
    for key, (_, created) in list(_states.items()):
        if now - created > STATE_TTL:
            _states.pop(key, None)
    state = secrets.token_urlsafe(24)
    _states[state] = (mode, now)
    query = urllib.parse.urlencode({
        "client_id": get_setting(db, "discord_client_id").strip(),
        "redirect_uri": _redirect_uri(),
        "response_type": "code",
        "scope": "identify email",
        "state": state,
    })
    return RedirectResponse(f"{AUTHORIZE_URL}?{query}")


@router.get("/link-url")
def link_url(user: User = Depends(current_user), db=Depends(get_db)):
    """Giriş yapmış kullanıcı için Discord yetkilendirme adresi (hesabı bu kullanıcıya bağlar)."""
    if not enabled(db):
        raise HTTPException(404, "Discord bağlantısı kapalı")
    state = secrets.token_urlsafe(24)
    _states[state] = (f"link:{user.id}", time.time())
    query = urllib.parse.urlencode({
        "client_id": get_setting(db, "discord_client_id").strip(),
        "redirect_uri": _redirect_uri(),
        "response_type": "code",
        "scope": "identify email",
        "state": state,
    })
    return {"url": f"{AUTHORIZE_URL}?{query}"}


@router.get("/callback")
def callback(request: Request, code: str = "", state: str = "", error: str = "", db=Depends(get_db)):
    item = _states.pop(state, None)
    if error or not code or item is None or time.time() - item[1] > STATE_TTL:
        return RedirectResponse(_panel("#/giris?discord=iptal"))
    mode = item[0]
    try:
        profile = _exchange(code, db)
    except Exception as exc:  # noqa: BLE001 - ayrıntı günlüğe yazılır, kullanıcıya kısa kod gösterilir
        detail = ""
        if isinstance(exc, urllib.error.HTTPError):
            try:
                detail = exc.read()[:300].decode("utf-8", "replace")
            except Exception:  # noqa: BLE001
                detail = ""
        log.warning("Discord girişi başarısız: %s %s", exc, detail)
        return RedirectResponse(_panel("#/giris?discord=" + _failure_code(exc)))
    discord_id = str(profile.get("id", ""))
    if not discord_id:
        return RedirectResponse(_panel("#/giris?discord=hata"))

    if mode.startswith("link:"):
        target = db.get(User, int(mode.split(":", 1)[1]))
        if target is None:
            return RedirectResponse(_panel("#/giris?discord=hata"))
        taken = db.query(User).filter(User.discord_id == discord_id, User.id != target.id).first()
        if taken is not None:
            return RedirectResponse(_panel("#/account?discord=kullanimda"))
        target.discord_id = discord_id
        db.commit()
        return RedirectResponse(_panel("#/account?discord=bagli"))

    user = db.query(User).filter_by(discord_id=discord_id).first()
    if user is None:
        if mode != "register":
            return RedirectResponse(_panel("#/giris?discord=kayitli-degil"))
        if maintenance_on(db) or not registration_enabled(db):
            return RedirectResponse(_panel("#/giris?discord=kayit-kapali"))
        email = profile.get("email") if profile.get("verified") else None
        if email and db.query(User).filter_by(email=email).first():
            email = None
        user = User(
            username=_unique_username(db, profile),
            email=email,
            password_hash=hash_password(secrets.token_urlsafe(32)),  # Discord ile girildiğinden şifre kullanılmaz
            is_admin=False,
            max_servers=default_max_servers(db),
            discord_id=discord_id,
            approved=not approval_required(db),
        )
        db.add(user)
        db.commit()
    elif not user.is_admin and maintenance_on(db):
        return RedirectResponse(_panel("#/giris?discord=bakim"))
    if not user.is_admin and not user.approved:
        return RedirectResponse(_panel("#/giris?discord=onay"))

    token = create_token(user, db, request)
    return RedirectResponse(_panel("#/discord?token=" + token))
