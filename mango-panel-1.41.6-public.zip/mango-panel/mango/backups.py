"""Sunucu yedekleri (1.32.0): sunucu klasörünün anlık arşivi; oluştur, listele, geri yükle, sil.

Yedekler data/backups/<sunucu-id>/ altında tutulur. Her sunucu için en fazla MAX_BACKUPS yedek saklanır.
Geri yükleme yalnızca sunucu kapalıyken yapılır ve mevcut dosyaların yerini alır."""
import datetime as dt
import re
import shutil
import tarfile
import tempfile
from pathlib import Path

import logging
import threading
import time

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from . import docker_manager as dm
from .api import _visible_server
from .config import settings
from .db import Server, SessionLocal, User
from .security import current_user, get_db

router = APIRouter(prefix="/api")
MAX_BACKUPS = 5
NAME_RE = re.compile(r"^\d{8}-\d{6}-\d{6}\.tar\.gz$")


def backup_dir(server_id: int) -> Path:
    path = Path(settings.data_dir) / "backups" / str(server_id)
    path.mkdir(parents=True, exist_ok=True)
    return path


def _check_name(name: str) -> None:
    if not NAME_RE.match(name):
        raise HTTPException(400, "Geçersiz yedek adı")


def create_backup(server_id: int, keep: int = MAX_BACKUPS) -> str:
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d-%H%M%S-%f")
    name = f"{stamp}.tar.gz"
    target = backup_dir(server_id) / name
    src = dm.server_dir(server_id)
    with tarfile.open(target, "w:gz") as tar:
        for item in sorted(src.iterdir()):
            tar.add(item, arcname=item.name)
    # En eski yedekleri sil
    files = sorted(backup_dir(server_id).glob("*.tar.gz"))
    for old in files[: max(0, len(files) - keep)]:
        old.unlink(missing_ok=True)
    return name


def list_backups(server_id: int) -> list[dict]:
    out = []
    for path in sorted(backup_dir(server_id).glob("*.tar.gz"), reverse=True):
        out.append({"name": path.name, "size_bytes": path.stat().st_size,
                    "created_at": dt.datetime.fromtimestamp(path.stat().st_mtime, dt.timezone.utc).isoformat()})
    return out


def restore_backup(server_id: int, name: str) -> None:
    _check_name(name)
    archive = backup_dir(server_id) / name
    if not archive.exists():
        raise HTTPException(404, "Yedek bulunamadı")
    dest = dm.server_dir(server_id)
    with tempfile.TemporaryDirectory(prefix="mango-restore-") as tmp:
        with tarfile.open(archive, "r:gz") as tar:
            tar.extractall(tmp, filter="data")  # güvenli çıkarma: yol kaçışı ve özel dosyalar reddedilir
        for item in dest.iterdir():
            if item.is_dir() and not item.is_symlink():
                shutil.rmtree(item)
            else:
                item.unlink()
        for item in Path(tmp).iterdir():
            shutil.move(str(item), str(dest / item.name))


def delete_backup(server_id: int, name: str) -> None:
    _check_name(name)
    path = backup_dir(server_id) / name
    if not path.exists():
        raise HTTPException(404, "Yedek bulunamadı")
    path.unlink()


@router.get("/servers/{server_id}/backups")
def api_list(server_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "files")
    return {
        "items": list_backups(server_id),
        "max": server.backup_keep or MAX_BACKUPS,
        "schedule": {
            "mode": server.backup_schedule or "off",
            "hour": server.backup_hour if server.backup_hour is not None else 4,
            "keep": server.backup_keep or MAX_BACKUPS,
            "last_run": server.backup_last_run,
        },
    }


class ScheduleIn(BaseModel):
    schedule: str = Field(pattern=r"^(off|daily|weekly)$")
    hour: int = Field(4, ge=0, le=23)
    keep: int = Field(5, ge=1, le=30)


@router.put("/servers/{server_id}/backups/schedule")
def api_schedule(server_id: int, body: ScheduleIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "files")
    server.backup_schedule = body.schedule
    server.backup_hour = body.hour
    server.backup_keep = body.keep
    db.commit()
    return {"ok": True}


@router.post("/servers/{server_id}/backups", status_code=201)
def api_create(server_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "files")
    name = create_backup(server.id, keep=server.backup_keep or MAX_BACKUPS)
    return {"name": name}


@router.post("/servers/{server_id}/backups/{name}/restore")
def api_restore(server_id: int, name: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "files")
    if dm.status(server) == "running":
        raise HTTPException(409, "Geri yüklemeden önce sunucuyu durdurun")
    try:
        restore_backup(server.id, name)
    except tarfile.TarError:
        raise HTTPException(400, "Yedek dosyası bozuk")
    return {"ok": True}


@router.delete("/servers/{server_id}/backups/{name}", status_code=204)
def api_delete(server_id: int, name: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "files")
    delete_backup(server.id, name)
    from fastapi import Response
    return Response(status_code=204)


# ---------- zamanlanmış yedekler (1.40.26) ----------
log = logging.getLogger("mango.backups")
BACKUP_TZ = dt.timezone(dt.timedelta(hours=3))  # Türkiye saati (UTC+3)
SCHEDULER_INTERVAL = 300  # saniye


def run_due_backups(now: dt.datetime | None = None) -> list[int]:
    """Saati gelmiş ve bugün henüz yedeği alınmamış sunucuların yedeğini alır (saat geçtiyse kaçırılmış gün de telafi edilir)."""
    now = now or dt.datetime.now(BACKUP_TZ)
    marker = now.strftime("%Y%m%d")
    done: list[int] = []
    db = SessionLocal()
    try:
        for server in db.query(Server).filter(Server.backup_schedule.in_(["daily", "weekly"])).all():
            if now.hour < (server.backup_hour if server.backup_hour is not None else 4):
                continue
            if server.backup_schedule == "weekly" and now.weekday() != 0:
                continue
            if server.backup_last_run == marker:
                continue
            try:
                create_backup(server.id, keep=server.backup_keep or MAX_BACKUPS)
                server.backup_last_run = marker
                done.append(server.id)
            except Exception:  # noqa: BLE001 - bir sunucunun hatası diğerlerini durdurmamalı
                log.exception("Otomatik yedek alınamadı (sunucu %s)", server.id)
        db.commit()
    finally:
        db.close()
    return done


def start_scheduler() -> None:
    def loop():
        while True:
            try:
                run_due_backups()
            except Exception:  # noqa: BLE001
                log.exception("Yedek zamanlayıcısı hatası")
            time.sleep(SCHEDULER_INTERVAL)

    threading.Thread(target=loop, name="mango-backup-schedule", daemon=True).start()
