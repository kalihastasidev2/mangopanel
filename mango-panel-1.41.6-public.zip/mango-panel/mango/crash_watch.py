"""1.40.22: Çalışırken kendiliğinden kapanan sunucuları tespit eder ve sahibine Discord'dan haber verir.
Kullanıcının kendi durdurması hata sayılmaz: yalnızca çıkış kodu 0 dışındaysa (çökme/bellek aşımı) bildirilir."""
import logging
import threading
import time

from . import docker_manager as dm
from .db import Server, SessionLocal, User
from .discord_notify import notify_discord

log = logging.getLogger("mango.crash")
INTERVAL_SECONDS = 30
_was_running: set[int] = set()


def _exit_code(server) -> int | None:
    try:
        cont = dm.client().containers.get(f"mango-{server.id}")
        return int(cont.attrs.get("State", {}).get("ExitCode"))
    except Exception:  # noqa: BLE001
        return None


def scan() -> list[int]:
    """Çöken sunucuların kimliklerini döndürür ve sahiplerine bildirim gönderir."""
    crashed: list[int] = []
    db = SessionLocal()
    try:
        for server in db.query(Server).all():
            try:
                state = dm.status(server)
            except Exception:  # noqa: BLE001
                continue
            if state == "running":
                _was_running.add(server.id)
                continue
            if server.id in _was_running and state in ("exited", "dead"):
                _was_running.discard(server.id)
                code = _exit_code(server)
                if code not in (0, None):
                    crashed.append(server.id)
                    owner = db.get(User, server.owner_id)
                    notify_discord(
                        db, owner,
                        f"⚠️ Sunucunuz **{server.name}** beklenmedik şekilde kapandı (çıkış kodu {code}). "
                        "Panelden kontrol edip yeniden başlatabilirsiniz.",
                    )
            else:
                _was_running.discard(server.id)
    finally:
        db.close()
    return crashed


def start_watcher() -> None:
    def loop():
        while True:
            try:
                scan()
            except Exception as exc:  # noqa: BLE001
                log.warning("Çökme taraması hatası: %s", exc)
            time.sleep(INTERVAL_SECONDS)

    threading.Thread(target=loop, name="mango-crash-watch", daemon=True).start()
