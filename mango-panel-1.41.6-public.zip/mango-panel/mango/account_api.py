"""1.23.0: eksik paket tarayıcısı (kod içindeki import'lar) ve kullanıcı kullanım raporu."""
import re
import sys
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from . import docker_manager as dm
from .api import _visible_server
from .db import PremiumPlan, Server, Ticket, User, UserSession
from .security import current_user, get_db

router = APIRouter(prefix="/api")

SCAN_EXTENSIONS = {".js", ".mjs", ".cjs", ".py"}
SKIP_DIRS = {"node_modules", ".venv", "venv", "__pycache__", ".git"}
MAX_FILES = 400
MAX_FILE_BYTES = 300_000
# Konsol komutuna güvenle girecek paket adları: shell metakarakteri içermez.
SAFE_NAME = re.compile(r"^(@[a-z0-9][\w.-]*/)?[a-z0-9][\w.-]*$", re.IGNORECASE)
NODE_BUILTINS = {
    "assert", "async_hooks", "buffer", "child_process", "cluster", "console", "constants", "crypto", "dgram",
    "diagnostics_channel", "dns", "domain", "events", "fs", "http", "http2", "https", "inspector", "module", "net",
    "os", "path", "perf_hooks", "process", "punycode", "querystring", "readline", "repl", "stream", "string_decoder",
    "sys", "timers", "tls", "trace_events", "tty", "url", "util", "v8", "vm", "wasi", "worker_threads", "zlib",
}
# pip'te modül adı ile paket adı farklı olanlar.
PIP_ALIASES = {
    "cv2": "opencv-python", "PIL": "pillow", "discord": "discord.py", "bs4": "beautifulsoup4",
    "dotenv": "python-dotenv", "yaml": "pyyaml", "sklearn": "scikit-learn", "dateutil": "python-dateutil",
    "jwt": "pyjwt", "telegram": "python-telegram-bot", "googleapiclient": "google-api-python-client",
}
JS_PATTERNS = [
    re.compile(r"""require\(\s*['"]([^'"]+)['"]\s*\)"""),
    re.compile(r"""import\(\s*['"]([^'"]+)['"]\s*\)"""),
    re.compile(r"""(?:import|export)\s[^'";]*?from\s*['"]([^'"]+)['"]"""),
    re.compile(r"""^\s*import\s*['"]([^'"]+)['"]""", re.MULTILINE),
]
PY_FROM = re.compile(r"^\s*from\s+([A-Za-z_][\w]*)[\w.]*\s+import\s", re.MULTILINE)
PY_IMPORT = re.compile(r"^\s*import\s+([^\n#]+)", re.MULTILINE)


def _norm(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def _js_package(spec: str) -> str | None:
    if spec.startswith((".", "/", "node:")):
        return None
    if spec.startswith("@"):
        parts = spec.split("/")
        return "/".join(parts[:2]) if len(parts) >= 2 else None
    head = spec.split("/")[0]
    return None if head in NODE_BUILTINS else head


def _py_modules(text: str) -> set[str]:
    found = set(PY_FROM.findall(text))
    for group in PY_IMPORT.findall(text):
        for item in group.split(","):
            name = item.strip().split(" as ")[0].strip().split(" ")[0].split(".")[0]  # PIL.Image -> PIL
            if re.match(r"^[A-Za-z_]\w*$", name):
                found.add(name)
    stdlib = set(sys.stdlib_module_names)
    return {m for m in found if m not in stdlib}


def scan(root: Path) -> dict:
    """Sunucu klasöründeki kodu tarar; eksik npm ve pip paketlerini döndürür."""
    npm_used: set[str] = set()
    pip_used: set[str] = set()
    scanned = 0
    for path in root.rglob("*"):
        if scanned >= MAX_FILES:
            break
        if any(part in SKIP_DIRS for part in path.relative_to(root).parts[:-1]):
            continue
        if not path.is_file() or path.suffix not in SCAN_EXTENSIONS:
            continue
        if path.stat().st_size > MAX_FILE_BYTES:
            continue
        scanned += 1
        text = path.read_text(encoding="utf-8", errors="ignore")
        if path.suffix == ".py":
            pip_used |= _py_modules(text)
        else:
            for pattern in JS_PATTERNS:
                for spec in pattern.findall(text):
                    pkg = _js_package(spec)
                    if pkg:
                        npm_used.add(pkg)

    # Zaten kurulu veya listelenmiş olanlar eksik sayılmaz.
    installed_npm: set[str] = set()
    package_json = root / "package.json"
    if package_json.is_file():
        import json
        try:
            data = json.loads(package_json.read_text(encoding="utf-8", errors="ignore") or "{}")
            installed_npm |= set(data.get("dependencies", {})) | set(data.get("devDependencies", {}))
        except ValueError:
            pass
    installed_pip: set[str] = set()
    requirements = root / "requirements.txt"
    if requirements.is_file():
        for line in requirements.read_text(encoding="utf-8", errors="ignore").splitlines():
            m = re.match(r"^\s*([A-Za-z0-9][A-Za-z0-9._-]*)", line)
            if m:
                installed_pip.add(_norm(m.group(1)))

    missing_npm = sorted(
        p for p in npm_used
        if SAFE_NAME.match(p) and p not in installed_npm and not (root / "node_modules" / p).exists()
    )
    missing_pip = []
    for module in sorted(pip_used):
        pkg = PIP_ALIASES.get(module, module)
        if SAFE_NAME.match(pkg) and _norm(pkg) not in installed_pip:
            missing_pip.append(pkg)
    return {"npm": missing_npm, "pip": sorted(set(missing_pip)), "files": scanned}


@router.get("/servers/{server_id}/missing-packages")
def missing_packages(server_id: int, user: User = Depends(current_user), db: Session = Depends(get_db)):
    server = _visible_server(user, db, server_id, "files")
    return scan(dm.server_dir(server.id))


@router.get("/me/usage")
def my_usage(user: User = Depends(current_user), db: Session = Depends(get_db)):
    servers = db.query(Server).filter_by(owner_id=user.id).all()
    try:
        statuses = dm.status_map() or {}
    except Exception:
        statuses = {}
    running = sum(1 for s in servers if s.container_id and statuses.get(s.container_id) == "running")
    tickets = db.query(Ticket).filter_by(user_id=user.id, category="support").count()
    purchases = []
    for t in db.query(Ticket).filter_by(user_id=user.id, category="purchase").order_by(Ticket.id.desc()).limit(50):
        plan = db.get(PremiumPlan, t.plan_id) if t.plan_id else None
        purchases.append({
            "id": t.id, "subject": t.subject, "plan": plan.name if plan else "",
            "status": t.status, "created_at": t.created_at.isoformat() if t.created_at else None,
        })
    return {
        "servers": len(servers),
        "running": running,
        "max_servers": user.max_servers,
        "memory_mb": sum(s.memory_mb or 0 for s in servers),
        "cpu_percent": sum(s.cpu_percent or 0 for s in servers),
        "tickets": tickets,
        "purchases": purchases,
        "discord_linked": bool(user.discord_id),
    }


def _iso(value):
    return value.isoformat() if value else None


@router.get("/me/sessions")
def my_sessions(user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Hesabın açık oturumları (1.27.0). Bu cihaz current=true ile işaretlenir."""
    rows = (db.query(UserSession).filter_by(user_id=user.id, revoked=False)
            .order_by(UserSession.last_seen.desc()).all())
    current = getattr(user, "session_id", None)
    return [{
        "id": r.id, "created_at": _iso(r.created_at), "last_seen": _iso(r.last_seen),
        "user_agent": r.user_agent or "", "ip": r.ip or "", "current": r.id == current,
    } for r in rows]


@router.delete("/me/sessions/{sid}", status_code=204)
def revoke_session(sid: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    row = db.get(UserSession, sid)
    if row is None or row.user_id != user.id:
        raise HTTPException(404, "Oturum bulunamadı")
    row.revoked = True
    db.commit()


@router.post("/me/sessions/revoke-others")
def revoke_other_sessions(user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Bu cihaz hariç tüm açık oturumları kapatır."""
    current = getattr(user, "session_id", None)
    query = db.query(UserSession).filter(UserSession.user_id == user.id, UserSession.revoked == False)  # noqa: E712
    if current:
        query = query.filter(UserSession.id != current)
    count = query.update({"revoked": True}, synchronize_session=False)
    db.commit()
    return {"revoked": count}
