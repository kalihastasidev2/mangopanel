"""Cloudflare ayar bağlantı testi (1.39.0). Özel alan adı işlemleri mango/cloudflare.py içindedir.

Yönetici Ayarlar'a Zone ID ve API token girer, "Bağlantıyı test et" ile token'ın geçerliliğini
ve zone'a erişimi doğrulatır. Token sunucuda saklanır, arayüze geri gönderilmez.
Alt alan adı oluşturma bu sürümde yoktur; yalnızca bağlantı kontrolü yapılır."""
import json
import urllib.error
import urllib.request

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .db import User
from .security import admin_only, get_db
from .store import get_setting

router = APIRouter(prefix="/api")
API = "https://api.cloudflare.com/client/v4"


def _get(path: str, token: str) -> tuple[int, dict]:
    """Cloudflare'e GET isteği atar. Ağ hatasında (0, {}) döner."""
    req = urllib.request.Request(API + path, headers={"Authorization": "Bearer " + token, "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=10) as res:
            return res.status, json.loads(res.read().decode() or "{}")
    except urllib.error.HTTPError as exc:
        try:
            body = json.loads(exc.read().decode() or "{}")
        except (ValueError, OSError):
            body = {}
        return exc.code, body
    except (urllib.error.URLError, TimeoutError, OSError, ValueError):
        return 0, {}


def check(token: str, zone_id: str, base: str = "") -> dict:
    """Token ve zone bağlantısını sınar. Dönen değer: {ok, message}."""
    if not token:
        return {"ok": False, "message": "API token girilmemiş. Ayarlara token girip kaydedin."}
    if not zone_id:
        return {"ok": False, "message": "Zone ID girilmemiş. Ayarlara Zone ID girip kaydedin."}
    status, body = _get("/user/tokens/verify", token)
    if status == 0:
        return {"ok": False, "message": "Cloudflare'e ulaşılamadı. Sunucunun internet bağlantısını kontrol edin."}
    if status != 200 or not body.get("success"):
        return {"ok": False, "message": "Token geçersiz veya süresi dolmuş. Cloudflare'de yeni token oluşturun."}
    status, body = _get(f"/zones/{zone_id}/dns_records?per_page=1", token)
    if status == 200 and body.get("success"):
        where = f" Alt alan adı: {base}" if base else ""
        return {"ok": True, "zone_name": base or None,
                "message": f"Bağlantı başarılı. DNS erişimi tamam.{where}"}
    if status == 404:
        return {"ok": False, "message": "Zone ID bulunamadı. Cloudflare'deki Zone ID'yi kontrol edin."}
    if status in (401, 403):
        return {"ok": False, "message": "Token bu zone'a erişemiyor. Token'da 'example.com' zone izni olmalı."}
    return {"ok": False, "message": "Cloudflare zone bilgisini döndürmedi. Birkaç dakika sonra tekrar deneyin."}


@router.post("/admin/cloudflare/test")
def test_cloudflare(_: User = Depends(admin_only), db: Session = Depends(get_db)):
    from .site_dns import base_domain
    return check(get_setting(db, "cf_api_token").strip(), get_setting(db, "cf_zone_id").strip(), base_domain(db))
