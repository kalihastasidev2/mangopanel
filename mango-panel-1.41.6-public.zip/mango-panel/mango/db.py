import datetime as dt
from pathlib import Path

from sqlalchemy import JSON, Boolean, DateTime, ForeignKey, Integer, String, create_engine, inspect, text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

from .config import settings


class Base(DeclarativeBase):
    pass


def _now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    username: Mapped[str] = mapped_column(String(32), unique=True)
    email: Mapped[str | None] = mapped_column(String(120), nullable=True)
    discord_id: Mapped[str | None] = mapped_column(String(32), nullable=True, index=True)  # 1.36.0
    password_hash: Mapped[str] = mapped_column(String(255))
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    max_servers: Mapped[int] = mapped_column(Integer, default=2)
    created_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), default=_now, nullable=True)
    onboarded: Mapped[bool] = mapped_column(Boolean, default=True)  # ilk kayıt rehberi tamamlandı mı
    approved: Mapped[bool] = mapped_column(Boolean, default=True)  # 1.40.4: yönetici onayı (yeni kayıtlar onay bekleyebilir)
    discord_id: Mapped[str | None] = mapped_column(String(32), nullable=True)  # bağlı Discord hesabı (1.22.0)


class Server(Base):
    __tablename__ = "servers"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(48))
    egg: Mapped[str] = mapped_column(String(64))
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    port: Mapped[int] = mapped_column(Integer, unique=True)
    memory_mb: Mapped[int] = mapped_column(Integer, default=512)
    cpu_percent: Mapped[int] = mapped_column(Integer, default=100)
    variables: Mapped[dict] = mapped_column(JSON, default=dict)
    container_id: Mapped[str | None] = mapped_column(String(80), nullable=True)
    suspended: Mapped[bool] = mapped_column(Boolean, default=False)  # yönetici askıya aldı mı
    maintenance: Mapped[bool] = mapped_column(Boolean, default=False)  # 1.35.0: sunucuya özel bakım
    expires_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)  # 1.38.0: demo bitişi
    expiry_notified_for: Mapped[str | None] = mapped_column(String(16), nullable=True)  # 1.40.24: hatırlatma tarihi
    site_dns_id: Mapped[str | None] = mapped_column(String(64), nullable=True)  # 1.40.0: Cloudflare DNS kayıt kimliği
    backup_schedule: Mapped[str] = mapped_column(String(8), default="off")  # 1.40.26: off | daily | weekly
    backup_hour: Mapped[int] = mapped_column(Integer, default=4)  # Türkiye saatiyle (UTC+3) yedek saati
    backup_keep: Mapped[int] = mapped_column(Integer, default=5)  # en fazla kaç yedek saklanır
    backup_last_run: Mapped[str | None] = mapped_column(String(16), nullable=True)  # son otomatik yedek günü
    site_host: Mapped[str | None] = mapped_column(String(253), nullable=True)  # 1.40.0: ad.example.com
    maintenance_message: Mapped[str | None] = mapped_column(String(300), nullable=True)
    rename_count: Mapped[int] = mapped_column(Integer, default=0)   # kullanıcının ad değiştirme sayısı
    site_slug: Mapped[str | None] = mapped_column(String(40), nullable=True)  # /sites/<slug> adresi
    env: Mapped[dict | None] = mapped_column(JSON, nullable=True)  # kullanıcının eklediği KEY=VALUE değişkenleri
    startup_override: Mapped[str | None] = mapped_column(String(500), nullable=True)  # boşsa egg'in başlatma komutu
    node_id: Mapped[int | None] = mapped_column(Integer, nullable=True)  # yönetici seçtiği node (kayıt amaçlı)


class ServerNote(Base):
    """Sunucuya eklenen iç notlar. Yalnızca sahip ve yönetici görür."""
    __tablename__ = "server_notes"
    id: Mapped[int] = mapped_column(primary_key=True)
    server_id: Mapped[int] = mapped_column(ForeignKey("servers.id"))
    author: Mapped[str] = mapped_column(String(32))
    text: Mapped[str] = mapped_column(String(500))
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)


class ApiKey(Base):
    """Kullanıcıya ait API anahtarı. Anahtarın kendisi saklanmaz, yalnızca özeti tutulur."""
    __tablename__ = "api_keys"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    name: Mapped[str] = mapped_column(String(48))
    prefix: Mapped[str] = mapped_column(String(16))  # ekranda gösterilen ilk karakterler
    key_hash: Mapped[str] = mapped_column(String(64), unique=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)
    last_used: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    # "client": kullanıcının kendi sunucuları. "application": yönetici işlemleri (yalnızca yönetici).
    scope: Mapped[str] = mapped_column(String(16), default="client")


class ServerAccess(Base):
    """Alt kullanıcı: sunucu sahibinin verdiği sınırlı yetkiler."""
    __tablename__ = "server_access"
    id: Mapped[int] = mapped_column(primary_key=True)
    server_id: Mapped[int] = mapped_column(ForeignKey("servers.id"))
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    permissions: Mapped[str] = mapped_column(String(120), default="")  # console,power,files,settings


class ServerTemplate(Base):
    """Sık kullanılan sunucu ayarlarının kaydı (ad hariç)."""
    __tablename__ = "server_templates"
    id: Mapped[int] = mapped_column(primary_key=True)
    owner_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    name: Mapped[str] = mapped_column(String(48))
    egg: Mapped[str] = mapped_column(String(64))
    memory_mb: Mapped[int] = mapped_column(Integer, default=512)
    cpu_percent: Mapped[int] = mapped_column(Integer, default=100)
    variables: Mapped[dict] = mapped_column(JSON, default=dict)


class AppSetting(Base):
    """Panel genelinde tutulan ayarlar (kayıt açık mı, varsayılan sunucu limiti vb.)."""
    __tablename__ = "app_settings"
    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value: Mapped[str] = mapped_column(String(255))


class AuditLog(Base):
    """Yönetici ve kritik işlemlerin kaydı."""
    __tablename__ = "audit_log"
    id: Mapped[int] = mapped_column(primary_key=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)
    actor: Mapped[str] = mapped_column(String(40))
    action: Mapped[str] = mapped_column(String(48))
    target: Mapped[str] = mapped_column(String(120), default="")
    detail: Mapped[str] = mapped_column(String(500), default="")


class UserSession(Base):
    """Açık oturumlar (1.27.0). Jetondaki sid bu kayda bağlıdır; iptal edilince jeton geçersiz olur."""
    __tablename__ = "user_sessions"
    id: Mapped[str] = mapped_column(String(40), primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)
    last_seen: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)
    user_agent: Mapped[str] = mapped_column(String(200), default="")
    ip: Mapped[str] = mapped_column(String(64), default="")
    revoked: Mapped[bool] = mapped_column(Boolean, default=False)


class PremiumPlan(Base):
    """Yönetici tarafından düzenlenen satışa sunulan paketler."""
    __tablename__ = "premium_plans"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(48))
    description: Mapped[str] = mapped_column(String(500), default="")
    price_text: Mapped[str] = mapped_column(String(60), default="")  # serbest metin, ör. "120 TL / ay"
    egg: Mapped[str | None] = mapped_column(String(64), nullable=True)  # doluysa paket bu egg'den sunucu içerir
    memory_mb: Mapped[int] = mapped_column(Integer, default=1024)
    cpu_percent: Mapped[int] = mapped_column(Integer, default=100)
    disk_mb: Mapped[int] = mapped_column(Integer, default=2048)
    max_servers: Mapped[int] = mapped_column(Integer, default=2)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    category: Mapped[str | None] = mapped_column(String(32), nullable=True)  # 1.27.0
    is_free: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    accent: Mapped[str | None] = mapped_column(String(7), nullable=True)  # #rrggbb, boşsa ürüne göre
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)


class Ticket(Base):
    """Destek veya satın alma talebi."""
    __tablename__ = "tickets"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    subject: Mapped[str] = mapped_column(String(120))
    category: Mapped[str] = mapped_column(String(16), default="support")  # support | purchase
    plan_id: Mapped[int | None] = mapped_column(ForeignKey("premium_plans.id"), nullable=True)
    coupon_code: Mapped[str | None] = mapped_column(String(32), nullable=True)  # 1.34.0
    status: Mapped[str] = mapped_column(String(16), default="open")  # open | answered | closed
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)
    updated_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)


class Coupon(Base):
    """İndirim kuponu (1.34.0). Ödeme otomatik hesaplanmaz; kupon talebe kaydedilir ve yöneticiye gösterilir."""
    __tablename__ = "coupons"
    id: Mapped[int] = mapped_column(primary_key=True)
    code: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    percent_off: Mapped[int] = mapped_column(Integer, default=10)     # 1-100
    plan_id: Mapped[int | None] = mapped_column(ForeignKey("premium_plans.id"), nullable=True)  # boşsa tüm paketler
    max_uses: Mapped[int | None] = mapped_column(Integer, nullable=True)  # boşsa sınırsız
    used_count: Mapped[int] = mapped_column(Integer, default=0)
    expires_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)


class Notification(Base):
    """Yönetici bildirimi (1.37.0)."""
    __tablename__ = "notifications"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str] = mapped_column(String(120))
    body: Mapped[str] = mapped_column(String(2000))
    target: Mapped[str] = mapped_column(String(16))  # all | plan | users
    plan_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_by: Mapped[str] = mapped_column(String(32))
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)


class NotificationRecipient(Base):
    """Bir bildirimin bir kullanıcıdaki kopyası; okundu bilgisi burada tutulur."""
    __tablename__ = "notification_recipients"
    id: Mapped[int] = mapped_column(primary_key=True)
    notification_id: Mapped[int] = mapped_column(ForeignKey("notifications.id"), index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)
    read_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class TicketMessage(Base):
    __tablename__ = "ticket_messages"
    id: Mapped[int] = mapped_column(primary_key=True)
    ticket_id: Mapped[int] = mapped_column(ForeignKey("tickets.id"))
    author: Mapped[str] = mapped_column(String(32))
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    text: Mapped[str] = mapped_column(String(2000))
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)


class Node(Base):
    """Sunucuların barındırılabileceği uzak makine. Anahtarın yalnızca özeti saklanır."""
    __tablename__ = "nodes"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(48))
    description: Mapped[str] = mapped_column(String(255), default="")
    token_hash: Mapped[str] = mapped_column(String(64), unique=True)
    max_memory_mb: Mapped[int] = mapped_column(Integer, default=8192)
    max_disk_mb: Mapped[int] = mapped_column(Integer, default=102400)
    stats: Mapped[dict | None] = mapped_column(JSON, nullable=True)  # ajanın son bildirdiği durum
    version: Mapped[str] = mapped_column(String(20), default="")
    last_seen: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)


class CustomDomain(Base):
    """Sunucunun statik/PHP sitesine bağlanan kullanıcı domaini. Doğrulanmadan yayınlanmaz."""
    __tablename__ = "custom_domains"
    id: Mapped[int] = mapped_column(primary_key=True)
    server_id: Mapped[int] = mapped_column(ForeignKey("servers.id"))
    domain: Mapped[str] = mapped_column(String(253), unique=True)
    token: Mapped[str] = mapped_column(String(40))  # DNS TXT ile sahiplik kanıtı
    verified: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)
    verified_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    cf_id: Mapped[str | None] = mapped_column(String(64), nullable=True)  # Cloudflare custom hostname kimliği


class DiscordLinkCode(Base):
    """Discord /bagla komutunun ürettiği, panelde kullanılan tek seferlik kod (1.22.0)."""
    __tablename__ = "discord_link_codes"
    code: Mapped[str] = mapped_column(String(16), primary_key=True)
    discord_id: Mapped[str] = mapped_column(String(32))
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)
    expires_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True))


class DiscordEvent(Base):
    """Bota iletilecek olay: sunucu durumu, destek ve satın alma talepleri (1.22.0)."""
    __tablename__ = "discord_events"
    id: Mapped[int] = mapped_column(primary_key=True)
    kind: Mapped[str] = mapped_column(String(32))
    text: Mapped[str] = mapped_column(String(500))
    server_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)


class ChatMessage(Base):
    """Genel sohbet mesajı; isteğe bağlı sunucu log görüntüsü içerir (1.24.0)."""
    __tablename__ = "chat_messages"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    username: Mapped[str] = mapped_column(String(32))
    text: Mapped[str] = mapped_column(String(2000), default="")
    help: Mapped[bool] = mapped_column(Boolean, default=False)
    server_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    server_name: Mapped[str | None] = mapped_column(String(48), nullable=True)
    log_text: Mapped[str | None] = mapped_column(String(4500), nullable=True)
    hidden: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)
    changed_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=_now)


_is_sqlite = settings.database_url.startswith("sqlite")
if _is_sqlite:
    _db_file = settings.database_url.split("///", 1)[-1]
    Path(_db_file).parent.mkdir(parents=True, exist_ok=True)

engine = create_engine(
    settings.database_url,
    connect_args={"check_same_thread": False} if _is_sqlite else {},
    pool_pre_ping=True,
)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)

if _is_sqlite:
    # Eşzamanlı istekler "database is locked" hatası vermesin: WAL modu ve 10 sn bekleme süresi.
    from sqlalchemy import event as _sa_event

    @_sa_event.listens_for(engine, "connect")
    def _sqlite_pragmas(dbapi_connection, _record):
        cur = dbapi_connection.cursor()
        cur.execute("PRAGMA journal_mode=WAL")
        cur.execute("PRAGMA busy_timeout=10000")
        cur.execute("PRAGMA synchronous=NORMAL")
        cur.close()

# Sürüm 1.0/1.1 veritabanlarına sonradan eklenen sütunlar.
_ADDED_USER_COLUMNS = {
    "email": "VARCHAR(120)",
    "discord_id": "VARCHAR(32)",
    "max_servers": "INTEGER NOT NULL DEFAULT 2",
    "created_at": "TIMESTAMP",
    # Mevcut kullanıcılar rehberi görmüş sayılır; yalnızca yeni kayıtlar False ile başlar.
    "onboarded": "BOOLEAN NOT NULL DEFAULT TRUE",
    "approved": "BOOLEAN NOT NULL DEFAULT TRUE",
    "discord_id": "VARCHAR(32)",
}


_ADDED_API_KEY_COLUMNS = {
    "scope": "VARCHAR(16) NOT NULL DEFAULT 'client'",
}

_ADDED_SERVER_COLUMNS = {
    "suspended": "BOOLEAN NOT NULL DEFAULT FALSE",
    "maintenance": "BOOLEAN NOT NULL DEFAULT FALSE",
    "expires_at": "TIMESTAMP",
    "backup_schedule": "VARCHAR(8) NOT NULL DEFAULT 'off'",
    "backup_hour": "INTEGER NOT NULL DEFAULT 4",
    "backup_keep": "INTEGER NOT NULL DEFAULT 5",
    "backup_last_run": "VARCHAR(16)",
    "expiry_notified_for": "VARCHAR(16)",
    "site_dns_id": "VARCHAR(64)",
    "site_host": "VARCHAR(253)",
    "maintenance_message": "VARCHAR(300)",
    "rename_count": "INTEGER NOT NULL DEFAULT 0",
    "site_slug": "VARCHAR(40)",
    "env": "JSON",
    "startup_override": "VARCHAR(500)",
    "node_id": "INTEGER",
}


_ADDED_PLAN_COLUMNS = {
    "egg": "VARCHAR(64)",
    "category": "VARCHAR(32)",
    "is_free": "BOOLEAN",
    "accent": "VARCHAR(7)",
}

_ADDED_DOMAIN_COLUMNS = {
    "cf_id": "VARCHAR(64)",
}

_ADDED_TICKET_COLUMNS = {
    "coupon_code": "VARCHAR(32)",
}


def _migrate() -> None:
    for table, wanted in (
        ("users", _ADDED_USER_COLUMNS),
        ("servers", _ADDED_SERVER_COLUMNS),
        ("api_keys", _ADDED_API_KEY_COLUMNS),
        ("premium_plans", _ADDED_PLAN_COLUMNS),
        ("custom_domains", _ADDED_DOMAIN_COLUMNS),
        ("tickets", _ADDED_TICKET_COLUMNS),
    ):
        columns = {c["name"] for c in inspect(engine).get_columns(table)}
        with engine.begin() as conn:
            for name, ddl in wanted.items():
                if name not in columns:
                    conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}"))


def init_db() -> None:
    Base.metadata.create_all(engine)
    _migrate()
