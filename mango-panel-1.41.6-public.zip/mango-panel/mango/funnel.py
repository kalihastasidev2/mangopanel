"""Satış hunisi (1.38.0): kayıt olan ama paket almayan kullanıcıları görmek için yönetici görünümü."""
from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session

from .db import Server, Ticket, User
from .security import admin_only, get_db

router = APIRouter(prefix="/api")


@router.get("/admin/funnel")
def funnel(_: User = Depends(admin_only), db: Session = Depends(get_db)):
    purchases = dict(db.query(Ticket.user_id, func.count(Ticket.id))
                     .filter(Ticket.category == "purchase").group_by(Ticket.user_id).all())
    servers = dict(db.query(Server.owner_id, func.count(Server.id)).group_by(Server.owner_id).all())
    users = db.query(User).filter_by(is_admin=False).order_by(User.id.desc()).limit(300).all()
    rows = []
    for u in users:
        rows.append({
            "id": u.id, "username": u.username,
            "created_at": u.created_at.isoformat() if u.created_at else None,
            "purchases": purchases.get(u.id, 0),
            "servers": servers.get(u.id, 0),
            "stage": "satin_aldi" if purchases.get(u.id, 0) else ("sunucusu_var" if servers.get(u.id, 0) else "kayitli"),
        })
    summary = {
        "registered": len(rows),
        "buyers": sum(1 for r in rows if r["purchases"]),
        "no_purchase": sum(1 for r in rows if not r["purchases"]),
    }
    return {"summary": summary, "users": rows}
