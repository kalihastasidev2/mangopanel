#!/bin/sh
# Konteyner başlangıcı.
# 1) Paket listelerini arka planda yeniler (apt install'ın "Unable to locate" hatası olmasın).
# 2) PID 1 olarak sleep SIGTERM'i yok sayar; docker stop her seferinde 20 sn sonra SIGKILL (137)
#    atar. Bu yüzden TERM sinyalini yakalayıp temiz çıkıyoruz.
( apt-get update -qq >/dev/null 2>&1 & )
trap 'exit 0' TERM INT
sleep infinity &
wait $!
