<?php
declare(strict_types=1);

/*
 * Mango Panel - arayüz katmanı (PHP).
 * Sayfa kabuğunu sunar; veri ve işlemler Python API'sine (/api) nginx üzerinden gider.
 */

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header(
    "Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'; "
    . "script-src 'self'; connect-src 'self' ws: wss:; img-src 'self' data:; frame-ancestors 'none'"
);

$configFile = __DIR__ . '/app-config.json';
$config = is_readable($configFile) ? json_decode((string) file_get_contents($configFile), true) : null;
if (!is_array($config)) {
    http_response_code(503);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Mango Panel henüz yapılandırılmadı.';
    exit;
}

$template = __DIR__ . '/static/index.html';
$html = is_readable($template) ? (string) file_get_contents($template) : '';
if ($html === '') {
    http_response_code(500);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Arayüz dosyası bulunamadı.';
    exit;
}

// Varlık sürümü: JS/CSS dosyalarının içeriğinden üretilir. Her güncellemede adres değişir,
// böylece tarayıcı eski dosyayı önbellekten kullanamaz (app-config.json'a bağımlı değildir).
$assetParts = [];
foreach (['static/app.js', 'static/platform.js', 'static/style.css'] as $asset) {
    $path = __DIR__ . '/' . $asset;
    $assetParts[] = is_readable($path) ? md5_file($path) : '-';
}
$version = htmlspecialchars(substr(md5(implode('|', $assetParts)), 0, 12), ENT_QUOTES, 'UTF-8');
$html = str_replace('{{VERSION}}', $version, $html);

header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-cache');
echo $html;
